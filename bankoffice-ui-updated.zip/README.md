# Bank Office UI — Angular 19 (restyled to match Updated_UI reference)

This folder contains **only** the Bank Officer part of the Angular app
(`src/app/features/bankoffice/**`), restyled to match the layout and
richness of `integration-2.html/css/js` in your `Updated_UI` reference
(page headers, colored stat cards, clickable rows, badges, empty states,
quick-action links, etc.).

## How to use
Drop this `bankoffice/` folder in place of the existing one at:

```
hlms-ui/src/app/features/bankoffice/
```

No other files were changed. It compiles cleanly against your existing
project as-is — verified with `ng build` against the rest of your
`hlms-ui-angular19-fixed` project.

## What it depends on (already in your project, untouched)
- **Services:** `LoanService`, `RepaymentService`, `DocumentService`, `LegalService`, `AuthService`, `ToastService`
- **Models:** `loan-application.model.ts`, `repayment.model.ts`, `document.model.ts`, `legal.model.ts`, `auction.model.ts`
- **Global styles:** `src/styles.scss` (already has all the classes used here —
  `.page-head`, `.card`, `.stat .val.orange/teal/red/green`, `.badge-*`,
  `.clickable-row`, `.quick-links`, `.empty-state`, `.back-link`, etc.)
- **Routing:** `app.routes.ts` already wires all 10 `bo*` paths to these components — unchanged.

## Components included (10)
| Component | Notes |
|---|---|
| `bo-dashboard` | Stat cards, recent applications, quick actions, portfolio snapshot |
| `bo-applications` | Full applications list, clickable rows |
| `bo-app-detail` | Applicant/property detail, workflow progress, decision form, direct-reject flow, decision history |
| `bo-disbursement` | Ready-to-disburse queue + new disbursement form + recent history |
| `bo-npa` | Overdue/NPA stat cards + table (defensive field access — see note below) |
| `bo-docs` | Document list, pending filter |
| `bo-auction` | Auction stat cards + per-case cards |
| `bo-portfolio` | Approved/disbursed customer portfolio |
| `bo-reports` | Status breakdown + turnaround report |
| `bo-settings` | Profile form + link to forgot-password flow |

## Known backend limitations kept intentional (not papered over)
- **`bo-docs`**: `document-service` only exposes upload/fetch/delete — no
  verify/reject endpoint — so this screen is still read-only, with a note
  shown in the UI. Wiring up Verify/Reject buttons needs a backend change first.
- **`bo-npa`**: `RepaymentService.getOverdue()` returns `unknown[]`
  (no shared DTO for `/default-management/overdue`), so the component reads
  fields defensively (`trackingNo`, `applicantEmail`, `overdueCount`,
  `outstandingBalance`) and falls back to `—` if a field is absent.
- **`bo-settings`**: `AuthService` has no change-password method (only an
  OTP-based `forgotPassword`/`resetPassword` flow), so Settings links to the
  existing Forgot Password screen instead of adding a fake password field.
