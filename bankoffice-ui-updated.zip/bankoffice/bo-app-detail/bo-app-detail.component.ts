import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoanService } from '../../../core/services/loan.service';
import { LegalService } from '../../../core/services/legal.service';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoanApplication } from '../../../core/models/loan-application.model';
import { BankOfficeDecision } from '../../../core/models/legal.model';

@Component({
  selector: 'app-bo-app-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bo-app-detail.component.html'
})
export class BoAppDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private loanService = inject(LoanService);
  private legalService = inject(LegalService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);

  appId = Number(this.route.snapshot.paramMap.get('appId'));
  application = signal<LoanApplication | null>(null);
  decisions = signal<BankOfficeDecision[]>([]);
  loading = signal(true);

  // Populated from loan-service's own /workflow-stages endpoint so this always
  // matches the real stage names/order, instead of a hard-coded guess.
  workflowStages = signal<string[]>([]);

  decisionValue: BankOfficeDecision['decision'] = 'Approved';
  remarks = '';
  showRejectForm = false;

  ngOnInit(): void {
    this.loanService.getApplication(this.appId).subscribe({
      next: (app) => { this.application.set(app); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
    this.loanService.getWorkflowStages().subscribe({
      next: (stages) => this.workflowStages.set(stages)
    });
    this.refreshDecisions();
  }

  refreshDecisions() {
    this.legalService.getDecisionsForApp(this.appId).subscribe({
      next: (list) => this.decisions.set(list)
    });
  }

  statusBadge(status?: string): string {
    if (status === 'Disbursed') return 'badge-green';
    if (status === 'Rejected') return 'badge-red';
    if (status === 'In Progress' || status === 'Submitted') return 'badge-orange';
    return 'badge-gray';
  }

  stageStatus(index: number): 'completed' | 'current' | 'upcoming' {
    const app = this.application();
    if (!app || app.stageIndex == null) return 'upcoming';
    if (index < app.stageIndex) return 'completed';
    if (index === app.stageIndex) return 'current';
    return 'upcoming';
  }

  canAdvance(): boolean {
    const app = this.application();
    if (!app) return false;
    return app.status !== 'Disbursed' && app.status !== 'Rejected';
  }

  canReject(): boolean {
    const app = this.application();
    if (!app) return false;
    return app.status !== 'Disbursed' && app.status !== 'Rejected';
  }

  recordDecision() {
    this.legalService.createDecision({
      appId: this.appId,
      decision: this.decisionValue,
      decidedBy: this.auth.currentUser()?.email,
      remarks: this.remarks,
      decidedAt: new Date().toISOString()
    }).subscribe({
      next: () => {
        this.toast.show('Decision recorded', 'Bank office decision has been logged.', 'success');
        this.remarks = '';
        this.refreshDecisions();
      }
    });
  }

  advanceStage(stageIndex: number) {
    const stageName = this.workflowStages()[stageIndex] ?? `Stage ${stageIndex}`;
    this.loanService.advanceStage(this.appId, stageIndex, stageName).subscribe({
      next: (updated) => {
        this.application.set(updated);
        this.toast.show('Stage updated', `Application moved to "${stageName}".`, 'success');
      }
    });
  }

  toggleRejectForm() {
    this.showRejectForm = !this.showRejectForm;
  }

  reject() {
    if (!this.remarks.trim()) {
      this.toast.show('Remarks required', 'Please provide a reason for the applicant.', 'error');
      return;
    }
    this.legalService.createDecision({
      appId: this.appId,
      decision: 'Rejected',
      decidedBy: this.auth.currentUser()?.email,
      remarks: this.remarks,
      decidedAt: new Date().toISOString()
    }).subscribe({
      next: () => {
        this.toast.show('Application Rejected', 'The applicant has been notified.', 'success');
        this.remarks = '';
        this.showRejectForm = false;
        this.refreshDecisions();
        this.loanService.getApplication(this.appId).subscribe((app) => this.application.set(app));
      }
    });
  }

  back() {
    this.router.navigate(['/app/boapplications']);
  }
}
