import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RepaymentService } from '../../../core/services/repayment.service';
import { AuctionCase } from '../../../core/models/auction.model';

@Component({
  selector: 'app-bo-auction',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-auction.component.html'
})
export class BoAuctionComponent implements OnInit {
  private repaymentService = inject(RepaymentService);

  auctions = signal<AuctionCase[]>([]);
  loading = signal(true);

  live = computed(() => this.auctions().filter((a) => a.stage === 'Scheduled' || a.stage === 'In Progress'));
  totalReserve = computed(() => this.auctions().reduce((sum, a) => sum + (a.reservePrice || 0), 0));

  ngOnInit(): void {
    this.repaymentService.getAuctions().subscribe({
      next: (list) => { this.auctions.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  stageBadge(stage: AuctionCase['stage']): string {
    if (stage === 'Sold') return 'badge-green';
    if (stage === 'Cancelled') return 'badge-red';
    if (stage === 'In Progress' || stage === 'Scheduled') return 'badge-navy';
    return 'badge-orange';
  }
}
