import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { LoanService } from '../../../core/services/loan.service';
import { RepaymentService } from '../../../core/services/repayment.service';
import { LoanApplication, WORKFLOW_STAGES } from '../../../core/models/loan-application.model';

@Component({
  selector: 'app-bo-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-dashboard.component.html'
})
export class BoDashboardComponent implements OnInit {
  private loanService = inject(LoanService);
  private repaymentService = inject(RepaymentService);
  private router = inject(Router);

  applications = signal<LoanApplication[]>([]);
  overdueCount = signal<number>(0);
  loading = signal(true);

  recent = computed(() =>
    this.applications()
      .slice()
      .sort((a, b) => new Date(b.createdAt ?? 0).getTime() - new Date(a.createdAt ?? 0).getTime())
      .slice(0, 5)
  );

  readyToDisburse = computed(() =>
    this.applications().filter(
      (a) => a.stageIndex === WORKFLOW_STAGES.length - 1 && a.status !== 'Disbursed'
    ).length
  );

  disbursedTotal = computed(() =>
    this.applications()
      .filter((a) => a.status === 'Disbursed')
      .reduce((sum, a) => sum + (a.loanAmount || 0), 0)
  );

  ngOnInit(): void {
    this.loanService.getAllApplications().subscribe({
      next: (apps) => { this.applications.set(apps); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
    this.repaymentService.getOverdue().subscribe({
      next: (list) => this.overdueCount.set(list?.length ?? 0),
      error: () => this.overdueCount.set(0)
    });
  }

  countByStatus(status: string): number {
    return this.applications().filter((a) => a.status === status).length;
  }

  statusBadge(status?: string): string {
    if (status === 'Disbursed') return 'badge-green';
    if (status === 'Rejected') return 'badge-red';
    if (status === 'In Progress' || status === 'Submitted') return 'badge-orange';
    return 'badge-gray';
  }

  open(appId?: number) {
    if (appId) this.router.navigate(['/app/boappdetail', appId]);
  }

  goTo(view: string) {
    this.router.navigate(['/app/' + view]);
  }
}
