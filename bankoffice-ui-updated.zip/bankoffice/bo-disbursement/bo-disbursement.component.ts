import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RepaymentService } from '../../../core/services/repayment.service';
import { LoanService } from '../../../core/services/loan.service';
import { ToastService } from '../../../core/services/toast.service';
import { Disbursement } from '../../../core/models/repayment.model';
import { LoanApplication, WORKFLOW_STAGES } from '../../../core/models/loan-application.model';

@Component({
  selector: 'app-bo-disbursement',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bo-disbursement.component.html'
})
export class BoDisbursementComponent implements OnInit {
  private repaymentService = inject(RepaymentService);
  private loanService = inject(LoanService);
  private toast = inject(ToastService);

  disbursements = signal<Disbursement[]>([]);
  applications = signal<LoanApplication[]>([]);
  loading = signal(true);

  newAppId: number | null = null;
  newAmount: number | null = null;
  newStage = 'Full Disbursement';

  recent = computed(() =>
    this.disbursements()
      .slice()
      .sort((a, b) => new Date(b.disbursementDate).getTime() - new Date(a.disbursementDate).getTime())
      .slice(0, 10)
  );

  readyToDisburse = computed(() =>
    this.applications().filter(
      (a) => a.stageIndex === WORKFLOW_STAGES.length - 1 && a.status !== 'Disbursed'
    )
  );

  ngOnInit(): void {
    this.refresh();
    this.loanService.getAllApplications().subscribe({
      next: (apps) => this.applications.set(apps),
      error: () => this.applications.set([])
    });
  }

  refresh() {
    this.repaymentService.getAllDisbursements().subscribe({
      next: (list) => { this.disbursements.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  disburse(app: LoanApplication) {
    this.newAppId = app.appId ?? null;
    this.newAmount = app.loanAmount;
  }

  create() {
    if (!this.newAppId || !this.newAmount) {
      this.toast.show('Missing details', 'Please enter application ID and amount.', 'error');
      return;
    }
    this.repaymentService.createDisbursement({
      appId: this.newAppId,
      amount: this.newAmount,
      disbursementDate: new Date().toISOString(),
      installmentStage: this.newStage
    }).subscribe({
      next: () => {
        this.toast.show('Disbursement recorded', 'Funds disbursement has been logged.', 'success');
        this.newAppId = null;
        this.newAmount = null;
        this.refresh();
        this.loanService.getAllApplications().subscribe((apps) => this.applications.set(apps));
      }
    });
  }
}
