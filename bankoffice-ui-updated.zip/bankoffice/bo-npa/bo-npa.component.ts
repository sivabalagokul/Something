import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { RepaymentService } from '../../../core/services/repayment.service';

// The default-management/overdue endpoint's exact response shape isn't
// pinned down by a shared DTO, so we read defensively via optional chaining
// rather than assuming an exact field set.
interface OverdueRow {
  appId?: number;
  trackingNo?: string;
  applicantEmail?: string;
  applicantName?: string;
  overdueCount?: number;
  outstandingBalance?: number;
  [key: string]: unknown;
}

@Component({
  selector: 'app-bo-npa',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-npa.component.html'
})
export class BoNpaComponent implements OnInit {
  private repaymentService = inject(RepaymentService);
  private router = inject(Router);

  overdue = signal<OverdueRow[]>([]);
  loading = signal(true);

  npaCount = computed(() => this.overdue().filter((o) => this.isNpa(o)).length);

  ngOnInit(): void {
    this.repaymentService.getOverdue().subscribe({
      next: (list) => { this.overdue.set((list ?? []) as OverdueRow[]); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  isNpa(row: OverdueRow): boolean {
    return (row.overdueCount ?? 0) >= 3;
  }

  open(row: OverdueRow) {
    if (row.appId) this.router.navigate(['/app/boappdetail', row.appId]);
  }
}
