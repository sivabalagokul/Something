import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { LoanService } from '../../../core/services/loan.service';
import { LoanApplication } from '../../../core/models/loan-application.model';

@Component({
  selector: 'app-bo-portfolio',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-portfolio.component.html'
})
export class BoPortfolioComponent implements OnInit {
  private loanService = inject(LoanService);
  private router = inject(Router);

  applications = signal<LoanApplication[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    this.loanService.getAllApplications().subscribe({
      next: (apps) => {
        this.applications.set(apps.filter((a) => a.status === 'Approved' || a.status === 'Disbursed'));
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  totalPortfolio(): number {
    return this.applications().reduce((sum, a) => sum + (a.loanAmount || 0), 0);
  }

  open(appId?: number) {
    if (appId) this.router.navigate(['/app/boappdetail', appId]);
  }
}
