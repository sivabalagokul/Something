import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoanService } from '../../../core/services/loan.service';
import { LoanApplication } from '../../../core/models/loan-application.model';

@Component({
  selector: 'app-bo-reports',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-reports.component.html'
})
export class BoReportsComponent implements OnInit {
  private loanService = inject(LoanService);

  turnaroundReport = signal<unknown>(null);
  applications = signal<LoanApplication[]>([]);
  loading = signal(true);

  totalDisbursed = computed(() =>
    this.applications()
      .filter((a) => a.status === 'Disbursed')
      .reduce((sum, a) => sum + (a.loanAmount || 0), 0)
  );

  avgLoanAmount = computed(() => {
    const apps = this.applications();
    if (!apps.length) return 0;
    return Math.round(apps.reduce((sum, a) => sum + (a.loanAmount || 0), 0) / apps.length);
  });

  byStatus = computed(() => this.groupCount(this.applications(), (a) => a.status ?? 'Unknown'));

  disbursedCount = computed(() => this.applications().filter((a) => a.status === 'Disbursed').length);

  ngOnInit(): void {
    this.loanService.getTurnaroundReport().subscribe({
      next: (report) => { this.turnaroundReport.set(report); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
    this.loanService.getAllApplications().subscribe({
      next: (apps) => this.applications.set(apps),
      error: () => this.applications.set([])
    });
  }

  private groupCount(apps: LoanApplication[], keyFn: (a: LoanApplication) => string): { key: string; count: number }[] {
    const counts: Record<string, number> = {};
    apps.forEach((a) => { const k = keyFn(a); counts[k] = (counts[k] || 0) + 1; });
    return Object.entries(counts).map(([key, count]) => ({ key, count }));
  }
}
