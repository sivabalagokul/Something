# HLMS — Bank Office Portal (Angular 19)

A single, self-contained Angular 19 app containing **only the Bank Officer
role** of the HLMS frontend, restyled to match the `Updated_UI` reference
design. It's a trimmed copy of your full `hlms-ui` project — same core
services, models, guards, layout shell, and build config — with every
other role's routes and screens removed.

## Structure
```
hlms-bankoffice-ui/
├── angular.json, package.json, tsconfig*.json, proxy.conf.json
├── src/
│   ├── index.html, main.ts, styles.scss
│   ├── environments/            # apiBaseUrl config (dev uses proxy, prod points at gateway)
│   ├── assets/images/
│   └── app/
│       ├── app.component.ts     # root shell + toast host
│       ├── app.config.ts        # providers: router, http client + interceptors
│       ├── app.routes.ts        # only /auth/* and /app/bo* routes
│       ├── core/
│       │   ├── guards/          # authGuard, roleGuard
│       │   ├── interceptors/    # JWT header, global error toast
│       │   ├── models/          # DTOs used by bank office screens
│       │   └── services/        # AuthService, LoanService, RepaymentService,
│       │                        # DocumentService, LegalService, NotificationService
│       ├── layout/
│       │   ├── shell/           # page frame (topbar + sidebar + router-outlet)
│       │   ├── topbar/
│       │   └── sidebar/         # nav items — trimmed to the Bank Office menu only
│       ├── shared/components/toast/
│       └── features/
│           ├── auth/login/              # staff login (redirects non-bankoffice users away)
│           ├── auth/forgot-password/    # OTP-based password reset
│           └── bankoffice/              # the 10 Bank Officer screens
│               ├── bo-dashboard/
│               ├── bo-applications/
│               ├── bo-app-detail/
│               ├── bo-disbursement/
│               ├── bo-npa/
│               ├── bo-docs/
│               ├── bo-auction/
│               ├── bo-portfolio/
│               ├── bo-reports/
│               └── bo-settings/
```

## Run it
```bash
npm install
npm start          # ng serve, proxies API calls to localhost:8080 via proxy.conf.json
```
Then open http://localhost:4200 — you'll land on `/auth/login`.

```bash
npm run build       # production build → dist/hlms-bankoffice-ui
```

Both commands were verified against this exact project (`npm install` + `ng build` ran clean).

## What was intentionally left out (and why)
- **No self-registration route.** Bank Office accounts are provisioned by
  Admin, not self-registered — the register screen/route wasn't ported.
- **No public home/marketing page.** `/` redirects straight to
  `/auth/login` since this build only serves staff.
- **No other roles.** Customer, Admin, Legal, and Bidder screens, routes,
  and sidebar entries were all removed — only what Bank Office needs
  remains (`AuthService`, `LoanService`, `RepaymentService`,
  `DocumentService`, `LegalService`, `NotificationService`, and their models).

## Known backend limitations kept honest (not papered over)
- **`bo-docs`**: `document-service` only exposes upload/fetch/delete — no
  verify/reject endpoint — so this screen is read-only, with a note shown
  in the UI. Wiring up Verify/Reject buttons needs a backend change first.
- **`bo-npa`**: `RepaymentService.getOverdue()` returns `unknown[]` (no
  shared DTO for `/default-management/overdue`), so the component reads
  fields defensively and falls back to `—` if a field is absent.
- **`bo-settings`**: `AuthService` has no change-password method (only an
  OTP-based `forgotPassword`/`resetPassword` flow), so Settings links to
  the Forgot Password screen instead of adding a fake password field.

## Backend
Point `src/environments/environment.prod.ts`'s `apiBaseUrl` at your API
Gateway, or (for local dev) run the gateway on `localhost:8080` — the dev
server's `proxy.conf.json` forwards relative `/*-service/api/...` calls
there automatically.
