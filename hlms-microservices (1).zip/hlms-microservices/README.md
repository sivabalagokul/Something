# HLMS Microservices

This is the `hlms-backend` monolith split into 6 business microservices plus
full Spring Cloud infrastructure (service discovery, centralized config, API
gateway), as a multi-module Maven reactor you can import into Eclipse as-is.

## Modules

| Module | Port | Responsibility (from the monolith) |
|---|---|---|
| `eureka-server` | 8761 | Service discovery (Netflix Eureka) |
| `config-server` | 8888 | Centralized config, served from `config-server/src/main/resources/config-repo/` |
| `api-gateway` | 8080 | Single entry point; routes `/api/**` to the right service by path |
| `user-service` | 8081 | Auth, users, roles, OTP (`AuthController`, `UserController`) |
| `loan-service` | 8082 | Loan applications, eligibility, guidance, mortgage calc, status tracking, products |
| `document-service` | 8083 | Application documents + post-disbursement document exchange |
| `legal-service` | 8084 | Legal verification, bank office decisions, legal notices |
| `repayment-service` | 8085 | EMI schedule/payments, disbursement, insurance, default management, auctions |
| `notification-service` | 8086 | Notifications + post-disbursement service requests |

Every business service still calls `http://localhost:8080/api/...` from the client's
point of view (via the gateway) - the port-per-service list above is for direct/local
debugging or Eclipse run configurations.

## Architecture decisions (so you know what you're getting)

- **Shared database.** Every service points at the *same* PostgreSQL database/schema
  the monolith used (see `sql/schema_additions_v3.sql` + your original `HLMS...sql`
  file). This was the simpler option vs. a database-per-service split. A few tables
  are mapped by more than one service where the original code read across domains
  (e.g. `loan_application` is read by `loan-service`, and also read/written by
  `repayment-service`'s default-escalation job; `audit_log` is mapped by
  `loan-service`, `repayment-service`, and `document-service`). This is a normal
  trade-off of the shared-DB approach: less isolation, but no need for every
  cross-domain read to become a network call.
- **True network calls only where the monolith called across domains for an action**
  (not just a read), specifically:
  - `user-service` → `notification-service` (`NotificationClient`, Feign) to send OTP codes
  - `repayment-service` → `notification-service` (`NotificationClient`) for EMI reminders / overdue notices
  - `repayment-service` → `legal-service` (`LegalNoticeClient`) to auto-generate a default notice
  These go through each callee's `/internal/**` endpoints, which skip normal user
  JWT auth (there's no logged-in user in a scheduled job) and instead check a
  shared `X-Internal-Api-Key` header (see `InternalApiKeyFilter` in `legal-service`
  and `notification-service`, and `FeignClientConfig` in the calling services).
  Change `hlms.internal.api-key` in `config-repo/application.properties` before any real
  deployment, same as the JWT secret.
- **JWT auth is fully duplicated in every service**, not centralized at the gateway.
  Each service independently validates the bearer token and enforces its own
  `@PreAuthorize` role checks - this is the standard pattern for stateless JWTs
  and means no service depends on another one being up just to authenticate a
  request.
- **Not yet built / not attempted here:** distributed tracing, circuit breakers
  (Resilience4j etc.), a message broker for async events, and container/K8s
  manifests. The `NOTES_v4_feature_update.md` file (kept from the original project)
  still lists the original monolith's own open items - those are unchanged by
  this split.
- **This project has not been compiled** in the environment that generated it
  (no internet access to pull Maven/Spring Cloud dependencies here) - please run
  `mvn clean compile` (or Eclipse's build) after importing, before relying on it.
  I traced every cross-class/cross-service reference by hand and via static
  checks, but a real compiler pass is the only way to be fully certain.

## Running it

### 1. Database
Same as the original monolith: create the database, run your `HLMS...sql` schema
file, then `sql/schema_additions_v3.sql`. `ddl-auto` stays `validate` everywhere.

### 2. Configure
Edit `config-server/src/main/resources/config-repo/application.properties`:
- `spring.datasource.*` - your DB URL/username/password (currently `localhost:5432/hlms` / `postgres`/`postgres`)
- `hlms.jwt.secret` - a long random value, shared by every service
- `hlms.internal.api-key` - a long random value, shared by every service

Per-service overrides (port, `spring.application.name`) live in
`config-server/.../config-repo/<service-name>.properties` if you need to change a port.

### 3. Import into Eclipse
File → Import → Maven → Existing Maven Projects → select this folder
(`hlms-microservices/`) as the root. Eclipse will detect the parent `pom.xml`
and all 9 modules as a multi-module project in one import.

### 4. Run order
Start these as separate Spring Boot / Java applications (right-click each
`*Application.java` → Run As → Java Application, or `mvn spring-boot:run` per
module from a terminal):

1. **`eureka-server`** first (`EurekaServerApplication`) - wait until
   `http://localhost:8761` loads.
2. **`config-server`** next (`ConfigServerApplication`) - the other services
   fetch their config from here on startup. Sanity-check it's serving config at
   `http://localhost:8888/user-service/default`.
3. The **6 business services**, any order: `UserServiceApplication`,
   `LoanServiceApplication`, `DocumentServiceApplication`, `LegalServiceApplication`,
   `RepaymentServiceApplication`, `NotificationServiceApplication`.
4. **`api-gateway`** last (`ApiGatewayApplication`).

Once everything's up, hit the API the same way you did against the monolith,
just through the gateway: `http://localhost:8080/api/...` (see the routing
table in `api-gateway/src/main/resources/application.properties`, or the original
endpoint list in each service's controllers).

### Building a jar without Eclipse
From the root: `mvn clean package`, then each module's jar is under its own
`target/` folder, e.g. `java -jar user-service/target/user-service.jar`
(pass `--spring.config.import=...` overrides the same way you would for the
monolith if you're not running Eureka/Config Server for a quick local test of
one service in isolation).
