package com.tcs.hlms.client;

import com.tcs.hlms.dto.LoanApplicationSummaryDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Declarative REST client for loan-service, resolved through Eureka.
 *
 * Usage from any @Service:
 *   LoanApplicationSummaryDTO app = loanServiceClient.getLoanApplication(appId);
 */
@FeignClient(name = "loan-service")
public interface LoanServiceClient {

    @GetMapping("/api/loan-applications/{appId}")
    LoanApplicationSummaryDTO getLoanApplication(@PathVariable("appId") String appId);
}
