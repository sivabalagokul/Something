package com.tcs.hlms.controller;

import com.tcs.hlms.entity.AuditLogEntity;
import com.tcs.hlms.service.AuditLogService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/audit-logs")
public class AuditLogController {

    private final AuditLogService auditLogService;

    public AuditLogController(
            AuditLogService auditLogService) {
        this.auditLogService = auditLogService;
    }

    @PostMapping
    public AuditLogEntity createAuditLog(
            @RequestBody AuditLogEntity auditLog) {

        return auditLogService.saveAuditLog(auditLog);
    }

    @GetMapping("/{logId}")
    public AuditLogEntity getAuditLogById(
            @PathVariable Long logId) {

        return auditLogService.getAuditLogById(logId);
    }

    @GetMapping
    public List<AuditLogEntity> getAllAuditLogs() {

        return auditLogService.getAllAuditLogs();
    }

    @DeleteMapping("/{logId}")
    public String deleteAuditLog(
            @PathVariable Long logId) {

        auditLogService.deleteAuditLog(logId);
        return "Audit Log deleted successfully";
    }
}