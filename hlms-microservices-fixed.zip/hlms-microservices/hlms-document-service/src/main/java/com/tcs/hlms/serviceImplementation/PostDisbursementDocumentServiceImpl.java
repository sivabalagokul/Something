package com.tcs.hlms.serviceImplementation;
import com.tcs.hlms.exceptions.ResourceNotFoundException;
import com.tcs.hlms.entity.PostDisbursementDocumentEntity;
import com.tcs.hlms.repository.PostDisbursementDocumentRepository;
import com.tcs.hlms.service.PostDisbursementDocumentService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostDisbursementDocumentServiceImpl
        implements PostDisbursementDocumentService {

    private final PostDisbursementDocumentRepository repository;

    public PostDisbursementDocumentServiceImpl(
            PostDisbursementDocumentRepository repository) {
        this.repository = repository;
    }

    @Override
    public PostDisbursementDocumentEntity saveDocument(
            PostDisbursementDocumentEntity document) {

        return repository.save(document);
    }

    @Override
    public PostDisbursementDocumentEntity getDocumentById(
            String documentId) {

        return repository.findById(documentId)
        		.orElseThrow(() ->
        	    new ResourceNotFoundException(
        	        "Post Disbursement Document not found : "
        	                + documentId));
    }

    @Override
    public List<PostDisbursementDocumentEntity> getDocumentsByAppId(
            String appId) {

        return repository.findByAppId(appId);
    }

    @Override
    public List<PostDisbursementDocumentEntity> getAllDocuments() {

        return repository.findAll();
    }

    @Override
    public void deleteDocument(String documentId) {

        repository.deleteById(documentId);
    }
}