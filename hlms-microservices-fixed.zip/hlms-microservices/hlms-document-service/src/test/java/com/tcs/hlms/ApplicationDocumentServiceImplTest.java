package com.tcs.hlms;

import com.tcs.hlms.entity.ApplicationDocumentEntity;
import com.tcs.hlms.exceptions.ResourceNotFoundException;
import com.tcs.hlms.repository.ApplicationDocumentRepository;
import com.tcs.hlms.serviceImplementation.ApplicationDocumentServiceImpl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplicationDocumentServiceImplTest {

    @Mock
    private ApplicationDocumentRepository repository;

    @InjectMocks
    private ApplicationDocumentServiceImpl service;

    @Test
    void saveDocument_Success() {

        ApplicationDocumentEntity document =
                new ApplicationDocumentEntity();

        when(repository.save(document))
                .thenReturn(document);

        ApplicationDocumentEntity result =
                service.saveDocument(document);

        assertNotNull(result);
        verify(repository).save(document);
    }

    @Test
    void getDocumentById_Success() {

        ApplicationDocumentEntity document =
                new ApplicationDocumentEntity();

        when(repository.findById("DOC1"))
                .thenReturn(Optional.of(document));

        assertNotNull(service.getDocumentById("DOC1"));
    }

    @Test
    void getDocumentById_NotFound() {

        when(repository.findById("DOC1"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getDocumentById("DOC1"));
    }

    @Test
    void getDocumentsByAppId_Success() {

        when(repository.findByAppId("APP1"))
                .thenReturn(List.of(new ApplicationDocumentEntity()));

        assertEquals(
                1,
                service.getDocumentsByAppId("APP1").size());
    }

    @Test
    void getDocumentsByAppId_Empty() {

        when(repository.findByAppId("APP1"))
                .thenReturn(Collections.emptyList());

        assertTrue(
                service.getDocumentsByAppId("APP1").isEmpty());
    }

    @Test
    void getAllDocuments_Success() {

        when(repository.findAll())
                .thenReturn(List.of(new ApplicationDocumentEntity()));

        assertEquals(
                1,
                service.getAllDocuments().size());
    }

    @Test
    void getAllDocuments_Empty() {

        when(repository.findAll())
                .thenReturn(Collections.emptyList());

        assertTrue(
                service.getAllDocuments().isEmpty());
    }

    @Test
    void deleteDocument_Success() {

        doNothing().when(repository)
                .deleteById("DOC1");

        service.deleteDocument("DOC1");

        verify(repository).deleteById("DOC1");
    }
    @Test
    void saveDocument_NullObject() {

        when(repository.save(null))
                .thenReturn(null);

        ApplicationDocumentEntity result =
                service.saveDocument(null);

        assertNull(result);
    }
    @Test
    void getDocumentsByAppId_NullAppId() {

        when(repository.findByAppId(null))
                .thenReturn(Collections.emptyList());

        List<ApplicationDocumentEntity> result =
                service.getDocumentsByAppId(null);

        assertNotNull(result);
    }
    @Test
    void deleteDocument_VerifyInvocation() {

        service.deleteDocument("DOC001");

        verify(repository, times(1))
                .deleteById("DOC001");
    }
    @Test
    void getAllDocuments_MultipleRecords() {

        List<ApplicationDocumentEntity> list =
                Arrays.asList(
                        new ApplicationDocumentEntity(),
                        new ApplicationDocumentEntity());

        when(repository.findAll())
                .thenReturn(list);

        assertEquals(
                2,
                service.getAllDocuments().size());
    }
}