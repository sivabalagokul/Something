package com.tcs.hlms.client;

import com.tcs.hlms.dto.UserSummaryDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Declarative REST client for user-service, resolved through Eureka
 * (name must match user-service's spring.application.name - no
 * hard-coded host/port).
 *
 * Usage from any @Service:
 *   UserSummaryDTO user = userServiceClient.getUserByEmail(email);
 */
@FeignClient(name = "user-service")
public interface UserServiceClient {

    @GetMapping("/api/users/{email}")
    UserSummaryDTO getUserByEmail(@PathVariable("email") String email);
}
