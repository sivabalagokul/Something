package com.tcs.hlms.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.tcs.hlms.client.LoanServiceClient;
import com.tcs.hlms.client.UserServiceClient;
import com.tcs.hlms.dto.LoanApplicationSummaryDTO;
import com.tcs.hlms.dto.UserSummaryDTO;
import com.tcs.hlms.entity.ServiceRequestEntity;
import com.tcs.hlms.service.ServiceRequestService;

import java.util.Map;

@RestController
@RequestMapping("/api/service-requests")
public class ServiceRequestController {

    private final ServiceRequestService serviceRequestService;
    private final LoanServiceClient loanServiceClient;
    private final UserServiceClient userServiceClient;

    public ServiceRequestController(ServiceRequestService serviceRequestService,
                                     LoanServiceClient loanServiceClient,
                                     UserServiceClient userServiceClient) {
        this.serviceRequestService = serviceRequestService;
        this.loanServiceClient = loanServiceClient;
        this.userServiceClient = userServiceClient;
    }

    /**
     * Cross-service example: validate/enrich a service request against the
     * owning loan application (loan-service) and requester (user-service)
     * over Feign via Eureka.
     */
    @GetMapping("/application/{appId}/context")
    public ResponseEntity<Map<String, Object>> getApplicationContext(@PathVariable String appId) {
        List<ServiceRequestEntity> requests = serviceRequestService.getRequestsByApplication(appId);
        LoanApplicationSummaryDTO loanApplication = loanServiceClient.getLoanApplication(appId);
        UserSummaryDTO applicant = loanApplication != null
                ? userServiceClient.getUserByEmail(loanApplication.getUserEmail())
                : null;

        return ResponseEntity.ok(Map.of(
                "requests", requests,
                "loanApplication", loanApplication != null ? loanApplication : Map.of(),
                "applicant", applicant != null ? applicant : Map.of()
        ));
    }

    @PostMapping
    public ResponseEntity<ServiceRequestEntity> createRequest(
            @RequestBody ServiceRequestEntity request) {

        return ResponseEntity.ok(
                serviceRequestService.createRequest(request));
    }

    @PutMapping
    public ResponseEntity<ServiceRequestEntity> updateRequest(
            @RequestBody ServiceRequestEntity request) {

        return ResponseEntity.ok(
                serviceRequestService.updateRequest(request));
    }

    @GetMapping("/user/{email}")
    public ResponseEntity<List<ServiceRequestEntity>> getByUser(
            @PathVariable String email) {

        return ResponseEntity.ok(
                serviceRequestService.getRequestsByUser(email));
    }

    @GetMapping("/application/{appId}")
    public ResponseEntity<List<ServiceRequestEntity>> getByApplication(
            @PathVariable String appId) {

        return ResponseEntity.ok(
                serviceRequestService.getRequestsByApplication(appId));
    }

    @DeleteMapping("/{requestId}")
    public ResponseEntity<String> deleteRequest(
            @PathVariable String requestId) {

        serviceRequestService.softDeleteRequest(requestId);

        return ResponseEntity.ok(
                "Service request deleted successfully");
    }
}