package com.tcs.hlms.service;

import java.util.List;

import com.tcs.hlms.entity.ServiceRequestEntity;

public interface ServiceRequestService {

    ServiceRequestEntity createRequest(ServiceRequestEntity request);

    ServiceRequestEntity updateRequest(ServiceRequestEntity request);

    List<ServiceRequestEntity> getRequestsByUser(String email);

    List<ServiceRequestEntity> getRequestsByApplication(String appId);

    void softDeleteRequest(String requestId);

}