package com.tcs.hlms;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import com.tcs.hlms.Exceptions.DuplicateResourceException;
import com.tcs.hlms.Exceptions.ErrorResponse;
import com.tcs.hlms.Exceptions.GlobalExceptionHandler;
import com.tcs.hlms.Exceptions.InvalidRequestException;
import com.tcs.hlms.Exceptions.ResourceNotFoundException;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler =
            new GlobalExceptionHandler();

    @Test
    void testHandleResourceNotFound() {

        ResponseEntity<ErrorResponse> response =
                handler.handleResourceNotFound(
                        new ResourceNotFoundException("Not Found"));

        assertEquals(404,
                response.getBody().getStatus());
    }

    @Test
    void testHandleDuplicateResource() {

        ResponseEntity<ErrorResponse> response =
                handler.handleDuplicateResource(
                        new DuplicateResourceException("Duplicate"));

        assertEquals(409,
                response.getBody().getStatus());
    }

    @Test
    void testHandleInvalidRequest() {

        ResponseEntity<ErrorResponse> response =
                handler.handleInvalidRequest(
                        new InvalidRequestException("Invalid"));

        assertEquals(400,
                response.getBody().getStatus());
    }

    @Test
    void testHandleGeneralException() {

        ResponseEntity<ErrorResponse> response =
                handler.handleException(
                        new Exception("Error"));

        assertEquals(500,
                response.getBody().getStatus());
    }
}