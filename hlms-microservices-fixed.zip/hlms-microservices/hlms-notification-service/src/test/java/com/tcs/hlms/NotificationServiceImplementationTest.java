package com.tcs.hlms;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.tcs.hlms.Exceptions.DuplicateResourceException;
import com.tcs.hlms.Exceptions.InvalidRequestException;
import com.tcs.hlms.Exceptions.ResourceNotFoundException;
import com.tcs.hlms.entity.NotificationEntity;
import com.tcs.hlms.repository.NotificationRepository;
import com.tcs.hlms.serviceImplementation.NotificationServiceImplementation;

@ExtendWith(MockitoExtension.class)
class NotificationServiceImplementationTest {

    @Mock
    private NotificationRepository notificationRepository;

    @InjectMocks
    private NotificationServiceImplementation notificationService;

    private NotificationEntity notification;

    @BeforeEach
    void setUp() {

        notification = new NotificationEntity();
        notification.setNotificationId("NOTIF-1001");
        notification.setUserEmail("user@test.com");
        notification.setTitle("Document Required");
        notification.setBody("Upload documents");
        notification.setIsRead(false);
    }

    @Test
    void testCreateNotificationSuccess() {

        when(notificationRepository.existsById("NOTIF-1001"))
                .thenReturn(false);

        when(notificationRepository.save(notification))
                .thenReturn(notification);

        NotificationEntity result =
                notificationService.createNotification(notification);

        assertNotNull(result);
    }

    @Test
    void testGetAllNotificationsSuccess() {

        when(notificationRepository.findByDeletedAtIsNull())
                .thenReturn(Arrays.asList(notification));

        assertEquals(1,
                notificationService.getAllNotifications().size());
    }

    @Test
    void testGetAllNotificationsEmpty() {

        when(notificationRepository.findByDeletedAtIsNull())
                .thenReturn(Collections.emptyList());

        assertTrue(
                notificationService.getAllNotifications().isEmpty());
    }

    @Test
    void testMarkAsReadSuccess() {

        when(notificationRepository.findById("NOTIF-1001"))
                .thenReturn(Optional.of(notification));

        notificationService.markAsRead("NOTIF-1001");

        assertTrue(notification.getIsRead());
    }

    @Test
    void testSoftDeleteNotificationSuccess() {

        when(notificationRepository.findById("NOTIF-1001"))
                .thenReturn(Optional.of(notification));

        notificationService.softDeleteNotification("NOTIF-1001");

        assertNotNull(notification.getDeletedAt());
    }

    @Test
    void testCreateNotification_Null() {

        assertThrows(
                InvalidRequestException.class,
                () -> notificationService.createNotification(null));
    }

    @Test
    void testCreateNotification_Duplicate() {

        when(notificationRepository.existsById("NOTIF-1001"))
                .thenReturn(true);

        assertThrows(
                DuplicateResourceException.class,
                () -> notificationService.createNotification(notification));
    }

    @Test
    void testMarkAsRead_NotFound() {

        when(notificationRepository.findById("NOTIF-999"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> notificationService.markAsRead("NOTIF-999"));
    }

    @Test
    void testSoftDeleteNotification_NotFound() {

        when(notificationRepository.findById("NOTIF-999"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> notificationService.softDeleteNotification("NOTIF-999"));
    }

    @Test
    void testCreateNotification_EmptyTitle() {

        notification.setTitle("");

        when(notificationRepository.existsById(anyString()))
                .thenReturn(false);

        when(notificationRepository.save(notification))
                .thenReturn(notification);

        NotificationEntity result =
                notificationService.createNotification(notification);

        assertEquals("", result.getTitle());
    }

    @Test
    void testCreateNotification_EmptyBody() {

        notification.setBody("");

        when(notificationRepository.existsById(anyString()))
                .thenReturn(false);

        when(notificationRepository.save(notification))
                .thenReturn(notification);

        NotificationEntity result =
                notificationService.createNotification(notification);

        assertEquals("", result.getBody());
    }

    @Test
    void testCreateNotification_LongTitle() {

        notification.setTitle("A".repeat(500));

        when(notificationRepository.existsById(anyString()))
                .thenReturn(false);

        when(notificationRepository.save(notification))
                .thenReturn(notification);

        assertNotNull(
                notificationService.createNotification(notification));
    }

    @Test
    void testCreateNotification_LongBody() {

        notification.setBody("A".repeat(5000));

        when(notificationRepository.existsById(anyString()))
                .thenReturn(false);

        when(notificationRepository.save(notification))
                .thenReturn(notification);

        assertNotNull(
                notificationService.createNotification(notification));
    }

    @Test
    void testMarkAsRead_AlreadyRead() {

        notification.setIsRead(true);

        when(notificationRepository.findById("NOTIF-1001"))
                .thenReturn(Optional.of(notification));

        notificationService.markAsRead("NOTIF-1001");

        assertTrue(notification.getIsRead());
    }

    @Test
    void testSoftDeleteNotification_AlreadyDeleted() {

        notification.setDeletedAt(OffsetDateTime.now());

        when(notificationRepository.findById("NOTIF-1001"))
                .thenReturn(Optional.of(notification));

        notificationService.softDeleteNotification("NOTIF-1001");

        assertNotNull(notification.getDeletedAt());
    }
}