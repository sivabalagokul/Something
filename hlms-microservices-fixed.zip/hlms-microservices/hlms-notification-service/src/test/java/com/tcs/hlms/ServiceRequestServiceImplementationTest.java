package com.tcs.hlms;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.tcs.hlms.Exceptions.DuplicateResourceException;
import com.tcs.hlms.Exceptions.InvalidRequestException;
import com.tcs.hlms.Exceptions.ResourceNotFoundException;
import com.tcs.hlms.entity.ServiceRequestEntity;
import com.tcs.hlms.repository.ServiceRequestRepository;
import com.tcs.hlms.serviceImplementation.ServiceRequestServiceImplementation;

@ExtendWith(MockitoExtension.class)
class ServiceRequestServiceImplementationTest {

    @Mock
    private ServiceRequestRepository serviceRequestRepository;

    @InjectMocks
    private ServiceRequestServiceImplementation serviceRequestService;

    private ServiceRequestEntity request;

    @BeforeEach
    void setUp() {

        request = new ServiceRequestEntity();
        request.setRequestId("SR-1001");
        request.setAppId("APP-1001");
        request.setUserEmail("user@test.com");
        request.setDescription("Test Request");
        request.setStatus("Requested");
    }

    @Test
    void testCreateRequestSuccess() {

        when(serviceRequestRepository.existsById("SR-1001"))
                .thenReturn(false);

        when(serviceRequestRepository.save(request))
                .thenReturn(request);

        assertNotNull(
                serviceRequestService.createRequest(request));
    }

    @Test
    void testUpdateRequestSuccess() {

        when(serviceRequestRepository.findById("SR-1001"))
                .thenReturn(Optional.of(request));

        when(serviceRequestRepository.save(any()))
                .thenReturn(request);

        assertNotNull(
                serviceRequestService.updateRequest(request));
    }

    @Test
    void testGetRequestsByUserSuccess() {

        when(serviceRequestRepository
                .findByUserEmailAndDeletedAtIsNull(anyString()))
                .thenReturn(Arrays.asList(request));

        assertEquals(
                1,
                serviceRequestService.getRequestsByUser("user@test.com")
                        .size());
    }

    @Test
    void testGetRequestsByUserEmpty() {

        when(serviceRequestRepository
                .findByUserEmailAndDeletedAtIsNull(anyString()))
                .thenReturn(Collections.emptyList());

        assertTrue(
                serviceRequestService.getRequestsByUser("abc@test.com")
                        .isEmpty());
    }

    @Test
    void testGetRequestsByApplicationSuccess() {

        when(serviceRequestRepository
                .findByAppIdAndDeletedAtIsNull("APP-1001"))
                .thenReturn(Arrays.asList(request));

        assertEquals(
                1,
                serviceRequestService.getRequestsByApplication("APP-1001")
                        .size());
    }

    @Test
    void testGetRequestsByApplication_EmptyList() {

        when(serviceRequestRepository
                .findByAppIdAndDeletedAtIsNull(anyString()))
                .thenReturn(Collections.emptyList());

        assertTrue(
                serviceRequestService
                        .getRequestsByApplication("APP-999")
                        .isEmpty());
    }

    @Test
    void testSoftDeleteRequestSuccess() {

        when(serviceRequestRepository.findById("SR-1001"))
                .thenReturn(Optional.of(request));

        serviceRequestService.softDeleteRequest("SR-1001");

        assertNotNull(request.getDeletedAt());
    }

    @Test
    void testCreateRequest_NullRequest() {

        assertThrows(
                InvalidRequestException.class,
                () -> serviceRequestService.createRequest(null));
    }

    @Test
    void testCreateRequest_DuplicateRequest() {

        when(serviceRequestRepository.existsById("SR-1001"))
                .thenReturn(true);

        assertThrows(
                DuplicateResourceException.class,
                () -> serviceRequestService.createRequest(request));
    }

    @Test
    void testUpdateRequest_NotFound() {

        when(serviceRequestRepository.findById("SR-999"))
                .thenReturn(Optional.empty());

        ServiceRequestEntity request =
                new ServiceRequestEntity();

        request.setRequestId("SR-999");

        assertThrows(
                ResourceNotFoundException.class,
                () -> serviceRequestService.updateRequest(request));
    }

    @Test
    void testSoftDeleteRequest_NotFoundException() {

        when(serviceRequestRepository.findById("SR-999"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> serviceRequestService.softDeleteRequest("SR-999"));
    }

    @Test
    void testUpdateRequest_StatusChanged() {

        ServiceRequestEntity updated =
                new ServiceRequestEntity();

        updated.setRequestId("SR-1001");
        updated.setStatus("Completed");
        updated.setDescription("Updated");

        when(serviceRequestRepository.findById("SR-1001"))
                .thenReturn(Optional.of(request));

        when(serviceRequestRepository.save(any()))
                .thenReturn(updated);

        ServiceRequestEntity result =
                serviceRequestService.updateRequest(updated);

        assertEquals("Completed", result.getStatus());
    }

    @Test
    void testUpdateRequest_DescriptionChanged() {

        ServiceRequestEntity updated =
                new ServiceRequestEntity();

        updated.setRequestId("SR-1001");
        updated.setDescription("Updated Description");

        when(serviceRequestRepository.findById("SR-1001"))
                .thenReturn(Optional.of(request));

        when(serviceRequestRepository.save(any()))
                .thenReturn(updated);

        ServiceRequestEntity result =
                serviceRequestService.updateRequest(updated);

        assertEquals(
                "Updated Description",
                result.getDescription());
    }

    @Test
    void testCreateRequest_EmptyDescription() {

        request.setDescription("");

        when(serviceRequestRepository.existsById(anyString()))
                .thenReturn(false);

        when(serviceRequestRepository.save(request))
                .thenReturn(request);

        assertEquals(
                "",
                serviceRequestService.createRequest(request)
                        .getDescription());
    }

    @Test
    void testCreateRequest_LongDescription() {

        request.setDescription("A".repeat(10000));

        when(serviceRequestRepository.existsById(anyString()))
                .thenReturn(false);

        when(serviceRequestRepository.save(request))
                .thenReturn(request);

        assertNotNull(
                serviceRequestService.createRequest(request));
    }

    @Test
    void testCreateRequest_NullRequestType() {

        request.setRequestType(null);

        when(serviceRequestRepository.existsById(anyString()))
                .thenReturn(false);

        when(serviceRequestRepository.save(request))
                .thenReturn(request);

        assertNull(
                serviceRequestService.createRequest(request)
                        .getRequestType());
    }

    @Test
    void testAlreadyDeletedRequest() {

        request.setDeletedAt(OffsetDateTime.now());

        when(serviceRequestRepository.findById("SR-1001"))
                .thenReturn(Optional.of(request));

        serviceRequestService.softDeleteRequest("SR-1001");

        assertNotNull(request.getDeletedAt());
    }
}