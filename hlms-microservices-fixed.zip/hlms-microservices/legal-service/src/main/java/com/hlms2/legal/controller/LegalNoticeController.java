package com.hlms2.legal.controller;

import com.hlms2.legal.dto.LegalNoticeDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.LegalNoticeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/legal-notices")
public class LegalNoticeController {

    private final LegalNoticeService service;

    public LegalNoticeController(LegalNoticeService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<LegalNoticeDTO> create(@RequestBody LegalNoticeDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{noticeId}")
    public LegalNoticeDTO update(@PathVariable String noticeId, @RequestBody LegalNoticeDTO dto) {
        dto.setNoticeId(noticeId);
        return service.update(dto);
    }

    @DeleteMapping("/{noticeId}")
    public ResponseEntity<Void> softDelete(@PathVariable String noticeId) {
        return service.softDelete(noticeId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/{noticeId}/restore")
    public ResponseEntity<Void> restore(@PathVariable String noticeId) {
        return service.restore(noticeId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{noticeId}")
    public LegalNoticeDTO findById(@PathVariable String noticeId) {
        LegalNoticeDTO dto = service.findById(noticeId);
        if (dto == null) {
            throw new ResourceNotFoundException("Notice " + noticeId + " does not exist.");
        }
        return dto;
    }

    @GetMapping
    public List<LegalNoticeDTO> findAll() {
        return service.findAll();
    }
}
