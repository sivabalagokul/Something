package com.hlms2.legal.dto;

public class LegalChecklistItemDTO {
    private String checklistItemId;
    private String appId;
    private String checklistKey;
    private String status;

    public LegalChecklistItemDTO() {
    }

    public LegalChecklistItemDTO(String checklistItemId, String appId, String checklistKey, String status) {
        this.checklistItemId = checklistItemId;
        this.appId = appId;
        this.checklistKey = checklistKey;
        this.status = status;
    }

    public String getChecklistItemId() {
        return checklistItemId;
    }

    public void setChecklistItemId(String checklistItemId) {
        this.checklistItemId = checklistItemId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getChecklistKey() {
        return checklistKey;
    }

    public void setChecklistKey(String checklistKey) {
        this.checklistKey = checklistKey;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String checklistItemId;
        private String appId;
        private String checklistKey;
        private String status;

        public Builder checklistItemId(String checklistItemId) {
            this.checklistItemId = checklistItemId;
            return this;
        }

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public Builder checklistKey(String checklistKey) {
            this.checklistKey = checklistKey;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public LegalChecklistItemDTO build() {
            return new LegalChecklistItemDTO(checklistItemId, appId, checklistKey, status);
        }
    }
}
