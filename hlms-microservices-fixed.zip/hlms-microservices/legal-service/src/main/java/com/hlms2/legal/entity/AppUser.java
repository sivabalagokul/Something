package com.hlms2.legal.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'app_user'. Ported from hlms2.entity.AppUser.
 *
 * This service doesn't own the app_user table (that belongs to the
 * user-service domain) - it's mapped here read-mostly, the same way the
 * app_id/officer foreign keys on legal_verification, legal_notice,
 * legal_checklist_item and bank_office_decision all reference it. Used to
 * confirm an officer email is a real, active user before a legal decision
 * is recorded against it.
 */
@Entity
@Table(name = "app_user")
public class AppUser {

    @Id
    @Column(name = "email", length = 255)
    private String email;

    @JsonIgnore
    @OneToMany(mappedBy = "officer", fetch = FetchType.LAZY)
    private java.util.List<BankOfficeDecision> bankOfficeDecisions;

    @JsonIgnore
    @OneToMany(mappedBy = "officer", fetch = FetchType.LAZY)
    private java.util.List<LegalVerification> legalVerifications;

    @JsonIgnore
    @OneToMany(mappedBy = "officer", fetch = FetchType.LAZY)
    private java.util.List<LegalNotice> legalNotices;

    public java.util.List<BankOfficeDecision> getBankOfficeDecisions() {
        return bankOfficeDecisions;
    }

    public java.util.List<LegalVerification> getLegalVerifications() {
        return legalVerifications;
    }

    public java.util.List<LegalNotice> getLegalNotices() {
        return legalNotices;
    }

    @Column(name = "name", length = 150, nullable = false)
    private String name;

    @Column(name = "mobile", length = 20, nullable = false)
    private String mobile;

    @JsonIgnore
    @Column(name = "password_hash", length = 255, nullable = false)
    private String passwordHash;

    @Column(name = "role", length = 30, nullable = false)
    private String role; // customer, legal, bankoffice, bidder, admin

    @Column(name = "active", nullable = false)
    private Boolean active;

    @Column(name = "id_type", length = 30)
    private String idType;

    @Column(name = "id_number", length = 50)
    private String idNumber;

    @Column(name = "pref_sms", nullable = false)
    private Boolean prefSms;

    @Column(name = "pref_email", nullable = false)
    private Boolean prefEmail;

    @Column(name = "pref_inapp", nullable = false)
    private Boolean prefInapp;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    // CHG(v2): soft delete marker. NULL = active, timestamp = deleted.
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public AppUser() {
    }

    public AppUser(String email, String name, String mobile, String passwordHash, String role, Boolean active,
                   String idType, String idNumber, Boolean prefSms, Boolean prefEmail, Boolean prefInapp,
                   OffsetDateTime createdAt, OffsetDateTime deletedAt) {
        this.email = email;
        this.name = name;
        this.mobile = mobile;
        this.passwordHash = passwordHash;
        this.role = role;
        this.active = active;
        this.idType = idType;
        this.idNumber = idNumber;
        this.prefSms = prefSms;
        this.prefEmail = prefEmail;
        this.prefInapp = prefInapp;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public Boolean getPrefSms() {
        return prefSms;
    }

    public void setPrefSms(Boolean prefSms) {
        this.prefSms = prefSms;
    }

    public Boolean getPrefEmail() {
        return prefEmail;
    }

    public void setPrefEmail(Boolean prefEmail) {
        this.prefEmail = prefEmail;
    }

    public Boolean getPrefInapp() {
        return prefInapp;
    }

    public void setPrefInapp(Boolean prefInapp) {
        this.prefInapp = prefInapp;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String email;
        private String name;
        private String mobile;
        private String passwordHash;
        private String role;
        private Boolean active;
        private String idType;
        private String idNumber;
        private Boolean prefSms;
        private Boolean prefEmail;
        private Boolean prefInapp;
        private OffsetDateTime createdAt;
        private OffsetDateTime deletedAt;

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder mobile(String mobile) {
            this.mobile = mobile;
            return this;
        }

        public Builder passwordHash(String passwordHash) {
            this.passwordHash = passwordHash;
            return this;
        }

        public Builder role(String role) {
            this.role = role;
            return this;
        }

        public Builder active(Boolean active) {
            this.active = active;
            return this;
        }

        public Builder idType(String idType) {
            this.idType = idType;
            return this;
        }

        public Builder idNumber(String idNumber) {
            this.idNumber = idNumber;
            return this;
        }

        public Builder prefSms(Boolean prefSms) {
            this.prefSms = prefSms;
            return this;
        }

        public Builder prefEmail(Boolean prefEmail) {
            this.prefEmail = prefEmail;
            return this;
        }

        public Builder prefInapp(Boolean prefInapp) {
            this.prefInapp = prefInapp;
            return this;
        }

        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public AppUser build() {
            return new AppUser(email, name, mobile, passwordHash, role, active, idType, idNumber, prefSms,
                    prefEmail, prefInapp, createdAt, deletedAt);
        }
    }
}
