package com.hlms2.legal.serviceimpl;

import com.hlms2.legal.dto.LegalVerificationDTO;
import com.hlms2.legal.entity.LegalVerification;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.exception.Validators;
import com.hlms2.legal.repository.AppUserRepository;
import com.hlms2.legal.repository.LegalVerificationRepository;
import com.hlms2.legal.service.LegalVerificationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Ported from hlms2.serviceimpl.LegalVerificationServiceImpl (plain JDBC
 * version), then updated for hlms_schema_updated_v2.sql:
 *
 * - verification_id is now the surrogate PK; app_id is a unique lookup
 *   column instead (create() checks uniqueness on app_id, update()/findById
 *   key off verification_id).
 * - delete is now a soft delete (sets deleted_at), with a matching restore().
 * - info_requested / info_request_details / info_requested_at are carried
 *   straight through - no extra validation added beyond what the plain-Java
 *   version already required.
 *
 * Business rules unchanged: decision must be PENDING/APPROVED/REJECTED,
 * officer must be a real active app_user, remarks required if REJECTED.
 */
@Service
@Transactional
public class LegalVerificationServiceImpl implements LegalVerificationService {

    private static final List<String> VALID_DECISIONS = List.of("PENDING", "APPROVED", "REJECTED");

    private final LegalVerificationRepository repository;
    private final AppUserRepository appUserRepository;

    public LegalVerificationServiceImpl(LegalVerificationRepository repository, AppUserRepository appUserRepository) {
        this.repository = repository;
        this.appUserRepository = appUserRepository;
    }

    @Override
    public LegalVerificationDTO create(LegalVerificationDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        if (repository.findByAppIdAndDeletedAtIsNull(dto.getAppId()).isPresent()) {
            throw new ValidationException("A legal verification record already exists for application " + dto.getAppId() + ".");
        }
        validate(dto);
        LegalVerification entity = toEntity(dto);
        entity.setVerificationId(null);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        entity.setInfoRequested(entity.getInfoRequested() == null ? Boolean.FALSE : entity.getInfoRequested());
        return toDto(repository.save(entity));
    }

    @Override
    public LegalVerificationDTO update(Long verificationId, LegalVerificationDTO dto) {
        LegalVerification existing = repository.findByVerificationIdAndDeletedAtIsNull(verificationId)
                .orElseThrow(() -> new ResourceNotFoundException("No legal verification found with id " + verificationId + "."));
        dto.setAppId(dto.getAppId() != null ? dto.getAppId() : existing.getAppId());
        validate(dto);
        LegalVerification entity = toEntity(dto);
        entity.setVerificationId(verificationId);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        return toDto(repository.save(entity));
    }

    @Override
    public boolean softDelete(Long verificationId) {
        return repository.findByVerificationIdAndDeletedAtIsNull(verificationId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(Long verificationId) {
        return repository.findById(verificationId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public LegalVerificationDTO findById(Long verificationId) {
        return repository.findByVerificationIdAndDeletedAtIsNull(verificationId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public LegalVerificationDTO findByAppId(String appId) {
        Validators.required(appId, "appId");
        return repository.findByAppIdAndDeletedAtIsNull(appId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<LegalVerificationDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    private void validate(LegalVerificationDTO dto) {
        Validators.oneOf(dto.getDecision(), "decision", VALID_DECISIONS.toArray(new String[0]));
        Validators.required(dto.getOfficerEmail(), "officerEmail");
        if (appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull(dto.getOfficerEmail()).isEmpty()) {
            throw new ValidationException("officerEmail " + dto.getOfficerEmail() + " is not a known active app_user.");
        }
        if ("REJECTED".equalsIgnoreCase(dto.getDecision())) {
            Validators.required(dto.getRemarks(), "remarks");
        }
    }

    private LegalVerification toEntity(LegalVerificationDTO dto) {
        return LegalVerification.builder()
                .verificationId(dto.getVerificationId())
                .appId(dto.getAppId())
                .decision(dto.getDecision())
                .decisionDate(dto.getDecisionDate())
                .officerEmail(dto.getOfficerEmail())
                .remarks(dto.getRemarks())
                .infoRequested(dto.getInfoRequested())
                .infoRequestDetails(dto.getInfoRequestDetails())
                .infoRequestedAt(dto.getInfoRequestedAt())
                .build();
    }

    private LegalVerificationDTO toDto(LegalVerification entity) {
        return LegalVerificationDTO.builder()
                .verificationId(entity.getVerificationId())
                .appId(entity.getAppId())
                .decision(entity.getDecision())
                .decisionDate(entity.getDecisionDate())
                .officerEmail(entity.getOfficerEmail())
                .remarks(entity.getRemarks())
                .infoRequested(entity.getInfoRequested())
                .infoRequestDetails(entity.getInfoRequestDetails())
                .infoRequestedAt(entity.getInfoRequestedAt())
                .build();
    }
}
