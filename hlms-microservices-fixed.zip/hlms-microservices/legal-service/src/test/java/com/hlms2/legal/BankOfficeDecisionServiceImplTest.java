package com.hlms2.legal;

import com.hlms2.legal.dto.BankOfficeDecisionDTO;
import com.hlms2.legal.entity.AppUser;
import com.hlms2.legal.entity.BankOfficeDecision;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.repository.AppUserRepository;
import com.hlms2.legal.repository.BankOfficeDecisionRepository;
import com.hlms2.legal.serviceimpl.BankOfficeDecisionServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BankOfficeDecisionServiceImplTest {

    @Mock
    private BankOfficeDecisionRepository repository;

    @Mock
    private AppUserRepository appUserRepository;

    @InjectMocks
    private BankOfficeDecisionServiceImpl service;

    private BankOfficeDecisionDTO validDto;

    @BeforeEach
    void setUp() {
        validDto = BankOfficeDecisionDTO.builder()
                .appId("APP-1")
                .status("APPROVED")
                .officerEmail("officer@bank.com")
                .build();
    }

    private void stubActiveOfficer() {
        when(appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull("officer@bank.com"))
                .thenReturn(Optional.of(AppUser.builder().email("officer@bank.com").active(true).build()));
    }

    private void stubSaveReturnsArgument() {
        when(repository.save(any(BankOfficeDecision.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    // ---------- create() ----------

    @Test
    void create_success_whenApprovedAndNoExistingDecision() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        BankOfficeDecisionDTO result = service.create(validDto);

        assertNotNull(result);
        assertEquals("APP-1", result.getAppId());
        assertEquals("APPROVED", result.getStatus());
        assertNotNull(result.getDecisionDate(), "decisionDate should default to now() when not supplied");
        verify(repository).save(any(BankOfficeDecision.class));
    }

    @Test
    void create_setsDecisionIdToNull_evenIfDtoHadOne() {
        validDto.setDecisionId(999L);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        ArgumentCaptor<BankOfficeDecision> captor = ArgumentCaptor.forClass(BankOfficeDecision.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        service.create(validDto);

        assertNull(captor.getValue().getDecisionId(), "a fresh insert must never carry over a client-supplied id");
    }

    @Test
    void create_preservesProvidedDecisionDate() {
        OffsetDateTime fixed = OffsetDateTime.parse("2026-01-01T10:15:30Z");
        validDto.setDecisionDate(fixed);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        BankOfficeDecisionDTO result = service.create(validDto);

        assertEquals(fixed, result.getDecisionDate());
    }

    @Test
    void create_reasonNotRequired_whenApproved() {
        // validDto has status APPROVED and no reason set.
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        assertDoesNotThrow(() -> service.create(validDto));
    }

    @Test
    void create_reasonRequired_whenRejectedWithoutReason() {
        validDto.setStatus("REJECTED");
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();

        ValidationException ex = assertThrows(ValidationException.class, () -> service.create(validDto));
        assertTrue(ex.getMessage().contains("reason"));
        verify(repository, never()).save(any());
    }

    @Test
    void create_success_whenRejectedWithReasonProvided() {
        validDto.setStatus("REJECTED");
        validDto.setReason("Missing documents");
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        BankOfficeDecisionDTO result = service.create(validDto);

        assertEquals("Missing documents", result.getReason());
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        validDto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(validDto));
        verifyNoInteractions(repository);
    }

    @Test
    void create_blankAppId_throwsValidationException() {
        validDto.setAppId("   ");

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_duplicateAppId_throwsValidationException() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1"))
                .thenReturn(Optional.of(new BankOfficeDecision()));

        ValidationException ex = assertThrows(ValidationException.class, () -> service.create(validDto));
        assertTrue(ex.getMessage().contains("APP-1"));
        verify(repository, never()).save(any());
    }

    @Test
    void create_invalidStatus_throwsValidationException() {
        validDto.setStatus("MADE_UP_STATUS");
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_statusIsCaseInsensitive() {
        validDto.setStatus("approved");
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        assertDoesNotThrow(() -> service.create(validDto));
    }

    @Test
    void create_missingOfficerEmail_throwsValidationException() {
        validDto.setOfficerEmail(null);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_officerNotActiveAppUser_throwsValidationException() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        when(appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull("officer@bank.com"))
                .thenReturn(Optional.empty());

        ValidationException ex = assertThrows(ValidationException.class, () -> service.create(validDto));
        assertTrue(ex.getMessage().contains("officerEmail"));
    }

    // ---------- update() ----------

    @Test
    void update_success_setsDecisionIdAndDefaultsDate() {
        BankOfficeDecision existing = BankOfficeDecision.builder()
                .decisionId(5L).appId("APP-1").status("PENDING").officerEmail("officer@bank.com").build();
        when(repository.findByDecisionIdAndDeletedAtIsNull(5L)).thenReturn(Optional.of(existing));
        stubActiveOfficer();
        ArgumentCaptor<BankOfficeDecision> captor = ArgumentCaptor.forClass(BankOfficeDecision.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        BankOfficeDecisionDTO result = service.update(5L, validDto);

        assertEquals(5L, captor.getValue().getDecisionId());
        assertNotNull(result.getDecisionDate());
    }

    @Test
    void update_notFound_throwsResourceNotFoundException() {
        when(repository.findByDecisionIdAndDeletedAtIsNull(404L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.update(404L, validDto));
        verify(repository, never()).save(any());
    }

    @Test
    void update_appIdDefaultsToExisting_whenDtoAppIdIsNull() {
        validDto.setAppId(null);
        BankOfficeDecision existing = BankOfficeDecision.builder()
                .decisionId(5L).appId("APP-EXISTING").status("PENDING").officerEmail("officer@bank.com").build();
        when(repository.findByDecisionIdAndDeletedAtIsNull(5L)).thenReturn(Optional.of(existing));
        stubActiveOfficer();
        stubSaveReturnsArgument();

        BankOfficeDecisionDTO result = service.update(5L, validDto);

        assertEquals("APP-EXISTING", result.getAppId());
    }

    @Test
    void update_invalidStatus_throwsValidationException() {
        validDto.setStatus("NOT_A_STATUS");
        BankOfficeDecision existing = BankOfficeDecision.builder()
                .decisionId(5L).appId("APP-1").status("PENDING").officerEmail("officer@bank.com").build();
        when(repository.findByDecisionIdAndDeletedAtIsNull(5L)).thenReturn(Optional.of(existing));

        assertThrows(ValidationException.class, () -> service.update(5L, validDto));
    }

    // ---------- softDelete() ----------

    @Test
    void softDelete_found_setsDeletedAtAndReturnsTrue() {
        BankOfficeDecision existing = BankOfficeDecision.builder().decisionId(5L).build();
        when(repository.findByDecisionIdAndDeletedAtIsNull(5L)).thenReturn(Optional.of(existing));
        ArgumentCaptor<BankOfficeDecision> captor = ArgumentCaptor.forClass(BankOfficeDecision.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        boolean result = service.softDelete(5L);

        assertTrue(result);
        assertNotNull(captor.getValue().getDeletedAt());
    }

    @Test
    void softDelete_notFound_returnsFalse() {
        when(repository.findByDecisionIdAndDeletedAtIsNull(999L)).thenReturn(Optional.empty());

        assertFalse(service.softDelete(999L));
        verify(repository, never()).save(any());
    }

    // ---------- restore() ----------

    @Test
    void restore_foundAndSoftDeleted_clearsDeletedAtAndReturnsTrue() {
        BankOfficeDecision existing = BankOfficeDecision.builder().decisionId(5L)
                .deletedAt(OffsetDateTime.now()).build();
        when(repository.findById(5L)).thenReturn(Optional.of(existing));
        ArgumentCaptor<BankOfficeDecision> captor = ArgumentCaptor.forClass(BankOfficeDecision.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        boolean result = service.restore(5L);

        assertTrue(result);
        assertNull(captor.getValue().getDeletedAt());
    }

    @Test
    void restore_foundButNotDeleted_returnsFalse() {
        BankOfficeDecision existing = BankOfficeDecision.builder().decisionId(5L).deletedAt(null).build();
        when(repository.findById(5L)).thenReturn(Optional.of(existing));

        assertFalse(service.restore(5L));
        verify(repository, never()).save(any());
    }

    @Test
    void restore_notFound_returnsFalse() {
        when(repository.findById(999L)).thenReturn(Optional.empty());

        assertFalse(service.restore(999L));
    }

    // ---------- findById() ----------

    @Test
    void findById_found_returnsMappedDto() {
        BankOfficeDecision existing = BankOfficeDecision.builder().decisionId(5L).appId("APP-1").build();
        when(repository.findByDecisionIdAndDeletedAtIsNull(5L)).thenReturn(Optional.of(existing));

        BankOfficeDecisionDTO result = service.findById(5L);

        assertNotNull(result);
        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void findById_notFound_returnsNull() {
        when(repository.findByDecisionIdAndDeletedAtIsNull(999L)).thenReturn(Optional.empty());

        assertNull(service.findById(999L));
    }

    // ---------- findByAppId() ----------

    @Test
    void findByAppId_missingAppId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.findByAppId(null));
        verifyNoInteractions(repository);
    }

    @Test
    void findByAppId_found_returnsMappedDto() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1"))
                .thenReturn(Optional.of(BankOfficeDecision.builder().appId("APP-1").build()));

        BankOfficeDecisionDTO result = service.findByAppId("APP-1");

        assertNotNull(result);
        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void findByAppId_notFound_returnsNull() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-404")).thenReturn(Optional.empty());

        assertNull(service.findByAppId("APP-404"));
    }

    // ---------- findAll() ----------

    @Test
    void findAll_returnsMappedList() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of(
                BankOfficeDecision.builder().appId("APP-1").build(),
                BankOfficeDecision.builder().appId("APP-2").build()));

        List<BankOfficeDecisionDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_noRecords_returnsEmptyList() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of());

        List<BankOfficeDecisionDTO> result = service.findAll();

        assertTrue(result.isEmpty());
    }
}
