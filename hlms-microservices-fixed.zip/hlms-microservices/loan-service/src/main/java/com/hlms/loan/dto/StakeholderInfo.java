package com.hlms.loan.dto;

/**
 * US-LT-03 Stakeholder Assignment Tracking.
 * Derived live from legal_verification.officer / bank_office_decision.officer /
 * disbursement existence - no new "assigned_to" column needed.
 */
public record StakeholderInfo(
        String appId,
        String currentStageName,
        String stakeholderRole,   // customer, legal, bankoffice, admin, none
        String stakeholderEmail,  // may be null if not yet assigned to a named officer
        String note
) {

	}
