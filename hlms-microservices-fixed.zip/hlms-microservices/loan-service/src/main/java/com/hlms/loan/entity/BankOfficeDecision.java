package com.hlms.loan.entity;

import jakarta.persistence.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "bank_office_decision")
public class BankOfficeDecision {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "decision_id")
    private Long decisionId;

    @Column(name = "app_id", nullable = false, unique = true)
    private String appId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "app_id", referencedColumnName = "app_id", insertable = false, updatable = false)
    private LoanApplication loanApplication;

    public LoanApplication getLoanApplication() {
        return loanApplication;
    }

    @Column(name = "status", length = 30)
    private String status;

    @Column(name = "officer")
    private String officer;

    @Column(name = "decision_date")
    private OffsetDateTime decisionDate;

    @Column(name = "reason", length = 255)
    private String reason;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public BankOfficeDecision() {
    }

    public BankOfficeDecision(Long decisionId, String appId, String status, String officer,
                               OffsetDateTime decisionDate, String reason, String remarks, OffsetDateTime deletedAt) {
        this.decisionId = decisionId;
        this.appId = appId;
        this.status = status;
        this.officer = officer;
        this.decisionDate = decisionDate;
        this.reason = reason;
        this.remarks = remarks;
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public Long getDecisionId() {
        return decisionId;
    }

    public void setDecisionId(Long decisionId) {
        this.decisionId = decisionId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOfficer() {
        return officer;
    }

    public void setOfficer(String officer) {
        this.officer = officer;
    }

    public OffsetDateTime getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(OffsetDateTime decisionDate) {
        this.decisionDate = decisionDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static final class Builder {
        private Long decisionId;
        private String appId;
        private String status;
        private String officer;
        private OffsetDateTime decisionDate;
        private String reason;
        private String remarks;
        private OffsetDateTime deletedAt;

        private Builder() {
        }

        public Builder decisionId(Long decisionId) {
            this.decisionId = decisionId;
            return this;
        }

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder officer(String officer) {
            this.officer = officer;
            return this;
        }

        public Builder decisionDate(OffsetDateTime decisionDate) {
            this.decisionDate = decisionDate;
            return this;
        }

        public Builder reason(String reason) {
            this.reason = reason;
            return this;
        }

        public Builder remarks(String remarks) {
            this.remarks = remarks;
            return this;
        }

        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public BankOfficeDecision build() {
            return new BankOfficeDecision(decisionId, appId, status, officer, decisionDate, reason, remarks, deletedAt);
        }
    }
}
