package com.hlms.loan.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hlms.loan.dto.EligibilityRequest;
import com.hlms.loan.dto.EligibilityResponse;
import com.hlms.loan.entity.EligibilityAssessment;
import com.hlms.loan.repository.EligibilityAssessmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Backs feature "2. Advanced Eligibility Assessment & CIBIL Analysis".
 *
 * assess() remains a pure calculation (used by /simulate, which is deliberately
 * stateless so customers can try scenarios freely). assessAndSave() runs the same
 * calculation and additionally persists a row to eligibility_assessment so a
 * customer's real eligibility runs have a retrievable history (see getHistory()).
 *
 * Rules implemented (simplified, adjust to your bank's actual policy):
 *  - Max EMI a customer can safely take on = 50% of monthly income, minus existing EMIs.
 *  - CIBIL < 650            -> Not Eligible
 *  - CIBIL 650-749          -> Conditionally Eligible
 *  - CIBIL >= 750           -> Eligible (subject to DTI check)
 *  - DTI (total EMI incl. new loan / monthly income) > 55% -> Not Eligible regardless of CIBIL
 */
@Service
public class EligibilityService {

    private final EligibilityAssessmentRepository assessmentRepository;
    private final ObjectMapper objectMapper;

    public EligibilityService(EligibilityAssessmentRepository assessmentRepository, ObjectMapper objectMapper) {
        this.assessmentRepository = assessmentRepository;
        this.objectMapper = objectMapper;
    }

    private static final BigDecimal MAX_EMI_TO_INCOME_RATIO = new BigDecimal("0.50");
    private static final BigDecimal MAX_DTI_RATIO = new BigDecimal("0.55");

    public EligibilityResponse assess(EligibilityRequest req) {
        List<String> reasons = new ArrayList<>();
        List<String> recommendations = new ArrayList<>();

        BigDecimal monthlyIncome = nz(req.getMonthlyIncome());
        BigDecimal otherEmis = nz(req.getOtherEmis());
        int cibil = req.getCibilScore() == null ? 0 : req.getCibilScore();
        int tenureYears = req.getTenureYears() == null ? 20 : req.getTenureYears();
        BigDecimal annualRate = req.getInterestRate() == null ? new BigDecimal("8.50") : req.getInterestRate();

        BigDecimal availableEmiCapacity = monthlyIncome
                .multiply(MAX_EMI_TO_INCOME_RATIO)
                .subtract(otherEmis)
                .max(BigDecimal.ZERO);

        BigDecimal maxEligibleLoanAmount = maxLoanForEmi(availableEmiCapacity, annualRate, tenureYears);

        BigDecimal requestedAmount = nz(req.getRequestedAmount());
        BigDecimal estimatedEmiForRequested = emiForLoan(requestedAmount, annualRate, tenureYears);

        BigDecimal totalMonthlyObligation = otherEmis.add(estimatedEmiForRequested);
        BigDecimal dti = monthlyIncome.signum() == 0
                ? BigDecimal.ZERO
                : totalMonthlyObligation.divide(monthlyIncome, 4, RoundingMode.HALF_UP);

        String status;
        if (cibil > 0 && cibil < 650) {
            status = "Not Eligible";
            reasons.add("CIBIL score of " + cibil + " is below the minimum threshold of 650.");
            recommendations.add("Improve your CIBIL score by clearing existing dues and reducing credit utilization, then reapply.");
        } else if (dti.compareTo(MAX_DTI_RATIO) > 0) {
            status = "Not Eligible";
            reasons.add("Debt-to-Income ratio of " + dti.multiply(new BigDecimal(100)).setScale(1, RoundingMode.HALF_UP)
                    + "% exceeds the maximum allowed 55%.");
            recommendations.add("Consider a lower loan amount, a longer tenure, or closing existing EMIs to improve DTI.");
        } else if (cibil >= 650 && cibil < 750) {
            status = "Conditionally Eligible";
            reasons.add("CIBIL score of " + cibil + " qualifies for conditional approval; additional checks may apply.");
            recommendations.add("A co-applicant or additional collateral may improve your terms.");
        } else {
            status = "Eligible";
            reasons.add("Income, existing obligations, and CIBIL score all meet policy requirements.");
        }

        if (requestedAmount.compareTo(maxEligibleLoanAmount) > 0) {
            recommendations.add("Requested amount exceeds your maximum eligible amount of " + maxEligibleLoanAmount
                    + "; consider reducing the loan amount or extending the tenure.");
        }

        return new EligibilityResponse(status, maxEligibleLoanAmount, estimatedEmiForRequested, dti, reasons, recommendations);
    }

    /** Runs the same calculation as assess() and persists the result against a customer. */
    @Transactional
    public EligibilityResponse assessAndSave(String userEmail, EligibilityRequest req) {
        EligibilityResponse result = assess(req);

        EligibilityAssessment record = EligibilityAssessment.builder()
                .userEmail(userEmail)
                .requestedAmount(req.getRequestedAmount())
                .tenureYears(req.getTenureYears())
                .cibilScore(req.getCibilScore())
                .monthlyIncome(req.getMonthlyIncome())
                .otherEmis(req.getOtherEmis())
                .interestRate(req.getInterestRate())
                .status(result.status())
                .maxEligibleLoanAmount(result.maxEligibleLoanAmount())
                .estimatedEmi(result.estimatedEmi())
                .dtiRatio(result.debtToIncomeRatio())
                .reasons(toJson(result.reasons()))
                .recommendations(toJson(result.recommendations()))
                .build();
        assessmentRepository.save(record);

        return result;
    }

    /** US-EL history: lets a customer (or a bank officer) review past eligibility runs. */
    public List<EligibilityAssessment> getHistory(String userEmail) {
        return assessmentRepository.findByUserEmailAndDeletedAtIsNullOrderByCreatedAtDesc(userEmail);
    }

    private String toJson(List<String> values) {
        try {
            return objectMapper.writeValueAsString(values);
        } catch (Exception e) {
            return "[]";
        }
    }

    /** Standard reducing-balance EMI formula. */
    public BigDecimal emiForLoan(BigDecimal principal, BigDecimal annualRatePercent, int tenureYears) {
        if (principal == null || principal.signum() <= 0) return BigDecimal.ZERO;
        double p = principal.doubleValue();
        double r = annualRatePercent.doubleValue() / 12.0 / 100.0;
        int n = tenureYears * 12;
        if (r == 0) return principal.divide(BigDecimal.valueOf(n), 2, RoundingMode.HALF_UP);
        double emi = p * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
        return BigDecimal.valueOf(emi).setScale(2, RoundingMode.HALF_UP);
    }

    /** Inverse of the EMI formula: given an EMI budget, how much principal can be borrowed. */
    public BigDecimal maxLoanForEmi(BigDecimal emiBudget, BigDecimal annualRatePercent, int tenureYears) {
        if (emiBudget == null || emiBudget.signum() <= 0) return BigDecimal.ZERO;
        double emi = emiBudget.doubleValue();
        double r = annualRatePercent.doubleValue() / 12.0 / 100.0;
        int n = tenureYears * 12;
        if (r == 0) return emiBudget.multiply(BigDecimal.valueOf(n)).setScale(2, RoundingMode.HALF_UP);
        double principal = emi * (Math.pow(1 + r, n) - 1) / (r * Math.pow(1 + r, n));
        return BigDecimal.valueOf(principal).setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal nz(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }
}
