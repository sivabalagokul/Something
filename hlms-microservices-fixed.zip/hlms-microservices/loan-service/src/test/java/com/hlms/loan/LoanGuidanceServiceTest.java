package com.hlms.loan;

import com.hlms.loan.dto.*;
import com.hlms.loan.entity.LoanProduct;
import com.hlms.loan.repository.LoanProductRepository;
import com.hlms.loan.service.EligibilityService;
import com.hlms.loan.service.LoanGuidanceService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoanGuidanceServiceTest {

    @Mock
    private LoanProductRepository loanProductRepository;

    @Mock
    private EligibilityService eligibilityService;

    @InjectMocks
    private LoanGuidanceService loanGuidanceService;

    private LoanRecommendationRequest recommendationRequest;
    private LoanProduct homeLoan;
    private LoanProduct personalLoan;

    @BeforeEach
    void setUp() {

        recommendationRequest =
                new LoanRecommendationRequest();

        recommendationRequest.setMonthlyIncome(
                new BigDecimal("100000"));
        recommendationRequest.setOtherEmis(
                new BigDecimal("5000"));
        recommendationRequest.setCibilScore(780);
        recommendationRequest.setRequestedAmount(
                new BigDecimal("1000000"));
        recommendationRequest.setTenureYears(20);
        recommendationRequest.setPurpose("home");

        homeLoan = LoanProduct.builder()
                .productId("HL001")
                .name("Home Loan")
                .category("Home")
                .interestRate(new BigDecimal("8.5"))
                .maxTenureYears(30)
                .maxLtv("80%")
                .build();

        personalLoan = LoanProduct.builder()
                .productId("PL001")
                .name("Personal Loan")
                .category("Personal")
                .interestRate(new BigDecimal("12.5"))
                .maxTenureYears(10)
                .maxLtv("N/A")
                .build();
    }

    // =====================================================
    // POSITIVE TEST CASES
    // =====================================================

    @Test
    void recommend_ShouldReturnMatchingProducts() {

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(List.of(homeLoan));

        when(eligibilityService.assess(any()))
                .thenReturn(
                        new EligibilityResponse(
                                "Eligible",
                                BigDecimal.valueOf(5000000),
                                BigDecimal.valueOf(10000),
                                BigDecimal.valueOf(0.25),
                                List.of(),
                                List.of()));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        new BigDecimal("10000"));

        List<ProductRecommendation> result =
                loanGuidanceService.recommend(
                        recommendationRequest);

        assertEquals(1, result.size());
        assertEquals(
                "HL001",
                result.get(0).productId());
    }

    @Test
    void recommend_ShouldIncludeMatchReason() {

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(List.of(homeLoan));

        when(eligibilityService.assess(any()))
                .thenReturn(
                        new EligibilityResponse(
                                "Eligible",
                                BigDecimal.ONE,
                                BigDecimal.ONE,
                                BigDecimal.ZERO,
                                List.of(),
                                List.of()));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        BigDecimal.valueOf(5000));

        List<ProductRecommendation> result =
                loanGuidanceService.recommend(
                        recommendationRequest);

        assertFalse(result.isEmpty());
    }

    @Test
    void recommend_ShouldSortByInterestRate() {

        LoanProduct cheaperLoan =
                LoanProduct.builder()
                        .productId("HL002")
                        .name("Premium Home Loan")
                        .category("Home")
                        .interestRate(
                                new BigDecimal("7.5"))
                        .maxTenureYears(30)
                        .build();

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(
                        List.of(homeLoan, cheaperLoan));

        when(eligibilityService.assess(any()))
                .thenReturn(
                        new EligibilityResponse(
                                "Eligible",
                                BigDecimal.ONE,
                                BigDecimal.ONE,
                                BigDecimal.ZERO,
                                List.of(),
                                List.of()));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        new BigDecimal("10000"));

        List<ProductRecommendation> result =
                loanGuidanceService.recommend(
                        recommendationRequest);

        assertEquals(
                "HL002",
                result.get(0).productId());
    }

    // =====================================================
    // NEGATIVE TEST CASES
    // =====================================================

    @Test
    void recommend_ShouldReturnEmpty_WhenNoProductsExist() {

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(List.of());

        List<ProductRecommendation> result =
                loanGuidanceService.recommend(
                        recommendationRequest);

        assertTrue(result.isEmpty());
    }

    @Test
    void recommend_ShouldSkipProduct_WhenTenureExceedsMaximum() {

        recommendationRequest.setTenureYears(20);

        personalLoan.setMaxTenureYears(10);

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(List.of(personalLoan));

        List<ProductRecommendation> result =
                loanGuidanceService.recommend(
                        recommendationRequest);

        assertTrue(result.isEmpty());
    }

    @Test
    void recommend_ShouldReturnEmpty_WhenAllProductsFilteredOut() {

        homeLoan.setMaxTenureYears(5);

        recommendationRequest.setTenureYears(20);

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(List.of(homeLoan));

        List<ProductRecommendation> result =
                loanGuidanceService.recommend(
                        recommendationRequest);

        assertTrue(result.isEmpty());
    }

    @Test
    void recommend_ShouldHandleNonMatchingPurpose() {

        recommendationRequest.setPurpose("vehicle");

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(List.of(homeLoan));

        when(eligibilityService.assess(any()))
                .thenReturn(
                        new EligibilityResponse(
                                "Eligible",
                                BigDecimal.ONE,
                                BigDecimal.ONE,
                                BigDecimal.ZERO,
                                List.of(),
                                List.of()));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        BigDecimal.valueOf(5000));

        List<ProductRecommendation> result =
                loanGuidanceService.recommend(
                        recommendationRequest);

        assertFalse(result.isEmpty());
    }

    // =====================================================
    // EDGE TEST CASES
    // =====================================================

    @Test
    void recommend_ShouldUseDefaultTenure_WhenNull() {

        recommendationRequest.setTenureYears(null);

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(List.of(homeLoan));

        when(eligibilityService.assess(any()))
                .thenReturn(
                        new EligibilityResponse(
                                "Eligible",
                                BigDecimal.ONE,
                                BigDecimal.ONE,
                                BigDecimal.ZERO,
                                List.of(),
                                List.of()));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        new BigDecimal("10000"));

        List<ProductRecommendation> result =
                loanGuidanceService.recommend(
                        recommendationRequest);

        assertEquals(1, result.size());
    }

    @Test
    void recommend_ShouldHandleNullPurpose() {

        recommendationRequest.setPurpose(null);

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(List.of(homeLoan));

        when(eligibilityService.assess(any()))
                .thenReturn(
                        new EligibilityResponse(
                                "Eligible",
                                BigDecimal.ONE,
                                BigDecimal.ONE,
                                BigDecimal.ZERO,
                                List.of(),
                                List.of()));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        BigDecimal.valueOf(10000));

        List<ProductRecommendation> result =
                loanGuidanceService.recommend(
                        recommendationRequest);

        assertEquals(1, result.size());
    }

    @Test
    void recommend_ShouldHandleEmptyPurpose() {

        recommendationRequest.setPurpose("");

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(List.of(homeLoan));

        when(eligibilityService.assess(any()))
                .thenReturn(
                        new EligibilityResponse(
                                "Eligible",
                                BigDecimal.ONE,
                                BigDecimal.ONE,
                                BigDecimal.ZERO,
                                List.of(),
                                List.of()));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        BigDecimal.valueOf(10000));

        List<ProductRecommendation> result =
                loanGuidanceService.recommend(
                        recommendationRequest);

        assertFalse(result.isEmpty());
    }

    @Test
    void emiTenureAssistant_ShouldReturnAllTenureOptions() {

        GuidanceAssistantRequest request =
                new GuidanceAssistantRequest();

        request.setLoanAmount(
                new BigDecimal("1000000"));
        request.setInterestRate(
                new BigDecimal("8.5"));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        new BigDecimal("15000"));

        List<EmiOption> result =
                loanGuidanceService.emiTenureAssistant(
                        request);

        assertEquals(6, result.size());
    }

    @Test
    void emiTenureAssistant_ShouldMarkRecommendedOption() {

        GuidanceAssistantRequest request =
                new GuidanceAssistantRequest();

        request.setLoanAmount(
                new BigDecimal("1000000"));

        request.setInterestRate(
                new BigDecimal("8.5"));

        request.setMaxAffordableEmi(
                new BigDecimal("20000"));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        new BigDecimal("15000"));

        List<EmiOption> result =
                loanGuidanceService.emiTenureAssistant(
                        request);

        assertTrue(
                result.stream()
                        .anyMatch(EmiOption::recommended));
    }

    @Test
    void emiTenureAssistant_ShouldRecommendMiddleOption_WhenAffordableEmiMissing() {

        GuidanceAssistantRequest request =
                new GuidanceAssistantRequest();

        request.setLoanAmount(
                new BigDecimal("1000000"));

        request.setInterestRate(
                new BigDecimal("8.5"));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        new BigDecimal("12000"));

        List<EmiOption> result =
                loanGuidanceService.emiTenureAssistant(
                        request);

        long recommendedCount =
                result.stream()
                        .filter(EmiOption::recommended)
                        .count();

        assertEquals(1, recommendedCount);
    }

    @Test
    void emiTenureAssistant_ShouldRecommendLastOption_WhenNothingAffordable() {

        GuidanceAssistantRequest request =
                new GuidanceAssistantRequest();

        request.setLoanAmount(
                new BigDecimal("1000000"));

        request.setInterestRate(
                new BigDecimal("8.5"));

        request.setMaxAffordableEmi(
                new BigDecimal("1"));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        new BigDecimal("20000"));

        List<EmiOption> result =
                loanGuidanceService.emiTenureAssistant(
                        request);

        assertTrue(
                result.get(result.size() - 1)
                        .recommended());
    }

    @Test
    void emiTenureAssistant_ShouldHandleZeroLoanAmount() {

        GuidanceAssistantRequest request =
                new GuidanceAssistantRequest();

        request.setLoanAmount(BigDecimal.ZERO);

        request.setInterestRate(
                new BigDecimal("8.5"));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(BigDecimal.ZERO);

        List<EmiOption> result =
                loanGuidanceService.emiTenureAssistant(
                        request);

        assertEquals(6, result.size());
    }

    @Test
    void emiTenureAssistant_ShouldHandleZeroInterestRate() {

        GuidanceAssistantRequest request =
                new GuidanceAssistantRequest();

        request.setLoanAmount(
                new BigDecimal("1000000"));

        request.setInterestRate(BigDecimal.ZERO);

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        new BigDecimal("10000"));

        List<EmiOption> result =
                loanGuidanceService.emiTenureAssistant(
                        request);

        assertFalse(result.isEmpty());
    }

    @Test
    void recommend_ShouldVerifyEmiCalculationCalled() {

        when(loanProductRepository.findByDeletedAtIsNull())
                .thenReturn(List.of(homeLoan));

        when(eligibilityService.assess(any()))
                .thenReturn(
                        new EligibilityResponse(
                                "Eligible",
                                BigDecimal.ONE,
                                BigDecimal.ONE,
                                BigDecimal.ZERO,
                                List.of(),
                                List.of()));

        when(eligibilityService.emiForLoan(
                any(),
                any(),
                anyInt()))
                .thenReturn(
                        new BigDecimal("10000"));

        loanGuidanceService.recommend(
                recommendationRequest);

        verify(eligibilityService)
                .emiForLoan(
                        any(),
                        any(),
                        anyInt());
    }
}