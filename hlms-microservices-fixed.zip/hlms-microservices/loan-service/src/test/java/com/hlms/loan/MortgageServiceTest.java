package com.hlms.loan;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hlms.loan.dto.EligibilityResponse;
import com.hlms.loan.dto.MortgageCalculationRequest;
import com.hlms.loan.dto.MortgageCalculationResponse;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.entity.LoanProduct;
import com.hlms.loan.exception.BadRequestException;
import com.hlms.loan.exception.ResourceNotFoundException;
import com.hlms.loan.repository.LoanApplicationRepository;
import com.hlms.loan.repository.LoanProductRepository;
import com.hlms.loan.service.AuditService;
import com.hlms.loan.service.EligibilityService;
import com.hlms.loan.service.MortgageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MortgageServiceTest {

    @Mock
    private LoanApplicationRepository loanApplicationRepository;

    @Mock
    private LoanProductRepository loanProductRepository;

    @Mock
    private EligibilityService eligibilityService;

    @Mock
    private AuditService auditService;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private MortgageService mortgageService;

    private MortgageCalculationRequest request;
    private LoanApplication application;
    private LoanProduct product;

    @BeforeEach
    void setUp() throws Exception {

        request = new MortgageCalculationRequest();
        request.setRequestedLoanAmount(
                new BigDecimal("3000000"));
        request.setPropertyValue(
                new BigDecimal("5000000"));
        request.setMonthlyIncome(
                new BigDecimal("100000"));
        request.setOtherEmis(
                new BigDecimal("10000"));
        request.setTenureYears(20);
        request.setInterestRate(
                new BigDecimal("8.5"));
        request.setCibilScore(780);

        application = LoanApplication.builder()
                .appId("APP001")
                .productId("HOME001")
                .loanAmount(new BigDecimal("3000000"))
                .propertyValue(new BigDecimal("5000000"))
                .monthlyIncome(new BigDecimal("100000"))
                .otherEmis(new BigDecimal("10000"))
                .interestRate(new BigDecimal("8.5"))
                .tenureYears(20)
                .build();

        product = LoanProduct.builder()
                .productId("HOME001")
                .maxLtv("80%")
                .build();

        lenient().when(objectMapper.readValue(
                anyString(),
                eq(LinkedHashMap.class)))
                .thenReturn(new LinkedHashMap<>());
    }

    // =====================================================
    // CALCULATE
    // =====================================================

    @Test
    void calculate_ShouldReturnMortgageRequired() {

        when(eligibilityService.assess(any()))
                .thenReturn(new EligibilityResponse(
                        "Eligible",
                        new BigDecimal("2000000"),
                        BigDecimal.ZERO,
                        BigDecimal.ZERO,
                        List.of(),
                        List.of()));

        MortgageCalculationResponse response =
                mortgageService.calculate(request);

        assertNotNull(response);
        assertTrue(response.mortgageRequired());
    }

    @Test
    void calculate_ShouldNotRequireMortgage() {

        when(eligibilityService.assess(any()))
                .thenReturn(new EligibilityResponse(
                        "Eligible",
                        new BigDecimal("5000000"),
                        BigDecimal.ZERO,
                        BigDecimal.ZERO,
                        List.of(),
                        List.of()));

        MortgageCalculationResponse response =
                mortgageService.calculate(request);

        assertFalse(response.mortgageRequired());
    }

    @Test
    void calculate_ShouldUseProductLtv() {

        request.setProductId("HOME001");

        when(loanProductRepository
                .findByProductIdAndDeletedAtIsNull(
                        "HOME001"))
                .thenReturn(Optional.of(product));

        when(eligibilityService.assess(any()))
                .thenReturn(new EligibilityResponse(
                        "Eligible",
                        BigDecimal.ONE,
                        BigDecimal.ZERO,
                        BigDecimal.ZERO,
                        List.of(),
                        List.of()));

        MortgageCalculationResponse response =
                mortgageService.calculate(request);

        assertEquals(
                "80%",
                response.maxLtvAllowed());
    }

    @Test
    void calculate_ShouldHandleInvalidLtvFormat() {

        product.setMaxLtv("INVALID");
        request.setProductId("HOME001");

        when(loanProductRepository
                .findByProductIdAndDeletedAtIsNull(
                        "HOME001"))
                .thenReturn(Optional.of(product));

        when(eligibilityService.assess(any()))
                .thenReturn(new EligibilityResponse(
                        "Eligible",
                        BigDecimal.ONE,
                        BigDecimal.ZERO,
                        BigDecimal.ZERO,
                        List.of(),
                        List.of()));

        assertNotNull(
                mortgageService.calculate(request));
    }

    @Test
    void calculate_ShouldHandleZeroPropertyValue() {

        request.setPropertyValue(BigDecimal.ZERO);

        when(eligibilityService.assess(any()))
                .thenReturn(new EligibilityResponse(
                        "Eligible",
                        BigDecimal.ONE,
                        BigDecimal.ZERO,
                        BigDecimal.ZERO,
                        List.of(),
                        List.of()));

        MortgageCalculationResponse response =
                mortgageService.calculate(request);

        assertEquals(
                BigDecimal.ZERO,
                response.loanToValueRatio());
    }

    @Test
    void calculate_ShouldThrowBadRequestException_WhenInvalidProduct() {

        request.setProductId("INVALID");

        when(loanProductRepository
                .findByProductIdAndDeletedAtIsNull(
                        "INVALID"))
                .thenReturn(Optional.empty());

        when(eligibilityService.assess(any()))
                .thenReturn(new EligibilityResponse(
                        "Eligible",
                        BigDecimal.ONE,
                        BigDecimal.ZERO,
                        BigDecimal.ZERO,
                        List.of(),
                        List.of()));

        assertThrows(
                BadRequestException.class,
                () -> mortgageService.calculate(request));
    }

    // =====================================================
    // CALCULATE FOR APPLICATION
    // =====================================================

    @Test
    void calculateForApplication_ShouldCalculateSuccessfully()
            throws Exception {

        when(loanApplicationRepository.findById("APP001"))
                .thenReturn(Optional.of(application));

        when(loanProductRepository
                .findByProductIdAndDeletedAtIsNull(
                        "HOME001"))
                .thenReturn(Optional.of(product));

        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{}");

        when(eligibilityService.assess(any()))
                .thenReturn(new EligibilityResponse(
                        "Eligible",
                        new BigDecimal("2000000"),
                        BigDecimal.ZERO,
                        BigDecimal.ZERO,
                        List.of(),
                        List.of()));

        MortgageCalculationResponse response =
                mortgageService.calculateForApplication(
                        "APP001",
                        "user@test.com");

        assertNotNull(response);

        verify(auditService).record(
                eq("loan_application"),
                eq("APP001"),
                eq("MORTGAGE_CALCULATED"),
                eq("user@test.com"),
                isNull(),
                anyMap());
    }

    @Test
    void calculateForApplication_ShouldThrowResourceNotFoundException() {

        when(loanApplicationRepository.findById("APP001"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> mortgageService.calculateForApplication(
                        "APP001",
                        "user@test.com"));
    }

    @Test
    void calculateForApplication_ShouldThrowWhenSoftDeleted() {

        application.setDeletedAt(
                OffsetDateTime.now());

        when(loanApplicationRepository.findById("APP001"))
                .thenReturn(Optional.of(application));

        assertThrows(
                ResourceNotFoundException.class,
                () -> mortgageService.calculateForApplication(
                        "APP001",
                        "user@test.com"));
    }

    // =====================================================
    // EVALUATE PROPERTY
    // =====================================================

    @Test
    void evaluateProperty_ShouldUpdatePropertyValue()
            throws Exception {

        when(loanApplicationRepository.findById("APP001"))
                .thenReturn(Optional.of(application));

        when(loanApplicationRepository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{}");

        LoanApplication result =
                mortgageService.evaluateProperty(
                        "APP001",
                        new BigDecimal("7000000"),
                        "Villa",
                        "Verified",
                        "admin@test.com");

        assertEquals(
                new BigDecimal("7000000"),
                result.getPropertyValue());

        assertEquals(
                "Villa",
                result.getPropertyType());

        verify(auditService).record(
                eq("loan_application"),
                eq("APP001"),
                eq("PROPERTY_EVALUATED"),
                eq("admin@test.com"),
                anyMap(),
                anyMap());
    }

    @Test
    void evaluateProperty_ShouldAcceptNullPropertyType()
            throws Exception {

        when(loanApplicationRepository.findById("APP001"))
                .thenReturn(Optional.of(application));

        when(loanApplicationRepository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        when(objectMapper.writeValueAsString(any()))
                .thenReturn("{}");

        LoanApplication result =
                mortgageService.evaluateProperty(
                        "APP001",
                        new BigDecimal("5000000"),
                        null,
                        "Notes",
                        "admin@test.com");

        assertNotNull(result);
    }

    @Test
    void evaluateProperty_ShouldThrowResourceNotFoundException() {

        when(loanApplicationRepository.findById("APP001"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> mortgageService.evaluateProperty(
                        "APP001",
                        BigDecimal.ONE,
                        "House",
                        "Notes",
                        "admin@test.com"));
    }

    @Test
    void evaluateProperty_ShouldThrowBadRequestException_WhenJsonSerializationFails()
            throws Exception {

        when(loanApplicationRepository.findById("APP001"))
                .thenReturn(Optional.of(application));

        when(loanApplicationRepository.save(any()))
                .thenAnswer(i -> i.getArgument(0));

        when(objectMapper.writeValueAsString(any()))
                .thenThrow(
                        new RuntimeException("JSON Error"));

        assertThrows(
                BadRequestException.class,
                () -> mortgageService.evaluateProperty(
                        "APP001",
                        BigDecimal.ONE,
                        "Flat",
                        "Notes",
                        "admin@test.com"));
    }

    // =====================================================
    // GET MORTGAGE RECORD
    // =====================================================

    @Test
    void getMortgageRecord_ShouldReturnRecord()
            throws Exception {

        Map<String, Object> mortgageRecord =
                new LinkedHashMap<>();

        mortgageRecord.put(
                "mortgageRequired",
                true);

        Map<String, Object> formData =
                new LinkedHashMap<>();

        formData.put(
                "mortgageAssessment",
                mortgageRecord);

        application.setFormData("{}");

        when(loanApplicationRepository.findById("APP001"))
                .thenReturn(Optional.of(application));

        when(objectMapper.readValue(
                anyString(),
                eq(LinkedHashMap.class)))
                .thenReturn((LinkedHashMap) formData);

        Map<String, Object> result =
                mortgageService.getMortgageRecord(
                        "APP001");

        assertNotNull(result);

        assertEquals(
                Boolean.TRUE,
                result.get("mortgageRequired"));
    }

    @Test
    void getMortgageRecord_ShouldThrowWhenAssessmentMissing() {

        application.setFormData("{}");

        when(loanApplicationRepository.findById("APP001"))
                .thenReturn(Optional.of(application));

        assertThrows(
                ResourceNotFoundException.class,
                () -> mortgageService.getMortgageRecord(
                        "APP001"));
    }

    @Test
    void getMortgageRecord_ShouldThrowWhenFormDataNull() {

        application.setFormData(null);

        when(loanApplicationRepository.findById("APP001"))
                .thenReturn(Optional.of(application));

        assertThrows(
                ResourceNotFoundException.class,
                () -> mortgageService.getMortgageRecord(
                        "APP001"));
    }
}