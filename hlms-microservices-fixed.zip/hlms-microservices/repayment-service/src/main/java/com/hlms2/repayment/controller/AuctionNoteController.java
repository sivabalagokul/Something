package com.hlms2.repayment.controller;

import com.hlms2.repayment.dto.AuctionNoteDTO;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.service.AuctionNoteService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Direct by-id access to auction notes; see AuctionCaseController for the nested /api/auctions/{appId}/notes routes. */
@RestController
@RequestMapping("/api/auction-notes")
public class AuctionNoteController {

    private final AuctionNoteService service;

    public AuctionNoteController(AuctionNoteService service) {
        this.service = service;
    }

    @PutMapping("/{noteId}")
    public AuctionNoteDTO update(@PathVariable String noteId, @RequestBody AuctionNoteDTO dto) {
        dto.setNoteId(noteId);
        return service.update(dto);
    }

    @DeleteMapping("/{noteId}")
    public ResponseEntity<Void> softDelete(@PathVariable String noteId) {
        return service.softDelete(noteId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/{noteId}/restore")
    public ResponseEntity<Void> restore(@PathVariable String noteId) {
        return service.restore(noteId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{noteId}")
    public AuctionNoteDTO findById(@PathVariable String noteId) {
        AuctionNoteDTO dto = service.findById(noteId);
        if (dto == null) {
            throw new ResourceNotFoundException("Auction note " + noteId + " does not exist.");
        }
        return dto;
    }

    @GetMapping
    public List<AuctionNoteDTO> findAll() {
        return service.findAll();
    }
}
