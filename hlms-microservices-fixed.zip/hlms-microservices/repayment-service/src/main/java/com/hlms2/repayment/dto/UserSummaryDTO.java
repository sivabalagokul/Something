package com.hlms2.repayment.dto;

/**
 * Slim, read-only projection of user-service's AppUser, used only for
 * cross-service Feign calls. Kept separate from any local JPA entity so
 * this service never accidentally treats another service's data as its
 * own persistence model.
 */
public class UserSummaryDTO {
    private String email;
    private String name;
    private String mobile;
    private String role;

    public UserSummaryDTO() {
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}
