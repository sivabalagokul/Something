package com.hlms2.repayment.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'app_user'. Ported from hlms2.entity.AppUser.
 *
 * This service doesn't own app_user (that's user-service's table) - mapped
 * here read-mostly, since bid.bidder_email and audit_log.actor_email are
 * both foreign keys into it. Used to confirm those emails are real, active
 * users before a bid/log entry is recorded against them.
 */
@Entity
@Table(name = "app_user")
public class AppUser {

    @Id
    @Column(name = "email", length = 255)
    private String email;

    @JsonIgnore
    @OneToMany(mappedBy = "borrower", fetch = FetchType.LAZY)
    private java.util.List<LoanApplication> loanApplications;

    @JsonIgnore
    @OneToMany(mappedBy = "bidder", fetch = FetchType.LAZY)
    private java.util.List<Bid> bids;

    public java.util.List<LoanApplication> getLoanApplications() {
        return loanApplications;
    }

    public java.util.List<Bid> getBids() {
        return bids;
    }

    @Column(name = "name", length = 150, nullable = false)
    private String name;

    @Column(name = "mobile", length = 20, nullable = false)
    private String mobile;

    @JsonIgnore
    @Column(name = "password_hash", length = 255, nullable = false)
    private String passwordHash;

    @Column(name = "role", length = 30, nullable = false)
    private String role;

    @Column(name = "active", nullable = false)
    private Boolean active;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public AppUser() {
    }

    public AppUser(String email, String name, String mobile, String passwordHash, String role, Boolean active, OffsetDateTime createdAt, OffsetDateTime deletedAt) {
        this.email = email;
        this.name = name;
        this.mobile = mobile;
        this.passwordHash = passwordHash;
        this.role = role;
        this.active = active;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    public String getPasswordHash() {
        return passwordHash;
    }
    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public Boolean getActive() {
        return active;
    }
    public void setActive(Boolean active) {
        this.active = active;
    }
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String email;
        private String name;
        private String mobile;
        private String passwordHash;
        private String role;
        private Boolean active;
        private OffsetDateTime createdAt;
        private OffsetDateTime deletedAt;

        public Builder email(String email) {
            this.email = email;
            return this;
        }
        public Builder name(String name) {
            this.name = name;
            return this;
        }
        public Builder mobile(String mobile) {
            this.mobile = mobile;
            return this;
        }
        public Builder passwordHash(String passwordHash) {
            this.passwordHash = passwordHash;
            return this;
        }
        public Builder role(String role) {
            this.role = role;
            return this;
        }
        public Builder active(Boolean active) {
            this.active = active;
            return this;
        }
        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public AppUser build() {
            return new AppUser(email, name, mobile, passwordHash, role, active, createdAt, deletedAt);
        }
    }
}
