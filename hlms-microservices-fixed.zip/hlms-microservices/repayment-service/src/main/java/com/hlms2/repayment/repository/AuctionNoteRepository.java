package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.AuctionNote;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AuctionNoteRepository extends JpaRepository<AuctionNote, String> {
    Optional<AuctionNote> findByNoteIdAndDeletedAtIsNull(String noteId);
    List<AuctionNote> findByDeletedAtIsNull();
    List<AuctionNote> findByAppIdAndDeletedAtIsNull(String appId);
}
