package com.hlms2.repayment.service;

import com.hlms2.repayment.dto.DisbursementDTO;

import java.util.List;

public interface DisbursementService {
    DisbursementDTO create(DisbursementDTO dto);
    DisbursementDTO update(Long disbursementId, DisbursementDTO dto);
    boolean softDelete(Long disbursementId);
    boolean restore(Long disbursementId);
    DisbursementDTO findById(Long disbursementId);
    DisbursementDTO findByAppId(String appId);
    List<DisbursementDTO> findAll();
}
