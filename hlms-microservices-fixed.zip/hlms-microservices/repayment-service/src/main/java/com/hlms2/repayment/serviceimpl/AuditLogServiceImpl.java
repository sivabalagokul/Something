package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.AuditLogDTO;
import com.hlms2.repayment.entity.AuditLog;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.exception.Validators;
import com.hlms2.repayment.repository.AppUserRepository;
import com.hlms2.repayment.repository.AuditLogRepository;
import com.hlms2.repayment.service.AuditLogService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Ported from hlms2.serviceimpl.AuditLogServiceImpl (plain JDBC version),
 * moved onto Spring Data JPA (AuditLogRepository). No update() at all
 * (see the service interface javadoc) - audit log rows are append-only,
 * mirroring US-LRM-05's "records cannot be modified without
 * authorization" for payment history. No soft delete either: audit_log
 * has no deleted_at column in the schema, so delete() here is a genuine
 * hard delete, exactly like the plain-Java version.
 *
 * CHG: actorEmail is now checked against AppUserRepository (a real,
 * active app_user) before a log entry is accepted - the plain-Java
 * version only required the field to be non-blank, but
 * audit_log.actor_email is a foreign key into app_user(email).
 */
@Service
@Transactional
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogRepository repository;
    private final AppUserRepository appUserRepository;

    public AuditLogServiceImpl(AuditLogRepository repository, AppUserRepository appUserRepository) {
        this.repository = repository;
        this.appUserRepository = appUserRepository;
    }

    @Override
    public AuditLogDTO create(AuditLogDTO dto) {
        Validators.required(dto.getEntityType(), "entityType");
        Validators.required(dto.getEntityId(), "entityId");
        Validators.oneOf(dto.getAction(), "action", "CREATE", "UPDATE", "DELETE", "APPROVE", "REJECT", "LOGIN", "LOGOUT");
        Validators.required(dto.getActorEmail(), "actorEmail");
        if (appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull(dto.getActorEmail()).isEmpty()) {
            throw new ValidationException("actorEmail " + dto.getActorEmail() + " is not a known active app_user.");
        }

        AuditLog entity = toEntity(dto);
        entity.setCreatedAt(entity.getCreatedAt() == null ? OffsetDateTime.now() : entity.getCreatedAt());
        return toDto(repository.save(entity));
    }

    @Override
    public boolean delete(Long logId) {
        Validators.required(logId, "logId");
        if (!repository.existsById(logId)) {
            return false;
        }
        repository.deleteById(logId);
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public AuditLogDTO findById(Long logId) {
        Validators.required(logId, "logId");
        return repository.findById(logId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogDTO> findAll() {
        return repository.findAll().stream().map(this::toDto).toList();
    }

    private AuditLog toEntity(AuditLogDTO dto) {
        return AuditLog.builder()
                .logId(dto.getLogId())
                .entityType(dto.getEntityType())
                .entityId(dto.getEntityId())
                .action(dto.getAction())
                .actorEmail(dto.getActorEmail())
                .beforeData(dto.getBeforeData())
                .afterData(dto.getAfterData())
                .createdAt(dto.getCreatedAt())
                .build();
    }

    private AuditLogDTO toDto(AuditLog entity) {
        return AuditLogDTO.builder()
                .logId(entity.getLogId())
                .entityType(entity.getEntityType())
                .entityId(entity.getEntityId())
                .action(entity.getAction())
                .actorEmail(entity.getActorEmail())
                .beforeData(entity.getBeforeData())
                .afterData(entity.getAfterData())
                .createdAt(entity.getCreatedAt())
                .build();
    }
}
