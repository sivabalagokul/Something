package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.BidDTO;
import com.hlms2.repayment.entity.AuctionCase;
import com.hlms2.repayment.entity.Bid;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.exception.Validators;
import com.hlms2.repayment.repository.AppUserRepository;
import com.hlms2.repayment.repository.AuctionCaseRepository;
import com.hlms2.repayment.repository.BidRepository;
import com.hlms2.repayment.service.BidService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Ported from hlms2.serviceimpl.BidServiceImpl (plain JDBC version), then
 * updated for hlms_schema_updated_v2.sql: delete is now a soft delete
 * (sets deleted_at), with a matching restore(). PK unchanged (bid_id
 * remains the natural key).
 *
 * CHG: bidderEmail is now checked against AppUserRepository (a real,
 * active app_user) before a bid is accepted - the plain-Java version only
 * required the field to be non-blank, but bid.bidder_email is a foreign
 * key into app_user(email), same reasoning as officerEmail in legal-service.
 *
 * Business logic unchanged (US-AM-02..04): a bid is only valid if it's
 * placed against an existing (non-deleted) auction case, is at least the
 * reserve price, and strictly beats the current highest bid for that
 * auction.
 */
@Service
@Transactional
public class BidServiceImpl implements BidService {

    private final BidRepository repository;
    private final AuctionCaseRepository auctionCaseRepository;
    private final AppUserRepository appUserRepository;

    public BidServiceImpl(BidRepository repository, AuctionCaseRepository auctionCaseRepository, AppUserRepository appUserRepository) {
        this.repository = repository;
        this.auctionCaseRepository = auctionCaseRepository;
        this.appUserRepository = appUserRepository;
    }

    @Override
    public BidDTO create(BidDTO dto) {
        validate(dto);
        Bid entity = toEntity(dto);
        if (entity.getBidId() == null || entity.getBidId().isBlank()) {
            entity.setBidId("BID-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setCreatedAt(entity.getCreatedAt() == null ? OffsetDateTime.now() : entity.getCreatedAt());
        return toDto(repository.save(entity));
    }

    @Override
    public BidDTO update(BidDTO dto) {
        Validators.required(dto.getBidId(), "bidId");
        repository.findByBidIdAndDeletedAtIsNull(dto.getBidId())
                .orElseThrow(() -> new ResourceNotFoundException("Bid " + dto.getBidId() + " does not exist."));
        validate(dto);
        Bid entity = toEntity(dto);
        return toDto(repository.save(entity));
    }

    @Override
    public boolean softDelete(String bidId) {
        return repository.findByBidIdAndDeletedAtIsNull(bidId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(String bidId) {
        return repository.findById(bidId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public BidDTO findById(String bidId) {
        Validators.required(bidId, "bidId");
        return repository.findByBidIdAndDeletedAtIsNull(bidId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BidDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    private void validate(BidDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        Validators.required(dto.getBidderEmail(), "bidderEmail");
        Validators.positive(dto.getBidAmount(), "bidAmount");

        AuctionCase auctionCase = auctionCaseRepository.findByAppIdAndDeletedAtIsNull(dto.getAppId())
                .orElseThrow(() -> new ValidationException("No auction case found for application " + dto.getAppId() + "."));
        if (auctionCase.getReservePrice() != null && dto.getBidAmount().compareTo(auctionCase.getReservePrice()) < 0) {
            throw new ValidationException("bidAmount must be at least the reserve price of " + auctionCase.getReservePrice() + ".");
        }
        if (appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull(dto.getBidderEmail()).isEmpty()) {
            throw new ValidationException("bidderEmail " + dto.getBidderEmail() + " is not a known active app_user.");
        }
        BigDecimal highestSoFar = highestBid(dto.getAppId());
        if (highestSoFar != null && dto.getBidAmount().compareTo(highestSoFar) <= 0) {
            throw new ValidationException("bidAmount must be higher than the current highest bid of " + highestSoFar + ".");
        }
    }

    private BigDecimal highestBid(String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId).stream()
                .map(Bid::getBidAmount)
                .max(BigDecimal::compareTo)
                .orElse(null);
    }

    private Bid toEntity(BidDTO dto) {
        return Bid.builder()
                .bidId(dto.getBidId())
                .appId(dto.getAppId())
                .bidderEmail(dto.getBidderEmail())
                .bidAmount(dto.getBidAmount())
                .createdAt(dto.getCreatedAt())
                .build();
    }

    private BidDTO toDto(Bid entity) {
        return BidDTO.builder()
                .bidId(entity.getBidId())
                .appId(entity.getAppId())
                .bidderEmail(entity.getBidderEmail())
                .bidAmount(entity.getBidAmount())
                .createdAt(entity.getCreatedAt())
                .build();
    }
}
