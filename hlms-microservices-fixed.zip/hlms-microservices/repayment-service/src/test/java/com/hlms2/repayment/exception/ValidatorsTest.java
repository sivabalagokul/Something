package com.hlms2.repayment.exception;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ValidatorsTest {

    // ---------- required() ----------

    @Test
    void required_negative_null_throws() {
        assertThatThrownBy(() -> Validators.required(null, "field"))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("field is required");
    }

    @Test
    void required_negative_blankString_throws() {
        assertThatThrownBy(() -> Validators.required("   ", "field"))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void required_positive_nonBlankString_passes() {
        assertThatCode(() -> Validators.required("value", "field")).doesNotThrowAnyException();
    }

    @Test
    void required_edge_nonStringObject_passes() {
        assertThatCode(() -> Validators.required(42, "field")).doesNotThrowAnyException();
    }

    // ---------- oneOf() ----------

    @Test
    void oneOf_positive_matches_passes() {
        assertThatCode(() -> Validators.oneOf("ACTIVE", "status", "ACTIVE", "INACTIVE"))
                .doesNotThrowAnyException();
    }

    @Test
    void oneOf_edge_caseInsensitiveMatch_passes() {
        assertThatCode(() -> Validators.oneOf("active", "status", "ACTIVE", "INACTIVE"))
                .doesNotThrowAnyException();
    }

    @Test
    void oneOf_negative_noMatch_throws() {
        assertThatThrownBy(() -> Validators.oneOf("BOGUS", "status", "ACTIVE", "INACTIVE"))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void oneOf_negative_null_throws() {
        assertThatThrownBy(() -> Validators.oneOf(null, "status", "ACTIVE"))
                .isInstanceOf(ValidationException.class);
    }

    // ---------- positive(BigDecimal) ----------

    @Test
    void positiveDecimal_positive_greaterThanZero_passes() {
        assertThatCode(() -> Validators.positive(BigDecimal.TEN, "amount")).doesNotThrowAnyException();
    }

    @Test
    void positiveDecimal_negative_zero_throws() {
        assertThatThrownBy(() -> Validators.positive(BigDecimal.ZERO, "amount"))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void positiveDecimal_negative_negativeValue_throws() {
        assertThatThrownBy(() -> Validators.positive(BigDecimal.valueOf(-5), "amount"))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void positiveDecimal_negative_null_throws() {
        assertThatThrownBy(() -> Validators.positive((BigDecimal) null, "amount"))
                .isInstanceOf(ValidationException.class);
    }

    // ---------- positive(Integer) ----------

    @Test
    void positiveInt_positive_greaterThanZero_passes() {
        assertThatCode(() -> Validators.positive(Integer.valueOf(1), "count")).doesNotThrowAnyException();
    }

    @Test
    void positiveInt_negative_zero_throws() {
        assertThatThrownBy(() -> Validators.positive(Integer.valueOf(0), "count"))
                .isInstanceOf(ValidationException.class);
    }

    // ---------- nonNegative() ----------

    @Test
    void nonNegative_positive_zero_passes() {
        assertThatCode(() -> Validators.nonNegative(BigDecimal.ZERO, "balance")).doesNotThrowAnyException();
    }

    @Test
    void nonNegative_negative_negativeValue_throws() {
        assertThatThrownBy(() -> Validators.nonNegative(BigDecimal.valueOf(-1), "balance"))
                .isInstanceOf(ValidationException.class);
    }

    // ---------- maxLength() ----------

    @Test
    void maxLength_positive_underLimit_passes() {
        assertThatCode(() -> Validators.maxLength("short", "text", 10)).doesNotThrowAnyException();
    }

    @Test
    void maxLength_edge_exactlyAtLimit_passes() {
        assertThatCode(() -> Validators.maxLength("1234567890", "text", 10)).doesNotThrowAnyException();
    }

    @Test
    void maxLength_negative_overLimit_throws() {
        assertThatThrownBy(() -> Validators.maxLength("12345678901", "text", 10))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void maxLength_edge_null_passes() {
        assertThatCode(() -> Validators.maxLength(null, "text", 10)).doesNotThrowAnyException();
    }

    // ---------- afterOrEqual() ----------

    @Test
    void afterOrEqual_positive_laterDateAfterEarlier_passes() {
        assertThatCode(() -> Validators.afterOrEqual(
                LocalDate.of(2026, 2, 1), LocalDate.of(2026, 1, 1), "later", "earlier"))
                .doesNotThrowAnyException();
    }

    @Test
    void afterOrEqual_edge_equalDates_passes() {
        LocalDate date = LocalDate.of(2026, 1, 1);
        assertThatCode(() -> Validators.afterOrEqual(date, date, "later", "earlier"))
                .doesNotThrowAnyException();
    }

    @Test
    void afterOrEqual_negative_laterBeforeEarlier_throws() {
        assertThatThrownBy(() -> Validators.afterOrEqual(
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 2, 1), "later", "earlier"))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void afterOrEqual_edge_nullValues_skipsCheck() {
        assertThatCode(() -> Validators.afterOrEqual(null, LocalDate.of(2026, 1, 1), "later", "earlier"))
                .doesNotThrowAnyException();
        assertThatCode(() -> Validators.afterOrEqual(LocalDate.of(2026, 1, 1), null, "later", "earlier"))
                .doesNotThrowAnyException();
    }

    // ---------- futureOrToday() ----------

    @Test
    void futureOrToday_edge_alwaysPasses_isPermissiveByDesign() {
        assertThatCode(() -> Validators.futureOrToday(LocalDate.of(2000, 1, 1), "date"))
                .doesNotThrowAnyException();
        assertThatCode(() -> Validators.futureOrToday(null, "date")).doesNotThrowAnyException();
    }
}
