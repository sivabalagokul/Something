package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.AuctionNoteDTO;
import com.hlms2.repayment.entity.AuctionNote;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.repository.AuctionNoteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuctionNoteServiceImplTest {

    @Mock
    private AuctionNoteRepository repository;

    private AuctionNoteServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new AuctionNoteServiceImpl(repository);
    }

    private AuctionNoteDTO validDto() {
        AuctionNoteDTO dto = new AuctionNoteDTO();
        dto.setAppId("APP-1");
        dto.setNoteText("Notice issued to borrower.");
        return dto;
    }

    // ---------- create() ----------

    @Test
    void create_positive_generatesNoteIdWhenBlank() {
        AuctionNoteDTO dto = validDto();
        when(repository.save(any(AuctionNote.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionNoteDTO result = service.create(dto);

        assertThat(result.getNoteId()).isNotBlank().startsWith("ANT-");
        assertThat(result.getNoteDate()).isNotNull();
    }

    @Test
    void create_edge_keepsProvidedNoteIdAndDate() {
        AuctionNoteDTO dto = validDto();
        dto.setNoteId("ANT-CUSTOM1");
        OffsetDateTime fixed = OffsetDateTime.parse("2026-01-01T10:00:00Z");
        dto.setNoteDate(fixed);
        when(repository.save(any(AuctionNote.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionNoteDTO result = service.create(dto);

        assertThat(result.getNoteId()).isEqualTo("ANT-CUSTOM1");
        assertThat(result.getNoteDate()).isEqualTo(fixed);
    }

    @Test
    void create_negative_missingAppId_throws() {
        AuctionNoteDTO dto = validDto();
        dto.setAppId(null);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
        verifyNoInteractions(repository);
    }

    @Test
    void create_negative_missingNoteText_throws() {
        AuctionNoteDTO dto = validDto();
        dto.setNoteText(" ");

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_noteTextTooLong_throws() {
        AuctionNoteDTO dto = validDto();
        dto.setNoteText("x".repeat(4001));

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("noteText");
    }

    @Test
    void create_edge_noteTextAtMaxLengthAllowed() {
        AuctionNoteDTO dto = validDto();
        dto.setNoteText("x".repeat(4000));
        when(repository.save(any(AuctionNote.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionNoteDTO result = service.create(dto);

        assertThat(result.getNoteText()).hasSize(4000);
    }

    // ---------- update() ----------

    @Test
    void update_positive_updatesExisting() {
        AuctionNoteDTO dto = validDto();
        dto.setNoteId("ANT-1");
        AuctionNote existing = AuctionNote.builder().noteId("ANT-1").appId("APP-1").noteText("old").build();
        when(repository.findByNoteIdAndDeletedAtIsNull("ANT-1")).thenReturn(Optional.of(existing));
        when(repository.save(any(AuctionNote.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionNoteDTO result = service.update(dto);

        assertThat(result.getNoteId()).isEqualTo("ANT-1");
        assertThat(result.getNoteText()).isEqualTo(dto.getNoteText());
    }

    @Test
    void update_negative_missingNoteId_throws() {
        AuctionNoteDTO dto = validDto();

        assertThatThrownBy(() -> service.update(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void update_negative_notFound_throwsResourceNotFound() {
        AuctionNoteDTO dto = validDto();
        dto.setNoteId("ANT-404");
        when(repository.findByNoteIdAndDeletedAtIsNull("ANT-404")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.update(dto)).isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- softDelete() / restore() ----------

    @Test
    void softDelete_positive_returnsTrue() {
        AuctionNote existing = AuctionNote.builder().noteId("ANT-1").appId("APP-1").noteText("x").build();
        when(repository.findByNoteIdAndDeletedAtIsNull("ANT-1")).thenReturn(Optional.of(existing));

        assertThat(service.softDelete("ANT-1")).isTrue();
        assertThat(existing.getDeletedAt()).isNotNull();
    }

    @Test
    void softDelete_negative_notFound_returnsFalse() {
        when(repository.findByNoteIdAndDeletedAtIsNull("ANT-404")).thenReturn(Optional.empty());

        assertThat(service.softDelete("ANT-404")).isFalse();
    }

    @Test
    void restore_positive_returnsTrue() {
        AuctionNote existing = AuctionNote.builder().noteId("ANT-1").appId("APP-1").noteText("x")
                .deletedAt(OffsetDateTime.now()).build();
        when(repository.findById("ANT-1")).thenReturn(Optional.of(existing));

        assertThat(service.restore("ANT-1")).isTrue();
        assertThat(existing.getDeletedAt()).isNull();
    }

    @Test
    void restore_edge_notDeleted_returnsFalse() {
        AuctionNote existing = AuctionNote.builder().noteId("ANT-1").appId("APP-1").noteText("x").build();
        when(repository.findById("ANT-1")).thenReturn(Optional.of(existing));

        assertThat(service.restore("ANT-1")).isFalse();
    }

    // ---------- findById / findAll / getAuctionRecord / recordAuctionEvent ----------

    @Test
    void findById_negative_missingId_throws() {
        assertThatThrownBy(() -> service.findById(null)).isInstanceOf(ValidationException.class);
    }

    @Test
    void findById_positive_returnsDto() {
        AuctionNote existing = AuctionNote.builder().noteId("ANT-1").appId("APP-1").noteText("x").build();
        when(repository.findByNoteIdAndDeletedAtIsNull("ANT-1")).thenReturn(Optional.of(existing));

        assertThat(service.findById("ANT-1")).isNotNull();
    }

    @Test
    void findAll_edge_empty() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of());
        assertThat(service.findAll()).isEmpty();
    }

    @Test
    void getAuctionRecord_positive_sortsByNoteDateAscending() {
        AuctionNote later = AuctionNote.builder().noteId("ANT-2").appId("APP-1")
                .noteText("later").noteDate(OffsetDateTime.parse("2026-02-01T00:00:00Z")).build();
        AuctionNote earlier = AuctionNote.builder().noteId("ANT-1").appId("APP-1")
                .noteText("earlier").noteDate(OffsetDateTime.parse("2026-01-01T00:00:00Z")).build();
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(List.of(later, earlier));

        List<AuctionNoteDTO> result = service.getAuctionRecord("APP-1");

        assertThat(result).extracting(AuctionNoteDTO::getNoteId).containsExactly("ANT-1", "ANT-2");
    }

    @Test
    void getAuctionRecord_negative_missingAppId_throws() {
        assertThatThrownBy(() -> service.getAuctionRecord(null)).isInstanceOf(ValidationException.class);
    }

    @Test
    void recordAuctionEvent_positive_createsSystemNote() {
        ArgumentCaptor<AuctionNote> captor = ArgumentCaptor.forClass(AuctionNote.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        AuctionNoteDTO result = service.recordAuctionEvent("APP-9", "Auction scheduled");

        assertThat(result.getAppId()).isEqualTo("APP-9");
        assertThat(result.getNoteText()).isEqualTo("Auction scheduled");
        assertThat(captor.getValue().getNoteId()).startsWith("ANT-");
    }

    @Test
    void recordAuctionEvent_negative_missingEventDescription_throws() {
        assertThatThrownBy(() -> service.recordAuctionEvent("APP-9", null))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void recordAuctionEvent_negative_missingAppId_throws() {
        assertThatThrownBy(() -> service.recordAuctionEvent(null, "event"))
                .isInstanceOf(ValidationException.class);
    }
}
