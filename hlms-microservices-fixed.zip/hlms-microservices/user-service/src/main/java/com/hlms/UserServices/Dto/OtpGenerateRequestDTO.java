package com.hlms.UserServices.Dto;


public class OtpGenerateRequestDTO {

    private String email;
    private String purpose;

    public OtpGenerateRequestDTO() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
}