package com.hlms.UserServices.Entity;

import java.time.LocalDateTime;

import com.hlms.UserServices.Enum.roleEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "app_user")
public class appUserEntity {

    @Id
    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @jakarta.persistence.OneToOne(mappedBy = "user", fetch = jakarta.persistence.FetchType.LAZY)
    private customerEmploymentProfileEntity employmentProfile;

    @jakarta.persistence.OneToMany(mappedBy = "user", fetch = jakarta.persistence.FetchType.LAZY)
    private java.util.List<otpVerificationEntity> otpVerifications;

    public customerEmploymentProfileEntity getEmploymentProfile() {
        return employmentProfile;
    }

    public java.util.List<otpVerificationEntity> getOtpVerifications() {
        return otpVerifications;
    }

    @Column(name = "name", nullable = false, length = 150)
    private String name;

    @Column(name = "mobile", nullable = false, length = 20)
    private String mobile;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @Enumerated(EnumType.STRING)
    @Column(name = "role", nullable = false)
    private roleEnum role;

    @Column(name = "active", nullable = false)
    private Boolean active = true;

    @Column(name = "id_type")
    private String idType;

    @Column(name = "id_number")
    private String idNumber;

    @Column(name = "pref_sms")
    private Boolean prefSms = true;

    @Column(name = "pref_email")
    private Boolean prefEmail = true;

    @Column(name = "pref_inapp")
    private Boolean prefInapp = true;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    public appUserEntity() {
    }

    @PrePersist
    public void prePersist() {

        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }

        if (active == null) {
            active = true;
        }

        if (prefSms == null) {
            prefSms = true;
        }

        if (prefEmail == null) {
            prefEmail = true;
        }

        if (prefInapp == null) {
            prefInapp = true;
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public roleEnum getRole() {
        return role;
    }

    public void setRole(roleEnum role) {
        this.role = role;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public Boolean getPrefSms() {
        return prefSms;
    }

    public void setPrefSms(Boolean prefSms) {
        this.prefSms = prefSms;
    }

    public Boolean getPrefEmail() {
        return prefEmail;
    }

    public void setPrefEmail(Boolean prefEmail) {
        this.prefEmail = prefEmail;
    }

    public Boolean getPrefInapp() {
        return prefInapp;
    }

    public void setPrefInapp(Boolean prefInapp) {
        this.prefInapp = prefInapp;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(LocalDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }
}