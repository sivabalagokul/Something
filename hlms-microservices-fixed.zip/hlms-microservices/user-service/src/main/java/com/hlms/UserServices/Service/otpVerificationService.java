package com.hlms.UserServices.Service;

public interface otpVerificationService {

    String generateOtp(
            String email,
            String purpose);

    String verifyOtp(
            String email,
            String otpCode);
}