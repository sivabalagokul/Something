package com.hlms.document.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.OffsetDateTime;
@Entity
@Table(name = "application_document")
public class ApplicationDocument {
    @Id
    @Column(name = "document_id", length = 50)
    private String documentId;
    @Column(name = "app_id", nullable = false)
    private String appId;
    @Column(name = "doc_type", length = 50, nullable = false)
    private String docType;
    @Column(name = "file_name", length = 255, nullable = false)
    private String fileName;
    // Excluded from default JSON responses - fetch via a dedicated download endpoint instead.
    @JsonIgnore
    @Lob
    @Column(name = "file_data", nullable = false)
    private byte[] fileData;
    @Column(name = "file_size")
    private Integer fileSize;
    @Column(name = "uploaded_at", nullable = false)
    private OffsetDateTime uploadedAt;
    @Column(name = "verification_status", length = 30, nullable = false)
    private String verificationStatus = "Pending";
    @Column(name = "verified_by")
    private String verifiedBy;
    @Column(name = "verified_at")
    private OffsetDateTime verifiedAt;
    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
    @PrePersist
    public void prePersist() {
        if (uploadedAt == null) uploadedAt = OffsetDateTime.now();
    }

    public ApplicationDocument() {
    }

    public ApplicationDocument(String documentId, String appId, String docType, String fileName, byte[] fileData, Integer fileSize, OffsetDateTime uploadedAt, String verificationStatus, String verifiedBy, OffsetDateTime verifiedAt, String remarks, OffsetDateTime deletedAt) {
        this.documentId = documentId;
        this.appId = appId;
        this.docType = docType;
        this.fileName = fileName;
        this.fileData = fileData;
        this.fileSize = fileSize;
        this.uploadedAt = uploadedAt;
        this.verificationStatus = verificationStatus;
        this.verifiedBy = verifiedBy;
        this.verifiedAt = verifiedAt;
        this.remarks = remarks;
        this.deletedAt = deletedAt;
    }

    public String getDocumentId() {
        return documentId;
    }
    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getDocType() {
        return docType;
    }
    public void setDocType(String docType) {
        this.docType = docType;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public byte[] getFileData() {
        return fileData;
    }
    public void setFileData(byte[] fileData) {
        this.fileData = fileData;
    }
    public Integer getFileSize() {
        return fileSize;
    }
    public void setFileSize(Integer fileSize) {
        this.fileSize = fileSize;
    }
    public OffsetDateTime getUploadedAt() {
        return uploadedAt;
    }
    public void setUploadedAt(OffsetDateTime uploadedAt) {
        this.uploadedAt = uploadedAt;
    }
    public String getVerificationStatus() {
        return verificationStatus;
    }
    public void setVerificationStatus(String verificationStatus) {
        this.verificationStatus = verificationStatus;
    }
    public String getVerifiedBy() {
        return verifiedBy;
    }
    public void setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }
    public OffsetDateTime getVerifiedAt() {
        return verifiedAt;
    }
    public void setVerifiedAt(OffsetDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }
    public String getRemarks() {
        return remarks;
    }
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private String documentId;
        private String appId;
        private String docType;
        private String fileName;
        private byte[] fileData;
        private Integer fileSize;
        private OffsetDateTime uploadedAt;
        private String verificationStatus = "Pending";
        private String verifiedBy;
        private OffsetDateTime verifiedAt;
        private String remarks;
        private OffsetDateTime deletedAt;

        public Builder documentId(String documentId) {
            this.documentId = documentId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder docType(String docType) {
            this.docType = docType;
            return this;
        }
        public Builder fileName(String fileName) {
            this.fileName = fileName;
            return this;
        }
        public Builder fileData(byte[] fileData) {
            this.fileData = fileData;
            return this;
        }
        public Builder fileSize(Integer fileSize) {
            this.fileSize = fileSize;
            return this;
        }
        public Builder uploadedAt(OffsetDateTime uploadedAt) {
            this.uploadedAt = uploadedAt;
            return this;
        }
        public Builder verificationStatus(String verificationStatus) {
            this.verificationStatus = verificationStatus;
            return this;
        }
        public Builder verifiedBy(String verifiedBy) {
            this.verifiedBy = verifiedBy;
            return this;
        }
        public Builder verifiedAt(OffsetDateTime verifiedAt) {
            this.verifiedAt = verifiedAt;
            return this;
        }
        public Builder remarks(String remarks) {
            this.remarks = remarks;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public ApplicationDocument build() {
            return new ApplicationDocument(documentId, appId, docType, fileName, fileData, fileSize, uploadedAt, verificationStatus, verifiedBy, verifiedAt, remarks, deletedAt);
        }
    }
}