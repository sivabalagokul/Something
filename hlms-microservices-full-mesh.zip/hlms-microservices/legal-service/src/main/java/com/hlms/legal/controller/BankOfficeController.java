package com.hlms.legal.controller;
import com.hlms.legal.entity.BankOfficeDecision;
import com.hlms.legal.service.BankOfficeService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController
@RequestMapping("/api/bank-office")
@PreAuthorize("hasAnyRole('BANKOFFICE','ADMIN')")
public class BankOfficeController {
    private final BankOfficeService service;
    @GetMapping("/{appId}")
    public BankOfficeDecision get(@PathVariable String appId) {
        return service.get(appId);
    }
    @PostMapping("/{appId}/decision")
    public BankOfficeDecision decide(@PathVariable String appId, @RequestBody Map<String, String> body) {
        return service.decide(appId, body.get("status"), body.get("officer"), body.get("reason"), body.get("remarks"));
    }

    public BankOfficeController(BankOfficeService service) {
        this.service = service;
    }
}