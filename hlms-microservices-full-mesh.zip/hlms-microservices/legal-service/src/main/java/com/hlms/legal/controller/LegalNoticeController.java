package com.hlms.legal.controller;
import com.hlms.legal.entity.LegalNotice;
import com.hlms.legal.service.LegalNoticeService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
/** Feature 10: Default Management and Notice Generation (US-DMNG-02..03) */
@RestController
@RequestMapping("/api/legal-notices")
@PreAuthorize("hasAnyRole('BANKOFFICE','LEGAL','ADMIN')")
public class LegalNoticeController {
    private final LegalNoticeService service;
    @PostMapping
    public LegalNotice generate(@RequestBody Map<String, String> body) {
        LocalDate dueDate = body.get("dueDate") != null ? LocalDate.parse(body.get("dueDate")) : null;
        return service.generateNotice(body.get("appId"), body.get("noticeType"), body.get("officer"),
                body.get("content"), dueDate);
    }
    @GetMapping("/by-app/{appId}")
    public List<LegalNotice> listForApp(@PathVariable String appId) {
        return service.listForApp(appId);
    }
    @PatchMapping("/{noticeId}/status")
    public LegalNotice updateStatus(@PathVariable String noticeId, @RequestBody Map<String, String> body) {
        return service.updateStatus(noticeId, body.get("status"));
    }

    public LegalNoticeController(LegalNoticeService service) {
        this.service = service;
    }
}