package com.hlms.loan.controller;
import com.hlms.loan.dto.SubmitApplicationRequest;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.service.LoanApplicationService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
/**
 * US-LA-01..06 Digital Loan Application Management
 * US-LT-01..06 Loan Status Tracking & Workflow Visibility
 */
@RestController
@RequestMapping("/api/loan-applications")
public class LoanApplicationController {
    private final LoanApplicationService service;
    @GetMapping
    public List<LoanApplication> listForUser(@RequestParam String userEmail) {
        return service.listForUser(userEmail);
    }
    @GetMapping("/all")
    public List<LoanApplication> listAll() {
        return service.listAll();
    }
    // Cross-cutting: paginated/sortable variants, e.g. ?page=0&size=20&sort=createdAt,desc
    @GetMapping("/all/page")
    public Page<LoanApplication> listAllPaged(@PageableDefault(size = 20) Pageable pageable) {
        return service.listAll(pageable);
    }
    @GetMapping("/page")
    public Page<LoanApplication> listForUserPaged(@RequestParam String userEmail,
                                                   @PageableDefault(size = 20) Pageable pageable) {
        return service.listForUser(userEmail, pageable);
    }
    @GetMapping("/{appId}")
    public LoanApplication get(@PathVariable String appId) {
        return service.get(appId);
    }
    // US-LT-01 Real-Time Status Tracking, by tracking number
    @GetMapping("/track/{trackingNo}")
    public LoanApplication track(@PathVariable String trackingNo) {
        return service.getByTrackingNo(trackingNo);
    }
    // US-LT-02 Stage Visibility
    @GetMapping("/workflow-stages")
    public List<String> workflowStages() {
        return service.workflowStages();
    }
    // US-LA-06 Draft Saving (create new draft or update an existing one)
    @PostMapping("/draft")
    public LoanApplication saveDraft(@RequestParam(required = false) String appId,
                                      @RequestParam String userEmail,
                                      @RequestParam(defaultValue = "1") int currentStep,
                                      @RequestBody SubmitApplicationRequest req) {
        return service.saveDraft(appId, userEmail, req, currentStep);
    }
    // US-LA-01 Online Loan Application (final submit)
    @PostMapping("/{appId}/submit")
    public LoanApplication submit(@PathVariable String appId) {
        return service.submit(appId);
    }
    @PatchMapping("/{appId}/stage")
    public LoanApplication updateStage(@PathVariable String appId, @RequestBody Map<String, Object> body) {
        int stageIndex = (int) body.get("stageIndex");
        String status = (String) body.get("status");
        return service.updateStage(appId, stageIndex, status);
    }
    @DeleteMapping("/{appId}")
    public ResponseEntity<Void> withdraw(@PathVariable String appId) {
        service.withdraw(appId);
        return ResponseEntity.noContent().build();
    }

    public LoanApplicationController(LoanApplicationService service) {
        this.service = service;
    }
}