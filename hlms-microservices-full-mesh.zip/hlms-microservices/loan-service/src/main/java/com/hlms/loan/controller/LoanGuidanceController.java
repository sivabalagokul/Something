package com.hlms.loan.controller;
import com.hlms.loan.dto.EmiOption;
import com.hlms.loan.dto.GuidanceAssistantRequest;
import com.hlms.loan.dto.LoanRecommendationRequest;
import com.hlms.loan.dto.ProductRecommendation;
import com.hlms.loan.service.LoanGuidanceService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
/** Feature 3: Loan Guidance & Recommendation Engine (US-LG-01..05) */
@RestController
@RequestMapping("/api/loan-guidance")
public class LoanGuidanceController {
    private final LoanGuidanceService service;
    // US-LG-03/04 Personalized / eligibility-based recommendations
    @PostMapping("/recommendations")
    public List<ProductRecommendation> recommend(@RequestBody LoanRecommendationRequest request) {
        return service.recommend(request);
    }
    // US-LG-05 Loan Guidance Assistant (EMI/tenure trade-offs)
    @PostMapping("/emi-assistant")
    public List<EmiOption> emiAssistant(@RequestBody GuidanceAssistantRequest request) {
        return service.emiTenureAssistant(request);
    }

    public LoanGuidanceController(LoanGuidanceService service) {
        this.service = service;
    }
}