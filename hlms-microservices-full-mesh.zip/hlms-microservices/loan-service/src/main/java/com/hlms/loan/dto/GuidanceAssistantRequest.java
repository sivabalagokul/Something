package com.hlms.loan.dto;
import java.math.BigDecimal;
public class GuidanceAssistantRequest {
    private BigDecimal loanAmount;
    private BigDecimal interestRate;      // annual %
    private BigDecimal maxAffordableEmi;  // optional - used to pick the "recommended" tenure

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }
    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }
    public BigDecimal getInterestRate() {
        return interestRate;
    }
    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }
    public BigDecimal getMaxAffordableEmi() {
        return maxAffordableEmi;
    }
    public void setMaxAffordableEmi(BigDecimal maxAffordableEmi) {
        this.maxAffordableEmi = maxAffordableEmi;
    }
}