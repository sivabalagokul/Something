package com.hlms.loan.dto;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
public class MortgageCalculationRequest {
    @NotNull @Positive
    private BigDecimal requestedLoanAmount;
    @NotNull @Positive
    private BigDecimal propertyValue;
    private String productId;          // used to look up loan_product.max_ltv, if known
    @Positive
    private Integer tenureYears;       // defaults to 20 if omitted
    private BigDecimal interestRate;   // annual %, defaults to 8.50 if omitted
    private BigDecimal monthlyIncome;  // used to derive the unsecured eligibility ceiling
    private BigDecimal otherEmis;
    private Integer cibilScore;

    public BigDecimal getRequestedLoanAmount() {
        return requestedLoanAmount;
    }
    public void setRequestedLoanAmount(BigDecimal requestedLoanAmount) {
        this.requestedLoanAmount = requestedLoanAmount;
    }
    public BigDecimal getPropertyValue() {
        return propertyValue;
    }
    public void setPropertyValue(BigDecimal propertyValue) {
        this.propertyValue = propertyValue;
    }
    public String getProductId() {
        return productId;
    }
    public void setProductId(String productId) {
        this.productId = productId;
    }
    public Integer getTenureYears() {
        return tenureYears;
    }
    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }
    public BigDecimal getInterestRate() {
        return interestRate;
    }
    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }
    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }
    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }
    public BigDecimal getOtherEmis() {
        return otherEmis;
    }
    public void setOtherEmis(BigDecimal otherEmis) {
        this.otherEmis = otherEmis;
    }
    public Integer getCibilScore() {
        return cibilScore;
    }
    public void setCibilScore(Integer cibilScore) {
        this.cibilScore = cibilScore;
    }
}