package com.hlms.loan.entity;
import jakarta.persistence.*;
import java.time.OffsetDateTime;
@Entity
@Table(name = "legal_verification")
public class LegalVerification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "verification_id")
    private Long verificationId;
    @Column(name = "app_id", nullable = false, unique = true)
    private String appId;
    @Column(name = "decision", length = 30)
    private String decision;
    @Column(name = "decision_date")
    private OffsetDateTime decisionDate;
    @Column(name = "officer")
    private String officer;
    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;
    @Column(name = "info_requested", nullable = false)
    private Boolean infoRequested = false;
    @Column(name = "info_request_details", columnDefinition = "TEXT")
    private String infoRequestDetails;
    @Column(name = "info_requested_at")
    private OffsetDateTime infoRequestedAt;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public LegalVerification() {
    }

    public LegalVerification(Long verificationId, String appId, String decision, OffsetDateTime decisionDate, String officer, String remarks, Boolean infoRequested, String infoRequestDetails, OffsetDateTime infoRequestedAt, OffsetDateTime deletedAt) {
        this.verificationId = verificationId;
        this.appId = appId;
        this.decision = decision;
        this.decisionDate = decisionDate;
        this.officer = officer;
        this.remarks = remarks;
        this.infoRequested = infoRequested;
        this.infoRequestDetails = infoRequestDetails;
        this.infoRequestedAt = infoRequestedAt;
        this.deletedAt = deletedAt;
    }

    public Long getVerificationId() {
        return verificationId;
    }
    public void setVerificationId(Long verificationId) {
        this.verificationId = verificationId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getDecision() {
        return decision;
    }
    public void setDecision(String decision) {
        this.decision = decision;
    }
    public OffsetDateTime getDecisionDate() {
        return decisionDate;
    }
    public void setDecisionDate(OffsetDateTime decisionDate) {
        this.decisionDate = decisionDate;
    }
    public String getOfficer() {
        return officer;
    }
    public void setOfficer(String officer) {
        this.officer = officer;
    }
    public String getRemarks() {
        return remarks;
    }
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    public Boolean isInfoRequested() {
        return infoRequested;
    }
    public void setInfoRequested(Boolean infoRequested) {
        this.infoRequested = infoRequested;
    }
    public String getInfoRequestDetails() {
        return infoRequestDetails;
    }
    public void setInfoRequestDetails(String infoRequestDetails) {
        this.infoRequestDetails = infoRequestDetails;
    }
    public OffsetDateTime getInfoRequestedAt() {
        return infoRequestedAt;
    }
    public void setInfoRequestedAt(OffsetDateTime infoRequestedAt) {
        this.infoRequestedAt = infoRequestedAt;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private Long verificationId;
        private String appId;
        private String decision;
        private OffsetDateTime decisionDate;
        private String officer;
        private String remarks;
        private Boolean infoRequested = false;
        private String infoRequestDetails;
        private OffsetDateTime infoRequestedAt;
        private OffsetDateTime deletedAt;

        public Builder verificationId(Long verificationId) {
            this.verificationId = verificationId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder decision(String decision) {
            this.decision = decision;
            return this;
        }
        public Builder decisionDate(OffsetDateTime decisionDate) {
            this.decisionDate = decisionDate;
            return this;
        }
        public Builder officer(String officer) {
            this.officer = officer;
            return this;
        }
        public Builder remarks(String remarks) {
            this.remarks = remarks;
            return this;
        }
        public Builder infoRequested(Boolean infoRequested) {
            this.infoRequested = infoRequested;
            return this;
        }
        public Builder infoRequestDetails(String infoRequestDetails) {
            this.infoRequestDetails = infoRequestDetails;
            return this;
        }
        public Builder infoRequestedAt(OffsetDateTime infoRequestedAt) {
            this.infoRequestedAt = infoRequestedAt;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public LegalVerification build() {
            return new LegalVerification(verificationId, appId, decision, decisionDate, officer, remarks, infoRequested, infoRequestDetails, infoRequestedAt, deletedAt);
        }
    }
}