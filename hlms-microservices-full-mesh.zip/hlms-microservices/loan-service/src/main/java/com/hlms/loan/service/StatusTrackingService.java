package com.hlms.loan.service;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hlms.loan.client.DocumentStatusClient;
import com.hlms.loan.client.DocumentStatusResponse;
import com.hlms.loan.client.LegalVerificationClient;
import com.hlms.loan.client.LegalStatusResponse;
import com.hlms.loan.client.RepaymentSummaryClient;
import com.hlms.loan.client.RepaymentSummaryResponse;
import com.hlms.loan.client.UserClient;
import com.hlms.loan.client.UserSummaryResponse;
import com.hlms.loan.dto.*;
import com.hlms.loan.entity.AuditLog;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.repository.BankOfficeDecisionRepository;
import com.hlms.loan.repository.DisbursementRepository;
import com.hlms.loan.repository.LegalVerificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.time.Duration;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
/**
 * Fills the "5. Loan Status Tracking & Workflow Visibility" gaps
 * (US-LT-03 stakeholder, US-LT-05 expected completion, US-LT-06 timeline,
 * US-LT-07 turnaround/SLA) WITHOUT any new table or column.
 *
 * Everything here is derived at read-time from data that already exists:
 *  - the audit_log rows LoanApplicationService now writes on CREATE/SUBMIT/STAGE_CHANGE
 *  - legal_verification.officer / bank_office_decision.officer / disbursement presence
 *  - a static in-app SLA-days-per-stage table (a business rule, not data)
 */
@Service
public class StatusTrackingService {
    private static final Logger log = LoggerFactory.getLogger(StatusTrackingService.class);

    private final LoanApplicationService loanApplicationService;
    private final AuditService auditService;
    private final LegalVerificationRepository legalVerificationRepository;
    private final BankOfficeDecisionRepository bankOfficeDecisionRepository;
    private final DisbursementRepository disbursementRepository;
    private final ObjectMapper objectMapper;
    private final UserClient userClient;
    private final DocumentStatusClient documentStatusClient;
    private final LegalVerificationClient legalVerificationClient;
    private final RepaymentSummaryClient repaymentSummaryClient;
    // Index-aligned with LoanApplicationService.WORKFLOW_STAGES:
    // Draft, Submitted, Document Verification, Legal Verification, Bank Office Decision, Disbursement, Active
    private static final int[] SLA_DAYS_PER_STAGE = {0, 2, 3, 5, 3, 2, 0};
    // ---------------------------------------------------------------- US-LT-03
    public StakeholderInfo currentStakeholder(String appId) {
        LoanApplication app = loanApplicationService.get(appId);
        List<String> stages = loanApplicationService.workflowStages();
        String stageName = stageNameOf(stages, app.getStageIndex());
        if (disbursementRepository.findByAppIdAndDeletedAtIsNull(appId).isPresent() || app.getStageIndex() >= 5) {
            return new StakeholderInfo(appId, stageName, "bankoffice", null,
                    "Disbursement / post-approval processing team.");
        }
        if (app.getStageIndex() >= 4) {
            var decision = bankOfficeDecisionRepository.findByAppIdAndDeletedAtIsNull(appId).orElse(null);
            return new StakeholderInfo(appId, stageName, "bankoffice",
                    decision != null ? decision.getOfficer() : null,
                    "Awaiting the bank office's final decision.");
        }
        if (app.getStageIndex() >= 2) {
            var verification = legalVerificationRepository.findByAppIdAndDeletedAtIsNull(appId).orElse(null);
            return new StakeholderInfo(appId, stageName, "legal",
                    verification != null ? verification.getOfficer() : null,
                    "With the legal team for document/title verification.");
        }
        if (app.getStageIndex() == 1) {
            return new StakeholderInfo(appId, stageName, "admin", null,
                    "Submitted; queued for initial processing.");
        }
        return new StakeholderInfo(appId, stageName, "customer", app.getUserEmail(),
                "Still a draft - awaiting the customer to complete and submit it.");
    }
    // ---------------------------------------------------------------- US-LT-06
    public WorkflowTimelineResponse timeline(String appId) {
        LoanApplication app = loanApplicationService.get(appId);
        List<String> stages = loanApplicationService.workflowStages();
        List<AuditLog> events = auditService.historyChronological("loan_application", appId);
        List<StageTimelineEntry> entries = new ArrayList<>();
        for (AuditLog e : events) {
            Integer stageIndex = extractStageIndex(e.getAfterData());
            entries.add(new StageTimelineEntry(
                    stageIndex != null ? stageIndex : -1,
                    stageIndex != null ? stageNameOf(stages, stageIndex) : e.getAction(),
                    "completed",
                    e.getCreatedAt(),
                    e.getActorEmail(),
                    e.getAction()
            ));
        }
        for (int i = 0; i < stages.size(); i++) {
            boolean alreadyListed = entries.stream().anyMatch(t -> t.stageIndex() == i);
            if (!alreadyListed) {
                entries.add(new StageTimelineEntry(i, stages.get(i),
                        i == app.getStageIndex() ? "current" : (i < app.getStageIndex() ? "completed" : "upcoming"),
                        null, null, null));
            }
        }
        entries.sort((a, b) -> Integer.compare(a.stageIndex(), b.stageIndex()));
        return new WorkflowTimelineResponse(appId, app.getStageIndex(), app.getStatus(), entries);
    }
    // ---------------------------------------------------------------- US-LT-05
    public ExpectedCompletion expectedCompletion(String appId) {
        LoanApplication app = loanApplicationService.get(appId);
        List<String> stages = loanApplicationService.workflowStages();
        int stageIndex = Math.min(app.getStageIndex(), SLA_DAYS_PER_STAGE.length - 1);
        int slaDays = SLA_DAYS_PER_STAGE[stageIndex];
        OffsetDateTime stageEnteredAt = lastTransitionTimestamp(appId, app);
        LocalDate expected = stageEnteredAt.plusDays(slaDays).toLocalDate();
        long daysElapsed = Duration.between(stageEnteredAt, OffsetDateTime.now()).toDays();
        int remaining = (int) Math.max(0, slaDays - daysElapsed);
        return new ExpectedCompletion(appId, app.getStageIndex(), stageNameOf(stages, app.getStageIndex()),
                expected, remaining);
    }
    // ---------------------------------------------------------------- US-LT-07
    /** Per-application list of how long each stage transition took. */
    public List<TurnaroundReportEntry> turnaroundReport(String appId) {
        List<String> stages = loanApplicationService.workflowStages();
        List<AuditLog> events = auditService.historyChronological("loan_application", appId);
        List<TurnaroundReportEntry> report = new ArrayList<>();
        AuditLog previous = null;
        for (AuditLog e : events) {
            if (previous != null) {
                Integer fromStage = extractStageIndex(previous.getAfterData());
                Integer toStage = extractStageIndex(e.getAfterData());
                double hours = Duration.between(previous.getCreatedAt(), e.getCreatedAt()).toMinutes() / 60.0;
                report.add(new TurnaroundReportEntry(appId,
                        fromStage != null ? stageNameOf(stages, fromStage) : previous.getAction(),
                        toStage != null ? stageNameOf(stages, toStage) : e.getAction(),
                        Math.round(hours * 100.0) / 100.0));
            }
            previous = e;
        }
        return report;
    }
    /** Bank-wide average turnaround per stage transition, for managers (US-LT-07). */
    public Map<String, Double> averageTurnaroundAcrossApplications() {
        Map<String, List<Double>> buckets = new LinkedHashMap<>();
        for (LoanApplication app : loanApplicationService.listAll()) {
            for (TurnaroundReportEntry entry : turnaroundReport(app.getAppId())) {
                String key = entry.fromStage() + " -> " + entry.toStage();
                buckets.computeIfAbsent(key, k -> new ArrayList<>()).add(entry.hoursTaken());
            }
        }
        Map<String, Double> averages = new LinkedHashMap<>();
        buckets.forEach((key, values) -> {
            double avg = values.stream().mapToDouble(Double::doubleValue).average().orElse(0);
            averages.put(key, Math.round(avg * 100.0) / 100.0);
        });
        return averages;
    }
    // ---------------------------------------------------------------- cross-service overview
    /**
     * Aggregates a live snapshot of this application from every other business
     * service via their Feign clients (see com.hlms.loan.client). Each call is
     * independent and best-effort: if one callee is down or has nothing to
     * report yet, that section of the overview is simply null rather than
     * failing the whole response.
     */
    public ApplicationOverview crossServiceOverview(String appId) {
        LoanApplication app = loanApplicationService.get(appId);

        UserSummaryResponse applicant = safeCall(() -> userClient.getUser(app.getUserEmail()),
                "user-service", appId);
        DocumentStatusResponse documentStatus = safeCall(() -> documentStatusClient.getStatus(appId),
                "document-service", appId);
        LegalStatusResponse legalStatus = safeCall(() -> legalVerificationClient.getStatus(appId),
                "legal-service", appId);
        RepaymentSummaryResponse repaymentStatus = safeCall(() -> repaymentSummaryClient.getSummary(appId),
                "repayment-service", appId);

        return new ApplicationOverview(appId, app.getStatus(), applicant, documentStatus, legalStatus, repaymentStatus);
    }

    private <T> T safeCall(java.util.function.Supplier<T> call, String service, String appId) {
        try {
            return call.get();
        } catch (Exception ex) {
            log.warn("Cross-service call to {} failed while building overview for {}: {}", service, appId, ex.getMessage());
            return null;
        }
    }

    // ---------------------------------------------------------------- helpers
    private OffsetDateTime lastTransitionTimestamp(String appId, LoanApplication app) {
        List<AuditLog> events = auditService.history("loan_application", appId); // newest first
        for (AuditLog e : events) {
            Integer stageIndex = extractStageIndex(e.getAfterData());
            if (stageIndex != null && stageIndex.equals(app.getStageIndex())) {
                return e.getCreatedAt();
            }
        }
        return app.getCreatedAt() != null ? app.getCreatedAt() : OffsetDateTime.now(ZoneOffset.UTC);
    }
    private String stageNameOf(List<String> stages, int index) {
        if (index < 0 || index >= stages.size()) return "Unknown";
        return stages.get(index);
    }
    private Integer extractStageIndex(String jsonAfterData) {
        if (jsonAfterData == null) return null;
        try {
            JsonNode node = objectMapper.readTree(jsonAfterData).get("stageIndex");
            return node != null && node.isInt() ? node.asInt() : null;
        } catch (Exception ex) {
            return null;
        }
    }

    public StatusTrackingService(LoanApplicationService loanApplicationService, AuditService auditService, LegalVerificationRepository legalVerificationRepository, BankOfficeDecisionRepository bankOfficeDecisionRepository, DisbursementRepository disbursementRepository, ObjectMapper objectMapper, UserClient userClient, DocumentStatusClient documentStatusClient, LegalVerificationClient legalVerificationClient, RepaymentSummaryClient repaymentSummaryClient) {
        this.loanApplicationService = loanApplicationService;
        this.auditService = auditService;
        this.legalVerificationRepository = legalVerificationRepository;
        this.bankOfficeDecisionRepository = bankOfficeDecisionRepository;
        this.disbursementRepository = disbursementRepository;
        this.objectMapper = objectMapper;
        this.userClient = userClient;
        this.documentStatusClient = documentStatusClient;
        this.legalVerificationClient = legalVerificationClient;
        this.repaymentSummaryClient = repaymentSummaryClient;
    }
}