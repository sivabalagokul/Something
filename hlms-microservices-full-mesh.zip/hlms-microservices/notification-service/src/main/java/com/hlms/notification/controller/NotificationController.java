package com.hlms.notification.controller;
import com.hlms.notification.entity.Notification;
import com.hlms.notification.service.NotificationService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
/** Feature 8: Notification & Communication Management (US-NM-01..05) */
@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final NotificationService service;
    @PostMapping
    public Notification send(@RequestBody Map<String, Object> body) {
        @SuppressWarnings("unchecked")
        List<String> channels = (List<String>) body.get("channels");
        return service.send((String) body.get("userEmail"), (String) body.get("title"), (String) body.get("body"), channels);
    }
    @GetMapping
    public List<Notification> listForUser(@RequestParam String userEmail) {
        return service.listForUser(userEmail);
    }
    // Cross-cutting: paginated/sortable variant, e.g. GET /api/notifications/page?userEmail=...&page=0&size=20&sort=createdAt,desc
    @GetMapping("/page")
    public Page<Notification> listForUserPaged(@RequestParam String userEmail,
                                                @PageableDefault(size = 20) Pageable pageable) {
        return service.listForUser(userEmail, pageable);
    }
    @GetMapping("/unread")
    public List<Notification> unread(@RequestParam String userEmail) {
        return service.listUnread(userEmail);
    }
    @PatchMapping("/{notificationId}/read")
    public Notification markRead(@PathVariable String notificationId) {
        return service.markRead(notificationId);
    }

    public NotificationController(NotificationService service) {
        this.service = service;
    }
}