package com.hlms.notification.entity;
import jakarta.persistence.*;
import java.time.OffsetDateTime;
@Entity
@Table(name = "service_request")
public class ServiceRequest {
    @Id
    @Column(name = "request_id", length = 50)
    private String requestId;
    @Column(name = "ref_no", length = 50, nullable = false, unique = true)
    private String refNo;
    @Column(name = "app_id")
    private String appId;
    @Column(name = "user_email", nullable = false)
    private String userEmail;
    @Column(name = "request_type", length = 50, nullable = false)
    private String requestType;
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;
    @Column(name = "status", length = 30, nullable = false)
    private String status = "Requested";
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
    }

    public ServiceRequest() {
    }

    public ServiceRequest(String requestId, String refNo, String appId, String userEmail, String requestType, String description, String status, OffsetDateTime createdAt, OffsetDateTime deletedAt) {
        this.requestId = requestId;
        this.refNo = refNo;
        this.appId = appId;
        this.userEmail = userEmail;
        this.requestType = requestType;
        this.description = description;
        this.status = status;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }

    public String getRequestId() {
        return requestId;
    }
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    public String getRefNo() {
        return refNo;
    }
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getUserEmail() {
        return userEmail;
    }
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    public String getRequestType() {
        return requestType;
    }
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private String requestId;
        private String refNo;
        private String appId;
        private String userEmail;
        private String requestType;
        private String description;
        private String status = "Requested";
        private OffsetDateTime createdAt;
        private OffsetDateTime deletedAt;

        public Builder requestId(String requestId) {
            this.requestId = requestId;
            return this;
        }
        public Builder refNo(String refNo) {
            this.refNo = refNo;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder userEmail(String userEmail) {
            this.userEmail = userEmail;
            return this;
        }
        public Builder requestType(String requestType) {
            this.requestType = requestType;
            return this;
        }
        public Builder description(String description) {
            this.description = description;
            return this;
        }
        public Builder status(String status) {
            this.status = status;
            return this;
        }
        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public ServiceRequest build() {
            return new ServiceRequest(requestId, refNo, appId, userEmail, requestType, description, status, createdAt, deletedAt);
        }
    }
}