package com.hlms.repayment.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Calls document-service's internal (service-to-service) endpoint. Checks document completeness/verification status from document-service for an appId this service already holds.
 * "document-service" is resolved via Eureka; see FeignClientConfig for the
 * internal API key header that authenticates this call.
 */
@FeignClient(name = "document-service", configuration = FeignClientConfig.class)
public interface DocumentStatusClient {

    @GetMapping("/internal/documents/application/{appId}/status")
    DocumentStatusResponse getStatus(@PathVariable("appId") String appId);
}
