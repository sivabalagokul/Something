package com.hlms.repayment.controller;
import com.hlms.repayment.dto.DefaultStatus;
import com.hlms.repayment.service.DefaultManagementService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
/** US-DMNG-04 Default Escalation Management, US-DMNG-05 Default Status Monitoring. */
@RestController
@RequestMapping("/api/default-management")
@PreAuthorize("hasAnyRole('BANKOFFICE','LEGAL','ADMIN')")
public class DefaultManagementController {
    private final DefaultManagementService service;
    @GetMapping("/status/{appId}")
    public DefaultStatus status(@PathVariable String appId) {
        return service.statusFor(appId);
    }
    @GetMapping("/overdue")
    public List<DefaultStatus> overdue() {
        return service.listOverdueApplications();
    }
    /** Manual trigger; the same logic also runs automatically via ReminderSchedulerService. */
    @PostMapping("/run-escalation")
    public List<DefaultStatus> runEscalation() {
        return service.runEscalationCheck();
    }

    public DefaultManagementController(DefaultManagementService service) {
        this.service = service;
    }
}