package com.hlms.repayment.entity;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
@Entity
@Table(name = "auction_case")
public class AuctionCase {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "auction_id")
    private Long auctionId;
    @Column(name = "app_id", nullable = false, unique = true)
    private String appId;
    @Column(name = "stage", length = 30, nullable = false)
    private String stage = "None"; // None, Notice Issued, Possession, Auction Scheduled, Resolved
    @Column(name = "notice_date")
    private LocalDate noticeDate;
    @Column(name = "notice_due_date")
    private LocalDate noticeDueDate;
    @Column(name = "demand_amount", precision = 14, scale = 2)
    private BigDecimal demandAmount;
    @Column(name = "possession_date")
    private LocalDate possessionDate;
    @Column(name = "auction_date")
    private LocalDate auctionDate;
    @Column(name = "reserve_price", precision = 14, scale = 2)
    private BigDecimal reservePrice;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public AuctionCase() {
    }

    public AuctionCase(Long auctionId, String appId, String stage, LocalDate noticeDate, LocalDate noticeDueDate, BigDecimal demandAmount, LocalDate possessionDate, LocalDate auctionDate, BigDecimal reservePrice, OffsetDateTime deletedAt) {
        this.auctionId = auctionId;
        this.appId = appId;
        this.stage = stage;
        this.noticeDate = noticeDate;
        this.noticeDueDate = noticeDueDate;
        this.demandAmount = demandAmount;
        this.possessionDate = possessionDate;
        this.auctionDate = auctionDate;
        this.reservePrice = reservePrice;
        this.deletedAt = deletedAt;
    }

    public Long getAuctionId() {
        return auctionId;
    }
    public void setAuctionId(Long auctionId) {
        this.auctionId = auctionId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getStage() {
        return stage;
    }
    public void setStage(String stage) {
        this.stage = stage;
    }
    public LocalDate getNoticeDate() {
        return noticeDate;
    }
    public void setNoticeDate(LocalDate noticeDate) {
        this.noticeDate = noticeDate;
    }
    public LocalDate getNoticeDueDate() {
        return noticeDueDate;
    }
    public void setNoticeDueDate(LocalDate noticeDueDate) {
        this.noticeDueDate = noticeDueDate;
    }
    public BigDecimal getDemandAmount() {
        return demandAmount;
    }
    public void setDemandAmount(BigDecimal demandAmount) {
        this.demandAmount = demandAmount;
    }
    public LocalDate getPossessionDate() {
        return possessionDate;
    }
    public void setPossessionDate(LocalDate possessionDate) {
        this.possessionDate = possessionDate;
    }
    public LocalDate getAuctionDate() {
        return auctionDate;
    }
    public void setAuctionDate(LocalDate auctionDate) {
        this.auctionDate = auctionDate;
    }
    public BigDecimal getReservePrice() {
        return reservePrice;
    }
    public void setReservePrice(BigDecimal reservePrice) {
        this.reservePrice = reservePrice;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private Long auctionId;
        private String appId;
        private String stage = "None";
        private LocalDate noticeDate;
        private LocalDate noticeDueDate;
        private BigDecimal demandAmount;
        private LocalDate possessionDate;
        private LocalDate auctionDate;
        private BigDecimal reservePrice;
        private OffsetDateTime deletedAt;

        public Builder auctionId(Long auctionId) {
            this.auctionId = auctionId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder stage(String stage) {
            this.stage = stage;
            return this;
        }
        public Builder noticeDate(LocalDate noticeDate) {
            this.noticeDate = noticeDate;
            return this;
        }
        public Builder noticeDueDate(LocalDate noticeDueDate) {
            this.noticeDueDate = noticeDueDate;
            return this;
        }
        public Builder demandAmount(BigDecimal demandAmount) {
            this.demandAmount = demandAmount;
            return this;
        }
        public Builder possessionDate(LocalDate possessionDate) {
            this.possessionDate = possessionDate;
            return this;
        }
        public Builder auctionDate(LocalDate auctionDate) {
            this.auctionDate = auctionDate;
            return this;
        }
        public Builder reservePrice(BigDecimal reservePrice) {
            this.reservePrice = reservePrice;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public AuctionCase build() {
            return new AuctionCase(auctionId, appId, stage, noticeDate, noticeDueDate, demandAmount, possessionDate, auctionDate, reservePrice, deletedAt);
        }
    }
}