package com.hlms.repayment.entity;
import jakarta.persistence.*;
import java.time.OffsetDateTime;
@Entity
@Table(name = "auction_note")
public class AuctionNote {
    @Id
    @Column(name = "note_id", length = 50)
    private String noteId;
    // References auction_case.app_id (the FK target in the SQL schema is auction_case(app_id))
    @Column(name = "app_id", nullable = false)
    private String appId;
    @Column(name = "note_date", nullable = false)
    private OffsetDateTime noteDate;
    @Column(name = "note_text", columnDefinition = "TEXT", nullable = false)
    private String noteText;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
    @PrePersist
    public void prePersist() {
        if (noteDate == null) noteDate = OffsetDateTime.now();
    }

    public AuctionNote() {
    }

    public AuctionNote(String noteId, String appId, OffsetDateTime noteDate, String noteText, OffsetDateTime deletedAt) {
        this.noteId = noteId;
        this.appId = appId;
        this.noteDate = noteDate;
        this.noteText = noteText;
        this.deletedAt = deletedAt;
    }

    public String getNoteId() {
        return noteId;
    }
    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public OffsetDateTime getNoteDate() {
        return noteDate;
    }
    public void setNoteDate(OffsetDateTime noteDate) {
        this.noteDate = noteDate;
    }
    public String getNoteText() {
        return noteText;
    }
    public void setNoteText(String noteText) {
        this.noteText = noteText;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private String noteId;
        private String appId;
        private OffsetDateTime noteDate;
        private String noteText;
        private OffsetDateTime deletedAt;

        public Builder noteId(String noteId) {
            this.noteId = noteId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder noteDate(OffsetDateTime noteDate) {
            this.noteDate = noteDate;
            return this;
        }
        public Builder noteText(String noteText) {
            this.noteText = noteText;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public AuctionNote build() {
            return new AuctionNote(noteId, appId, noteDate, noteText, deletedAt);
        }
    }
}