package com.hlms.repayment.service;
import com.hlms.repayment.entity.AuctionCase;
import com.hlms.repayment.entity.AuctionNote;
import com.hlms.repayment.entity.Bid;
import com.hlms.repayment.exception.BadRequestException;
import com.hlms.repayment.exception.ResourceNotFoundException;
import com.hlms.repayment.repository.AuctionCaseRepository;
import com.hlms.repayment.repository.AuctionNoteRepository;
import com.hlms.repayment.repository.BidRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
/** Backs feature "11. Auction Management" (SARFAESI recovery workflow). */
@Service
public class AuctionService {
    private final AuctionCaseRepository auctionCaseRepository;
    private final AuctionNoteRepository auctionNoteRepository;
    private final BidRepository bidRepository;
    /** US-AM-01: an application is eligible for auction once a notice has been issued and gone unanswered. */
    public boolean isEligibleForAuction(AuctionCase auctionCase) {
        return auctionCase != null
                && List.of("Notice Issued", "Possession").contains(auctionCase.getStage())
                && auctionCase.getNoticeDueDate() != null
                && auctionCase.getNoticeDueDate().isBefore(LocalDate.now());
    }
    @Transactional
    public AuctionCase openCase(String appId) {
        return auctionCaseRepository.findByAppIdAndDeletedAtIsNull(appId)
                .orElseGet(() -> auctionCaseRepository.save(
                        AuctionCase.builder().appId(appId).stage("None").build()));
    }
    public AuctionCase get(String appId) {
        return auctionCaseRepository.findByAppIdAndDeletedAtIsNull(appId)
                .orElseThrow(() -> new ResourceNotFoundException("No auction case for app: " + appId));
    }
    /** US-AM-02: initiate the auction - only allowed for eligible cases. */
    @Transactional
    public AuctionCase scheduleAuction(String appId, LocalDate auctionDate, BigDecimal reservePrice) {
        AuctionCase auctionCase = get(appId);
        if (!isEligibleForAuction(auctionCase)) {
            throw new BadRequestException("This case is not yet eligible for auction (notice period must have lapsed).");
        }
        auctionCase.setStage("Auction Scheduled");
        auctionCase.setAuctionDate(auctionDate);
        auctionCase.setReservePrice(reservePrice);
        return auctionCaseRepository.save(auctionCase);
    }
    @Transactional
    public AuctionCase updateStage(String appId, String stage) {
        AuctionCase auctionCase = get(appId);
        auctionCase.setStage(stage);
        return auctionCaseRepository.save(auctionCase);
    }
    @Transactional
    public AuctionNote addNote(String appId, String noteText) {
        AuctionNote note = AuctionNote.builder()
                .noteId("ANOTE-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .appId(appId)
                .noteText(noteText)
                .build();
        return auctionNoteRepository.save(note);
    }
    public List<AuctionNote> listNotes(String appId) {
        return auctionNoteRepository.findByAppIdAndDeletedAtIsNullOrderByNoteDateDesc(appId);
    }
    /** US-AM-04: record a bid; recovery amount is derived from the highest bid once resolved. */
    @Transactional
    public Bid placeBid(String appId, String bidderEmail, BigDecimal bidAmount) {
        AuctionCase auctionCase = get(appId);
        if (!"Auction Scheduled".equals(auctionCase.getStage())) {
            throw new BadRequestException("Bidding is only open while the auction is in 'Auction Scheduled' stage.");
        }
        if (auctionCase.getReservePrice() != null && bidAmount.compareTo(auctionCase.getReservePrice()) < 0) {
            throw new BadRequestException("Bid amount must meet or exceed the reserve price.");
        }
        Bid bid = Bid.builder()
                .bidId("BID-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .appId(appId)
                .bidderEmail(bidderEmail)
                .bidAmount(bidAmount)
                .build();
        return bidRepository.save(bid);
    }
    public List<Bid> listBids(String appId) {
        return bidRepository.findByAppIdAndDeletedAtIsNullOrderByBidAmountDesc(appId);
    }
    /** US-AM-04: resolves the auction using the highest bid as the recovery amount. */
    @Transactional
    public AuctionCase resolve(String appId) {
        AuctionCase auctionCase = get(appId);
        List<Bid> bids = listBids(appId);
        if (bids.isEmpty()) {
            throw new BadRequestException("Cannot resolve an auction with no bids.");
        }
        auctionCase.setStage("Resolved");
        return auctionCaseRepository.save(auctionCase);
    }

    public AuctionService(AuctionCaseRepository auctionCaseRepository, AuctionNoteRepository auctionNoteRepository, BidRepository bidRepository) {
        this.auctionCaseRepository = auctionCaseRepository;
        this.auctionNoteRepository = auctionNoteRepository;
        this.bidRepository = bidRepository;
    }
}