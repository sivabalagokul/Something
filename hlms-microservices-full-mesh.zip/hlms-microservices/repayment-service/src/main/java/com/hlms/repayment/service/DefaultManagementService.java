package com.hlms.repayment.service;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hlms.repayment.dto.DefaultStatus;
import com.hlms.repayment.entity.AuditLog;
import com.hlms.repayment.entity.EmiInstallment;
import com.hlms.repayment.entity.LoanApplication;
import com.hlms.repayment.client.LegalNoticeClient;
import com.hlms.repayment.client.LegalNoticeRequest;
import com.hlms.repayment.client.NotificationClient;
import com.hlms.repayment.client.NotificationRequest;
import com.hlms.repayment.repository.EmiInstallmentRepository;
import com.hlms.repayment.repository.LoanApplicationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
/**
 * Backs feature "10. Default Management and Notice Generation" gaps:
 * US-DMNG-04 Default Escalation Management, US-DMNG-05 Default Status Monitoring.
 * (US-DMNG-01 overdue detection and US-DMNG-02/03 notice generation/tracking already
 * existed via EmiService.markOverdueInstallments() and LegalNoticeService.)
 *
 * No new table/column: escalation level is computed on every call from live
 * emi_installment rows, and "last level acted on" is read back from the audit_log
 * row this service itself writes (action = DEFAULT_ESCALATION) - the same pattern
 * StatusTrackingService uses for the workflow timeline.
 */
@Service
public class DefaultManagementService {
    private final EmiInstallmentRepository emiInstallmentRepository;
    private final LoanApplicationRepository loanApplicationRepository;
    private final NotificationClient notificationClient;
    private final LegalNoticeClient legalNoticeClient;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;
    /** US-DMNG-05: current default status for one application, computed live. */
    public DefaultStatus statusFor(String appId) {
        List<EmiInstallment> overdue = emiInstallmentRepository
                .findByAppIdAndDeletedAtIsNullOrderByInstallmentNoAsc(appId).stream()
                .filter(e -> "Overdue".equals(e.getStatus()))
                .toList();
        LoanApplication app = loanApplicationRepository.findById(appId).orElse(null);
        String userEmail = app != null ? app.getUserEmail() : null;
        if (overdue.isEmpty()) {
            return new DefaultStatus(appId, userEmail, 0, 0, 0, "Current", "No action required.");
        }
        long maxDaysOverdue = overdue.stream()
                .mapToLong(e -> ChronoUnit.DAYS.between(e.getDueDate(), LocalDate.now()))
                .max().orElse(0);
        return buildStatus(appId, userEmail, overdue.size(), maxDaysOverdue);
    }
    /** US-DMNG-05: default status across every application that currently has an overdue EMI. */
    public List<DefaultStatus> listOverdueApplications() {
        Map<String, List<EmiInstallment>> byApp = new LinkedHashMap<>();
        for (EmiInstallment e : emiInstallmentRepository.findByStatusAndDeletedAtIsNull("Overdue")) {
            byApp.computeIfAbsent(e.getAppId(), k -> new ArrayList<>()).add(e);
        }
        List<DefaultStatus> statuses = new ArrayList<>();
        for (var entry : byApp.entrySet()) {
            statuses.add(statusFor(entry.getKey()));
        }
        return statuses;
    }
    /** US-DMNG-04: runs escalation for every app with overdue EMIs, taking action only when
     *  the computed level is higher than the last level this service recorded for that app.
     *  Intended to be called by a scheduled sweep (see ReminderSchedulerService) or on demand. */
    @Transactional
    public List<DefaultStatus> runEscalationCheck() {
        List<DefaultStatus> escalated = new ArrayList<>();
        for (DefaultStatus status : listOverdueApplications()) {
            int lastLevel = lastRecordedEscalationLevel(status.appId());
            if (status.escalationLevel() > lastLevel) {
                applyEscalationAction(status);
                escalated.add(status);
            }
        }
        return escalated;
    }
    // ------------------------------------------------------------------ internals
    private DefaultStatus buildStatus(String appId, String userEmail, int overdueCount, long maxDaysOverdue) {
        int level;
        String label;
        String action;
        if (maxDaysOverdue >= 90) {
            level = 4; label = "Auction Referral";
            action = "Refer the mortgaged asset for SARFAESI possession/auction proceedings.";
        } else if (maxDaysOverdue >= 60) {
            level = 3; label = "Legal Notice Issued";
            action = "Issue a formal SARFAESI default notice via the legal team.";
        } else if (maxDaysOverdue >= 15) {
            level = 2; label = "Warning Notice";
            action = "Send a written warning notice; flag for bank officer review.";
        } else {
            level = 1; label = "Reminder";
            action = "Send a payment reminder to the customer.";
        }
        return new DefaultStatus(appId, userEmail, overdueCount, maxDaysOverdue, level, label, action);
    }
    private int lastRecordedEscalationLevel(String appId) {
        List<AuditLog> history = auditService.history("loan_application", appId); // newest first
        for (AuditLog log : history) {
            if (!"DEFAULT_ESCALATION".equals(log.getAction())) continue;
            try {
                JsonNode node = objectMapper.readTree(log.getAfterData()).get("escalationLevel");
                if (node != null) return node.asInt();
            } catch (Exception ignored) { /* fall through to keep scanning */ }
        }
        return 0;
    }
    private void applyEscalationAction(DefaultStatus status) {
        if (status.userEmail() != null) {
            notificationClient.send(new NotificationRequest(status.userEmail(),
                    "Overdue loan payment - " + status.escalationLabel(),
                    "Your loan application " + status.appId() + " has " + status.overdueInstallmentCount()
                            + " overdue installment(s), up to " + status.maxDaysOverdue() + " day(s) overdue. "
                            + status.recommendedAction(),
                    List.of("inapp", "sms", "email")));
        }
        if (status.escalationLevel() >= 3) {
            legalNoticeClient.generateNotice(new LegalNoticeRequest(status.appId(), "Default Notice", "system",
                    "Automatically generated: " + status.overdueInstallmentCount()
                            + " installment(s) overdue, up to " + status.maxDaysOverdue() + " days.",
                    LocalDate.now().plusDays(15).toString()));
        }
        auditService.record("loan_application", status.appId(), "DEFAULT_ESCALATION", "system",
                null,
                Map.of("escalationLevel", status.escalationLevel(),
                        "escalationLabel", status.escalationLabel(),
                        "overdueInstallmentCount", status.overdueInstallmentCount(),
                        "maxDaysOverdue", status.maxDaysOverdue()));
    }

    public DefaultManagementService(EmiInstallmentRepository emiInstallmentRepository, LoanApplicationRepository loanApplicationRepository, NotificationClient notificationClient, LegalNoticeClient legalNoticeClient, AuditService auditService, ObjectMapper objectMapper) {
        this.emiInstallmentRepository = emiInstallmentRepository;
        this.loanApplicationRepository = loanApplicationRepository;
        this.notificationClient = notificationClient;
        this.legalNoticeClient = legalNoticeClient;
        this.auditService = auditService;
        this.objectMapper = objectMapper;
    }
}