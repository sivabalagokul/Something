package com.hlms.user.dto;
import jakarta.validation.constraints.*;
public class RegisterRequest {
    @NotBlank @Email
    private String email;
    @NotBlank
    private String name;
    @NotBlank
    @Pattern(regexp = "\\d{10}", message = "mobile must be a 10-digit number")
    private String mobile;
    @NotBlank @Size(min = 8, message = "password must be at least 8 characters")
    private String password;
    @NotBlank
    private String role; // customer, legal, bankoffice, bidder, admin
    private String idType;
    private String idNumber;

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public String getIdType() {
        return idType;
    }
    public void setIdType(String idType) {
        this.idType = idType;
    }
    public String getIdNumber() {
        return idNumber;
    }
    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }
}