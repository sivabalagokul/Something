# hlms2 microservices

This is `repayment-service` wired up as a proper Spring Boot microservice,
plus the minimum infrastructure it needs to actually be one:

| Module            | Port | Role                                                              |
|--------------------|------|--------------------------------------------------------------------|
| `eureka-server`     | 8761 | Service registry - everything below registers here on startup.   |
| `config-server`      | 8888 | Centralised config (native/classpath-backed - no Git repo needed). |
| `api-gateway`        | 8080 | Single public entry point; routes `/api/**` to the owning service. |
| `user-service`       | 8081 | **Stub.** Owns `app_user`. Only `GET /api/users/{email}`.         |
| `loan-service`       | 8082 | **Stub.** Owns `loan_application`. Only `GET /api/loan-applications/{appId}`. |
| `repayment-service`  | 8085 | The full service you uploaded - EMI, auctions, bids, disbursements, insurance, audit log, default management. |

`user-service` and `loan-service` are intentionally minimal - just enough
for `repayment-service`'s Feign clients to have something real to call so
the whole system runs end to end. Your other 3 planned services (legal,
notification, eligibility) aren't included since I don't have their code;
follow the exact same pattern (`pom.xml` deps + `application.properties`
block) shown in `user-service`/`loan-service` to add them, and they'll be
discoverable through Eureka and routable through the gateway automatically.

## What changed in `repayment-service`

It used to read `app_user` and `loan_application` directly via local JPA
entities/repositories, even though it doesn't own either table - a
shared-database read across service boundaries. That's now:

- `client/UserServiceClient` / `client/LoanServiceClient` - Feign
  interfaces resolved through Eureka by application name (`user-service`,
  `loan-service`), not a hardcoded host:port.
- `client/dto/UserDTO` / `client/dto/LoanApplicationDTO` - the wire
  contract, kept intentionally thin (e.g. no password hash).
- `client/fallback/*FallbackFactory` - if user-service/loan-service can't
  be reached at all (as opposed to answering with a normal 404), calls
  fail closed with a `DownstreamServiceException` → HTTP 503, instead of
  silently letting a bid or audit-log entry through unchecked.

`BidServiceImpl` and `AuditLogServiceImpl` were updated to call the Feign
clients instead of the old repositories; every validation rule and all
other business logic is untouched. No Lombok anywhere in any module -
every class uses plain, explicit getters/setters/constructors.

## Running it locally

1. Load `schema/hlms_schema_combined_v3.sql` into Postgres (`hlms` DB) -
   same one file backs `repayment-service`, `user-service`, and
   `loan-service`; each only touches its own tables.
2. Update the `spring.datasource.*` values in each service's
   `application.properties` if your Postgres credentials differ.
3. Start in this order (each is a normal Maven module - `mvn spring-boot:run`,
   or Eclipse's **Run As → Spring Boot App** per project):
   1. `eureka-server` - wait for it to come up on 8761.
   2. `config-server` - 8888.
   3. `user-service`, `loan-service`, `repayment-service` - any order, once
      Eureka is up. Each takes ~30s after `mvn spring-boot:run` to
      register (`eureka.instance.lease-renewal-interval-in-seconds=10`).
   4. `api-gateway` - 8080, last, once the others are registered.
4. Check registration: `http://localhost:8761` (Eureka dashboard) should
   list `REPAYMENT-SERVICE`, `USER-SERVICE`, `LOAN-SERVICE`, and
   `API-GATEWAY`.
5. Everything is now reachable through the gateway on port 8080, e.g.
   `http://localhost:8080/api/emi/installments`,
   `http://localhost:8080/api/bids`,
   `http://localhost:8080/api/users/someone@bank.com` - or still directly
   on each service's own port during development.

If `eureka-server`/`config-server` aren't running yet, `repayment-service`,
`user-service`, and `loan-service` all still start fine on their own
(`spring.config.import=optional:configserver:...` and Eureka client
retries are both non-fatal) - they just won't be discoverable by name
until the registry comes up.

## Importing into Eclipse

**File → Import → Maven → Existing Maven Projects**, point at this
`hlms-microservices/` folder and check all 6 modules (they're independent
`pom.xml`s, not a Maven multi-module parent, so import them together in
one go). Same JDK 17 requirement as before.
