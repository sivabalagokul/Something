package com.hlms2.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

/**
 * Serves shared configuration to every hlms2 service. Each service's
 * spring.config.import=optional:configserver:http://localhost:8888 pulls
 * from here on startup; the "optional:" prefix means a service still
 * starts fine (using its own local application.properties) if this isn't
 * up yet.
 */
@SpringBootApplication
@EnableConfigServer
public class ConfigServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ConfigServerApplication.class, args);
    }
}
