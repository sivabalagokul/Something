package com.hlms2.loan.controller;

import com.hlms2.loan.dto.LoanApplicationDTO;
import com.hlms2.loan.entity.LoanApplication;
import com.hlms2.loan.exception.ResourceNotFoundException;
import com.hlms2.loan.repository.LoanApplicationRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Minimal read endpoint - this is the contract
 * com.hlms2.repayment.client.LoanServiceClient calls. Extend with the
 * rest of the "Digital Loan Application Management" backlog
 * (US-LA-01..06: submit, document upload/validation, review, tracking
 * number, drafts) as loan-service is built out for real.
 */
@RestController
@RequestMapping("/api/loan-applications")
public class LoanApplicationController {

    private final LoanApplicationRepository repository;

    public LoanApplicationController(LoanApplicationRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/{appId}")
    public LoanApplicationDTO getByAppId(@PathVariable String appId) {
        LoanApplication app = repository.findById(appId)
                .orElseThrow(() -> new ResourceNotFoundException("No loan_application with app_id " + appId));
        return new LoanApplicationDTO(
                app.getAppId(),
                app.getTrackingNo(),
                app.getUserEmail(),
                app.getProductId(),
                app.getLoanAmount(),
                app.getTenureYears(),
                app.getStatus(),
                app.getStageIndex(),
                app.getDeletedAt() != null
        );
    }
}
