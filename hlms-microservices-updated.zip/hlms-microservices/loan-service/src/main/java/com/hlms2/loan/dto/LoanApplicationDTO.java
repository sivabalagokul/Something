package com.hlms2.loan.dto;

import java.math.BigDecimal;

/**
 * Wire format returned by GET /api/loan-applications/{appId}. Field
 * names/semantics must stay in lockstep with repayment-service's
 * com.hlms2.repayment.client.dto.LoanApplicationDTO.
 */
public class LoanApplicationDTO {

    private String appId;
    private String trackingNo;
    private String userEmail;
    private String productId;
    private BigDecimal loanAmount;
    private Integer tenureYears;
    private String status;
    private Integer stageIndex;
    private Boolean deleted;

    public LoanApplicationDTO() {
    }

    public LoanApplicationDTO(String appId, String trackingNo, String userEmail, String productId,
                               BigDecimal loanAmount, Integer tenureYears, String status,
                               Integer stageIndex, Boolean deleted) {
        this.appId = appId;
        this.trackingNo = trackingNo;
        this.userEmail = userEmail;
        this.productId = productId;
        this.loanAmount = loanAmount;
        this.tenureYears = tenureYears;
        this.status = status;
        this.stageIndex = stageIndex;
        this.deleted = deleted;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    public Integer getTenureYears() {
        return tenureYears;
    }

    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getStageIndex() {
        return stageIndex;
    }

    public void setStageIndex(Integer stageIndex) {
        this.stageIndex = stageIndex;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
}
