package com.hlms2.loan.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * JPA entity for 'loan_application' - loan-service is the one service
 * that's actually allowed to own this table now (repayment-service used
 * to read it directly; that shared-database read is what this stub
 * replaces via LoanServiceClient). Trimmed to the columns
 * repayment-service's LoanApplicationDTO contract needs.
 */
@Entity
@Table(name = "loan_application")
public class LoanApplication {

    @Id
    @Column(name = "app_id", length = 50)
    private String appId;

    @Column(name = "tracking_no", length = 50)
    private String trackingNo;

    @Column(name = "user_email")
    private String userEmail;

    @Column(name = "product_id")
    private String productId;

    @Column(name = "loan_amount")
    private BigDecimal loanAmount;

    @Column(name = "tenure_years")
    private Integer tenureYears;

    @Column(name = "status", length = 30)
    private String status;

    @Column(name = "stage_index")
    private Integer stageIndex;

    @Column(name = "created_at")
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public LoanApplication() {
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    public Integer getTenureYears() {
        return tenureYears;
    }

    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getStageIndex() {
        return stageIndex;
    }

    public void setStageIndex(Integer stageIndex) {
        this.stageIndex = stageIndex;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }
}
