# Changes made for Eclipse

The original project relied on **Lombok** (`@Getter`, `@Setter`, `@NoArgsConstructor`,
`@AllArgsConstructor`, `@Builder`, `@RequiredArgsConstructor`) to generate boilerplate
at compile time. That only works in Eclipse if the Lombok jar is installed into
Eclipse itself (`java -jar lombok.jar` -> pick your `eclipse.exe` -> restart), and it's
a common source of "cannot find symbol" errors on getters/setters/builders if that
step was skipped or the Eclipse Maven project wasn't refreshed afterwards.

To remove that dependency entirely, every class that used Lombok has been rewritten
with plain, explicit Java:

- All **entity** classes (`entity/*.java`) and **DTO** classes (`dto/*.java`):
  Lombok's `@Getter/@Setter/@NoArgsConstructor/@AllArgsConstructor/@Builder` were
  replaced with hand-written getters, setters, a no-arg constructor, an all-args
  constructor, and a `Builder` inner class with the exact same fluent API
  (`Xxx.builder().field(value)...build()`) that Lombok would have generated - so
  none of the service/controller code that calls `.builder()...build()` needed to
  change.
- All **controller** and **serviceimpl** classes: `@RequiredArgsConstructor` was
  replaced with an explicit constructor injecting the same `final` fields.
- `ApiError.java`: same treatment (explicit constructor + getters).
- The `lombok` dependency and the matching `spring-boot-maven-plugin` exclude
  block were removed from `pom.xml`, since nothing in the code needs it anymore.

## To run in Eclipse

1. `File -> Import -> Maven -> Existing Maven Projects`, point it at the
   `repayment-service` folder (the one with `pom.xml`).
2. Right-click the project -> `Maven -> Update Project...` (check "Force Update").
3. Make sure Eclipse is using a JDK 17+ (`Window -> Preferences -> Java ->
   Installed JREs`), and the project's `Java Build Path` / `Java Compiler`
   compliance level is set to 17.
4. Update `src/main/resources/application.properties` with your local Postgres
   credentials/DB name if they differ from the defaults, and make sure the
   `hlms_schema_combined_v3.sql` schema (in `../schema/`) has been loaded into
   that database first (`spring.jpa.hibernate.ddl-auto=validate` means Hibernate
   won't create the tables for you).
5. Run `Hlms2RepaymentServiceApplication.java` as a **Java Application** (or
   right-click the project -> `Run As -> Spring Boot App` if you have STS).

No Lombok installation step is required any more.

## Unit tests (JUnit 5 + Mockito)

`src/test/java/.../serviceimpl/` now has a test class for every one of the 7
service implementations (`AuctionCaseServiceImplTest`, `AuctionNoteServiceImplTest`,
`AuditLogServiceImplTest`, `BidServiceImplTest`, `DisbursementServiceImplTest`,
`EmiInstallmentServiceImplTest`, `InsurancePolicyServiceImplTest`), plus a
`ValidatorsTest` for the shared validation helper - **181 test methods** in total.
Each service's repository dependency is mocked with Mockito
(`@ExtendWith(MockitoExtension.class)`, `@Mock`, `@InjectMocks`-style manual wiring),
so no real database is needed to run them.

Every test class follows the same **positive / negative / edge** pattern for each
public method:
- **Positive** - the happy path (valid input, entity found, business rule satisfied).
- **Negative** - invalid input, missing required fields, duplicate/not-found records,
  and every business-rule violation (e.g. a bid below the reserve price, an EMI whose
  principal + interest don't add up, an auction date before the possession date).
- **Edge** - boundary conditions (empty lists, null optional fields, values exactly at
  a threshold, first-bid-with-no-prior-bids, already-restored records, etc).

To run them and get a coverage report:

```
mvn test
```

or in Eclipse: right-click the project → `Run As → Maven test` (or select the
`src/test/java` folder → `Run As → JUnit Test`).

### Coverage

The `pom.xml` now also has the **JaCoCo** plugin wired in with an 85% line-coverage
gate (`mvn test` will fail the build if coverage on the service layer drops below
85%). The check only applies to the service layer (`serviceimpl` + `exception`
helpers) - entities, DTOs, repositories, controllers and the `@SpringBootApplication`
class are excluded, since those are either pure boilerplate or would need a full
Spring context / DB to test meaningfully. After running `mvn test`, an HTML report is
generated at:

```
target/site/jacoco/index.html
```

Open that file in a browser to see the exact line/branch coverage per class.

