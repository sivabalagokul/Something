# repayment-service

Spring Boot port of the repayment domain (`emi_installment`, `auction_case`,
`auction_note`, `bid`, `disbursement`, `insurance_policy`, `audit_log`).
Runs on **port 8085**.

See the root [`../README.md`](../README.md) for how this fits together
with the other 5 services (Eureka, Config Server, API Gateway,
user-service, loan-service) and how to run the whole system.

## What changed vs. the original upload

- **Registers with Eureka** (`@EnableDiscoveryClient`) and pulls optional
  overlay config from Config Server
  (`spring.config.import=optional:configserver:http://localhost:8888`).
- **No more direct reads of `app_user` / `loan_application`.** Those
  tables are owned by `user-service` / `loan-service`; this service now
  calls them over Feign (`client/UserServiceClient`,
  `client/LoanServiceClient`) instead of joining against them locally.
  See `client/` for the Feign interfaces, DTOs, and fallback factories,
  and `exception/DownstreamServiceException` for how an unreachable
  dependency (as opposed to a normal 404) is surfaced as HTTP 503.
- `BidServiceImpl` and `AuditLogServiceImpl` were updated to call
  `UserServiceClient` instead of the old `AppUserRepository`. Every
  validation rule, escalation-tier calculation, and ID-generation scheme
  is otherwise untouched - see the Javadoc on each `*ServiceImpl` class.
- **Still no Lombok** - see `ECLIPSE_NOTES.md` (unchanged from the
  original upload; this was already true before these changes and stayed
  true after).

## Updated for hlms_schema_updated_v2.sql / combined v3 schema

1. **Surrogate PKs.** `auction_case` and `disbursement` have a real
   `BIGSERIAL` PK (`auction_id`, `disbursement_id`) instead of using
   `app_id` as the PK. `app_id` is a unique column on both, so
   `findByAppId(...)` / `GET .../by-application/{appId}` is how you look
   things up the old way; `update()` takes the surrogate id.
   `emi_installment`, `auction_note`, `bid`, `insurance_policy` keep
   their original natural-key PKs (`installment_id`, `note_id`, `bid_id`,
   `policy_id`) unchanged.
2. **Soft delete everywhere except `audit_log`.** Every other entity has
   `deletedAt`; `delete()` was renamed to `softDelete()` (sets
   `deleted_at = now()`), reads filter it out, and a matching `restore()`
   + `POST .../{id}/restore` endpoint undoes it. `audit_log` has **no**
   `deleted_at` column in the schema on purpose (append-only audit trail)
   - `AuditLogServiceImpl.delete()` is a genuine hard delete.
3. **Cascading soft delete on auctions.** The schema's
   `trg_cascade_soft_delete_auction_case` trigger automatically
   soft-deletes an auction case's `auction_note` and `bid` rows the
   moment `auction_case.deleted_at` is set - no extra code needed for
   that cascade to work correctly.

## Worth flagging (business-rule / seed-data mismatches, not silently fixed)

- `emi_installment.status` defaults to `'Due'` in the schema, but the
  original validation only allows `PENDING/PAID/OVERDUE`. Kept as-is -
  widen `VALID_STATUSES` in `EmiInstallmentServiceImpl` if `'Due'` should
  be valid.
- `emi_installment` has a `UNIQUE (app_id, installment_no)` constraint
  the original code never checked before inserting; a
  `DataIntegrityViolationException` handler in `GlobalExceptionHandler`
  turns a duplicate insert into a clean 409 instead of a raw DB stack
  trace.

## How to run in Eclipse

1. **File → Import → Maven → Existing Maven Projects**, point at this
   `repayment-service/` folder (or the whole `hlms-microservices/` parent
   to import every module at once).
2. Update `src/main/resources/application.properties` with your actual
   Postgres credentials.
3. Make sure `schema/hlms_schema_combined_v3.sql` has already been run
   against your database - `ddl-auto=validate` won't create tables.
4. Start `eureka-server` first (see root README) so this service can
   register.
5. Right-click `Hlms2RepaymentServiceApplication.java` → **Run As → Java
   Application** (or **Spring Boot App** with STS).
6. Test via `http://localhost:8085/api/emi/installments`,
   `/api/auctions`, `/api/default-management/overdue`,
   `/api/disbursements`, `/api/insurance-policies`, `/api/audit-log`,
   `/api/auction-notes`, `/api/bids` - or through the gateway on 8080.
