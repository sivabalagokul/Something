package com.hlms2.repayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Registers with Eureka ({@code @EnableDiscoveryClient}) and enables the
 * Feign clients in {@code com.hlms2.repayment.client} used to reach
 * user-service and loan-service ({@code @EnableFeignClients}).
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = "com.hlms2.repayment.client")
public class Hlms2RepaymentServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(Hlms2RepaymentServiceApplication.class, args);
    }
}
