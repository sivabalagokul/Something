package com.hlms2.repayment.client;

import com.hlms2.repayment.client.dto.LoanApplicationDTO;
import com.hlms2.repayment.client.fallback.LoanServiceClientFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Declarative REST client for loan-service, resolved through Eureka by
 * its {@code spring.application.name} ("loan-service"). Every table this
 * service owns (emi_installment, auction_case, disbursement, ...) has an
 * {@code app_id} foreign key into {@code loan_application}, which
 * loan-service owns; this replaces the old local, read-only
 * {@code LoanApplicationRepository} JPA mapping of that table.
 */
@FeignClient(
        name = "loan-service",
        path = "/api/loan-applications",
        fallbackFactory = LoanServiceClientFallbackFactory.class
)
public interface LoanServiceClient {

    @GetMapping("/{appId}")
    LoanApplicationDTO getByAppId(@PathVariable("appId") String appId);
}
