package com.hlms2.repayment.client;

import com.hlms2.repayment.client.dto.UserDTO;
import com.hlms2.repayment.client.fallback.UserServiceClientFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Declarative REST client for user-service, resolved through Eureka by
 * its {@code spring.application.name} ("user-service") rather than a
 * hardcoded host:port. Used to confirm {@code bid.bidder_email} /
 * {@code audit_log.actor_email} belong to a real, active user - the same
 * check that used to be a local join against the (shared) {@code app_user}
 * table via {@code AppUserRepository}.
 */
@FeignClient(
        name = "user-service",
        path = "/api/users",
        fallbackFactory = UserServiceClientFallbackFactory.class
)
public interface UserServiceClient {

    @GetMapping("/{email}")
    UserDTO getByEmail(@PathVariable("email") String email);
}
