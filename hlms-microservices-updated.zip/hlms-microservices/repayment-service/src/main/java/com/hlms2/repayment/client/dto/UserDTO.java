package com.hlms2.repayment.client.dto;

/**
 * Wire format for {@code GET /api/users/{email}} on user-service.
 *
 * Replaces the old local {@code AppUser} JPA entity - this service no
 * longer reads the {@code app_user} table directly. Only the fields
 * {@code BidServiceImpl} / {@code AuditLogServiceImpl} actually need are
 * kept; the password hash and anything else user-service owns internally
 * never crosses the wire.
 */
public class UserDTO {

    private String email;
    private String name;
    private String role;
    private Boolean active;
    private Boolean deleted;

    public UserDTO() {
    }

    public UserDTO(String email, String name, String role, Boolean active, Boolean deleted) {
        this.email = email;
        this.name = name;
        this.role = role;
        this.active = active;
        this.deleted = deleted;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    /** True only for a real, active, non-deleted user - the same check
     *  {@code AppUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull}
     *  used to do at the database layer. */
    public boolean isUsable() {
        return Boolean.TRUE.equals(active) && !Boolean.TRUE.equals(deleted);
    }
}
