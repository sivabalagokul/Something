package com.hlms2.repayment.client.fallback;

import com.hlms2.repayment.client.LoanServiceClient;
import com.hlms2.repayment.client.dto.LoanApplicationDTO;
import com.hlms2.repayment.exception.DownstreamServiceException;
import feign.FeignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

/**
 * Builds the fallback used when the circuit breaker trips on
 * {@link LoanServiceClient}. Same rule as
 * {@link UserServiceClientFallbackFactory}: a real 404 means "no such
 * application" (return null, caller treats it as not found); anything
 * else means loan-service itself is unreachable (503).
 */
@Component
public class LoanServiceClientFallbackFactory implements FallbackFactory<LoanServiceClient> {

    private static final Logger log = LoggerFactory.getLogger(LoanServiceClientFallbackFactory.class);

    @Override
    public LoanServiceClient create(Throwable cause) {
        return appId -> {
            if (cause instanceof FeignException.NotFound) {
                return null;
            }
            log.warn("loan-service unreachable while looking up '{}': {}", appId, cause.toString());
            throw new DownstreamServiceException(
                    "loan-service is currently unavailable; could not look up application " + appId);
        };
    }
}
