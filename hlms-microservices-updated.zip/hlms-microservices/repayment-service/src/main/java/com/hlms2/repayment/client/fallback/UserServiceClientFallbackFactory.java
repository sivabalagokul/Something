package com.hlms2.repayment.client.fallback;

import com.hlms2.repayment.client.UserServiceClient;
import com.hlms2.repayment.client.dto.UserDTO;
import com.hlms2.repayment.exception.DownstreamServiceException;
import feign.FeignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

/**
 * Builds the fallback used when the circuit breaker trips on
 * {@link UserServiceClient}. A genuine 404 from user-service ("no such
 * user") is treated as "not found" - the caller already handles a null
 * response that way. Anything else (timeout, connection refused, 5xx)
 * means user-service itself is unhealthy, which is surfaced as a 503
 * rather than silently letting the bid/audit-log entry through.
 */
@Component
public class UserServiceClientFallbackFactory implements FallbackFactory<UserServiceClient> {

    private static final Logger log = LoggerFactory.getLogger(UserServiceClientFallbackFactory.class);

    @Override
    public UserServiceClient create(Throwable cause) {
        return email -> {
            if (cause instanceof FeignException.NotFound) {
                return null;
            }
            log.warn("user-service unreachable while looking up '{}': {}", email, cause.toString());
            throw new DownstreamServiceException(
                    "user-service is currently unavailable; could not verify user " + email);
        };
    }
}
