package com.hlms2.repayment.config;

import feign.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Shared Feign configuration for every {@code @FeignClient} in this
 * service. {@code BASIC} logs the request method/URL, response status,
 * and execution time for each call to user-service / loan-service -
 * useful while wiring the services together without being as noisy as
 * {@code FULL}. Requires {@code logging.level.com.hlms2.repayment.client=DEBUG}
 * to actually print (Feign logging is silent otherwise).
 */
@Configuration
public class FeignConfig {

    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.BASIC;
    }
}
