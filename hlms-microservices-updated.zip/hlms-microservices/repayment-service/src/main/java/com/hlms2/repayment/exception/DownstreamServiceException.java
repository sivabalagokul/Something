package com.hlms2.repayment.exception;

/**
 * Raised by a Feign client fallback when the downstream microservice
 * (user-service, loan-service, ...) could not be reached at all - as
 * opposed to reaching it and getting a normal 404, which callers handle
 * as "not found" instead. Mapped to HTTP 503 by
 * {@link GlobalExceptionHandler}.
 */
public class DownstreamServiceException extends RuntimeException {

    public DownstreamServiceException(String message) {
        super(message);
    }
}
