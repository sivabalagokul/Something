package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.client.UserServiceClient;
import com.hlms2.repayment.client.dto.UserDTO;
import com.hlms2.repayment.dto.AuditLogDTO;
import com.hlms2.repayment.entity.AuditLog;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.exception.Validators;
import com.hlms2.repayment.repository.AuditLogRepository;
import com.hlms2.repayment.service.AuditLogService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Ported from hlms2.serviceimpl.AuditLogServiceImpl (plain JDBC version),
 * moved onto Spring Data JPA (AuditLogRepository). No update() at all
 * (see the service interface javadoc) - audit log rows are append-only,
 * mirroring US-LRM-05's "records cannot be modified without
 * authorization" for payment history. No soft delete either: audit_log
 * has no deleted_at column in the schema, so delete() here is a genuine
 * hard delete, exactly like the plain-Java version.
 *
 * CHG: actorEmail is now checked against user-service (a real, active
 * app_user, fetched over Feign via {@link UserServiceClient}) before a log
 * entry is accepted - the plain-Java version only required the field to be
 * non-blank, but audit_log.actor_email is a foreign key into
 * app_user(email). This used to be a local join against the (shared)
 * app_user table; now it's a REST call to the service that owns it.
 */
@Service
@Transactional
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogRepository repository;
    private final UserServiceClient userServiceClient;

    public AuditLogServiceImpl(AuditLogRepository repository, UserServiceClient userServiceClient) {
        this.repository = repository;
        this.userServiceClient = userServiceClient;
    }

    @Override
    public AuditLogDTO create(AuditLogDTO dto) {
        Validators.required(dto.getEntityType(), "entityType");
        Validators.required(dto.getEntityId(), "entityId");
        Validators.oneOf(dto.getAction(), "action", "CREATE", "UPDATE", "DELETE", "APPROVE", "REJECT", "LOGIN", "LOGOUT");
        Validators.required(dto.getActorEmail(), "actorEmail");
        UserDTO actor = userServiceClient.getByEmail(dto.getActorEmail());
        if (actor == null || !actor.isUsable()) {
            throw new ValidationException("actorEmail " + dto.getActorEmail() + " is not a known active app_user.");
        }

        AuditLog entity = toEntity(dto);
        entity.setCreatedAt(entity.getCreatedAt() == null ? OffsetDateTime.now() : entity.getCreatedAt());
        return toDto(repository.save(entity));
    }

    @Override
    public boolean delete(Long logId) {
        Validators.required(logId, "logId");
        if (!repository.existsById(logId)) {
            return false;
        }
        repository.deleteById(logId);
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public AuditLogDTO findById(Long logId) {
        Validators.required(logId, "logId");
        return repository.findById(logId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogDTO> findAll() {
        return repository.findAll().stream().map(this::toDto).toList();
    }

    private AuditLog toEntity(AuditLogDTO dto) {
        return AuditLog.builder()
                .logId(dto.getLogId())
                .entityType(dto.getEntityType())
                .entityId(dto.getEntityId())
                .action(dto.getAction())
                .actorEmail(dto.getActorEmail())
                .beforeData(dto.getBeforeData())
                .afterData(dto.getAfterData())
                .createdAt(dto.getCreatedAt())
                .build();
    }

    private AuditLogDTO toDto(AuditLog entity) {
        return AuditLogDTO.builder()
                .logId(entity.getLogId())
                .entityType(entity.getEntityType())
                .entityId(entity.getEntityId())
                .action(entity.getAction())
                .actorEmail(entity.getActorEmail())
                .beforeData(entity.getBeforeData())
                .afterData(entity.getAfterData())
                .createdAt(entity.getCreatedAt())
                .build();
    }
}
