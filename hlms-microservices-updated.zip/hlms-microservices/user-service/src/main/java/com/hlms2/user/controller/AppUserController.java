package com.hlms2.user.controller;

import com.hlms2.user.dto.UserDTO;
import com.hlms2.user.entity.AppUser;
import com.hlms2.user.exception.ResourceNotFoundException;
import com.hlms2.user.repository.AppUserRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Minimal read endpoint - this is the contract
 * com.hlms2.repayment.client.UserServiceClient calls. A 200 means the
 * email exists at all (active or not); repayment-service's own
 * UserDTO.isUsable() decides whether it's a real, active, non-deleted
 * user before accepting a bid/audit-log entry against it. A 404 here
 * means no such app_user row exists.
 *
 * Extend this controller with the rest of the "Authentication & User
 * Management" backlog (US-UM-01..05: registration, login/OTP, password
 * reset, profile management) as user-service is built out for real.
 */
@RestController
@RequestMapping("/api/users")
public class AppUserController {

    private final AppUserRepository repository;

    public AppUserController(AppUserRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/{email}")
    public UserDTO getByEmail(@PathVariable String email) {
        AppUser user = repository.findById(email)
                .orElseThrow(() -> new ResourceNotFoundException("No app_user with email " + email));
        return new UserDTO(
                user.getEmail(),
                user.getName(),
                user.getRole(),
                user.getActive(),
                user.getDeletedAt() != null
        );
    }
}
