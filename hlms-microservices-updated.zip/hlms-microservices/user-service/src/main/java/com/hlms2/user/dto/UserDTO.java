package com.hlms2.user.dto;

/**
 * Wire format returned by GET /api/users/{email}. Field names and
 * semantics must stay in lockstep with repayment-service's
 * com.hlms2.repayment.client.dto.UserDTO, since that's the contract
 * consumers rely on - never expose passwordHash here.
 */
public class UserDTO {

    private String email;
    private String name;
    private String role;
    private Boolean active;
    private Boolean deleted;

    public UserDTO() {
    }

    public UserDTO(String email, String name, String role, Boolean active, Boolean deleted) {
        this.email = email;
        this.name = name;
        this.role = role;
        this.active = active;
        this.deleted = deleted;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
}
