package com.hlms2.user.repository;

import com.hlms2.user.entity.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AppUserRepository extends JpaRepository<AppUser, String> {
    Optional<AppUser> findByEmailAndDeletedAtIsNull(String email);
}
