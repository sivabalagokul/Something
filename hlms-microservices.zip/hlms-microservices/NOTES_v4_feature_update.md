# HLMS Backend - Feature Update Notes (this session)

## Zero schema changes - confirmed
Nothing in `sql/` was touched. Every feature below is built entirely on tables/columns
that already existed (the v2 schema + the v3 additions for OTP/eligibility). The
techniques used instead of new tables/columns:

- **`audit_log`** (existed, unused before this session) is now written to by
  `AuditService`, and read back by `StatusTrackingService` and
  `DefaultManagementService` to reconstruct history/state that would normally need
  a dedicated table (stage timeline, "last escalation level", reminder de-dupe).
- **`loan_application.form_data`** (existing JSONB column) now also holds a
  `mortgageAssessment` and `propertyEvaluation` key, used as the "mortgage record"
  storage for Feature 6 - no `mortgage_assessment` table was added.
- **`loan_application.property_value` / `property_type`** (existing columns) are
  what property evaluation actually writes to.
- **Escalation level** (Feature 10) is *computed live* from `emi_installment.status`
  / `due_date` every time it's needed, rather than stored.

## What's new

| Feature | Files |
|---|---|
| Audit logging infrastructure | `service/AuditService.java`; wired into `LoanApplicationService` |
| 5. Status Tracking (stakeholder, expected completion, timeline, turnaround) | `service/StatusTrackingService.java`, `controller/StatusTrackingController.java`, `dto/StageTimelineEntry.java`, `dto/WorkflowTimelineResponse.java`, `dto/StakeholderInfo.java`, `dto/ExpectedCompletion.java`, `dto/TurnaroundReportEntry.java` |
| 6. Mortgage Requirement Calculation (entirely new) | `service/MortgageService.java`, `controller/MortgageController.java`, `dto/MortgageCalculationRequest.java`, `dto/MortgageCalculationResponse.java` |
| 8. Notifications - real dispatch seam + reminders | `service/NotificationGateway.java`, `service/LoggingNotificationGateway.java`, `service/ReminderSchedulerService.java`, `config/SchedulingConfig.java` |
| 9. Post-Disbursement document exchange | `service/PostDisbursementDocumentService.java`, `controller/PostDisbursementDocumentController.java` |
| 10. Default Management escalation/monitoring | `service/DefaultManagementService.java`, `controller/DefaultManagementController.java`, `dto/DefaultStatus.java` |
| Cross-cutting: pagination | `Page`/`Pageable` overloads added to `LoanApplicationRepository`/`Service`/`Controller` and `NotificationRepository`/`Service`/`Controller`, alongside the original (unbroken) endpoints |

## New endpoints (summary)

```
GET  /api/loan-applications/{appId}/stakeholder
GET  /api/loan-applications/{appId}/timeline
GET  /api/loan-applications/{appId}/expected-completion
GET  /api/loan-applications/{appId}/turnaround
GET  /api/loan-applications/turnaround-report          (ADMIN/BANKOFFICE)
GET  /api/loan-applications/all/page   ?page&size&sort
GET  /api/loan-applications/page       ?userEmail&page&size&sort

POST /api/mortgage/calculate
POST /api/mortgage/{appId}/calculate
POST /api/mortgage/{appId}/evaluate-property           (BANKOFFICE/LEGAL/ADMIN)
GET  /api/mortgage/{appId}

GET  /api/notifications/page           ?userEmail&page&size&sort

POST /api/post-disbursement-documents/{appId}/upload
GET  /api/post-disbursement-documents/{appId}
GET  /api/post-disbursement-documents/download/{pdDocId}
PATCH /api/post-disbursement-documents/{pdDocId}/verify
POST /api/post-disbursement-documents/{pdDocId}/share

GET  /api/default-management/status/{appId}            (BANKOFFICE/LEGAL/ADMIN)
GET  /api/default-management/overdue                    (BANKOFFICE/LEGAL/ADMIN)
POST /api/default-management/run-escalation             (BANKOFFICE/LEGAL/ADMIN)
```

Scheduled jobs (no endpoint - run automatically once the app is deployed):
- 08:00 daily - EMI due-soon reminders (US-NM-04)
- 00:30 daily - overdue sweep (US-DMNG-01)
- 01:00 daily - default escalation sweep (US-DMNG-04/05)

## Still open (be upfront about this)
- **Validation coverage**: added to the new Mortgage DTOs; not yet swept across every
  older DTO (`SubmitApplicationRequest`, etc.).
- **Integration/unit tests**: none added yet for the new services.
- **This project has not been compiled** in this environment (no internet access to
  pull Maven dependencies here), so please run `mvn clean compile` locally before
  relying on it - I've been careful with imports/types but a real compiler pass is
  the only way to be certain.
- Real SMS/email provider integration is still a logging stub
  (`LoggingNotificationGateway`) by design - plug in Twilio/SES/etc. by adding
  another `NotificationGateway` bean marked `@Primary`.
