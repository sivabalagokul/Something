package com.hlms.document.controller;

import com.hlms.document.entity.PostDisbursementDocument;
import com.hlms.document.service.PostDisbursementDocumentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/** US-PD-01..04: Post-Disbursement Service Management document exchange. */
@RestController
@RequestMapping("/api/post-disbursement-documents")
@RequiredArgsConstructor
public class PostDisbursementDocumentController {

    private final PostDisbursementDocumentService service;

    @PostMapping(value = "/{appId}/upload", consumes = "multipart/form-data")
    public PostDisbursementDocument upload(@PathVariable String appId,
                                            @RequestParam String docType,
                                            @RequestParam(required = false) String note,
                                            @RequestParam("file") MultipartFile file,
                                            @RequestParam(required = false) String uploadedBy) {
        return service.upload(appId, docType, note, file, uploadedBy);
    }

    @GetMapping("/{appId}")
    public List<PostDisbursementDocument> listForApp(@PathVariable String appId) {
        return service.listForApp(appId);
    }

    @GetMapping("/download/{pdDocId}")
    public ResponseEntity<byte[]> download(@PathVariable String pdDocId,
                                            @RequestParam(required = false) String downloadedBy) {
        PostDisbursementDocument doc = service.get(pdDocId);
        if (downloadedBy != null) {
            service.recordShare(pdDocId, downloadedBy, doc.getVerifiedBy());
        }
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + doc.getFileName() + "\"")
                .body(doc.getFileData());
    }

    @PatchMapping("/{pdDocId}/verify")
    public PostDisbursementDocument verify(@PathVariable String pdDocId, @RequestBody Map<String, String> body) {
        return service.verify(pdDocId, body.get("status"), body.get("verifiedBy"), body.get("remarks"));
    }

    @PostMapping("/{pdDocId}/share")
    public PostDisbursementDocument share(@PathVariable String pdDocId, @RequestBody Map<String, String> body) {
        return service.recordShare(pdDocId, body.get("sharedWithEmail"), body.get("sharedByEmail"));
    }
}
