package com.hlms.document.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "application_document")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ApplicationDocument {

    @Id
    @Column(name = "document_id", length = 50)
    private String documentId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "doc_type", length = 50, nullable = false)
    private String docType;

    @Column(name = "file_name", length = 255, nullable = false)
    private String fileName;

    // Excluded from default JSON responses - fetch via a dedicated download endpoint instead.
    @JsonIgnore
    @Lob
    @Column(name = "file_data", nullable = false)
    private byte[] fileData;

    @Column(name = "file_size")
    private Integer fileSize;

    @Column(name = "uploaded_at", nullable = false)
    private OffsetDateTime uploadedAt;

    @Column(name = "verification_status", length = 30, nullable = false)
    @Builder.Default
    private String verificationStatus = "Pending";

    @Column(name = "verified_by")
    private String verifiedBy;

    @Column(name = "verified_at")
    private OffsetDateTime verifiedAt;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @PrePersist
    public void prePersist() {
        if (uploadedAt == null) uploadedAt = OffsetDateTime.now();
    }
}
