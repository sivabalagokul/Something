package com.hlms.document.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "post_disbursement_document")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PostDisbursementDocument {

    @Id
    @Column(name = "pd_doc_id", length = 50)
    private String pdDocId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "doc_type", length = 80, nullable = false)
    private String docType;

    @Column(name = "file_name", length = 255, nullable = false)
    private String fileName;

    @JsonIgnore
    @Lob
    @Column(name = "file_data", nullable = false)
    private byte[] fileData;

    @Column(name = "file_size")
    private Integer fileSize;

    @Column(name = "note", columnDefinition = "TEXT")
    private String note;

    @Column(name = "status", length = 30, nullable = false)
    @Builder.Default
    private String status = "Pending";

    @Column(name = "uploaded_at", nullable = false)
    private OffsetDateTime uploadedAt;

    @Column(name = "verified_by")
    private String verifiedBy;

    @Column(name = "verified_at")
    private OffsetDateTime verifiedAt;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @PrePersist
    public void prePersist() {
        if (uploadedAt == null) uploadedAt = OffsetDateTime.now();
    }
}
