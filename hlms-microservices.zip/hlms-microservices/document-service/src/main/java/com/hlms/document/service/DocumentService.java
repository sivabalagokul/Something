package com.hlms.document.service;

import com.hlms.document.entity.ApplicationDocument;
import com.hlms.document.exception.BadRequestException;
import com.hlms.document.exception.ResourceNotFoundException;
import com.hlms.document.repository.ApplicationDocumentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

/** Backs US-LA-02 (Document Upload) and US-LA-03 (Document Validation). */
@Service
@RequiredArgsConstructor
public class DocumentService {

    private final ApplicationDocumentRepository repository;

    // Documents every application must have before it can move past review.
    private static final List<String> MANDATORY_DOC_TYPES = List.of("idProof", "incomeProof", "propertyDocs");

    @Transactional
    public ApplicationDocument upload(String appId, String docType, MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BadRequestException("No file was provided.");
        }
        byte[] data;
        try {
            data = file.getBytes();
        } catch (IOException e) {
            throw new BadRequestException("Could not read uploaded file: " + e.getMessage());
        }

        ApplicationDocument doc = ApplicationDocument.builder()
                .documentId("DOC-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase())
                .appId(appId)
                .docType(docType)
                .fileName(file.getOriginalFilename())
                .fileData(data)
                .fileSize((int) file.getSize())
                .verificationStatus("Pending")
                .build();
        return repository.save(doc);
    }

    public List<ApplicationDocument> listForApp(String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId);
    }

    public ApplicationDocument get(String documentId) {
        return repository.findById(documentId)
                .filter(d -> d.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Document not found: " + documentId));
    }

    /** US-LA-03: returns the mandatory doc types that are still missing for an application. */
    public List<String> missingMandatoryDocs(String appId) {
        List<String> uploaded = listForApp(appId).stream().map(ApplicationDocument::getDocType).toList();
        return MANDATORY_DOC_TYPES.stream().filter(t -> !uploaded.contains(t)).toList();
    }

    @Transactional
    public ApplicationDocument verify(String documentId, String status, String verifiedBy, String remarks) {
        ApplicationDocument doc = get(documentId);
        doc.setVerificationStatus(status);
        doc.setVerifiedBy(verifiedBy);
        doc.setVerifiedAt(java.time.OffsetDateTime.now());
        doc.setRemarks(remarks);
        return repository.save(doc);
    }
}
