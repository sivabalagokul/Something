package com.hlms.legal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class LegalServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(LegalServiceApplication.class, args);
    }
}
