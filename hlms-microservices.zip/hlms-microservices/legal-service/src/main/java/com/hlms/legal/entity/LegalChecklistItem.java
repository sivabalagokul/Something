package com.hlms.legal.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "legal_checklist_item")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LegalChecklistItem {

    @Id
    @Column(name = "checklist_item_id", length = 50)
    private String checklistItemId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "checklist_key", length = 100, nullable = false)
    private String checklistKey;

    @Column(name = "status", length = 30, nullable = false)
    @Builder.Default
    private String status = "Pending";

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
