package com.hlms.legal.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Entity
@Table(name = "legal_notice")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LegalNotice {

    @Id
    @Column(name = "notice_id", length = 50)
    private String noticeId;

    @Column(name = "notice_no", length = 50, nullable = false, unique = true)
    private String noticeNo;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "notice_type", length = 50, nullable = false)
    private String noticeType;

    @Column(name = "issue_date", nullable = false)
    private LocalDate issueDate;

    @Column(name = "due_date")
    private LocalDate dueDate;

    @Column(name = "status", length = 30, nullable = false)
    @Builder.Default
    private String status = "Active"; // Active, Sent, Delivered, Failed...

    @Column(name = "officer")
    private String officer;

    @Column(name = "content", columnDefinition = "TEXT")
    private String content;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
