package com.hlms.legal.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "legal_verification")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LegalVerification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "verification_id")
    private Long verificationId;

    @Column(name = "app_id", nullable = false, unique = true)
    private String appId;

    @Column(name = "decision", length = 30)
    private String decision;

    @Column(name = "decision_date")
    private OffsetDateTime decisionDate;

    @Column(name = "officer")
    private String officer;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    @Column(name = "info_requested", nullable = false)
    @Builder.Default
    private Boolean infoRequested = false;

    @Column(name = "info_request_details", columnDefinition = "TEXT")
    private String infoRequestDetails;

    @Column(name = "info_requested_at")
    private OffsetDateTime infoRequestedAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
