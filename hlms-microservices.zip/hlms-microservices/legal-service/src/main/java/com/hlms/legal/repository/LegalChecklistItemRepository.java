package com.hlms.legal.repository;

import com.hlms.legal.entity.LegalChecklistItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LegalChecklistItemRepository extends JpaRepository<LegalChecklistItem, String> {
    List<LegalChecklistItem> findByAppIdAndDeletedAtIsNull(String appId);
}
