package com.hlms.legal.repository;

import com.hlms.legal.entity.LegalNotice;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LegalNoticeRepository extends JpaRepository<LegalNotice, String> {
    List<LegalNotice> findByAppIdAndDeletedAtIsNull(String appId);
}
