package com.hlms.legal.service;

import com.hlms.legal.entity.BankOfficeDecision;
import com.hlms.legal.repository.BankOfficeDecisionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;

@Service
@RequiredArgsConstructor
public class BankOfficeService {

    private final BankOfficeDecisionRepository repository;

    public BankOfficeDecision get(String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId)
                .orElseGet(() -> BankOfficeDecision.builder().appId(appId).status("Pending").build());
    }

    @Transactional
    public BankOfficeDecision decide(String appId, String status, String officer, String reason, String remarks) {
        BankOfficeDecision decision = repository.findByAppIdAndDeletedAtIsNull(appId)
                .orElseGet(() -> BankOfficeDecision.builder().appId(appId).build());
        decision.setStatus(status);
        decision.setOfficer(officer);
        decision.setReason(reason);
        decision.setRemarks(remarks);
        decision.setDecisionDate(OffsetDateTime.now());
        return repository.save(decision);
    }
}
