package com.hlms.legal.service;

import com.hlms.legal.entity.LegalNotice;
import com.hlms.legal.repository.LegalNoticeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

/** Backs feature "10. Default Management and Notice Generation". */
@Service
@RequiredArgsConstructor
public class LegalNoticeService {

    private final LegalNoticeRepository repository;

    @Transactional
    public LegalNotice generateNotice(String appId, String noticeType, String officer, String content, LocalDate dueDate) {
        LegalNotice notice = LegalNotice.builder()
                .noticeId("NOTICE-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .noticeNo("NO-" + System.currentTimeMillis())
                .appId(appId)
                .noticeType(noticeType)
                .issueDate(LocalDate.now())
                .dueDate(dueDate)
                .status("Active")
                .officer(officer)
                .content(content)
                .build();
        return repository.save(notice);
    }

    public List<LegalNotice> listForApp(String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId);
    }

    @Transactional
    public LegalNotice updateStatus(String noticeId, String status) {
        LegalNotice notice = repository.findById(noticeId).orElseThrow();
        notice.setStatus(status); // Sent, Delivered, Failed (US-DMNG-03 Notice Tracking)
        return repository.save(notice);
    }
}
