package com.hlms.loan.controller;

import com.hlms.loan.entity.LoanProduct;
import com.hlms.loan.repository.LoanProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** US-LG-01/02 Loan Product Information & Type Classification */
@RestController
@RequestMapping("/api/loan-products")
@RequiredArgsConstructor
public class LoanProductController {

    private final LoanProductRepository repository;

    @GetMapping
    public List<LoanProduct> list() {
        return repository.findByDeletedAtIsNull();
    }

    @GetMapping("/{productId}")
    public ResponseEntity<LoanProduct> get(@PathVariable String productId) {
        return repository.findById(productId)
                .filter(p -> p.getDeletedAt() == null)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
