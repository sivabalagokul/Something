package com.hlms.loan.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter @Setter
public class MortgageCalculationRequest {

    @NotNull @Positive
    private BigDecimal requestedLoanAmount;

    @NotNull @Positive
    private BigDecimal propertyValue;

    private String productId;          // used to look up loan_product.max_ltv, if known

    @Positive
    private Integer tenureYears;       // defaults to 20 if omitted

    private BigDecimal interestRate;   // annual %, defaults to 8.50 if omitted

    private BigDecimal monthlyIncome;  // used to derive the unsecured eligibility ceiling
    private BigDecimal otherEmis;
    private Integer cibilScore;
}
