package com.hlms.loan.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Persists a snapshot of each eligibility run (feature 2), instead of being stateless-only. */
@Entity
@Table(name = "eligibility_assessment")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class EligibilityAssessment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "assessment_id")
    private Long assessmentId;

    @Column(name = "user_email", nullable = false)
    private String userEmail;

    @Column(name = "requested_amount", precision = 14, scale = 2)
    private BigDecimal requestedAmount;

    @Column(name = "tenure_years")
    private Integer tenureYears;

    @Column(name = "cibil_score")
    private Integer cibilScore;

    @Column(name = "monthly_income", precision = 14, scale = 2)
    private BigDecimal monthlyIncome;

    @Column(name = "other_emis", precision = 14, scale = 2)
    private BigDecimal otherEmis;

    @Column(name = "interest_rate", precision = 5, scale = 2)
    private BigDecimal interestRate;

    @Column(name = "status", length = 30, nullable = false)
    private String status;

    @Column(name = "max_eligible_loan_amount", precision = 14, scale = 2)
    private BigDecimal maxEligibleLoanAmount;

    @Column(name = "estimated_emi", precision = 14, scale = 2)
    private BigDecimal estimatedEmi;

    @Column(name = "dti_ratio", precision = 6, scale = 4)
    private BigDecimal dtiRatio;

    // Stored as JSON text (list of strings serialized by the service layer).
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "reasons", columnDefinition = "jsonb")
    private String reasons;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "recommendations", columnDefinition = "jsonb")
    private String recommendations;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
    }
}
