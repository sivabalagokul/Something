package com.hlms.loan.repository;

import com.hlms.loan.entity.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface AppUserRepository extends JpaRepository<AppUser, String> {
    List<AppUser> findByDeletedAtIsNull();
    Optional<AppUser> findByEmailAndDeletedAtIsNull(String email);
    List<AppUser> findByRoleAndDeletedAtIsNull(String role);
    boolean existsByMobile(String mobile);
}
