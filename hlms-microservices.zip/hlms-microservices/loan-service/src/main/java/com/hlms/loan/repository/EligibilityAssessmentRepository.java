package com.hlms.loan.repository;

import com.hlms.loan.entity.EligibilityAssessment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EligibilityAssessmentRepository extends JpaRepository<EligibilityAssessment, Long> {
    List<EligibilityAssessment> findByUserEmailAndDeletedAtIsNullOrderByCreatedAtDesc(String userEmail);
}
