package com.hlms.loan.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hlms.loan.dto.EligibilityRequest;
import com.hlms.loan.dto.EligibilityResponse;
import com.hlms.loan.dto.MortgageCalculationRequest;
import com.hlms.loan.dto.MortgageCalculationResponse;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.entity.LoanProduct;
import com.hlms.loan.exception.BadRequestException;
import com.hlms.loan.exception.ResourceNotFoundException;
import com.hlms.loan.repository.LoanApplicationRepository;
import com.hlms.loan.repository.LoanProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Backs feature "6. Mortgage Requirement Calculation" (US-MRC-01..05) in full - this
 * feature previously had no entity, service, or endpoints at all.
 *
 * Deliberately built with NO new tables/columns:
 *  - loan_application.property_value / property_type (already in the schema) hold the
 *    property evaluation (US-MRC-02).
 *  - loan_product.max_ltv (already in the schema) is the collateral policy input.
 *  - loan_application.form_data (existing JSONB "free area" of the schema) holds the
 *    structured mortgage assessment record for "Mortgage Record Management" (US-MRC-05)
 *    under a "mortgageAssessment" key, alongside whatever the frontend already stores there.
 */
@Service
@RequiredArgsConstructor
public class MortgageService {

    private final LoanApplicationRepository loanApplicationRepository;
    private final LoanProductRepository loanProductRepository;
    private final EligibilityService eligibilityService;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;

    /** US-MRC-01/03/04: ad-hoc calculation, usable with or without a specific application. */
    public MortgageCalculationResponse calculate(MortgageCalculationRequest req) {
        int tenureYears = req.getTenureYears() == null ? 20 : req.getTenureYears();
        BigDecimal interestRate = req.getInterestRate() == null ? new BigDecimal("8.50") : req.getInterestRate();

        EligibilityRequest eligibilityRequest = new EligibilityRequest();
        eligibilityRequest.setMonthlyIncome(req.getMonthlyIncome());
        eligibilityRequest.setOtherEmis(req.getOtherEmis());
        eligibilityRequest.setCibilScore(req.getCibilScore());
        eligibilityRequest.setRequestedAmount(req.getRequestedLoanAmount());
        eligibilityRequest.setTenureYears(tenureYears);
        eligibilityRequest.setInterestRate(interestRate);
        EligibilityResponse eligibility = eligibilityService.assess(eligibilityRequest);

        BigDecimal unsecuredLimit = eligibility.maxEligibleLoanAmount();
        BigDecimal requested = req.getRequestedLoanAmount();

        boolean mortgageRequired = requested.compareTo(unsecuredLimit) > 0;
        BigDecimal mortgageValueRequired = mortgageRequired
                ? requested.subtract(unsecuredLimit).setScale(2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

        String maxLtv = "N/A";
        BigDecimal maxLtvFraction = null;
        if (req.getProductId() != null) {
            LoanProduct product = loanProductRepository.findByProductIdAndDeletedAtIsNull(req.getProductId())
                    .orElseThrow(() -> new BadRequestException("Unknown loan product: " + req.getProductId()));
            maxLtv = product.getMaxLtv();
            maxLtvFraction = parseLtvPercent(maxLtv);
        }

        BigDecimal ltvRatio = req.getPropertyValue().signum() == 0
                ? BigDecimal.ZERO
                : requested.multiply(BigDecimal.valueOf(100))
                    .divide(req.getPropertyValue(), 2, RoundingMode.HALF_UP);

        boolean collateralSufficient;
        if (maxLtvFraction != null) {
            BigDecimal maxSecuredAmount = req.getPropertyValue().multiply(maxLtvFraction).setScale(2, RoundingMode.HALF_UP);
            collateralSufficient = maxSecuredAmount.compareTo(requested) >= 0;
        } else {
            // No product context supplied - fall back to a conservative 80% LTV policy default.
            collateralSufficient = req.getPropertyValue().multiply(new BigDecimal("0.80"))
                    .setScale(2, RoundingMode.HALF_UP).compareTo(requested) >= 0;
        }

        List<String> notes = new ArrayList<>();
        if (mortgageRequired) {
            notes.add("Requested amount exceeds the unsecured eligibility limit of " + unsecuredLimit
                    + "; " + mortgageValueRequired + " of the loan must be secured against the property.");
        } else {
            notes.add("Requested amount is within the unsecured eligibility limit; no mortgage is strictly required.");
        }
        if (!collateralSufficient) {
            notes.add("Property value is insufficient collateral for the requested loan amount under the applicable LTV policy.");
        }

        return new MortgageCalculationResponse(requested, req.getPropertyValue(), unsecuredLimit, mortgageRequired,
                mortgageValueRequired, maxLtv, ltvRatio, collateralSufficient, notes);
    }

    /** Same calculation, but scoped to a real application: pulls income/property data from it,
     *  and persists the result into form_data (US-MRC-05 Mortgage Record Management). */
    @Transactional
    public MortgageCalculationResponse calculateForApplication(String appId, String actorEmail) {
        LoanApplication app = getApp(appId);

        MortgageCalculationRequest req = new MortgageCalculationRequest();
        req.setRequestedLoanAmount(nz(app.getLoanAmount()));
        req.setPropertyValue(nz(app.getPropertyValue()));
        req.setProductId(app.getProductId());
        req.setTenureYears(app.getTenureYears());
        req.setInterestRate(app.getInterestRate());
        req.setMonthlyIncome(app.getMonthlyIncome());
        req.setOtherEmis(app.getOtherEmis());

        MortgageCalculationResponse response = calculate(req);
        saveMortgageRecord(app, response, "CALCULATION");

        auditService.record("loan_application", appId, "MORTGAGE_CALCULATED", actorEmail,
                null, Map.of("mortgageRequired", response.mortgageRequired(),
                        "mortgageValueRequired", response.mortgageValueRequired().toString()));
        return response;
    }

    /** US-MRC-02 Property Evaluation: records/updates the property valuation used as collateral. */
    @Transactional
    public LoanApplication evaluateProperty(String appId, BigDecimal propertyValue, String propertyType,
                                             String valuationNotes, String actorEmail) {
        LoanApplication app = getApp(appId);
        BigDecimal previousValue = app.getPropertyValue();

        app.setPropertyValue(propertyValue);
        if (propertyType != null) app.setPropertyType(propertyType);
        LoanApplication saved = loanApplicationRepository.save(app);

        Map<String, Object> evaluation = new LinkedHashMap<>();
        evaluation.put("propertyValue", propertyValue);
        evaluation.put("propertyType", saved.getPropertyType());
        evaluation.put("notes", valuationNotes);
        evaluation.put("evaluatedBy", actorEmail);
        evaluation.put("evaluatedAt", OffsetDateTime.now().toString());
        mergeIntoFormData(saved, "propertyEvaluation", evaluation);
        loanApplicationRepository.save(saved);

        auditService.record("loan_application", appId, "PROPERTY_EVALUATED", actorEmail,
                Map.of("propertyValue", previousValue == null ? "null" : previousValue.toString()),
                Map.of("propertyValue", propertyValue.toString()));
        return saved;
    }

    /** US-MRC-04/05: returns the last persisted mortgage record for an application, if any. */
    public Map<String, Object> getMortgageRecord(String appId) {
        LoanApplication app = getApp(appId);
        Map<String, Object> formData = readFormData(app);
        Object record = formData.get("mortgageAssessment");
        if (record == null) {
            throw new ResourceNotFoundException("No mortgage assessment has been calculated yet for " + appId
                    + ". Call POST /api/mortgage/" + appId + "/calculate first.");
        }
        return (Map<String, Object>) record;
    }

    // ------------------------------------------------------------------ helpers

    private void saveMortgageRecord(LoanApplication app, MortgageCalculationResponse response, String source) {
        Map<String, Object> record = new LinkedHashMap<>();
        record.put("source", source);
        record.put("requestedLoanAmount", response.requestedLoanAmount());
        record.put("propertyValue", response.propertyValue());
        record.put("unsecuredEligibleAmount", response.unsecuredEligibleAmount());
        record.put("mortgageRequired", response.mortgageRequired());
        record.put("mortgageValueRequired", response.mortgageValueRequired());
        record.put("maxLtvAllowed", response.maxLtvAllowed());
        record.put("loanToValueRatio", response.loanToValueRatio());
        record.put("collateralSufficient", response.collateralSufficient());
        record.put("notes", response.notes());
        record.put("calculatedAt", OffsetDateTime.now().toString());
        mergeIntoFormData(app, "mortgageAssessment", record);
        loanApplicationRepository.save(app);
    }

    private void mergeIntoFormData(LoanApplication app, String key, Object value) {
        Map<String, Object> formData = readFormData(app);
        formData.put(key, value);
        try {
            app.setFormData(objectMapper.writeValueAsString(formData));
        } catch (Exception e) {
            throw new BadRequestException("Failed to serialize form_data update: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> readFormData(LoanApplication app) {
        String raw = app.getFormData();
        if (raw == null || raw.isBlank()) return new LinkedHashMap<>();
        try {
            return objectMapper.readValue(raw, LinkedHashMap.class);
        } catch (Exception e) {
            return new LinkedHashMap<>();
        }
    }

    private LoanApplication getApp(String appId) {
        return loanApplicationRepository.findById(appId)
                .filter(a -> a.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Loan application not found: " + appId));
    }

    private BigDecimal parseLtvPercent(String maxLtv) {
        if (maxLtv == null) return null;
        try {
            String digits = maxLtv.replace("%", "").trim();
            return new BigDecimal(digits).divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_UP);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private BigDecimal nz(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }
}
