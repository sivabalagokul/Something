package com.hlms.notification.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "service_request")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ServiceRequest {

    @Id
    @Column(name = "request_id", length = 50)
    private String requestId;

    @Column(name = "ref_no", length = 50, nullable = false, unique = true)
    private String refNo;

    @Column(name = "app_id")
    private String appId;

    @Column(name = "user_email", nullable = false)
    private String userEmail;

    @Column(name = "request_type", length = 50, nullable = false)
    private String requestType;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "status", length = 30, nullable = false)
    @Builder.Default
    private String status = "Requested";

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
    }
}
