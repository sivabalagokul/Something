package com.hlms.notification.service;

import com.hlms.notification.entity.Notification;
import com.hlms.notification.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/** Backs feature "8. Notification & Communication Management". */
@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository repository;
    private final NotificationGateway gateway;

    @Transactional
    public Notification send(String userEmail, String title, String body, List<String> channels) {
        List<String> effectiveChannels = channels == null || channels.isEmpty() ? List.of("inapp") : channels;
        Notification notification = Notification.builder()
                .notificationId("NOTIF-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase())
                .userEmail(userEmail)
                .title(title)
                .body(body)
                .channels(effectiveChannels)
                .build();
        Notification saved = repository.save(notification);

        // US-NM-05 Multi-Channel Communication: actually dispatch on every requested channel.
        // The row above is saved regardless of dispatch outcome, so in-app history never
        // depends on an external gateway succeeding.
        for (String channel : effectiveChannels) {
            try {
                gateway.dispatch(channel, userEmail, title, body);
            } catch (Exception ex) {
                // A failed SMS/email dispatch should never fail the whole request -
                // the notification is already recorded and visible in-app.
            }
        }
        return saved;
    }

    public List<Notification> listForUser(String userEmail) {
        return repository.findByUserEmailAndDeletedAtIsNullOrderByCreatedAtDesc(userEmail);
    }

    /** Paginated/sortable variant (cross-cutting gap) - e.g. ?page=0&size=20&sort=createdAt,desc */
    public org.springframework.data.domain.Page<Notification> listForUser(String userEmail, org.springframework.data.domain.Pageable pageable) {
        return repository.findByUserEmailAndDeletedAtIsNull(userEmail, pageable);
    }

    public List<Notification> listUnread(String userEmail) {
        return repository.findByUserEmailAndIsReadAndDeletedAtIsNull(userEmail, false);
    }

    @Transactional
    public Notification markRead(String notificationId) {
        Notification n = repository.findById(notificationId).orElseThrow();
        n.setIsRead(true);
        return repository.save(n);
    }
}
