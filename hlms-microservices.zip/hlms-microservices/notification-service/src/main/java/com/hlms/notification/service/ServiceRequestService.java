package com.hlms.notification.service;

import com.hlms.notification.entity.ServiceRequest;
import com.hlms.notification.exception.ResourceNotFoundException;
import com.hlms.notification.repository.ServiceRequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/** Backs feature "9. Post-Disbursement Service Management". */
@Service
@RequiredArgsConstructor
public class ServiceRequestService {

    private final ServiceRequestRepository repository;

    @Transactional
    public ServiceRequest create(String appId, String userEmail, String requestType, String description) {
        ServiceRequest sr = ServiceRequest.builder()
                .requestId("SR-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .refNo("SR-REF-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase())
                .appId(appId)
                .userEmail(userEmail)
                .requestType(requestType)
                .description(description)
                .status("Requested")
                .build();
        return repository.save(sr);
    }

    public List<ServiceRequest> listForUser(String userEmail) {
        return repository.findByUserEmailAndDeletedAtIsNull(userEmail);
    }

    public List<ServiceRequest> listForApp(String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId);
    }

    public ServiceRequest get(String requestId) {
        return repository.findById(requestId)
                .filter(r -> r.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Service request not found: " + requestId));
    }

    @Transactional
    public ServiceRequest updateStatus(String requestId, String status) {
        ServiceRequest sr = get(requestId);
        sr.setStatus(status);
        return repository.save(sr);
    }
}
