package com.hlms.repayment.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Calls legal-service's internal endpoint so repayment-service's automated default
 * escalation sweep can trigger a legal notice without owning legal-service's code/table.
 */
@FeignClient(name = "legal-service", configuration = FeignClientConfig.class)
public interface LegalNoticeClient {

    @PostMapping("/internal/legal-notices")
    void generateNotice(@RequestBody LegalNoticeRequest request);
}
