package com.hlms.repayment.client;

/** Request body shape for legal-service's internal notice-generation endpoint. */
public record LegalNoticeRequest(String appId, String noticeType, String officer, String content, String dueDate) { }
