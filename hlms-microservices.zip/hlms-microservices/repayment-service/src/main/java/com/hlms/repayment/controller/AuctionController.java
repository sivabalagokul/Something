package com.hlms.repayment.controller;

import com.hlms.repayment.entity.AuctionCase;
import com.hlms.repayment.entity.AuctionNote;
import com.hlms.repayment.entity.Bid;
import com.hlms.repayment.service.AuctionService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/** Feature 11: Auction Management (US-AM-01..05) */
@RestController
@RequestMapping("/api/auctions")
@RequiredArgsConstructor
public class AuctionController {

    private final AuctionService service;

    @PreAuthorize("hasAnyRole('BANKOFFICE','ADMIN')")
    @PostMapping("/{appId}/open")
    public AuctionCase open(@PathVariable String appId) {
        return service.openCase(appId);
    }

    @GetMapping("/{appId}")
    public AuctionCase get(@PathVariable String appId) {
        return service.get(appId);
    }

    @GetMapping("/{appId}/eligible")
    public Map<String, Object> eligible(@PathVariable String appId) {
        AuctionCase auctionCase = service.get(appId);
        return Map.of("appId", appId, "eligibleForAuction", service.isEligibleForAuction(auctionCase));
    }

    @PreAuthorize("hasAnyRole('BANKOFFICE','ADMIN')")
    @PostMapping("/{appId}/schedule")
    public AuctionCase schedule(@PathVariable String appId, @RequestBody Map<String, Object> body) {
        LocalDate date = LocalDate.parse(body.get("auctionDate").toString());
        BigDecimal reserve = new BigDecimal(body.get("reservePrice").toString());
        return service.scheduleAuction(appId, date, reserve);
    }

    @PreAuthorize("hasAnyRole('BANKOFFICE','ADMIN')")
    @PatchMapping("/{appId}/stage")
    public AuctionCase updateStage(@PathVariable String appId, @RequestBody Map<String, String> body) {
        return service.updateStage(appId, body.get("stage"));
    }

    @PostMapping("/{appId}/notes")
    public AuctionNote addNote(@PathVariable String appId, @RequestBody Map<String, String> body) {
        return service.addNote(appId, body.get("noteText"));
    }

    @GetMapping("/{appId}/notes")
    public List<AuctionNote> notes(@PathVariable String appId) {
        return service.listNotes(appId);
    }

    @PreAuthorize("hasRole('BIDDER')")
    @PostMapping("/{appId}/bids")
    public Bid placeBid(@PathVariable String appId, @RequestBody Map<String, Object> body) {
        String bidderEmail = (String) body.get("bidderEmail");
        BigDecimal amount = new BigDecimal(body.get("bidAmount").toString());
        return service.placeBid(appId, bidderEmail, amount);
    }

    @GetMapping("/{appId}/bids")
    public List<Bid> listBids(@PathVariable String appId) {
        return service.listBids(appId);
    }

    @PreAuthorize("hasAnyRole('BANKOFFICE','ADMIN')")
    @PostMapping("/{appId}/resolve")
    public AuctionCase resolve(@PathVariable String appId) {
        return service.resolve(appId);
    }
}
