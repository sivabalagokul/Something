package com.hlms.repayment.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Entity
@Table(name = "auction_case")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuctionCase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "auction_id")
    private Long auctionId;

    @Column(name = "app_id", nullable = false, unique = true)
    private String appId;

    @Column(name = "stage", length = 30, nullable = false)
    @Builder.Default
    private String stage = "None"; // None, Notice Issued, Possession, Auction Scheduled, Resolved

    @Column(name = "notice_date")
    private LocalDate noticeDate;

    @Column(name = "notice_due_date")
    private LocalDate noticeDueDate;

    @Column(name = "demand_amount", precision = 14, scale = 2)
    private BigDecimal demandAmount;

    @Column(name = "possession_date")
    private LocalDate possessionDate;

    @Column(name = "auction_date")
    private LocalDate auctionDate;

    @Column(name = "reserve_price", precision = 14, scale = 2)
    private BigDecimal reservePrice;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
