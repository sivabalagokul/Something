package com.hlms.repayment.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "auction_note")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuctionNote {

    @Id
    @Column(name = "note_id", length = 50)
    private String noteId;

    // References auction_case.app_id (the FK target in the SQL schema is auction_case(app_id))
    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "note_date", nullable = false)
    private OffsetDateTime noteDate;

    @Column(name = "note_text", columnDefinition = "TEXT", nullable = false)
    private String noteText;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @PrePersist
    public void prePersist() {
        if (noteDate == null) noteDate = OffsetDateTime.now();
    }
}
