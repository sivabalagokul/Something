package com.hlms.repayment.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "bid")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Bid {

    @Id
    @Column(name = "bid_id", length = 50)
    private String bidId;

    // References auction_case.app_id
    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "bidder_email", nullable = false)
    private String bidderEmail;

    @Column(name = "bid_amount", precision = 14, scale = 2, nullable = false)
    private BigDecimal bidAmount;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
    }
}
