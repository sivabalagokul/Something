package com.hlms.repayment.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Entity
@Table(name = "emi_installment", uniqueConstraints = @UniqueConstraint(columnNames = {"app_id", "installment_no"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class EmiInstallment {

    @Id
    @Column(name = "installment_id", length = 50)
    private String installmentId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "installment_no", nullable = false)
    private Integer installmentNo;

    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;

    @Column(name = "emi_amount", precision = 14, scale = 2, nullable = false)
    private BigDecimal emiAmount;

    @Column(name = "principal_component", precision = 14, scale = 2)
    private BigDecimal principalComponent;

    @Column(name = "interest_component", precision = 14, scale = 2)
    private BigDecimal interestComponent;

    @Column(name = "closing_balance", precision = 14, scale = 2)
    private BigDecimal closingBalance;

    @Column(name = "status", length = 30, nullable = false)
    @Builder.Default
    private String status = "Due"; // Due, Paid, Overdue

    @Column(name = "paid_date")
    private LocalDate paidDate;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
