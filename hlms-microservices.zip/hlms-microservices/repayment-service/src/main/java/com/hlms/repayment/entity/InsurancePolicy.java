package com.hlms.repayment.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Entity
@Table(name = "insurance_policy")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class InsurancePolicy {

    @Id
    @Column(name = "policy_id", length = 50)
    private String policyId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "policy_type", length = 50)
    private String policyType; // property, life

    @Column(name = "status", length = 30, nullable = false)
    @Builder.Default
    private String status = "Active";

    @Column(name = "valid_till")
    private LocalDate validTill;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
