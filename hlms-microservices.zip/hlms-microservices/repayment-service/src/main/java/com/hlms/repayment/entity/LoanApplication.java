package com.hlms.repayment.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "loan_application")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LoanApplication {

    @Id
    @Column(name = "app_id", length = 50)
    private String appId;

    @Column(name = "tracking_no", length = 50, unique = true)
    private String trackingNo;

    @Column(name = "user_email", nullable = false)
    private String userEmail;

    @Column(name = "product_id")
    private String productId;

    @Column(name = "loan_amount", precision = 14, scale = 2)
    private BigDecimal loanAmount;

    @Column(name = "tenure_years")
    private Integer tenureYears;

    @Column(name = "purpose", length = 150)
    private String purpose;

    @Column(name = "interest_rate", precision = 5, scale = 2)
    private BigDecimal interestRate;

    @Column(name = "status", length = 30, nullable = false)
    @Builder.Default
    private String status = "Draft"; // Draft, Submitted, Under Review, Rejected, Disbursed

    @Column(name = "stage_index", nullable = false)
    @Builder.Default
    private Integer stageIndex = 0;

    @Column(name = "current_step", nullable = false)
    @Builder.Default
    private Integer currentStep = 1;

    // Raw JSON text, mapped to the jsonb column via Hibernate 6's built-in JSON support.
    // Serialize/deserialize with ObjectMapper in the service layer as needed.
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "form_data", columnDefinition = "jsonb", nullable = false)
    @Builder.Default
    private String formData = "{}";

    @Column(name = "saved_at", nullable = false)
    private OffsetDateTime savedAt;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "applicant_name", length = 150)
    private String applicantName;
    @Column(name = "applicant_mobile", length = 20)
    private String applicantMobile;
    @Column(name = "applicant_pan", length = 20)
    private String applicantPan;

    @Column(name = "addr_door_no", length = 30)
    private String addrDoorNo;
    @Column(name = "addr_street", length = 150)
    private String addrStreet;
    @Column(name = "addr_city", length = 100)
    private String addrCity;
    @Column(name = "addr_state", length = 100)
    private String addrState;
    @Column(name = "addr_pincode", length = 10)
    private String addrPincode;

    @Column(name = "employment_type", length = 30)
    private String employmentType;
    @Column(name = "employer", length = 150)
    private String employer;
    @Column(name = "monthly_income", precision = 14, scale = 2)
    private BigDecimal monthlyIncome;
    @Column(name = "other_emis", precision = 14, scale = 2)
    private BigDecimal otherEmis;

    @Column(name = "property_address", columnDefinition = "TEXT")
    private String propertyAddress;
    @Column(name = "property_type", length = 50)
    private String propertyType;
    @Column(name = "property_value", precision = 14, scale = 2)
    private BigDecimal propertyValue;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @PrePersist
    public void prePersist() {
        OffsetDateTime now = OffsetDateTime.now();
        if (createdAt == null) createdAt = now;
        if (savedAt == null) savedAt = now;
    }

    @PreUpdate
    public void preUpdate() {
        this.savedAt = OffsetDateTime.now();
    }
}
