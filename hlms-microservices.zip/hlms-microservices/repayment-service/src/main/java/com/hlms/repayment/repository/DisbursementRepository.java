package com.hlms.repayment.repository;

import com.hlms.repayment.entity.Disbursement;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface DisbursementRepository extends JpaRepository<Disbursement, Long> {
    Optional<Disbursement> findByAppIdAndDeletedAtIsNull(String appId);
}
