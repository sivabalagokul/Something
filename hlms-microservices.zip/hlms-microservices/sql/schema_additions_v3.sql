-- ============================================================
-- HLMS - Schema Additions (v3)
-- Run this AFTER your existing v2 schema file.
-- Adds the two tables needed by the new backend features:
--   1. otp_verification  - backs OTP-based secure login (US-UM-03)
--   2. eligibility_assessment - persists eligibility results/history
--      instead of being calculated stateless-per-request (feature 2)
-- Both follow the same soft-delete convention as the rest of the schema.
-- ============================================================

CREATE TABLE otp_verification (
    otp_id       VARCHAR(50) PRIMARY KEY,
    email        VARCHAR(255) NOT NULL REFERENCES app_user(email) ON DELETE CASCADE,
    otp_code     VARCHAR(10) NOT NULL,
    purpose      VARCHAR(30) NOT NULL DEFAULT 'LOGIN',
    expires_at   TIMESTAMPTZ NOT NULL,
    consumed     BOOLEAN NOT NULL DEFAULT FALSE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at   TIMESTAMPTZ
);
CREATE INDEX idx_otp_email ON otp_verification(email);
CREATE INDEX idx_otp_email_purpose ON otp_verification(email, purpose);

CREATE TABLE eligibility_assessment (
    assessment_id           BIGSERIAL PRIMARY KEY,
    user_email              VARCHAR(255) NOT NULL REFERENCES app_user(email) ON DELETE CASCADE,
    requested_amount        NUMERIC(14,2),
    tenure_years            INT,
    cibil_score             INT,
    monthly_income          NUMERIC(14,2),
    other_emis              NUMERIC(14,2),
    interest_rate           NUMERIC(5,2),
    status                  VARCHAR(30) NOT NULL,
    max_eligible_loan_amount NUMERIC(14,2),
    estimated_emi           NUMERIC(14,2),
    dti_ratio               NUMERIC(6,4),
    reasons                 JSONB,
    recommendations         JSONB,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at              TIMESTAMPTZ
);
CREATE INDEX idx_eligibility_user ON eligibility_assessment(user_email);
CREATE INDEX idx_eligibility_created ON eligibility_assessment(created_at);
