package com.hlms.user.controller;

import com.hlms.user.entity.AppUser;
import com.hlms.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    // US-UM-05 Profile Management
    @GetMapping("/{email}")
    public ResponseEntity<AppUser> get(@PathVariable String email) {
        return ResponseEntity.ok(userService.getByEmail(email));
    }

    @PutMapping("/{email}")
    public ResponseEntity<AppUser> update(@PathVariable String email, @RequestBody AppUser patch) {
        return ResponseEntity.ok(userService.updateProfile(email, patch));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<?> listByRole(@RequestParam String role) {
        return ResponseEntity.ok(userService.listByRole(role));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{email}")
    public ResponseEntity<Void> softDelete(@PathVariable String email) {
        userService.softDelete(email);
        return ResponseEntity.noContent().build();
    }
}
