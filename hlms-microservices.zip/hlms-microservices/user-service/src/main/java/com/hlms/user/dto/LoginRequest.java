package com.hlms.user.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class LoginRequest {
    @NotBlank
    private String email;

    @NotBlank
    private String password;

    // Placeholder for OTP-based 2nd factor (US-UM-03). Wire up an OTP
    // provider/service and validate this before issuing a token.
    private String otp;
}
