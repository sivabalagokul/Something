package com.hlms.user.dto;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RegisterRequest {
    @NotBlank @Email
    private String email;

    @NotBlank
    private String name;

    @NotBlank
    @Pattern(regexp = "\\d{10}", message = "mobile must be a 10-digit number")
    private String mobile;

    @NotBlank @Size(min = 8, message = "password must be at least 8 characters")
    private String password;

    @NotBlank
    private String role; // customer, legal, bankoffice, bidder, admin

    private String idType;
    private String idNumber;
}
