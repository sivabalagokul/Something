package com.hlms.user.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "app_user")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AppUser {

    @Id
    @Column(name = "email", length = 255)
    private String email;

    @Column(name = "name", length = 150, nullable = false)
    private String name;

    @Column(name = "mobile", length = 20, nullable = false)
    private String mobile;

    @JsonIgnore
    @Column(name = "password_hash", length = 255, nullable = false)
    private String passwordHash;

    @Column(name = "role", length = 30, nullable = false)
    private String role; // customer, legal, bankoffice, bidder, admin

    @Column(name = "active", nullable = false)
    @Builder.Default
    private Boolean active = true;

    @Column(name = "id_type", length = 30)
    private String idType;

    @Column(name = "id_number", length = 50)
    private String idNumber;

    @Column(name = "pref_sms", nullable = false)
    @Builder.Default
    private Boolean prefSms = true;

    @Column(name = "pref_email", nullable = false)
    @Builder.Default
    private Boolean prefEmail = true;

    @Column(name = "pref_inapp", nullable = false)
    @Builder.Default
    private Boolean prefInapp = true;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
    }
}
