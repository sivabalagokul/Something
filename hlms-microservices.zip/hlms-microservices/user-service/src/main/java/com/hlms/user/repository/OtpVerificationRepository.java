package com.hlms.user.repository;

import com.hlms.user.entity.OtpVerification;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface OtpVerificationRepository extends JpaRepository<OtpVerification, String> {
    Optional<OtpVerification> findTopByEmailAndPurposeAndConsumedFalseAndDeletedAtIsNullOrderByCreatedAtDesc(
            String email, String purpose);

    List<OtpVerification> findByEmailAndPurposeAndConsumedFalseAndDeletedAtIsNull(String email, String purpose);
}
