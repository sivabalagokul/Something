package com.hlms.user.service;

import com.hlms.user.entity.OtpVerification;
import com.hlms.user.exception.BadRequestException;
import com.hlms.user.client.NotificationClient;
import com.hlms.user.client.NotificationRequest;
import com.hlms.user.repository.OtpVerificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Backs US-UM-03 (Secure Login via password + OTP). Generation/validation only -
 * actual SMS/email dispatch is delegated to notification-service via NotificationClient
 * (a Feign call to its /internal/notifications endpoint), which currently just persists
 * a Notification row (see its own TODO for a real gateway).
 */
@Service
@RequiredArgsConstructor
public class OtpService {

    private final OtpVerificationRepository repository;
    private final NotificationClient notificationClient;
    private static final SecureRandom RANDOM = new SecureRandom();

    @Value("${hlms.otp.length:6}")
    private int otpLength;

    @Value("${hlms.otp.expiry-minutes:5}")
    private int expiryMinutes;

    @Transactional
    public String generateAndSend(String email, String purpose) {
        String code = randomNumericCode(otpLength);

        OtpVerification otp = OtpVerification.builder()
                .otpId("OTP-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase())
                .email(email)
                .otpCode(code)
                .purpose(purpose)
                .expiresAt(OffsetDateTime.now().plusMinutes(expiryMinutes))
                .build();
        repository.save(otp);

        notificationClient.send(new NotificationRequest(email, "Your HLMS verification code",
                "Your one-time password is " + code + ". It expires in " + expiryMinutes + " minute(s).",
                java.util.List.of("sms", "email")));

        // Returned only so callers/tests can see it without a real SMS gateway configured;
        // don't return this from the actual /login/initiate response in production.
        return code;
    }

    @Transactional
    public void verify(String email, String otpCode, String purpose) {
        OtpVerification otp = repository
                .findTopByEmailAndPurposeAndConsumedFalseAndDeletedAtIsNullOrderByCreatedAtDesc(email, purpose)
                .orElseThrow(() -> new BadRequestException("No OTP request found. Please request a new OTP."));

        if (Boolean.TRUE.equals(otp.getConsumed())) {
            throw new BadRequestException("This OTP has already been used.");
        }
        if (otp.getExpiresAt().isBefore(OffsetDateTime.now())) {
            throw new BadRequestException("OTP has expired. Please request a new one.");
        }
        if (!otp.getOtpCode().equals(otpCode)) {
            throw new BadRequestException("Incorrect OTP.");
        }
        otp.setConsumed(true);
        repository.save(otp);
    }

    private String randomNumericCode(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(RANDOM.nextInt(10));
        }
        return sb.toString();
    }
}
