package com.hlms.user.service;

import com.hlms.user.dto.RegisterRequest;
import com.hlms.user.entity.AppUser;
import com.hlms.user.exception.BadRequestException;
import com.hlms.user.exception.ResourceNotFoundException;
import com.hlms.user.repository.AppUserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {

    private final AppUserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    private static final List<String> VALID_ROLES =
            List.of("customer", "legal", "bankoffice", "bidder", "admin");

    @Transactional
    public AppUser register(RegisterRequest req) {
        if (userRepository.existsById(req.getEmail())) {
            throw new BadRequestException("An account with this email already exists.");
        }
        if (userRepository.existsByMobile(req.getMobile())) {
            throw new BadRequestException("An account with this mobile number already exists.");
        }
        if (!VALID_ROLES.contains(req.getRole())) {
            throw new BadRequestException("role must be one of " + VALID_ROLES);
        }

        AppUser user = AppUser.builder()
                .email(req.getEmail())
                .name(req.getName())
                .mobile(req.getMobile())
                .passwordHash(passwordEncoder.encode(req.getPassword()))
                .role(req.getRole())
                .idType(req.getIdType())
                .idNumber(req.getIdNumber())
                .build();

        return userRepository.save(user);
    }

    public AppUser authenticate(String email, String rawPassword) {
        AppUser user = userRepository.findByEmailAndDeletedAtIsNull(email)
                .orElseThrow(() -> new BadRequestException("Invalid email or password."));
        if (!Boolean.TRUE.equals(user.getActive())) {
            throw new BadRequestException("This account has been deactivated.");
        }
        if (!passwordEncoder.matches(rawPassword, user.getPasswordHash())) {
            throw new BadRequestException("Invalid email or password.");
        }
        // TODO (US-UM-03): validate OTP here before returning success.
        return user;
    }

    public AppUser getByEmail(String email) {
        return userRepository.findByEmailAndDeletedAtIsNull(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + email));
    }

    public List<AppUser> listByRole(String role) {
        return userRepository.findByRoleAndDeletedAtIsNull(role);
    }

    @Transactional
    public AppUser updateProfile(String email, AppUser patch) {
        AppUser existing = getByEmail(email);
        if (patch.getName() != null) existing.setName(patch.getName());
        if (patch.getMobile() != null) existing.setMobile(patch.getMobile());
        if (patch.getIdType() != null) existing.setIdType(patch.getIdType());
        if (patch.getIdNumber() != null) existing.setIdNumber(patch.getIdNumber());
        if (patch.getPrefSms() != null) existing.setPrefSms(patch.getPrefSms());
        if (patch.getPrefEmail() != null) existing.setPrefEmail(patch.getPrefEmail());
        if (patch.getPrefInapp() != null) existing.setPrefInapp(patch.getPrefInapp());
        return userRepository.save(existing);
    }

    @Transactional
    public void changePassword(String email, String currentPassword, String newPassword) {
        AppUser user = getByEmail(email);
        if (!passwordEncoder.matches(currentPassword, user.getPasswordHash())) {
            throw new BadRequestException("Current password is incorrect.");
        }
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepository.save(user);
    }

    @Transactional
    public void softDelete(String email) {
        AppUser user = getByEmail(email);
        user.setDeletedAt(java.time.OffsetDateTime.now());
        userRepository.save(user);
    }
}
