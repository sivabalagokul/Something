package com.hlms2.legal.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.List;

/**
 * JPA entity for 'loan_application'.
 *
 * legal-service doesn't own this table (that's loan-service's domain) - it's
 * mapped here read-mostly, the same way {@link AppUser} is, purely so the
 * app_id foreign keys on legal_verification, legal_notice,
 * legal_checklist_item and bank_office_decision can be modelled as real JPA
 * @ManyToOne relationships (for convenient joined reads) instead of bare
 * String columns. Any state-changing operation against a loan application
 * (e.g. pushing its stage/status forward after a legal decision) should go
 * through loan-service's REST API via the LoanServiceClient Feign client,
 * not through this entity.
 */
@Entity
@Table(name = "loan_application")
public class LoanApplication {

    @Id
    @Column(name = "app_id", length = 50)
    private String appId;

    @Column(name = "tracking_no", length = 50)
    private String trackingNo;

    @Column(name = "user_email")
    private String userEmail;

    @Column(name = "applicant_name", length = 150)
    private String applicantName;

    @Column(name = "loan_amount", precision = 14, scale = 2)
    private BigDecimal loanAmount;

    @Column(name = "status")
    private String status;

    @JsonIgnore
    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private List<LegalVerification> legalVerifications;

    @JsonIgnore
    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private List<LegalNotice> legalNotices;

    @JsonIgnore
    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private List<LegalChecklistItem> checklistItems;

    @JsonIgnore
    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private List<BankOfficeDecision> bankOfficeDecisions;

    public LoanApplication() {
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<LegalVerification> getLegalVerifications() {
        return legalVerifications;
    }

    public List<LegalNotice> getLegalNotices() {
        return legalNotices;
    }

    public List<LegalChecklistItem> getChecklistItems() {
        return checklistItems;
    }

    public List<BankOfficeDecision> getBankOfficeDecisions() {
        return bankOfficeDecisions;
    }
}
