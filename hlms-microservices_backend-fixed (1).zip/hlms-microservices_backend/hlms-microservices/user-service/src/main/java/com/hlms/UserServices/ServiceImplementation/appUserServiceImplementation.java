package com.hlms.UserServices.ServiceImplementation;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hlms.UserServices.Dto.LoginRequestDTO;
import com.hlms.UserServices.Dto.LoginResponseDTO;
import com.hlms.UserServices.Dto.RegisterRequestDTO;
import com.hlms.UserServices.Entity.appUserEntity;
import com.hlms.UserServices.Exception.DuplicateRecordException;
import com.hlms.UserServices.Exception.InvalidCredentialsException;
import com.hlms.UserServices.Exception.ResourceNotFoundException;
import com.hlms.UserServices.Repository.appUserRepository;
import com.hlms.UserServices.Service.appUserService;
import com.hlms.UserServices.security.JwtService;

@Service
public class appUserServiceImplementation implements appUserService {

    @Autowired
    private appUserRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    @Override
    @Transactional
    public appUserEntity registerUser(RegisterRequestDTO request) {

        if (repository.existsByEmail(request.getEmail())) {
            throw new DuplicateRecordException("User already exists");
        }

        appUserEntity user = new appUserEntity();

        user.setEmail(request.getEmail());
        user.setName(request.getName());
        user.setMobile(request.getMobile());
        user.setRole(request.getRole());
        user.setIdType(request.getIdType());
        user.setIdNumber(request.getIdNumber());

        user.setPasswordHash(
                passwordEncoder.encode(request.getPassword()));

        user.setCreatedAt(LocalDateTime.now());

        return repository.save(user);
    }

    @Override
    @Transactional(readOnly = true)
    public LoginResponseDTO login(LoginRequestDTO request) {

        appUserEntity user = repository
                .findByEmailAndDeletedAtIsNull(request.getEmail())
                .orElseThrow(() ->
                        new ResourceNotFoundException("User not found"));

        if (!passwordEncoder.matches(
                request.getPassword(),
                user.getPasswordHash())) {

            throw new InvalidCredentialsException(
                    "Invalid password");
        }

        if (!Boolean.TRUE.equals(user.getActive())) {
            throw new InvalidCredentialsException("Account is inactive");
        }

        String token = jwtService.generateToken(
                user.getEmail(),
                user.getRole().name());

        return new LoginResponseDTO(token);
    }

    @Override
    @Transactional(readOnly = true)
    public appUserEntity getUserByEmail(String email) {

        return repository
                .findByEmailAndDeletedAtIsNull(email)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User not found"));
    }

    @Override
    @Transactional
    public appUserEntity updateUser(
            String email,
            appUserEntity updatedUser) {

        appUserEntity existing = getUserByEmail(email);

        existing.setName(updatedUser.getName());
        existing.setMobile(updatedUser.getMobile());
        existing.setPrefEmail(updatedUser.getPrefEmail());
        existing.setPrefSms(updatedUser.getPrefSms());
        existing.setPrefInapp(updatedUser.getPrefInapp());

        return repository.save(existing);
    }

    @Override
    @Transactional
    public void deleteUser(String email) {

        appUserEntity user = getUserByEmail(email);

        user.setDeletedAt(LocalDateTime.now());

        repository.save(user);
    }

    @Override
    public String forgotPassword(String email) {

        getUserByEmail(email);

        String otp = String.valueOf(
                (int) ((Math.random() * 900000) + 100000));

        return otp;
    }

    @Override
    @Transactional
    public String resetPassword(
            String email,
            String otpCode,
            String newPassword) {

        appUserEntity user = getUserByEmail(email);

        user.setPasswordHash(
                passwordEncoder.encode(newPassword));

        repository.save(user);

        return "Password Reset Successful";
    }
}