# API Gaps & Backend Recommendations

Found while wiring the Angular 19 customer UI to the live HLMS backend. Nothing below blocks the
UI from working — each gap has a documented workaround in code (search `API_GAPS.md` in code
comments) — but they're worth fixing for correctness, security, and a better UX.

---

## 🔴 High priority

### 1. OTP endpoints require a JWT, but are needed *before* the user has one
`user-service`'s `SecurityConfig` only `permitAll()`s `/api/users/register`, `/login`,
`/forgot-password`, `/reset-password`. `/api/otp/generate` and `/api/otp/verify` require
authentication.

That's fine for `forgot-password`/`reset-password` (they call the OTP logic internally, not via
those endpoints), **but** it means the generic OTP endpoints can't be used for things like
"verify your email/mobile at registration" or a two-factor login step, because the user has no
token yet at that point. Your old UI's demo flow simulated exactly this kind of pre-login OTP
step — it isn't achievable against the real backend as currently secured.

**Fix:** either `permitAll()` `/api/otp/**` and have the endpoints accept an unauthenticated
"purpose" + email/mobile pair, or add dedicated `permitAll` endpoints like
`/api/users/register/verify-otp` that are scoped to the registration flow only.

*Current UI behavior:* registration and login are both single-step (no OTP), matching what the
backend actually supports today.

### 2. No "pay EMI" endpoint
`repayment-service`'s `EmiInstallmentController` only exposes CRUD (`create`, `update by id`,
`delete`, `restore`, `find`) — there's no purpose-built "pay this installment" or
payment-gateway-integration endpoint.

**Fix:** add `POST /api/emi/installments/{id}/pay` that validates the amount, sets
`status=Paid`, `paidDate=now`, and (ideally) integrates a real payment gateway.

*Current UI behavior:* the "Pay Now" button on the Repayment page calls the generic
`PUT /api/emi/installments/{id}` and sets `status`/`paidDate` itself. This works, but is a
workaround, not a real payment flow — no gateway, no idempotency, no receipt.

### 3. Endpoints don't verify the JWT subject matches the requested resource owner
Several endpoints take an email or app ID as a path/query parameter and rely only on
role-based `@PreAuthorize` (e.g. `hasAnyRole('CUSTOMER','ADMIN')`), not on checking that the
JWT's subject actually owns that resource:

- `GET/PUT /api/users/{email}`
- `GET/POST/PUT /api/customer-profile/{email}`
- `GET /api/loan-applications?userEmail=...`
- `GET /api/notifications?userEmail=...`, `/api/service-requests?userEmail=...`

Any authenticated `CUSTOMER` can currently read or modify **another customer's** data by simply
changing the email/appId in the request, since nothing ties the request back to the token's
`sub` claim.

**Fix:** in each of these controllers/services, derive the email from the authenticated
principal (`Authentication`/`SecurityContext`) rather than trusting the request parameter, or at
minimum assert `principal.email == pathEmail` before proceeding.

*Current UI behavior:* the Angular app only ever sends the logged-in user's own email, so it
doesn't exploit this gap — but the gap exists server-side regardless.

---

## 🟡 Medium priority

### 4. No "by application" filter on legal notices or checklist items
`legal-service` has `GET /api/bank-office/decisions/by-application/{appId}` and
`GET /api/legal/verifications/by-application/{appId}`, but **no equivalent** on
`LegalNoticeController` or `LegalChecklistItemController` — only `findAll()` and `findById()`.

**Fix:** add `GET /api/legal-notices/by-application/{appId}` and
`GET /api/legal/checklist-items/by-application/{appId}`.

*Current UI behavior:* the Legal & Auction page fetches **all** notices/checklist items and
filters client-side by `appId`. Besides being wasteful as the table grows, this also means any
authenticated customer can currently pull every other customer's legal notices over the wire
(even though the UI itself only displays the filtered subset) — see gap #3.

### 5. No "insurance policies by application" endpoint
`repayment-service`'s `InsurancePolicyController` only has `findAll()`/`findById()` — no
`by-application/{appId}`.

**Fix:** add `GET /api/insurance-policies/by-application/{appId}`.

*Current UI behavior:* the Repayment page fetches all policies and filters client-side —
same efficiency/exposure caveat as #4.

### 6. No logged-in "change password" endpoint
The only password-change path is the OTP-based `forgot-password` → `reset-password` flow.
There's no `PUT /api/users/{email}/password` (or similar) for an already-authenticated user who
simply wants to change their password from their profile page.

**Fix:** add an authenticated change-password endpoint that takes the current password + new
password, so users don't have to go through the "forgot password" flow just to update it.

*Current UI behavior:* the Profile page links to the Forgot Password flow for this.

### 7. No refresh-token / token-renewal endpoint
`JwtService` issues tokens with a configurable expiry (60 minutes by default) but there's no
`/api/users/refresh-token` endpoint, so once a token expires the user must log in again — even
mid-task.

**Fix:** add a refresh endpoint (or a longer-lived refresh token issued alongside the access
token).

*Current UI behavior:* on any `401`, the app force-logs-out and redirects to `/login` with a
"session expired" message.

### 8. No global/cross-entity search endpoint
There's no backend search across applications/documents/notifications, so a unified search bar
(present in the old UI mockup) isn't achievable server-side today.

**Fix (optional):** a lightweight `GET /api/search?userEmail=&q=` aggregator, either in the
gateway or a new endpoint, if this is a feature you want.

*Current UI behavior:* the topbar search box is present but disabled with a "coming soon"
tooltip, since there's nothing to call.

---

## 🟢 Low priority / observations

- **Documents are returned as base64 JSON**, not streamed as binary/multipart. Fine for the
  small KYC-style files in the demo data, but will not scale well for larger files (scanned
  property documents, etc.) — consider a multipart upload/download endpoint if file sizes grow.
- **`role` is a free-form string claim** in the JWT (`CUSTOMER`, `LEGAL`, `BANK_OFFICER`,
  `BIDDER`, `ADMIN`) rather than a structured claim/array — fine for now, but worth keeping in
  mind if you ever need multi-role users.
- **No logout/token-blacklist endpoint** — expected for a stateless JWT setup, just noting the
  app doesn't call anything server-side on logout, it simply discards the token client-side.

---

## Summary of endpoints actually used by this UI

| Feature | Endpoints |
|---|---|
| Auth | `POST /user-service/api/users/register`, `/login`, `/forgot-password`, `/reset-password`; `GET/PUT /api/users/{email}` |
| Profile | `GET/POST/PUT /user-service/api/customer-profile/{email}` |
| Products & Guidance | `GET /loan-service/api/loan-products`, `POST /api/loan-guidance/recommendations`, `/api/loan-guidance/emi-assistant` |
| Eligibility | `POST /loan-service/api/eligibility/assess`, `/simulate`; `GET /api/eligibility/history` |
| Applications | `GET/POST /loan-service/api/loan-applications`, `/draft`, `/{id}/submit`, `DELETE /{id}`, `GET /{id}/stakeholder`, `/timeline`, `/expected-completion` |
| Documents | `GET/POST/DELETE /document-service/api/application-documents/**`, `/post-disbursement-documents/**` |
| Repayment | `GET /repayment-service/api/emi/{appId}/schedule`, `PUT /api/emi/installments/{id}`, `GET /api/disbursements/by-application/{appId}`, `GET /api/insurance-policies` |
| Legal & Auction | `GET /legal-service/api/legal-notices`, `/api/legal/verifications/by-application/{appId}`; `GET /repayment-service/api/auctions/by-application/{appId}`, `/notes`, `/bids` |
| Notifications & Support | `GET/PATCH /notification-service/api/notifications/**`, `GET/POST /api/service-requests/**` |
