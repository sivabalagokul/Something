import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { routes } from './app.routes';
import { authInterceptor } from './core/interceptors/auth.interceptor';
import { BIDDER_AUTH } from './core/auth/bidder-auth.port';
import { AuthService } from './core/services/auth.service';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes, withComponentInputBinding()),
    provideHttpClient(withInterceptors([authInterceptor])),

    // The bidder feature module (ported from hlms-bidder-portal) reads auth
    // through this port instead of injecting AuthService directly. This one
    // line is the entire integration point their README describes.
    { provide: BIDDER_AUTH, useExisting: AuthService }
  ]
};
