import { Routes } from '@angular/router';
import { authGuard, guestGuard, roleGuard } from './core/guards/auth.guard';
import { Shell } from './shared/components/shell/shell';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/home/home').then((m) => m.Home)
  },
  {
    path: 'login',
    canActivate: [guestGuard],
    loadComponent: () => import('./features/auth/login/login').then((m) => m.Login)
  },
  {
    path: 'register',
    canActivate: [guestGuard],
    loadComponent: () => import('./features/auth/register/register').then((m) => m.Register)
  },
  {
    path: 'forgot-password',
    canActivate: [guestGuard],
    loadComponent: () =>
      import('./features/auth/forgot-password/forgot-password').then((m) => m.ForgotPassword)
  },
  {
    path: 'unauthorized',
    loadComponent: () =>
      import('./shared/components/unauthorized/unauthorized').then((m) => m.Unauthorized)
  },
  {
    path: 'bidder',
    canActivate: [roleGuard(['BIDDER'])],
    canActivateChild: [roleGuard(['BIDDER'])],
    loadChildren: () => import('./features/bidder/bidder.routes').then((m) => m.BIDDER_ROUTES)
  },
  {
    path: 'admin',
    canActivate: [roleGuard(['ADMIN'])],
    canActivateChild: [roleGuard(['ADMIN'])],
    loadChildren: () => import('./features/admin/admin.routes').then((m) => m.ADMIN_ROUTES)
  },
  {
    path: 'legal',
    canActivate: [roleGuard(['LEGAL'])],
    canActivateChild: [roleGuard(['LEGAL'])],
    loadChildren: () => import('./features/legal/legal.routes').then((m) => m.LEGAL_ROUTES)
  },
  {
    path: 'bankoffice',
    canActivate: [roleGuard(['BANK_OFFICER'])],
    canActivateChild: [roleGuard(['BANK_OFFICER'])],
    loadChildren: () => import('./features/bankoffice/bankoffice.routes').then((m) => m.BANKOFFICE_ROUTES)
  },
  {
    path: 'customer',
    component: Shell,
    canActivate: [authGuard, roleGuard(['CUSTOMER'])],
    children: [
      {
        path: 'dashboard',
        loadComponent: () => import('./features/dashboard/dashboard').then((m) => m.Dashboard)
      },
      {
        path: 'guidance',
        loadComponent: () => import('./features/guidance/guidance').then((m) => m.Guidance)
      },
      {
        path: 'eligibility',
        loadComponent: () => import('./features/eligibility/eligibility').then((m) => m.Eligibility)
      },
      {
        path: 'apply',
        loadComponent: () => import('./features/apply/apply').then((m) => m.Apply)
      },
      {
        path: 'apply/:appId',
        loadComponent: () => import('./features/apply/apply').then((m) => m.Apply)
      },
      {
        path: 'tracking',
        loadComponent: () => import('./features/tracking/tracking').then((m) => m.Tracking)
      },
      {
        path: 'tracking/:appId',
        loadComponent: () => import('./features/tracking/tracking').then((m) => m.Tracking)
      },
      {
        path: 'repayment',
        loadComponent: () => import('./features/repayment/repayment').then((m) => m.Repayment)
      },
      {
        path: 'repayment/:appId',
        loadComponent: () => import('./features/repayment/repayment').then((m) => m.Repayment)
      },
      {
        path: 'postdisb',
        loadComponent: () => import('./features/postdisb/postdisb').then((m) => m.Postdisb)
      },
      {
        path: 'postdisb/:appId',
        loadComponent: () => import('./features/postdisb/postdisb').then((m) => m.Postdisb)
      },
      {
        path: 'documents',
        loadComponent: () => import('./features/documents/documents').then((m) => m.Documents)
      },
      {
        path: 'documents/:appId',
        loadComponent: () => import('./features/documents/documents').then((m) => m.Documents)
      },
      {
        path: 'auction',
        loadComponent: () => import('./features/auction/auction').then((m) => m.Auction)
      },
      {
        path: 'auction/:appId',
        loadComponent: () => import('./features/auction/auction').then((m) => m.Auction)
      },
      {
        path: 'profile',
        loadComponent: () => import('./features/profile/profile').then((m) => m.Profile)
      },
      {
        path: 'support',
        loadComponent: () => import('./features/support/support').then((m) => m.Support)
      },
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
    ]
  },
  { path: '**', redirectTo: '' }
];
