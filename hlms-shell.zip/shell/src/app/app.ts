import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ToastHost } from './shared/components/toast/toast';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, ToastHost],
  template: `
    <router-outlet></router-outlet>
    <app-toast-host></app-toast-host>
  `
})
export class App {}
