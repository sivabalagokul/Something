import { InjectionToken, Signal } from '@angular/core';

/**
 * The authenticated user, as this module needs to see them.
 *
 * `email` is the identity the HLMS backend keys everything on: it is the
 * JWT subject issued by user-service, the PK of `app_user`, and the value
 * stored in `bid.bidder_email`. It is NOT a display concern - it is the
 * join key for "my bids".
 */
export interface BidderSession {
  /** JWT `sub` claim - app_user.email. */
  readonly email: string;
  /** JWT `role` claim, e.g. 'BIDDER' (see user-service roleEnum). */
  readonly role: string;
  /** Display name, if the host shell knows it. Resolved from the profile API otherwise. */
  readonly name?: string;
}

/**
 * The one thing this module needs from the rest of the HLMS front end.
 *
 * Authentication is deliberately NOT implemented here: no login screen, no
 * login call, no token minting. The host shell logs the user in against
 * user-service (`POST /user-service/api/users/login`) and this module reads
 * the result through this port.
 *
 * To plug in your team's own AuthService, implement this interface (or add
 * these members to the existing service) and override the provider:
 *
 *   { provide: BIDDER_AUTH, useExisting: YourAuthService }
 *
 * Everything else - guard, interceptor, "my bids" filtering, profile - goes
 * through this port and needs no further change.
 */
export interface BidderAuthPort {
  /** Current session, or null when nobody is signed in. Signal so the shell can react. */
  readonly session: Signal<BidderSession | null>;

  /** Raw bearer token to attach to backend calls, or null. */
  token(): string | null;

  /** True when a non-expired token is present. */
  isAuthenticated(): boolean;

  /** True when the signed-in user carries the BIDDER role. */
  isBidder(): boolean;

  /**
   * Called when the backend rejects the session (401) or the user signs out.
   * The host shell owns what happens next - clearing storage, redirecting to
   * its own login route, etc.
   */
  signOut(reason?: 'expired' | 'user'): void;
}

export const BIDDER_AUTH = new InjectionToken<BidderAuthPort>('BIDDER_AUTH');

/** Role name that grants access to this portal. Matches user-service roleEnum.BIDDER. */
export const BIDDER_ROLE = 'BIDDER';
