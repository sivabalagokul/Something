import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/** Must be logged in with a non-expired token. Use alongside roleGuard for role-specific areas. */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isLoggedIn()) return true;

  router.navigate(['/login']);
  return false;
};

/**
 * Gates a role-specific area (e.g. /customer, /admin, /bidder, /legal,
 * /bankoffice). Wrong role -> /unauthorized rather than silently signing
 * the user out, since they may hold a different valid role.
 */
export const roleGuard = (allowed: string[]): CanActivateFn => {
  return () => {
    const auth = inject(AuthService);
    const router = inject(Router);

    if (!auth.isLoggedIn()) {
      router.navigate(['/login']);
      return false;
    }
    if (auth.hasRole(...allowed)) return true;
    return router.createUrlTree(['/unauthorized']);
  };
};

/** Keeps already-logged-in users out of the public login/register pages. */
export const guestGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isLoggedIn()) {
    const landing: Record<string, string> = {
      CUSTOMER: '/customer/dashboard',
      ADMIN: '/admin/dashboard',
      BIDDER: '/bidder/dashboard',
      LEGAL: '/legal/dashboard',
      BANK_OFFICER: '/bankoffice/bodash'
    };
    router.navigateByUrl(landing[auth.currentUser()?.role ?? ''] ?? '/');
    return false;
  }
  return true;
};
