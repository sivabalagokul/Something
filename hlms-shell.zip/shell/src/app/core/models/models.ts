/**
 * TypeScript interfaces mirroring the Java DTOs / JPA entities exposed by the
 * HLMS backend microservices. Field names match the JSON the backend actually
 * serializes (Jackson default: same name as the Java field, camelCase).
 */

// ===================== user-service =====================

export type UserRole = 'CUSTOMER' | 'LEGAL' | 'BANK_OFFICER' | 'BIDDER' | 'ADMIN';

export interface AppUser {
  email: string;
  name: string;
  mobile: string;
  passwordHash?: string;
  role: UserRole;
  active?: boolean;
  idType?: string;
  idNumber?: string;
  prefSms?: boolean;
  prefEmail?: boolean;
  prefInapp?: boolean;
  createdAt?: string;
  deletedAt?: string | null;
}

export interface RegisterRequest {
  email: string;
  name: string;
  mobile: string;
  password: string;
  role: UserRole;
  idType?: string;
  idNumber?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
}

export interface CustomerEmploymentProfile {
  profileId?: number;
  userEmail: string;
  employmentType?: string;
  employer?: string;
  monthlyIncome?: number;
  otherEmis?: number;
  desiredAmount?: number;
  pan?: string;
  deletedAt?: string | null;
}

// ===================== loan-service =====================

export interface LoanProduct {
  productId: string;
  name: string;
  category: string;
  interestRate: number;
  maxTenureYears: number;
  maxLtv: string;
  description: string;
  deletedAt?: string | null;
}

export interface EligibilityRequest {
  monthlyIncome: number;
  otherEmis: number;
  cibilScore: number;
  requestedAmount: number;
  tenureYears: number;
  interestRate: number;
}

export interface EligibilityResponse {
  status: string;
  maxEligibleLoanAmount: number;
  estimatedEmi: number;
  debtToIncomeRatio: number;
  reasons: string[];
  recommendations: string[];
}

export interface EligibilityAssessment {
  assessmentId: number;
  userEmail: string;
  requestedAmount: number;
  tenureYears: number;
  cibilScore: number;
  monthlyIncome: number;
  otherEmis: number;
  interestRate: number;
  status: string;
  maxEligibleLoanAmount: number;
  estimatedEmi: number;
  dtiRatio: number;
  reasons: string;
  recommendations: string;
  createdAt: string;
}

export interface MortgageCalculationRequest {
  requestedLoanAmount: number;
  propertyValue: number;
  productId?: string;
  tenureYears?: number;
  interestRate?: number;
  monthlyIncome?: number;
  otherEmis?: number;
  cibilScore?: number;
}

export interface MortgageCalculationResponse {
  requestedLoanAmount: number;
  propertyValue: number;
  unsecuredEligibleAmount: number;
  mortgageRequired: boolean;
  mortgageValueRequired: number;
  maxLtvAllowed: string;
  loanToValueRatio: number;
  collateralSufficient: boolean;
  notes: string[];
}

export interface LoanRecommendationRequest {
  purpose?: string;
  monthlyIncome?: number;
  otherEmis?: number;
  cibilScore?: number;
  requestedAmount?: number;
  tenureYears?: number;
}

export interface ProductRecommendation {
  productId: string;
  name: string;
  category: string;
  interestRate: number;
  maxTenureYears: number;
  maxLtv: string;
  estimatedEmi: number;
  matchReason: string;
}

export interface GuidanceAssistantRequest {
  loanAmount: number;
  interestRate: number;
  maxAffordableEmi?: number;
}

export interface EmiOption {
  tenureYears: number;
  emi: number;
  totalPayment: number;
  totalInterest: number;
  recommended: boolean;
}

export interface SubmitApplicationRequest {
  productId?: string;
  loanAmount?: number;
  tenureYears?: number;
  purpose?: string;
  applicantName?: string;
  applicantMobile?: string;
  applicantPan?: string;
  addrDoorNo?: string;
  addrStreet?: string;
  addrCity?: string;
  addrState?: string;
  addrPincode?: string;
  employmentType?: string;
  employer?: string;
  monthlyIncome?: number;
  otherEmis?: number;
  propertyAddress?: string; 
  propertyType?: string;
  propertyValue?: number;
  accountNumber?: string;
  confirmAccountNumber?: string;
}

export interface LoanApplication extends SubmitApplicationRequest {
  appId: string;
  trackingNo?: string;
  userEmail: string;
  interestRate?: number;
  status: string; // Draft, Submitted, Under Review, Rejected, Disbursed, ...
  stageIndex: number;
  currentStep: number;
  formData?: string;
  savedAt?: string;
  createdAt?: string;
  deletedAt?: string | null;
}

export interface StakeholderInfo {
  appId: string;
  currentStageName: string;
  stakeholderRole: string;
  stakeholderEmail: string | null;
  note: string;
}

export interface StageTimelineEntry {
  stageIndex: number;
  stageName: string;
  status: 'completed' | 'current' | 'upcoming' | string;
  occurredAt: string | null;
  actorEmail: string | null;
  action: string | null;
}

export interface WorkflowTimelineResponse {
  appId: string;
  currentStageIndex: number;
  currentStatus: string;
  timeline: StageTimelineEntry[];
}

export interface ExpectedCompletion {
  appId: string;
  currentStageIndex: number;
  currentStageName: string;
  expectedCompletionDate: string;
  slaDaysRemainingForStage: number;
}

// ===================== document-service =====================

export interface ApplicationDocument {
  documentId?: string;
  appId: string;
  docType: string;
  fileName: string;
  fileData?: string; // base64
  fileSize?: number;
  uploadedAt?: string;
  verificationStatus?: string; // Pending, Verified, Rejected
  verifiedBy?: string;
  verifiedAt?: string;
  remarks?: string;
  deletedAt?: string | null;
}

export interface PostDisbursementDocument {
  pdDocId?: string;
  appId: string;
  docType: string;
  fileName: string;
  fileData?: string; // base64
  fileSize?: number;
  note?: string;
  status?: string; // Pending, Verified, Rejected
  uploadedAt?: string;
  verifiedBy?: string;
  verifiedAt?: string;
  remarks?: string;
  deletedAt?: string | null;
}

// ===================== repayment-service =====================

export interface EmiInstallment {
  installmentId?: string;
  appId: string;
  installmentNo: number;
  dueDate: string;
  emiAmount: number;
  principalComponent: number;
  interestComponent: number;
  closingBalance: number;
  status: string; // Pending, Paid, Overdue
  paidDate?: string | null;
}

export interface Disbursement {
  disbursementId?: number;
  appId: string;
  disbursedDate: string;
  amount: number;
  refNo: string;
  mode: string;
  bankDetails: string;
}

export interface InsurancePolicy {
  policyId?: string;
  appId: string;
  policyType: string;
  status: string;
  validTill: string;
}

export interface AuctionCase {
  auctionId?: number;
  appId: string;
  stage: string;
  noticeDate?: string;
  noticeDueDate?: string;
  demandAmount?: number;
  possessionDate?: string;
  auctionDate?: string;
  reservePrice?: number;
}

export interface AuctionNote {
  noteId?: string;
  appId: string;
  noteDate?: string;
  noteText: string;
}

export interface Bid {
  bidId?: string;
  appId: string;
  bidderEmail: string;
  bidAmount: number;
  createdAt?: string;
}

// ===================== legal-service =====================

export interface LegalNotice {
  noticeId?: string;
  noticeNo?: string;
  appId: string;
  noticeType: string;
  issueDate: string;
  dueDate: string;
  status: string;
  officerEmail?: string;
  content?: string;
}

export interface LegalVerification {
  verificationId?: number;
  appId: string;
  decision: string;
  decisionDate?: string;
  officerEmail?: string;
  remarks?: string;
  infoRequested?: boolean;
  infoRequestDetails?: string;
  infoRequestedAt?: string;
}

export interface LegalChecklistItem {
  checklistItemId?: string;
  appId: string;
  checklistKey: string;
  status: string;
}

export interface BankOfficeDecision {
  decisionId?: number;
  appId: string;
  status: string;
  officerEmail?: string;
  decisionDate?: string;
  reason?: string;
  remarks?: string;
}

// ===================== notification-service =====================

export interface Notification {
  notificationId?: string;
  userEmail: string;
  title: string;
  body: string;
  channels?: string[];
  isRead?: boolean;
  createdAt?: string;
}

export interface ServiceRequest {
  requestId?: string;
  refNo?: string;
  appId?: string;
  userEmail: string;
  requestType: string;
  description?: string;
  status?: string; // Requested, In Progress, Completed, Rejected
  createdAt?: string;
}
