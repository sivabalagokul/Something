import { Injectable, computed, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap, switchMap, of } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AppUser, LoginRequest, LoginResponse, RegisterRequest } from '../models/models';

const TOKEN_KEY = 'hlms_token';
const USER_KEY = 'hlms_user';

interface DecodedToken {
  sub: string; // email
  role: string;
  exp: number;
  iat: number;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private base = `${environment.apiBase}/user-service/api/users`;

  private _token = signal<string | null>(localStorage.getItem(TOKEN_KEY));
  private _user = signal<AppUser | null>(this.readStoredUser());

  readonly token = computed(() => this._token());
  readonly currentUser = computed(() => this._user());
  readonly isLoggedIn = computed(() => !!this._token() && !this.isExpired());
  readonly isCustomer = computed(() => this._user()?.role === 'CUSTOMER');
  readonly isAdmin = computed(() => this._user()?.role === 'ADMIN');
  readonly isLegal = computed(() => this._user()?.role === 'LEGAL');
  readonly isBankOfficer = computed(() => this._user()?.role === 'BANK_OFFICER');
  readonly isBidderRole = computed(() => this._user()?.role === 'BIDDER');

  /**
   * Shape expected by feature modules ported in from standalone apps
   * (bidder portal's BidderAuthPort, and similarly-shaped ports in the
   * legal / bankoffice modules). email/role/name only - the minimum every
   * ported module needs to gate routes and filter "my X" queries.
   */
  readonly session = computed(() => {
    const u = this._user();
    return u ? { email: u.email, role: u.role, name: u.name } : null;
  });

  hasRole(...roles: string[]): boolean {
    const role = this._user()?.role;
    return !!role && roles.includes(role);
  }

  constructor(private http: HttpClient, private router: Router) {}

  private readStoredUser(): AppUser | null {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? (JSON.parse(raw) as AppUser) : null;
  }

  private decode(token: string): DecodedToken | null {
    try {
      const payload = token.split('.')[1];
      const json = decodeURIComponent(
        atob(payload.replace(/-/g, '+').replace(/_/g, '/'))
          .split('')
          .map((c) => '%' + c.charCodeAt(0).toString(16).padStart(2, '0'))
          .join('')
      );
      return JSON.parse(json);
    } catch {
      return null;
    }
  }

  private isExpired(): boolean {
    const t = this._token();
    if (!t) return true;
    const decoded = this.decode(t);
    if (!decoded) return true;
    return decoded.exp * 1000 < Date.now();
  }

  /** Login against user-service, then hydrate the full profile via GET /api/users/{email}. */
  login(req: LoginRequest): Observable<AppUser> {
    return this.http.post<LoginResponse>(`${this.base}/login`, req).pipe(
      switchMap((res) => {
        const decoded = this.decode(res.token);
        if (!decoded) throw new Error('Received an invalid token from the server.');
        localStorage.setItem(TOKEN_KEY, res.token);
        this._token.set(res.token);
        return this.http.get<AppUser>(`${this.base}/${encodeURIComponent(decoded.sub)}`);
      }),
      tap((user) => {
        localStorage.setItem(USER_KEY, JSON.stringify(user));
        this._user.set(user);
      })
    );
  }

  register(req: RegisterRequest): Observable<AppUser> {
    return this.http.post<AppUser>(`${this.base}/register`, req);
  }

  forgotPassword(email: string): Observable<string> {
    return this.http.post(`${this.base}/forgot-password`, { email }, { responseType: 'text' });
  }

  resetPassword(email: string, otpCode: string, newPassword: string): Observable<string> {
    return this.http.post(
      `${this.base}/reset-password`,
      { email, otpCode, newPassword },
      { responseType: 'text' }
    );
  }

  refreshCurrentUser(): Observable<AppUser | null> {
    const email = this._user()?.email;
    if (!email) return of(null);
    return this.http.get<AppUser>(`${this.base}/${encodeURIComponent(email)}`).pipe(
      tap((user) => {
        localStorage.setItem(USER_KEY, JSON.stringify(user));
        this._user.set(user);
      })
    );
  }

  logout(navigate = true): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    this._token.set(null);
    this._user.set(null);
    if (navigate) this.router.navigateByUrl('/');
  }

  // ---- Method-shaped surface for ported feature modules -------------------
  // The bidder/legal/bankoffice modules were built as standalone apps and
  // call these as methods (auth.token(), auth.isAuthenticated(), ...)
  // rather than reading the computed signals above directly. Both surfaces
  // stay in sync because they read the same private signals.

  isAuthenticated(): boolean {
    return this.isLoggedIn();
  }

  isBidder(): boolean {
    return this.isBidderRole();
  }

  /** Alias so BIDDER_AUTH's signOut(reason) call site needs no changes. */
  signOut(reason?: 'expired' | 'user'): void {
    this.logout(true);
  }
}
