import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { BankOfficeDecision, LegalChecklistItem, LegalNotice, LegalVerification } from '../models/models';

@Injectable({ providedIn: 'root' })
export class LegalService {
  private base = `${environment.apiBase}/legal-service/api`;

  constructor(private http: HttpClient) {}

  /**
   * LegalNoticeController has no "by-application/{appId}" endpoint (unlike
   * BankOfficeDecisionController / LegalVerificationController), so this
   * fetches the full list and filters client-side (see API_GAPS.md).
   */
  noticesForApp(appId: string): Observable<LegalNotice[]> {
    return this.http
      .get<LegalNotice[]>(`${this.base}/legal-notices`)
      .pipe(map((all) => all.filter((n) => n.appId === appId)));
  }

  verificationByApp(appId: string): Observable<LegalVerification> {
    return this.http.get<LegalVerification>(`${this.base}/legal/verifications/by-application/${appId}`);
  }

  /**
   * LegalChecklistItemController has no "by-application/{appId}" endpoint either;
   * filtered client-side the same way as legal notices (see API_GAPS.md).
   */
  checklistForApp(appId: string): Observable<LegalChecklistItem[]> {
    return this.http
      .get<LegalChecklistItem[]>(`${this.base}/legal/checklist-items`)
      .pipe(map((all) => all.filter((c) => c.appId === appId)));
  }

  bankOfficeDecisionByApp(appId: string): Observable<BankOfficeDecision> {
    return this.http.get<BankOfficeDecision>(`${this.base}/bank-office/decisions/by-application/${appId}`);
  }
}
