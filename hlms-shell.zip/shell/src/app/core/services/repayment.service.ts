import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  AuctionCase,
  AuctionNote,
  Bid,
  Disbursement,
  EmiInstallment,
  InsurancePolicy
} from '../models/models';

@Injectable({ providedIn: 'root' })
export class RepaymentService {
  private base = `${environment.apiBase}/repayment-service/api`;

  constructor(private http: HttpClient) {}

  // ---- EMI schedule ----

  schedule(appId: string): Observable<EmiInstallment[]> {
    return this.http.get<EmiInstallment[]>(`${this.base}/emi/${appId}/schedule`);
  }

  /**
   * No dedicated "pay EMI" endpoint exists on the backend (see API_GAPS.md).
   * As a workaround this updates the installment record directly via the
   * generic PUT /api/emi/installments/{id} endpoint.
   */
  markInstallmentPaid(installment: EmiInstallment): Observable<EmiInstallment> {
    const payload: EmiInstallment = {
      ...installment,
      status: 'Paid',
      paidDate: new Date().toISOString().slice(0, 10)
    };
    return this.http.put<EmiInstallment>(
      `${this.base}/emi/installments/${installment.installmentId}`,
      payload
    );
  }

  // ---- Disbursement ----

  disbursementByApp(appId: string): Observable<Disbursement> {
    return this.http.get<Disbursement>(`${this.base}/disbursements/by-application/${appId}`);
  }

  // ---- Insurance ----
  // NOTE: there is no GET /api/insurance-policies/by-application/{appId} endpoint,
  // so callers must fetch all and filter client-side (see API_GAPS.md).

  allInsurancePolicies(): Observable<InsurancePolicy[]> {
    return this.http.get<InsurancePolicy[]>(`${this.base}/insurance-policies`);
  }

  // ---- Auction / SARFAESI transparency ----

  auctionByApp(appId: string): Observable<AuctionCase> {
    return this.http.get<AuctionCase>(`${this.base}/auctions/by-application/${appId}`);
  }

  auctionNotes(appId: string): Observable<AuctionNote[]> {
    return this.http.get<AuctionNote[]>(`${this.base}/auctions/${appId}/notes`);
  }

  auctionBids(appId: string): Observable<Bid[]> {
    return this.http.get<Bid[]>(`${this.base}/auctions/${appId}/bids`);
  }

  // ---- Default management ----

  defaultStatus(appId: string): Observable<string> {
    return this.http.get(`${this.base}/default-management/status/${appId}`, { responseType: 'text' });
  }

  escalationLevel(appId: string): Observable<string> {
    return this.http.get(`${this.base}/default-management/escalation/${appId}`, {
      responseType: 'text'
    });
  }
}
