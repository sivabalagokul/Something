import { Injectable, signal } from '@angular/core';

export interface ToastMsg {
  id: number;
  title: string;
  message: string;
  type: 'info' | 'success' | 'error';
}

let counter = 0;

@Injectable({ providedIn: 'root' })
export class ToastService {
  readonly toasts = signal<ToastMsg[]>([]);

  show(title: string, message: string, type: ToastMsg['type'] = 'info') {
    const id = ++counter;
    this.toasts.update((t) => [...t, { id, title, message, type }]);
    setTimeout(() => this.dismiss(id), 4500);
  }

  success(title: string, message = '') {
    this.show(title, message, 'success');
  }

  error(title: string, message = '') {
    this.show(title, message, 'error');
  }

  dismiss(id: number) {
    this.toasts.update((t) => t.filter((x) => x.id !== id));
  }
}
