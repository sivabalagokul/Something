import { Routes } from '@angular/router';

/**
 * Everything under /admin. Role-gated in app.routes.ts (roleGuard(['ADMIN'])),
 * so no auth/role guard is repeated here.
 */
export const ADMIN_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./admin-shell/admin-shell.component').then((m) => m.AdminShellComponent),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      {
        path: 'dashboard',
        loadComponent: () => import('./dashboard/dashboard.component').then((m) => m.DashboardComponent)
      },
      {
        path: 'bidder-management',
        loadComponent: () =>
          import('./staff-management/staff-management.component').then((m) => m.StaffManagementComponent),
        data: {
          pageTitle: 'Bidder Management',
          pageDesc: 'Manage bidder accounts from one place.',
          activeTab: 'BIDDER',
          tabs: [{ key: 'BIDDER', label: 'Bidders', route: '/admin/bidder-management' }]
        }
      },
      { path: 'admin-management', redirectTo: 'employee-management', pathMatch: 'full' },
      {
        path: 'employee-management',
        loadComponent: () =>
          import('./staff-management/staff-management.component').then((m) => m.StaffManagementComponent),
        data: {
          pageTitle: 'Employee Management',
          pageDesc: 'Manage staff accounts and their access to HLMS across departments.',
          activeTab: 'ADMIN',
          tabs: [
            { key: 'ADMIN', label: 'Admins', route: '/admin/employee-management' },
            { key: 'LEGAL', label: 'Legal Team', route: '/admin/legal-management' },
            { key: 'BANK_OFFICER', label: 'Bank Office', route: '/admin/bankoffice-management' }
          ]
        }
      },
      {
        path: 'legal-management',
        loadComponent: () =>
          import('./staff-management/staff-management.component').then((m) => m.StaffManagementComponent),
        data: {
          pageTitle: 'Legal Team',
          pageDesc: 'Manage legal & valuation team accounts.',
          activeTab: 'LEGAL',
          tabs: [
            { key: 'ADMIN', label: 'Admins', route: '/admin/employee-management' },
            { key: 'LEGAL', label: 'Legal Team', route: '/admin/legal-management' },
            { key: 'BANK_OFFICER', label: 'Bank Office', route: '/admin/bankoffice-management' }
          ]
        }
      },
      {
        path: 'bankoffice-management',
        loadComponent: () =>
          import('./staff-management/staff-management.component').then((m) => m.StaffManagementComponent),
        data: {
          pageTitle: 'Bank Office',
          pageDesc: 'Manage bank officer accounts.',
          activeTab: 'BANK_OFFICER',
          tabs: [
            { key: 'ADMIN', label: 'Admins', route: '/admin/employee-management' },
            { key: 'LEGAL', label: 'Legal Team', route: '/admin/legal-management' },
            { key: 'BANK_OFFICER', label: 'Bank Office', route: '/admin/bankoffice-management' }
          ]
        }
      },
      {
        path: 'profile',
        loadComponent: () => import('./profile/profile.component').then((m) => m.ProfileComponent)
      }
    ]
  }
];
