import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

import { UserService } from '../core/services/user.service';
import { AuthService } from '../../../core/services/auth.service';
import { ApiBannerComponent } from '../shared/api-banner/api-banner.component';
import { AppUser, ROLE_LABELS, UiRole } from '../core/models/user.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, ApiBannerComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
  private userService = inject(UserService);
  auth = inject(AuthService);

  loading = signal(true);
  apiUnavailable = signal(false);

  counts = signal({ employee: 0, legal: 0, bankoffice: 0, bidder: 0, admin: 0 });
  totalStaff = signal(0);
  recentUsers = signal<AppUser[]>([]);
  roleLabels = ROLE_LABELS;

  ngOnInit(): void {
    this.userService.listByRoles(['EMPLOYEE', 'LEGAL', 'BANK_OFFICER', 'BIDDER', 'ADMIN']).subscribe({
      next: (byRole) => {
        const employee = byRole['EMPLOYEE']?.length ?? 0;
        const legal = byRole['LEGAL']?.length ?? 0;
        const bankoffice = byRole['BANK_OFFICER']?.length ?? 0;
        const bidder = byRole['BIDDER']?.length ?? 0;
        const admin = byRole['ADMIN']?.length ?? 0;

        this.counts.set({ employee, legal, bankoffice, bidder, admin });
        this.totalStaff.set(admin + employee + legal + bankoffice);

        const all = ([] as AppUser[]).concat(...Object.values(byRole));
        this.apiUnavailable.set(all.length === 0);

        this.recentUsers.set(
          [...all]
            .sort((a, b) => new Date(b.createdAt ?? 0).getTime() - new Date(a.createdAt ?? 0).getTime())
            .slice(0, 6)
        );

        this.loading.set(false);
      },
      error: () => {
        this.apiUnavailable.set(true);
        this.loading.set(false);
      }
    });
  }

  roleLabel(role: UiRole): string {
    return this.roleLabels[role] ?? role;
  }

  firstName(): string {
    const name = this.auth.currentUser()?.name ?? '';
    return name.split(' ')[0] || 'Admin';
  }
}
