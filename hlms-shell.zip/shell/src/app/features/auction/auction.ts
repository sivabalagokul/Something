import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { LegalService } from '../../core/services/legal.service';
import { RepaymentService } from '../../core/services/repayment.service';
import { AuctionCase, AuctionNote, Bid, LegalNotice, LoanApplication } from '../../core/models/models';

@Component({
  selector: 'app-auction',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Legal &amp; Auction Status</h1>
      <p>Transparency view of any legal notices or SARFAESI/auction proceedings on your loan.</p>
    </div>

    @if (!appId()) {
      <div class="card">
        @if (listLoading()) {
          <div class="page-loading"><span class="spinner dark"></span> Loading your applications…</div>
        } @else if (apps().length === 0) {
          <div class="empty-state"><p>No applications found.</p></div>
        } @else {
          <table>
            <thead><tr><th>App ID</th><th>Product</th><th>Status</th><th></th></tr></thead>
            <tbody>
              @for (a of apps(); track a.appId) {
                <tr class="clickable-row" [routerLink]="['/auction', a.appId]">
                  <td>{{ a.trackingNo || a.appId }}</td><td>{{ a.productId || '—' }}</td>
                  <td><span class="badge badge-gray">{{ a.status }}</span></td>
                  <td><span class="btn-link">View →</span></td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    } @else {
      <button class="back-link" routerLink="/auction">← All Applications</button>

      <div class="card">
        <h3>📜 Legal Notices</h3>
        @if (notices().length === 0) {
          <div class="empty-state"><p>No legal notices on record for this application. That's good news.</p></div>
        } @else {
          <table>
            <thead><tr><th>Notice No.</th><th>Type</th><th>Issued</th><th>Due</th><th>Status</th></tr></thead>
            <tbody>
              @for (n of notices(); track n.noticeId) {
                <tr>
                  <td>{{ n.noticeNo || n.noticeId }}</td><td>{{ n.noticeType }}</td>
                  <td>{{ n.issueDate | date }}</td><td>{{ n.dueDate | date }}</td>
                  <td><span class="badge badge-red">{{ n.status }}</span></td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>

      @if (auctionCase(); as ac) {
        <div class="card">
          <h3>🏛 Auction Case</h3>
          <div class="case-card">
            <div class="grid grid-4">
              <div class="stat"><span class="lbl">Stage</span><span class="val">{{ ac.stage }}</span></div>
              <div class="stat"><span class="lbl">Demand Amount</span><span class="val">₹{{ ac.demandAmount | number: '1.0-0' }}</span></div>
              <div class="stat"><span class="lbl">Auction Date</span><span class="val">{{ ac.auctionDate ? (ac.auctionDate | date) : '—' }}</span></div>
              <div class="stat"><span class="lbl">Reserve Price</span><span class="val">{{ ac.reservePrice ? ('₹' + (ac.reservePrice | number: '1.0-0')) : '—' }}</span></div>
            </div>
          </div>

          @if (notes().length > 0) {
            <h4 style="margin-top:16px;">Case Notes</h4>
            @for (n of notes(); track n.noteId) {
              <div class="note-item">
                <div class="dt">{{ n.noteDate | date: 'medium' }}</div>
                {{ n.noteText }}
              </div>
            }
          }

          @if (bids().length > 0) {
            <h4 style="margin-top:16px;">Bids Received</h4>
            <table>
              <thead><tr><th>Bidder</th><th>Amount</th><th>Placed</th></tr></thead>
              <tbody>
                @for (b of bids(); track b.bidId) {
                  <tr><td>{{ b.bidderEmail }}</td><td>₹{{ b.bidAmount | number: '1.0-0' }}</td><td>{{ b.createdAt | date: 'medium' }}</td></tr>
                }
              </tbody>
            </table>
          }
        </div>
      } @else if (!loadingAuction()) {
        <div class="card">
          <div class="empty-state"><div class="ic">☆</div><p>No auction proceedings on record for this application.</p></div>
        </div>
      }
    }
  `
})
export class Auction {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private legalSvc = inject(LegalService);
  private repaySvc = inject(RepaymentService);
  private route = inject(ActivatedRoute);

  appId = signal<string | null>(null);
  listLoading = signal(true);
  apps = signal<LoanApplication[]>([]);

  notices = signal<LegalNotice[]>([]);
  auctionCase = signal<AuctionCase | null>(null);
  loadingAuction = signal(true);
  notes = signal<AuctionNote[]>([]);
  bids = signal<Bid[]>([]);

  constructor() {
    const routeAppId = this.route.snapshot.paramMap.get('appId');
    if (routeAppId) {
      this.appId.set(routeAppId);
      this.listLoading.set(false);
      this.loadDetail(routeAppId);
    } else {
      const email = this.auth.currentUser()?.email;
      if (email) {
        this.loanSvc.listForUser(email).subscribe({
          next: (list) => {
            this.apps.set(list);
            this.listLoading.set(false);
          },
          error: () => this.listLoading.set(false)
        });
      } else {
        this.listLoading.set(false);
      }
    }
  }

  private loadDetail(appId: string): void {
    this.legalSvc.noticesForApp(appId).subscribe({ next: (n) => this.notices.set(n), error: () => {} });
    this.repaySvc.auctionByApp(appId).subscribe({
      next: (ac) => {
        this.auctionCase.set(ac);
        this.loadingAuction.set(false);
        this.repaySvc.auctionNotes(appId).subscribe({ next: (n) => this.notes.set(n), error: () => {} });
        this.repaySvc.auctionBids(appId).subscribe({ next: (b) => this.bids.set(b), error: () => {} });
      },
      error: () => this.loadingAuction.set(false)
    });
  }
}
