import { Routes } from '@angular/router';

/**
 * Everything under /bankoffice. Route segments (bodash, boapplications, ...)
 * match sidebar.config.ts's BANK_OFFICE_NAV_ITEMS exactly - keep them in
 * sync if either changes. Role-gated in app.routes.ts (roleGuard(['BANK_OFFICER'])).
 */
export const BANKOFFICE_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./layout/shell/shell.component').then((m) => m.ShellComponent),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'bodash' },
      { path: 'bodash', loadComponent: () => import('./bo-dashboard/bo-dashboard.component').then((m) => m.BoDashboardComponent) },
      { path: 'boapplications', loadComponent: () => import('./bo-applications/bo-applications.component').then((m) => m.BoApplicationsComponent) },
      { path: 'boappdetail/:appId', loadComponent: () => import('./bo-app-detail/bo-app-detail.component').then((m) => m.BoAppDetailComponent) },
      { path: 'boportfolio', loadComponent: () => import('./bo-portfolio/bo-portfolio.component').then((m) => m.BoPortfolioComponent) },
      { path: 'bodisbursement', loadComponent: () => import('./bo-disbursement/bo-disbursement.component').then((m) => m.BoDisbursementComponent) },
      { path: 'bonpa', loadComponent: () => import('./bo-npa/bo-npa.component').then((m) => m.BoNpaComponent) },
      { path: 'bodocs', loadComponent: () => import('./bo-docs/bo-docs.component').then((m) => m.BoDocsComponent) },
      { path: 'boauction', loadComponent: () => import('./bo-auction/bo-auction.component').then((m) => m.BoAuctionComponent) },
      { path: 'boreports', loadComponent: () => import('./bo-reports/bo-reports.component').then((m) => m.BoReportsComponent) },
      { path: 'bosettings', loadComponent: () => import('./bo-settings/bo-settings.component').then((m) => m.BoSettingsComponent) }
    ]
  }
];
