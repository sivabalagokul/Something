import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { forkJoin, of, catchError } from 'rxjs';
import { LoanService } from '../core/services/loan.service';
import { RepaymentService } from '../core/services/repayment.service';
import { LoanApplication, WORKFLOW_STAGES } from '../core/models/loan-application.model';

const NPA_THRESHOLD = 3; // 3+ overdue installments, matching bo-npa's classification rule

@Component({
  selector: 'app-bo-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-dashboard.component.html'
})
export class BoDashboardComponent implements OnInit {
  private loanService = inject(LoanService);
  private repaymentService = inject(RepaymentService);
  private router = inject(Router);

  applications = signal<LoanApplication[]>([]);
  productNames = signal<Record<string, string>>({});
  overdueCount = signal<number>(0);
  npaCount = signal<number>(0);
  disbursedThisMonth = signal<number>(0);
  loading = signal(true);

  recent = computed(() =>
    this.applications()
      .slice()
      .sort((a, b) => new Date(b.createdAt ?? 0).getTime() - new Date(a.createdAt ?? 0).getTime())
      .slice(0, 5)
  );

  readyToDisburse = computed(() =>
    this.applications().filter(
      (a) => a.stageIndex === WORKFLOW_STAGES.length - 1 && a.status !== 'Disbursed'
    ).length
  );

  disbursedTotal = computed(() =>
    this.applications()
      .filter((a) => a.status === 'Disbursed')
      .reduce((sum, a) => sum + (a.loanAmount || 0), 0)
  );

  totalCustomers = computed(() => new Set(this.applications().map((a) => a.userEmail)).size);

  ngOnInit(): void {
    this.loanService.getAllApplications().subscribe({
      next: (apps) => { this.applications.set(apps); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
    this.loanService.getProductNameMap().subscribe({
      next: (map) => this.productNames.set(map),
      error: () => this.productNames.set({})
    });

    this.repaymentService.getOverdue().subscribe({
      next: (appIds) => {
        this.overdueCount.set(appIds?.length ?? 0);
        this.computeNpaCount(appIds ?? []);
      },
      error: () => this.overdueCount.set(0)
    });

    this.repaymentService.getAllDisbursements().subscribe({
      next: (list) => {
        const now = new Date();
        const count = (list || []).filter((d) => {
          const dt = new Date(d.disbursedDate);
          return dt.getMonth() === now.getMonth() && dt.getFullYear() === now.getFullYear();
        }).length;
        this.disbursedThisMonth.set(count);
      },
      error: () => this.disbursedThisMonth.set(0)
    });
  }

  private computeNpaCount(appIds: string[]) {
    if (!appIds.length) { this.npaCount.set(0); return; }
    const requests = appIds.map((appId) =>
      this.repaymentService.getSchedule(appId).pipe(catchError(() => of([])))
    );
    forkJoin(requests).subscribe({
      next: (schedules) => {
        const npa = schedules.filter((s) => s.filter((i) => i.status === 'OVERDUE').length >= NPA_THRESHOLD).length;
        this.npaCount.set(npa);
      },
      error: () => this.npaCount.set(0)
    });
  }

  productName(productId?: string): string {
    if (!productId) return '—';
    return this.productNames()[productId] ?? productId;
  }

  countByStatus(status: string): number {
    return this.applications().filter((a) => a.status === status).length;
  }

  statusBadge(status?: string): string {
    if (status === 'Disbursed') return 'badge-green';
    if (status === 'Rejected') return 'badge-red';
    if (status === 'In Progress' || status === 'Submitted') return 'badge-orange';
    return 'badge-gray';
  }

  open(appId?: string) {
    if (appId) this.router.navigate(['/app/boappdetail', appId]);
  }

  goTo(view: string) {
    this.router.navigate(['/app/' + view]);
  }
}
