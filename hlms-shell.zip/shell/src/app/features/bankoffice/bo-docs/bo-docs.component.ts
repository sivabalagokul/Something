import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocumentService } from '../core/services/document.service';
import { LoanService } from '../core/services/loan.service';
import { NotificationService } from '../core/services/notification.service';
import { AuthService } from '../core/services/auth.service';
import { ToastService } from '../core/services/toast.service';
import { ApplicationDocument } from '../core/models/document.model';
import { LoanApplication } from '../core/models/loan-application.model';

interface CustomerDocGroup {
  appId: string;
  applicantName: string;
  trackingNo: string;
  loanType: string;
  loanAmount: number;
  docs: ApplicationDocument[];
  pendingCount: number;
}

@Component({
  selector: 'app-bo-docs',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-docs.component.html'
})
export class BoDocsComponent implements OnInit {
  private documentService = inject(DocumentService);
  private notificationService = inject(NotificationService);
  private loanService = inject(LoanService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);

  documents = signal<ApplicationDocument[]>([]);
  applications = signal<LoanApplication[]>([]);
  productNames = signal<Record<string, string>>({});
  loading = signal(true);
  pendingOnly = signal(true);

  pendingCount = computed(() => this.documents().filter((d) => d.verificationStatus === 'Pending').length);

  customersWithDocuments = computed(() => new Set(this.documents().map((d) => d.appId)).size);

  // One row per application, with its documents nested underneath - matches
  // the "Document Verification" screen's per-customer grouping.
  groups = computed<CustomerDocGroup[]>(() => {
    const byApp = new Map<string, ApplicationDocument[]>();
    for (const d of this.filtered()) {
      if (!byApp.has(d.appId)) byApp.set(d.appId, []);
      byApp.get(d.appId)!.push(d);
    }
    return Array.from(byApp.entries()).map(([appId, docs]) => {
      const app = this.applications().find((a) => String(a.appId) === String(appId));
      return {
        appId,
        applicantName: app?.applicantName || app?.userEmail || appId,
        trackingNo: app?.trackingNo || appId,
        loanType: app?.productId ? (this.productNames()[app.productId] ?? app.productId) : '—',
        loanAmount: app?.loanAmount ?? 0,
        docs,
        pendingCount: docs.filter((d) => d.verificationStatus === 'Pending').length
      };
    });
  });

  ngOnInit(): void {
    this.refresh();
    this.loanService.getAllApplications().subscribe({
      next: (apps) => this.applications.set(apps),
      error: () => this.applications.set([])
    });
    this.loanService.getProductNameMap().subscribe({
      next: (map) => this.productNames.set(map),
      error: () => this.productNames.set({})
    });
  }

  refresh() {
    this.loading.set(true);
    this.documentService.getAllDocuments().subscribe({
      next: (docs) => { this.documents.set(docs); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  filtered(): ApplicationDocument[] {
    return this.pendingOnly() ? this.documents().filter((d) => d.verificationStatus === 'Pending') : this.documents();
  }

  statusBadge(status: string): string {
    if (status === 'Verified') return 'badge-green';
    if (status === 'Rejected') return 'badge-red';
    return 'badge-orange';
  }

  applicantFor(appId: string): string {
    const app = this.applications().find((a) => String(a.appId) === String(appId));
    return app?.applicantName || app?.trackingNo || appId;
  }

  // Opens the document in a new tab using the base64 file bytes already
  // included on the entity - no extra endpoint needed. Mime type is guessed
  // from the file extension since the backend doesn't store a content-type.
  view(doc: ApplicationDocument) {
    if (!doc.fileData) {
      this.toast.show('No file available', 'This document has no stored file content.', 'error');
      return;
    }
    const ext = (doc.fileName || '').split('.').pop()?.toLowerCase();
    const mime =
      ext === 'pdf' ? 'application/pdf' :
      ext === 'png' ? 'image/png' :
      ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg' :
      'application/octet-stream';
    const win = window.open('', '_blank');
    if (win) {
      win.document.write(
        mime.startsWith('image/')
          ? `<img src="data:${mime};base64,${doc.fileData}" style="max-width:100%;">`
          : `<embed src="data:${mime};base64,${doc.fileData}" style="width:100%;height:100vh;" />`
      );
    }
  }
}
