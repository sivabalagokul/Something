import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { forkJoin, of, catchError } from 'rxjs';
import { RepaymentService } from '../core/services/repayment.service';
import { LoanService } from '../core/services/loan.service';
import { LegalService } from '../core/services/legal.service';
import { AuthService } from '../core/services/auth.service';
import { NotificationService } from '../core/services/notification.service';
import { ToastService } from '../core/services/toast.service';
import { LoanApplication } from '../core/models/loan-application.model';
import { AuctionCase } from '../core/models/auction.model';

interface OverdueRow {
  appId: string;
  trackingNo: string;
  applicantName: string;
  applicantEmail: string;
  overdueCount: number;
  outstandingBalance: number;
  auctionStage: AuctionCase['stage'];
  auction: AuctionCase | null;
}

const NPA_THRESHOLD = 3; // 3+ overdue installments -> eligible for NPA classification

@Component({
  selector: 'app-bo-npa',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-npa.component.html'
})
export class BoNpaComponent implements OnInit {
  private repaymentService = inject(RepaymentService);
  private loanService = inject(LoanService);
  private legalService = inject(LegalService);
  private auth = inject(AuthService);
  private notificationService = inject(NotificationService);
  private toast = inject(ToastService);
  private router = inject(Router);

  rows = signal<OverdueRow[]>([]);
  loading = signal(true);
  processingAppId = signal<string | null>(null);

  npaCount = computed(() => this.rows().filter((r) => this.isNpa(r)).length);

  ngOnInit(): void {
    this.load();
  }

  load() {
    this.loading.set(true);
    this.repaymentService.getOverdue().subscribe({
      next: (appIds) => {
        if (!appIds.length) { this.rows.set([]); this.loading.set(false); return; }
        this.loanService.getAllApplications().subscribe({
          next: (apps) => this.buildRows(appIds, apps),
          error: () => { this.rows.set([]); this.loading.set(false); }
        });
      },
      error: () => { this.rows.set([]); this.loading.set(false); }
    });
  }

  private buildRows(appIds: string[], apps: LoanApplication[]) {
    const requests = appIds.map((appId) =>
      forkJoin({
        appId: of(appId),
        schedule: this.repaymentService.getSchedule(appId).pipe(catchError(() => of([]))),
        auction: this.repaymentService.getAuctionForApp(appId).pipe(catchError(() => of(null)))
      })
    );
    forkJoin(requests).subscribe({
      next: (results) => {
        const rows: OverdueRow[] = results.map(({ appId, schedule, auction }) => {
          const app = apps.find((a) => String(a.appId) === String(appId));
          const overdueCount = schedule.filter((s) => s.status === 'OVERDUE').length;
          const latest = schedule.slice().sort((a, b) => b.installmentNo - a.installmentNo)[0];
          const outstandingBalance = latest?.closingBalance ?? app?.loanAmount ?? 0;
          return {
            appId,
            trackingNo: app?.trackingNo ?? appId,
            applicantName: app?.applicantName || app?.userEmail || appId,
            applicantEmail: app?.userEmail ?? '',
            overdueCount,
            outstandingBalance,
            auctionStage: (auction?.stage ?? 'None') as AuctionCase['stage'],
            auction
          };
        });
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => { this.rows.set([]); this.loading.set(false); }
    });
  }

  isNpa(row: OverdueRow): boolean {
    return row.overdueCount >= NPA_THRESHOLD;
  }

  open(row: OverdueRow) {
    if (row.appId) this.router.navigate(['/app/boappdetail', row.appId]);
  }

  canMarkNpa(row: OverdueRow): boolean {
    return this.isNpa(row) && row.auctionStage === 'None';
  }

  markAsNpa(row: OverdueRow) {
    if (!confirm(
      `Classify ${row.trackingNo} (${row.applicantName}) as NPA and start the auction/recovery process? ` +
      `A demand notice will be issued and the Legal Team will be notified.`
    )) return;

    const officer = this.auth.currentUser()?.email ?? 'bank-office';
    const now = new Date();
    const dueDate = new Date(now.getTime() + 60 * 24 * 60 * 60 * 1000);

    this.processingAppId.set(row.appId);

    this.repaymentService.createAuction({
      appId: row.appId,
      stage: 'Notice Issued',
      noticeDate: now.toISOString().slice(0, 10),
      noticeDueDate: dueDate.toISOString().slice(0, 10),
      demandAmount: row.outstandingBalance
    }).subscribe({
      next: () => {
        this.legalService.createNotice({
          appId: row.appId,
          noticeType: 'NPA Classification & Demand Notice — Section 13(2), SARFAESI Act',
          issueDate: now.toISOString().slice(0, 10),
          dueDate: dueDate.toISOString().slice(0, 10),
          status: 'Active',
          officerEmail: officer,
          content:
            `NPA CLASSIFICATION & DEMAND NOTICE UNDER SECTION 13(2) OF THE SARFAESI ACT, 2002\n\n` +
            `Loan Account No.: ${row.trackingNo}\n\n` +
            `Dear ${row.applicantName},\n\n` +
            `Your loan account has been classified as a Non-Performing Asset (NPA) due to non-payment of ` +
            `${row.overdueCount} or more EMI installments. You are hereby called upon to repay the outstanding ` +
            `amount of ₹${row.outstandingBalance} within 60 days of this notice, failing which the Bank may ` +
            `exercise its rights under Section 13(4) of the SARFAESI Act, 2002, including taking possession of ` +
            `the secured asset and its sale by e-auction, without further reference to you.\n\n` +
            `For HLMS Bank\nBank Office\n${officer}`
        }).subscribe({ error: () => {} });

        if (row.applicantEmail) {
          this.notificationService.send(
            row.applicantEmail,
            'Account Classified as NPA',
            `Your loan account ${row.trackingNo} has been classified as a Non-Performing Asset due to ` +
            `${row.overdueCount} overdue installments. A demand notice has been issued — please clear ` +
            `outstanding dues within 60 days.`
          ).subscribe({ error: () => {} });
        }

        this.processingAppId.set(null);
        this.toast.show('Marked as NPA', `${row.trackingNo} — demand notice issued and Legal Team notified.`, 'success');
        this.load();
      },
      error: () => {
        this.processingAppId.set(null);
        this.toast.show('Error', 'Could not classify account as NPA.', 'error');
      }
    });
  }
}
