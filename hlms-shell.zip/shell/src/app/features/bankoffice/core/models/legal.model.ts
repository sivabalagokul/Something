// NOTE: appId is a String business key (e.g. "APP1001") in every
// microservice's schema - never a numeric id. Field names below are
// kept in exact sync with each service's DTO (see hlms2.legal.dto.*).

export interface LegalVerification {
  verificationId?: number;
  appId: string;
  // LegalVerificationDTO calls this "decision", not "status".
  decision?: 'Pending' | 'Cleared' | 'Flagged' | 'Rejected';
  decisionDate?: string;
  officerEmail?: string;
  remarks?: string;
  infoRequested?: boolean;
  infoRequestDetails?: string;
}

export interface LegalChecklistItem {
  checklistItemId?: string;
  appId: string;
  // LegalChecklistItemDTO calls this "checklistKey", not "itemName",
  // and has no separate "completed" boolean - status carries that.
  checklistKey: string;
  status: 'Pending' | 'Verified' | 'Rejected';
}

export interface LegalNotice {
  noticeId?: string;
  noticeNo?: string;
  appId: string;
  noticeType: string;
  // LegalNoticeDTO's JSON fields are "issueDate" / "content", not
  // "issuedDate" / "description".
  issueDate: string;
  dueDate?: string;
  status?: 'Active' | 'Resolved' | 'Withdrawn';
  officerEmail?: string;
  content?: string;
}

export interface BankOfficeDecision {
  decisionId?: number;
  appId: string;
  // BankOfficeDecisionDTO's JSON field is "status", not "decision" -
  // and there's no "decidedBy"/"decidedAt", it's "officerEmail"/"decisionDate".
  status: 'Approved' | 'Rejected' | 'Pending';
  officerEmail?: string;
  decisionDate?: string;
  reason?: string;
  remarks?: string;
}
