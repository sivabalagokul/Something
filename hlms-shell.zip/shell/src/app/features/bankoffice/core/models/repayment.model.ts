// Field names/types below are kept in exact sync with repayment-service's
// DTOs (com.hlms2.repayment.dto.*) - appId is always the String business
// key (e.g. "APP1001"), and most primary ids there are String (UUID) too;
// only auctionId, decisionId, verificationId, disbursementId are numeric.

export interface EmiInstallment {
  installmentId?: string;
  appId: string;
  installmentNo: number;
  dueDate: string;
  emiAmount: number;
  principalComponent: number;
  interestComponent: number;
  closingBalance?: number;
  // EmiInstallmentServiceImpl validates against these exact uppercase values.
  status: 'PENDING' | 'PAID' | 'OVERDUE';
  paidDate?: string;
}

export interface Disbursement {
  disbursementId?: number;
  appId: string;
  // DisbursementDTO's JSON field is "disbursedDate", not "disbursementDate".
  disbursedDate: string;
  amount: number;
  refNo?: string;
  mode?: string;
  bankDetails?: string;
}

export interface InsurancePolicy {
  policyId?: string;
  appId: string;
  policyType: string;
  status: string;
  validTill?: string;
}
