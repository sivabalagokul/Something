export type UserRole = 'admin' | 'employee' | 'legal' | 'bankoffice' | 'customer' | 'bidder';

export interface AppUser {
  id?: number;
  fullName: string;
  email: string;
  phone?: string;
  password?: string;
  role: UserRole;
  active?: boolean;
  createdAt?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  role: UserRole;
}

/** Mirrors user-service's roleEnum, as used throughout the backend. */
export type BackendRole = 'CUSTOMER' | 'LEGAL' | 'BANK_OFFICER' | 'BIDDER' | 'ADMIN';

export const TO_UI_ROLE: Record<BackendRole, UserRole> = {
  CUSTOMER: 'customer',
  LEGAL: 'legal',
  BANK_OFFICER: 'bankoffice',
  BIDDER: 'bidder',
  ADMIN: 'admin'
};

export const TO_BACKEND_ROLE: Partial<Record<UserRole, BackendRole>> = {
  customer: 'CUSTOMER',
  legal: 'LEGAL',
  bankoffice: 'BANK_OFFICER',
  bidder: 'BIDDER',
  admin: 'ADMIN'
};
