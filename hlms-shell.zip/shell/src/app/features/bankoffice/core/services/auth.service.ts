import { Injectable, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { AuthService as ShellAuthService } from '../../../../core/services/auth.service';
import { AppUser, BackendRole, TO_UI_ROLE, TO_BACKEND_ROLE } from '../models/user.model';

/**
 * Bank-office feature module was built as its own app with its own AppUser
 * shape (fullName/phone, lowercase role strings) and its own AuthService.
 * Rather than rewrite all 10 bo-*.component.ts files, this thin adapter
 * keeps that exact shape but reads real session state from the shell's
 * shared AuthService, so login/logout/session stay unified app-wide.
 * Only updateProfile still calls the backend directly (the shared
 * AuthService has no equivalent).
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private shell = inject(ShellAuthService);
  private http = inject(HttpClient);
  private readonly baseUrl = `${environment.apiBaseUrl}/user-service/api/users`;

  readonly currentUser = computed<AppUser | null>(() => {
    const u = this.shell.currentUser();
    if (!u) return null;
    return {
      fullName: u.name,
      email: u.email,
      phone: u.mobile,
      role: TO_UI_ROLE[u.role as BackendRole] ?? 'customer',
      active: u.active,
      createdAt: u.createdAt
    };
  });

  readonly isLoggedIn = computed(() => this.shell.isLoggedIn());
  readonly role = computed(() => this.currentUser()?.role ?? null);

  logout(): void {
    this.shell.logout(true);
  }

  updateProfile(email: string, changes: Partial<AppUser>): Observable<AppUser> {
    const body = {
      email,
      name: changes.fullName,
      mobile: changes.phone,
      role: changes.role ? (TO_BACKEND_ROLE[changes.role] ?? 'CUSTOMER') : undefined,
      active: changes.active
    };
    return this.http.put<any>(`${this.baseUrl}/${encodeURIComponent(email)}`, body).pipe(
      map((u) => ({
        fullName: u.name,
        email: u.email,
        phone: u.mobile,
        role: TO_UI_ROLE[u.role as BackendRole] ?? 'customer',
        active: u.active,
        createdAt: u.createdAt
      }) as AppUser)
    );
  }
}
