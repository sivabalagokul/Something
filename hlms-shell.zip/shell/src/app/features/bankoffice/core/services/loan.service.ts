import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map, shareReplay } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { LoanApplication } from '../models/loan-application.model';
import { EligibilityRequest, EligibilityResult } from '../models/eligibility.model';

interface LoanProductLite { productId: string; name: string; }

@Injectable({ providedIn: 'root' })
export class LoanService {
  private readonly apps = `${environment.apiBaseUrl}/loan-service/api/loan-applications`;
  private readonly products = `${environment.apiBaseUrl}/loan-service/api/loan-products`;
  private readonly eligibility = `${environment.apiBaseUrl}/loan-service/api/eligibility`;
  private readonly mortgage = `${environment.apiBaseUrl}/loan-service/api/mortgage`;
  private readonly guidance = `${environment.apiBaseUrl}/loan-service/api/loan-guidance`;

  constructor(private http: HttpClient) {}

  // ---- Loan products ----
  getLoanProducts(): Observable<unknown[]> {
    return this.http.get<unknown[]>(this.products);
  }

  // productId -> display name (e.g. "HPL01" -> "Home Purchase Loan"), fetched
  // once per app session and shared across every component that needs a
  // human-readable "Loan Type" label instead of the raw product id.
  private productNameMap$?: Observable<Record<string, string>>;
  getProductNameMap(): Observable<Record<string, string>> {
    if (!this.productNameMap$) {
      this.productNameMap$ = this.http.get<LoanProductLite[]>(this.products).pipe(
        map((list) => Object.fromEntries((list || []).map((p) => [p.productId, p.name]))),
        shareReplay(1)
      );
    }
    return this.productNameMap$;
  }

  // ---- Applications ----
  // LoanApplicationController's root GET expects a "userEmail" query param, not "applicantEmail".
  getMyApplications(email: string): Observable<LoanApplication[]> {
    return this.http.get<LoanApplication[]>(this.apps, { params: { userEmail: email } });
  }

  // Drafts are applications the applicant hasn't submitted yet - they're not
  // a real submission, so the Bank Office should never see them in any
  // list/dashboard/report. Filtered here (rather than per-component) so
  // every screen that calls getAllApplications() is covered consistently.
  getAllApplications(): Observable<LoanApplication[]> {
    return this.http.get<LoanApplication[]>(`${this.apps}/all`).pipe(
      map((apps) => (apps || []).filter((a) => a.status !== 'Draft'))
    );
  }

  getApplication(appId: string): Observable<LoanApplication> {
    return this.http.get<LoanApplication>(`${this.apps}/${appId}`);
  }

  // NOTE: loan-applications has no "/context" aggregate endpoint - this call
  // will 404. Not currently invoked by any component.
  getApplicationContext(appId: string): Observable<unknown> {
    return this.http.get(`${this.apps}/${appId}/context`);
  }

  trackByNumber(trackingNo: string): Observable<LoanApplication> {
    return this.http.get<LoanApplication>(`${this.apps}/track/${trackingNo}`);
  }

  getWorkflowStages(): Observable<string[]> {
    return this.http.get<string[]>(`${this.apps}/workflow-stages`);
  }

  // LoanApplicationController.saveDraft takes appId/userEmail/currentStep as query
  // params (appId omitted = create new draft) and the form fields as the JSON body.
  saveDraft(
    userEmail: string,
    payload: Record<string, unknown>,
    appId?: string,
    currentStep = 1
  ): Observable<LoanApplication> {
    const params: Record<string, string> = { userEmail, currentStep: String(currentStep) };
    if (appId) params['appId'] = appId;
    return this.http.post<LoanApplication>(`${this.apps}/draft`, payload, { params });
  }

  submitApplication(appId: number): Observable<LoanApplication> {
    return this.http.post<LoanApplication>(`${this.apps}/${appId}/submit`, {});
  }

  // LoanApplicationController.updateStage expects { stageIndex, status } in the body,
  // not a free-text "stage" name.
  advanceStage(appId: string, stageIndex: number, status: string): Observable<LoanApplication> {
    return this.http.patch<LoanApplication>(`${this.apps}/${appId}/stage`, { stageIndex, status });
  }

  deleteApplication(appId: string): Observable<void> {
    return this.http.delete<void>(`${this.apps}/${appId}`);
  }

  // ---- Status tracking ----
  getTimeline(appId: string): Observable<unknown> {
    return this.http.get(`${this.apps}/${appId}/timeline`);
  }

  getExpectedCompletion(appId: string): Observable<unknown> {
    return this.http.get(`${this.apps}/${appId}/expected-completion`);
  }

  getTurnaround(appId: string): Observable<unknown> {
    return this.http.get(`${this.apps}/${appId}/turnaround`);
  }

  getTurnaroundReport(): Observable<unknown> {
    return this.http.get(`${this.apps}/turnaround-report`);
  }

  // ---- Eligibility ----
  assessEligibility(payload: EligibilityRequest): Observable<EligibilityResult> {
    return this.http.post<EligibilityResult>(`${this.eligibility}/assess`, payload);
  }

  simulateEligibility(payload: EligibilityRequest): Observable<EligibilityResult> {
    return this.http.post<EligibilityResult>(`${this.eligibility}/simulate`, payload);
  }

  getEligibilityHistory(): Observable<unknown[]> {
    return this.http.get<unknown[]>(`${this.eligibility}/history`);
  }

  // ---- Mortgage / property ----
  calculateMortgage(payload: unknown): Observable<unknown> {
    return this.http.post(`${this.mortgage}/calculate`, payload);
  }

  calculateMortgageForApp(appId: string, payload: unknown): Observable<unknown> {
    return this.http.post(`${this.mortgage}/${appId}/calculate`, payload);
  }

  evaluateProperty(appId: string, payload: unknown): Observable<unknown> {
    return this.http.post(`${this.mortgage}/${appId}/evaluate-property`, payload);
  }

  getMortgageDetail(appId: string): Observable<unknown> {
    return this.http.get(`${this.mortgage}/${appId}`);
  }

  // ---- Guidance ----
  getRecommendations(payload: unknown): Observable<unknown> {
    return this.http.post(`${this.guidance}/recommendations`, payload);
  }

  emiAssistant(payload: unknown): Observable<unknown> {
    return this.http.post(`${this.guidance}/emi-assistant`, payload);
  }
}
