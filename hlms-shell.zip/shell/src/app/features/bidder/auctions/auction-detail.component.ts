import { ChangeDetectionStrategy, Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { BIDDER_AUTH } from '../../../core/auth/bidder-auth.port';
import { AuctionListing, AuctionNoteDto, BidDto, PortalError } from '../core/models/hlms.models';
import { AuctionService } from '../core/services/auction.service';
import { BidService, equalsIgnoreCase } from '../core/services/bid.service';
import { BidderPortalService } from '../core/services/bidder-portal.service';
import { NotificationService } from '../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { ConfirmDialogComponent } from '../shared/components/confirm-dialog.component';
import { StateBlockComponent } from '../shared/components/state-block.component';
import { StatusBadgeComponent } from '../shared/components/status-badge.component';
import { DaysLeftPipe } from '../shared/pipes/days-left.pipe';
import { HlmsDatePipe } from '../shared/pipes/hlms-date.pipe';
import { InrPipe } from '../shared/pipes/inr.pipe';

/**
 * Auction detail and the place-bid workflow.
 *
 * The bid path is: local validation -> confirmation -> POST -> reload.
 * Local validation exists to save a round trip, never to decide the outcome:
 * BidServiceImpl re-checks the reserve price, the current highest bid and the
 * bidder's account on every request, and whatever it says is what the screen
 * reports. After a successful bid the auction and its history are re-fetched
 * rather than patched locally, so a competing bid placed a second earlier
 * shows up immediately.
 */
@Component({
  selector: 'hlms-auction-detail',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    ReactiveFormsModule,
    RouterLink,
    StateBlockComponent,
    StatusBadgeComponent,
    ConfirmDialogComponent,
    InrPipe,
    HlmsDatePipe,
    DaysLeftPipe,
  ],
  template: `
    <a class="back-link" routerLink="/bidder/auctions">← Back to auctions</a>

    <hlms-state-block
      [loading]="loading()"
      [error]="error()"
      loadingText="Loading auction..."
      (retry)="load()"
    >
      @if (listing(); as l) {
        <div class="page-head">
          <div class="row-between">
            <div>
              <h1>{{ l.property?.address ?? 'Property ' + l.auction.appId }}</h1>
              <p>
                {{ l.property?.type ?? 'Property' }} · Reference
                {{ l.property?.reference ?? l.auction.appId }} · Auction ID {{ l.auction.auctionId }}
              </p>
            </div>
            <hlms-status-badge [phase]="l.phase" />
          </div>
        </div>

        <div class="grid grid-2">
          <section class="card">
            <h3>🏠 Property</h3>
            <table>
              <tbody>
                <tr><td>Address</td><td class="right">{{ l.property?.address ?? '—' }}</td></tr>
                <tr><td>Property type</td><td class="right">{{ l.property?.type ?? '—' }}</td></tr>
                <tr><td>Location</td><td class="right">{{ location(l) }}</td></tr>
                <tr><td>Declared value</td><td class="right num">{{ l.property?.declaredValue | inr }}</td></tr>
                <tr><td>Loan reference</td><td class="right">{{ l.property?.reference ?? l.auction.appId }}</td></tr>
              </tbody>
            </table>
            <p class="small muted disclosure">
              Borrower identity is withheld from public listings under bank policy. Photographs, floor area and
              inspection schedules are not published through this portal.
            </p>
          </section>

          <section class="card">
            <h3>🔨 Auction</h3>
            <table>
              <tbody>
                <tr><td>Reserve price</td><td class="right num"><strong>{{ l.auction.reservePrice | inr }}</strong></td></tr>
                <tr><td>Current highest bid</td><td class="right num">{{ l.highestBid | inr: 'No bids yet' }}</td></tr>
                <tr><td>Minimum next bid</td><td class="right num">{{ l.minimumNextBid | inr }}</td></tr>
                <tr><td>Bids received</td><td class="right">{{ l.bidCount }}</td></tr>
                <tr><td>Auction date</td><td class="right">{{ l.auction.auctionDate | hlmsDate }}</td></tr>
                <tr><td>Possession date</td><td class="right">{{ l.auction.possessionDate | hlmsDate }}</td></tr>
                <tr>
                  <td>Status</td>
                  <td class="right">
                    @if (portal.canBid(l.phase)) {
                      <span class="countdown-pill">{{ l.daysLeft | daysLeft }}</span>
                    } @else {
                      <hlms-status-badge [phase]="l.phase" />
                    }
                  </td>
                </tr>
              </tbody>
            </table>
          </section>
        </div>

        <section class="card">
          <h3>💰 Place your bid</h3>

          @if (!portal.canBid(l.phase)) {
            <div class="empty-state">
              <div class="ic">🔒</div>
              @switch (l.phase) {
                @case ('UPCOMING') { This auction has not opened for bidding yet. }
                @case ('CONCLUDED') { The bank has closed this case. It is no longer accepting bids. }
                @default { Bidding closed on {{ l.auction.auctionDate | hlmsDate }}. }
              }
            </div>
          } @else {
            @if (l.iAmHighest) {
              <div class="notice ok">You hold the highest bid on this property at {{ l.myBid | inr }}.</div>
            } @else if (l.myBid !== null) {
              <div class="notice warn">
                You have been outbid. Your last bid was {{ l.myBid | inr }}; the highest is now {{ l.highestBid | inr }}.
              </div>
            }

            <form [formGroup]="form" (ngSubmit)="review()">
              <div class="two-col">
                <div class="field">
                  <label for="current">Current highest bid</label>
                  <input id="current" type="text" [value]="(l.highestBid | inr: 'No bids yet')" disabled />
                </div>
                <div class="field">
                  <label for="amount">Your bid (₹)</label>
                  <input
                    id="amount"
                    type="number"
                    formControlName="amount"
                    [min]="l.minimumNextBid"
                    step="1000"
                    [class.invalid]="showAmountError()"
                    [attr.aria-describedby]="showAmountError() ? 'amountError' : 'amountHint'"
                  />
                  @if (showAmountError()) {
                    <div class="error" id="amountError">
                      Enter at least {{ l.minimumNextBid | inr }} — bids must beat the current highest and the reserve.
                    </div>
                  } @else {
                    <div class="hint" id="amountHint">Minimum {{ l.minimumNextBid | inr }} · suggested {{ suggested() | inr }}</div>
                  }
                </div>
              </div>

              @if (bidError()) {
                <div class="notice err" role="alert">{{ bidError() }}</div>
              }

              <button type="submit" class="btn btn-primary btn-block" [disabled]="submitting()">
                {{ submitting() ? 'Placing bid...' : 'Place bid' }}
              </button>
              <p class="small muted terms">
                Placing a bid is a binding offer under the bank's e-auction terms and conditions.
              </p>
            </form>
          }
        </section>

        <section class="card">
          <h3>📜 Bid history</h3>
          @if (bids().length === 0) {
            <div class="empty-state"><div class="ic">📭</div>No bids yet. Yours would be the first.</div>
          } @else {
            <div class="table-wrap">
              <table>
                <thead>
                  <tr><th>Bidder</th><th>Amount</th><th>Placed</th></tr>
                </thead>
                <tbody>
                  @for (bid of bids(); track bid.bidId) {
                    <tr [class.mine]="isMine(bid)">
                      <td>{{ maskBidder(bid) }}</td>
                      <td class="num">{{ bid.bidAmount | inr }}</td>
                      <td>{{ bid.createdAt | hlmsDate: true }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
        </section>

        @if (notes().length > 0) {
          <section class="card">
            <h3>🗒️ Auction notices</h3>
            <div class="stack-8">
              @for (note of notes(); track note.noteId) {
                <div class="note">
                  <div class="small muted">{{ note.noteDate | hlmsDate: true }}</div>
                  <div>{{ note.noteText }}</div>
                </div>
              }
            </div>
          </section>
        }

        <hlms-confirm-dialog
          [open]="confirming()"
          title="Confirm your bid"
          [message]="confirmMessage()"
          confirmLabel="Place bid"
          [busy]="submitting()"
          (confirm)="submit()"
          (cancel)="confirming.set(false)"
        />
      }
    </hlms-state-block>
  `,
  styles: [
    `
      .disclosure { margin-top: 12px; line-height: 1.5; }
      .terms { margin-top: 10px; }
      tr.mine td { background: var(--teal-light); font-weight: 600; color: var(--teal); }
      .note { border-left: 3px solid var(--border); padding-left: 12px; font-size: 13.5px; color: var(--text-mid); }
    `,
  ],
})
export class AuctionDetailComponent implements OnInit {
  /** Bound from the route parameter via withComponentInputBinding(). */
  readonly auctionId = input.required<string>();

  readonly portal = inject(BidderPortalService);
  private readonly auctions = inject(AuctionService);
  private readonly bidService = inject(BidService);
  private readonly notifications = inject(NotificationService);
  private readonly auth = inject(BIDDER_AUTH);
  private readonly toasts = inject(ToastService);
  private readonly router = inject(Router);
  private readonly fb = inject(FormBuilder);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly listing = signal<AuctionListing | null>(null);
  readonly bids = signal<BidDto[]>([]);
  readonly notes = signal<AuctionNoteDto[]>([]);
  readonly bidError = signal<string | null>(null);
  readonly submitting = signal(false);
  readonly confirming = signal(false);

  readonly form = this.fb.nonNullable.group({
    amount: [null as number | null, [Validators.required, Validators.min(1)]],
  });

  readonly suggested = computed(() => {
    const l = this.listing();
    return l ? this.portal.suggestedBid(l.auction.reservePrice, l.highestBid) : 0;
  });

  readonly showAmountError = computed(() => {
    const control = this.form.controls.amount;
    return control.touched && !this.amountIsValid();
  });

  readonly confirmMessage = computed(() => {
    const l = this.listing();
    const amount = this.form.controls.amount.value ?? 0;
    const formatted = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(
      amount,
    );
    return `You are bidding ${formatted} on ${l?.property?.address ?? 'this property'}. Bids are binding and cannot be withdrawn from this portal.`;
  });

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    const id = Number(this.auctionId());
    if (!Number.isFinite(id)) {
      this.error.set('That auction reference is not valid.');
      this.loading.set(false);
      return;
    }

    this.loading.set(true);
    this.error.set(null);
    this.portal.listing(id).subscribe({
      next: (listing) => {
        this.listing.set(listing);
        this.loading.set(false);
        this.form.controls.amount.setValue(this.portal.suggestedBid(listing.auction.reservePrice, listing.highestBid));
        this.loadBids(listing.auction.appId);
        this.loadNotes(listing.auction.appId);
      },
      error: (err: PortalError) => {
        this.error.set(err.message ?? 'Unable to load this auction.');
        this.loading.set(false);
      },
    });
  }

  /** Step 1: local check, then the confirmation dialog. */
  review(): void {
    this.bidError.set(null);
    this.form.controls.amount.markAsTouched();
    if (!this.amountIsValid()) {
      return;
    }
    this.confirming.set(true);
  }

  /** Step 2: the actual POST. Guarded so a double tap cannot send two bids. */
  submit(): void {
    const listing = this.listing();
    const amount = this.form.controls.amount.value;
    const email = this.auth.session()?.email;

    if (!listing || amount === null || !email || this.submitting()) {
      return;
    }

    this.submitting.set(true);
    this.bidService.place({ appId: listing.auction.appId, bidderEmail: email, bidAmount: amount }).subscribe({
      next: (bid) => {
        this.submitting.set(false);
        this.confirming.set(false);
        this.toasts.success('Bid placed', `Your bid of ₹${bid.bidAmount.toLocaleString('en-IN')} has been recorded.`);
        this.notifications.refreshUnreadCount(email);
        this.load(); // refresh auction, highest bid and history from the backend
      },
      error: (err: PortalError) => {
        this.submitting.set(false);
        this.confirming.set(false);
        this.bidError.set(err.message);
        if (err.status === 400 || err.status === 409) {
          // The backend saw a state we did not - re-sync before the next attempt.
          this.load();
        }
      },
    });
  }

  isMine(bid: BidDto): boolean {
    return equalsIgnoreCase(bid.bidderEmail, this.auth.session()?.email);
  }

  /**
   * Bidder identities stay private: only the signed-in bidder sees their own
   * row unmasked. The email never reaches the screen.
   */
  maskBidder(bid: BidDto): string {
    if (this.isMine(bid)) {
      return 'You';
    }
    const [local] = bid.bidderEmail.split('@');
    return `${local.charAt(0).toUpperCase()}••• bidder`;
  }

  location(listing: AuctionListing): string {
    return [listing.property?.city, listing.property?.state].filter(Boolean).join(', ') || '—';
  }

  private amountIsValid(): boolean {
    const listing = this.listing();
    const amount = this.form.controls.amount.value;
    return !!listing && amount !== null && Number.isFinite(amount) && amount >= listing.minimumNextBid;
  }

  private loadBids(appId: string): void {
    this.portal.bidHistory(appId).subscribe({
      next: (bids) => this.bids.set(bids),
      error: () => this.bids.set([]),
    });
  }

  private loadNotes(appId: string): void {
    this.auctions.notes(appId).subscribe({
      next: (notes) => this.notes.set(notes),
      error: () => this.notes.set([]),
    });
  }
}
