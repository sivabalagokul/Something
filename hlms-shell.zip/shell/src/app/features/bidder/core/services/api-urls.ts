import { environment } from '../../../../../environments/environment';

/**
 * Every backend URL this module talks to, in one place.
 *
 * The HLMS gateway (api-gateway, :8080) routes by service name with
 * StripPrefix=1, so a call to
 *   {gateway}/repayment-service/api/auctions
 * reaches repayment-service as
 *   /api/auctions
 * No service base path is hard-coded anywhere else in the app.
 */
const gw = environment.apiBaseUrl;
const s = environment.services;

export const API = {
  auctions: {
    list: () => `${gw}${s.repayment}/api/auctions`,
    byId: (auctionId: number) => `${gw}${s.repayment}/api/auctions/${auctionId}`,
    byApplication: (appId: string) => `${gw}${s.repayment}/api/auctions/by-application/${encodeURIComponent(appId)}`,
    notes: (appId: string) => `${gw}${s.repayment}/api/auctions/${encodeURIComponent(appId)}/notes`,
    bids: (appId: string) => `${gw}${s.repayment}/api/auctions/${encodeURIComponent(appId)}/bids`,
  },
  bids: {
    all: () => `${gw}${s.repayment}/api/bids`,
    byId: (bidId: string) => `${gw}${s.repayment}/api/bids/${encodeURIComponent(bidId)}`,
  },
  loanApplications: {
    byId: (appId: string) => `${gw}${s.loan}/api/loan-applications/${encodeURIComponent(appId)}`,
  },
  notifications: {
    forUser: () => `${gw}${s.notification}/api/notifications`,
    unread: () => `${gw}${s.notification}/api/notifications/unread`,
    markRead: (notificationId: string) =>
      `${gw}${s.notification}/api/notifications/${encodeURIComponent(notificationId)}/read`,
  },
  users: {
    byEmail: (email: string) => `${gw}${s.user}/api/users/${encodeURIComponent(email)}`,
  },
} as const;
