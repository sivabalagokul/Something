import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, map } from 'rxjs';
import { BidDto, PlaceBidRequest } from '../models/hlms.models';
import { API } from './api-urls';
import { rethrowAsPortalError } from './error-mapper';

/**
 * repayment-service BidController + the nested bid routes on
 * AuctionCaseController.
 *
 * Backend rules enforced on POST (BidServiceImpl.validate) - the client
 * mirrors them for fast feedback but never assumes them:
 *   1. the auction case must exist and not be soft-deleted;
 *   2. bidAmount >= reservePrice;
 *   3. bidderEmail must be an active app_user;
 *   4. bidAmount must be strictly greater than the current highest bid.
 * The bid id is generated server-side ("BID-XXXXXXXX") and createdAt is
 * stamped server-side, so neither is ever sent from here.
 */
@Injectable({ providedIn: 'root' })
export class BidService {
  private readonly http = inject(HttpClient);

  /** GET /repayment-service/api/auctions/{appId}/bids - full bid history for one auction. */
  forAuction(appId: string): Observable<BidDto[]> {
    return this.http.get<BidDto[]>(API.auctions.bids(appId)).pipe(map(sortByAmountDesc), catchError(rethrowAsPortalError));
  }

  /**
   * POST /repayment-service/api/auctions/{appId}/bids -> 201 with the saved BidDTO.
   * A rejected bid comes back as 400 with the reason in ApiError.message.
   */
  place(request: PlaceBidRequest): Observable<BidDto> {
    const body: Partial<BidDto> = {
      appId: request.appId,
      bidderEmail: request.bidderEmail,
      bidAmount: request.bidAmount,
    };
    return this.http.post<BidDto>(API.auctions.bids(request.appId), body).pipe(catchError(rethrowAsPortalError));
  }

  /**
   * Every bid the signed-in bidder has placed.
   *
   * There is no by-bidder endpoint: GET /api/bids returns every bid from every
   * bidder, and the filtering below happens after the response has already
   * crossed the wire. That is a privacy problem, not just a performance one -
   * see BACKEND-GAPS.md #1 for the endpoint that should replace this.
   */
  mine(bidderEmail: string): Observable<BidDto[]> {
    return this.http.get<BidDto[]>(API.bids.all()).pipe(
      map((bids) => bids.filter((b) => equalsIgnoreCase(b.bidderEmail, bidderEmail))),
      map(sortByCreatedDesc),
      catchError(rethrowAsPortalError),
    );
  }

  /** All bids, used to compute highest-bid figures across the listing screens. */
  all(): Observable<BidDto[]> {
    return this.http.get<BidDto[]>(API.bids.all()).pipe(catchError(rethrowAsPortalError));
  }

  /** GET /repayment-service/api/bids/{bidId} */
  byId(bidId: string): Observable<BidDto> {
    return this.http.get<BidDto>(API.bids.byId(bidId)).pipe(catchError(rethrowAsPortalError));
  }
}

function sortByAmountDesc(bids: BidDto[]): BidDto[] {
  return [...bids].sort((a, b) => b.bidAmount - a.bidAmount || (a.createdAt ?? '').localeCompare(b.createdAt ?? ''));
}

function sortByCreatedDesc(bids: BidDto[]): BidDto[] {
  return [...bids].sort((a, b) => (b.createdAt ?? '').localeCompare(a.createdAt ?? ''));
}

export function equalsIgnoreCase(a: string | null | undefined, b: string | null | undefined): boolean {
  return !!a && !!b && a.toLowerCase() === b.toLowerCase();
}
