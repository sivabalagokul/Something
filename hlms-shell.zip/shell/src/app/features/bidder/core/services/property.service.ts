import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, map, of } from 'rxjs';
import { LoanApplicationPropertyView, PropertySummary } from '../models/hlms.models';
import { API } from './api-urls';
import { toPortalError } from './error-mapper';

/**
 * Property details behind an auction, from loan-service.
 *
 * An auction case carries only `appId` - the property itself lives on the
 * loan application. GET /loan-service/api/loan-applications/{appId} is the
 * only way to reach it today, and it returns the WHOLE application, borrower
 * PII included (applicantName, applicantPan, applicantMobile, monthlyIncome,
 * employer, ...).
 *
 * `toSummary` below is the containment measure: the response is narrowed to
 * property-safe fields at the service boundary, so no component can render
 * borrower data even by accident. The real fix is a bidder-safe projection on
 * the backend - BACKEND-GAPS.md #4.
 */
@Injectable({ providedIn: 'root' })
export class PropertyService {
  private readonly http = inject(HttpClient);
  private readonly cache = new Map<string, PropertySummary | null>();

  /** Resolves to null rather than failing - a missing property should not blank out an auction. */
  forApplication(appId: string): Observable<PropertySummary | null> {
    const cached = this.cache.get(appId);
    if (cached !== undefined) {
      return of(cached);
    }
    return this.http.get<LoanApplicationPropertyView>(API.loanApplications.byId(appId)).pipe(
      map((app) => this.toSummary(app)),
      map((summary) => {
        this.cache.set(appId, summary);
        return summary;
      }),
      catchError((error) => {
        const portal = toPortalError(error);
        // 401/403 must keep bubbling; a 404 just means no property record.
        if (portal.authFailure) {
          throw portal;
        }
        this.cache.set(appId, null);
        return of(null);
      }),
    );
  }

  private toSummary(app: LoanApplicationPropertyView): PropertySummary {
    const locality = [app.addrCity, app.addrState].filter(Boolean).join(', ');
    return {
      appId: app.appId,
      reference: app.trackingNo ?? app.appId,
      address: app.propertyAddress?.trim() || locality || 'Address available on request',
      type: app.propertyType?.trim() || 'Residential',
      declaredValue: app.propertyValue,
      city: app.addrCity,
      state: app.addrState,
    };
  }

  clear(): void {
    this.cache.clear();
  }
}
