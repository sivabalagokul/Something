import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { BIDDER_AUTH } from '../../../core/auth/bidder-auth.port';
import { AuctionListing, DashboardSummary, MyBidRow, PortalError } from '../core/models/hlms.models';
import { BidderPortalService } from '../core/services/bidder-portal.service';
import { ProfileService } from '../core/services/profile.service';
import { StateBlockComponent } from '../shared/components/state-block.component';
import { StatusBadgeComponent } from '../shared/components/status-badge.component';
import { DaysLeftPipe } from '../shared/pipes/days-left.pipe';
import { HlmsDatePipe } from '../shared/pipes/hlms-date.pipe';
import { InrPipe } from '../shared/pipes/inr.pipe';

@Component({
  selector: 'hlms-bidder-dashboard',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, StateBlockComponent, StatusBadgeComponent, InrPipe, HlmsDatePipe, DaysLeftPipe],
  template: `
    <div class="page-head">
      <h1>Welcome, {{ firstName() }}</h1>
      <p>Bank-listed properties under SARFAESI e-auction, and where your bids stand.</p>
    </div>

    <hlms-state-block
      [loading]="loading()"
      [error]="error()"
      loadingText="Loading your dashboard..."
      (retry)="load()"
    >
      <div class="grid grid-4">
        <div class="card stat">
          <div class="lbl">Open auctions</div>
          <div class="val teal">{{ summary()?.openAuctions ?? 0 }}</div>
          <div class="sub">Accepting bids now</div>
        </div>
        <div class="card stat">
          <div class="lbl">Bids placed</div>
          <div class="val">{{ summary()?.totalBids ?? 0 }}</div>
          <div class="sub">Across all listings</div>
        </div>
        <div class="card stat">
          <div class="lbl">Currently winning</div>
          <div class="val green">{{ summary()?.winningBids ?? 0 }}</div>
          <div class="sub">{{ summary()?.outbidBids ?? 0 }} outbid</div>
        </div>
        <div class="card stat">
          <div class="lbl">Won (provisional)</div>
          <div class="val orange">{{ summary()?.wonProvisional ?? 0 }}</div>
          <div class="sub">Awaiting bank confirmation</div>
        </div>
      </div>

      <div class="quick">
        <a class="btn btn-teal btn-sm" routerLink="/bidder/auctions">Browse auctions</a>
        <a class="btn btn-outline btn-sm" routerLink="/bidder/my-bids">My bids</a>
        <a class="btn btn-outline btn-sm" routerLink="/bidder/upcoming-auctions">
          Upcoming ({{ summary()?.upcomingAuctions ?? 0 }})
        </a>
        <a class="btn btn-outline btn-sm" routerLink="/bidder/notifications">
          Notifications ({{ summary()?.unreadNotifications ?? 0 }})
        </a>
      </div>

      <div class="card">
        <h3>⏰ Auctions ending soon</h3>
        @if (endingSoon().length === 0) {
          <div class="empty-state">
            <div class="ic">📭</div>
            No auctions are open for bidding right now. Properties appear here once the bank's legal team lists them.
          </div>
        } @else {
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Property</th>
                  <th>Reserve price</th>
                  <th>Current highest</th>
                  <th>Auction date</th>
                  <th>Closes</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                @for (listing of endingSoon(); track listing.auction.auctionId) {
                  <tr class="clickable-row" (click)="open(listing)">
                    <td>{{ listing.property?.address ?? listing.auction.appId }}</td>
                    <td class="num">{{ listing.auction.reservePrice | inr }}</td>
                    <td class="num">{{ listing.highestBid | inr }}</td>
                    <td>{{ listing.auction.auctionDate | hlmsDate }}</td>
                    <td><span class="countdown-pill">{{ listing.daysLeft | daysLeft }}</span></td>
                    <td class="right">
                      <button type="button" class="btn btn-teal btn-sm" (click)="open(listing); $event.stopPropagation()">
                        View &amp; bid
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>

      <div class="card">
        <h3>📋 Your recent bids</h3>
        @if (recentBids().length === 0) {
          <div class="empty-state">
            <div class="ic">📭</div>
            You haven't placed a bid yet.
            <div class="action"><a class="btn btn-outline btn-sm" routerLink="/bidder/auctions">Browse auctions</a></div>
          </div>
        } @else {
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Property</th>
                  <th>Your bid</th>
                  <th>Current highest</th>
                  <th>Placed</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                @for (row of recentBids(); track row.bid.bidId) {
                  <tr class="clickable-row" (click)="openRow(row)">
                    <td>{{ row.listing?.property?.address ?? row.bid.appId }}</td>
                    <td class="num">{{ row.bid.bidAmount | inr }}</td>
                    <td class="num">{{ row.highestBid | inr }}</td>
                    <td>{{ row.bid.createdAt | hlmsDate: true }}</td>
                    <td><hlms-status-badge [bidStatus]="row.status" /></td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>

      <div class="notice">
        Properties are listed here by the bank's legal and valuation team following SARFAESI recovery proceedings.
        Every bid is a binding offer under the auction terms. Borrower identity is withheld from all listings.
      </div>
    </hlms-state-block>
  `,
  styles: [`.quick { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 18px; }`],
})
export class BidderDashboardComponent implements OnInit {
  private readonly portal = inject(BidderPortalService);
  private readonly profiles = inject(ProfileService);
  private readonly auth = inject(BIDDER_AUTH);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly summary = signal<DashboardSummary | null>(null);
  readonly endingSoon = signal<AuctionListing[]>([]);
  readonly recentBids = signal<MyBidRow[]>([]);
  private readonly resolvedName = signal<string | null>(null);

  readonly firstName = computed(() => {
    const fromProfile = this.resolvedName();
    if (fromProfile) {
      return fromProfile.split(' ')[0];
    }
    const session = this.auth.session();
    return session?.name?.split(' ')[0] ?? session?.email?.split('@')[0] ?? 'Bidder';
  });

  ngOnInit(): void {
    this.load();
    this.loadName();
  }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.portal.dashboard().subscribe({
      next: ({ summary, endingSoon, recentBids }) => {
        this.summary.set(summary);
        this.endingSoon.set(endingSoon);
        this.recentBids.set(recentBids);
        this.loading.set(false);
      },
      error: (err: PortalError) => {
        this.error.set(err.message ?? 'Unable to load your dashboard.');
        this.loading.set(false);
      },
    });
  }

  /**
   * The JWT carries only `sub` and `role`, so the display name comes from the
   * profile API rather than being guessed from the email.
   */
  private loadName(): void {
    const email = this.auth.session()?.email;
    if (!email) {
      return;
    }
    this.profiles.get(email).subscribe({
      next: (user) => this.resolvedName.set(user.name),
      error: () => this.resolvedName.set(null),
    });
  }

  open(listing: AuctionListing): void {
    void this.router.navigate(['/bidder/auctions', listing.auction.auctionId]);
  }

  openRow(row: MyBidRow): void {
    if (row.listing) {
      this.open(row.listing);
    }
  }
}
