import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { BIDDER_AUTH } from '../../../core/auth/bidder-auth.port';
import { AppUser, PortalError } from '../core/models/hlms.models';
import { ProfileService } from '../core/services/profile.service';
import { ToastService } from '../../../core/services/toast.service';
import { StateBlockComponent } from '../shared/components/state-block.component';
import { HlmsDatePipe } from '../shared/pipes/hlms-date.pipe';

/**
 * Bidder profile, backed by user-service GET/PUT /api/users/{email}.
 *
 * Only name and mobile are editable, because those are the only identity
 * fields appUserServiceImplementation.updateUser actually copies onto the
 * stored row (notification preferences are the other three, and they live on
 * the Settings screen where they belong). Email, role, bidder ID and account
 * status render as disabled inputs: the backend ignores them on update, so
 * offering them as editable would be a lie the UI tells about itself.
 */
@Component({
  selector: 'hlms-bidder-profile',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, StateBlockComponent],
  template: `
    <div class="page-head">
      <h1>Profile</h1>
      <p>Your bidder account details as held by HLMS.</p>
    </div>

    <hlms-state-block [loading]="loading()" [error]="error()" loadingText="Loading your profile..." (retry)="load()">
      @if (user(); as u) {
        <div class="grid grid-2">
          <section class="card">
            <h3>👤 Your details</h3>
            <form [formGroup]="form" (ngSubmit)="save()">
              <div class="field">
                <label for="name">Full name</label>
                <input id="name" type="text" formControlName="name" [class.invalid]="invalid('name')" />
                @if (invalid('name')) {
                  <div class="error">Enter your full name.</div>
                }
              </div>

              <div class="field">
                <label for="mobile">Mobile</label>
                <input id="mobile" type="tel" formControlName="mobile" [class.invalid]="invalid('mobile')" inputmode="numeric" />
                @if (invalid('mobile')) {
                  <div class="error">Enter a valid mobile number (10 to 15 digits).</div>
                }
              </div>

              @if (saveError()) {
                <div class="notice err" role="alert">{{ saveError() }}</div>
              }

              <button type="submit" class="btn btn-primary" [disabled]="saving() || form.pristine">
                {{ saving() ? 'Saving...' : 'Save changes' }}
              </button>
            </form>
          </section>

          <section class="card">
            <h3>🔒 Account</h3>
            <div class="field">
              <label for="email">Email (your bidder ID)</label>
              <input id="email" type="email" [value]="u.email" disabled />
              <div class="hint">Bids are recorded against this address. It cannot be changed here.</div>
            </div>
            <div class="two-col">
              <div class="field">
                <label for="role">Role</label>
                <input id="role" type="text" [value]="u.role" disabled />
              </div>
              <div class="field">
                <label for="status">Account status</label>
                <input id="status" type="text" [value]="u.active ? 'Active' : 'Suspended'" disabled />
              </div>
            </div>
            <div class="two-col">
              <div class="field">
                <label for="idType">ID type</label>
                <input id="idType" type="text" [value]="u.idType ?? '—'" disabled />
              </div>
              <div class="field">
                <label for="idNumber">ID number</label>
                <input id="idNumber" type="text" [value]="maskId(u.idNumber)" disabled />
              </div>
            </div>
            <div class="field">
              <label for="since">Registered</label>
              <input id="since" type="text" [value]="registered(u)" disabled />
            </div>
            <p class="small muted">
              Role, bidder ID and verification details are set by the bank. Contact HLMS support to correct them.
            </p>
          </section>
        </div>
      }
    </hlms-state-block>
  `,
})
export class BidderProfileComponent implements OnInit {
  private readonly profiles = inject(ProfileService);
  private readonly auth = inject(BIDDER_AUTH);
  private readonly toasts = inject(ToastService);
  private readonly fb = inject(FormBuilder);
  private readonly dates = new HlmsDatePipe();

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly saveError = signal<string | null>(null);
  readonly saving = signal(false);
  readonly user = signal<AppUser | null>(null);

  readonly form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.maxLength(150)]],
    mobile: ['', [Validators.required, Validators.pattern(/^\d{10,15}$/)]],
  });

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    const email = this.auth.session()?.email;
    if (!email) {
      this.error.set('No signed-in bidder.');
      this.loading.set(false);
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    this.profiles.get(email).subscribe({
      next: (user) => {
        this.user.set(user);
        this.form.reset({ name: user.name ?? '', mobile: user.mobile ?? '' });
        this.loading.set(false);
      },
      error: (err: PortalError) => {
        this.error.set(err.message ?? 'Unable to load your profile.');
        this.loading.set(false);
      },
    });
  }

  save(): void {
    const user = this.user();
    if (!user || this.form.invalid || this.saving()) {
      this.form.markAllAsTouched();
      return;
    }

    this.saving.set(true);
    this.saveError.set(null);
    const { name, mobile } = this.form.getRawValue();

    // The preferences must ride along: updateUser copies all five fields, so
    // omitting them would blank the user's notification settings.
    this.profiles
      .update(user.email, {
        name,
        mobile,
        prefSms: user.prefSms,
        prefEmail: user.prefEmail,
        prefInapp: user.prefInapp,
      })
      .subscribe({
        next: (updated) => {
          this.user.set(updated);
          this.form.reset({ name: updated.name, mobile: updated.mobile });
          this.saving.set(false);
          this.toasts.success('Profile updated', 'Your details have been saved.');
        },
        error: (err: PortalError) => {
          this.saving.set(false);
          this.saveError.set(err.message);
        },
      });
  }

  invalid(control: 'name' | 'mobile'): boolean {
    const field = this.form.controls[control];
    return field.touched && field.invalid;
  }

  /** Verification IDs are shown partially - no reason for a full PAN to sit on screen. */
  maskId(idNumber: string | null): string {
    if (!idNumber) {
      return '—';
    }
    return idNumber.length <= 4 ? idNumber : `${'•'.repeat(idNumber.length - 4)}${idNumber.slice(-4)}`;
  }

  registered(user: AppUser): string {
    return this.dates.transform(user.createdAt);
  }
}
