import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { BIDDER_AUTH } from '../../../core/auth/bidder-auth.port';
import { AppUser, PortalError } from '../core/models/hlms.models';
import { ProfileService } from '../core/services/profile.service';
import { ToastService } from '../../../core/services/toast.service';
import { StateBlockComponent } from '../shared/components/state-block.component';

/**
 * Settings.
 *
 * Notification preferences map to app_user.pref_sms / pref_email / pref_inapp
 * and are saved through the same PUT /api/users/{email} as the profile.
 *
 * Password change is deliberately absent. Credentials belong to the host
 * shell's authentication module, not to this one, and user-service only
 * exposes the OTP-based forgot/reset pair rather than an authenticated change
 * endpoint. The link below hands the user back to the shell rather than this
 * module growing a credential form it has no business owning. No password,
 * token or credential is ever written to storage from here.
 */
@Component({
  selector: 'hlms-bidder-settings',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, StateBlockComponent],
  template: `
    <div class="page-head">
      <h1>Settings</h1>
      <p>How HLMS contacts you about auctions, and your session.</p>
    </div>

    <hlms-state-block [loading]="loading()" [error]="error()" loadingText="Loading your settings..." (retry)="load()">
      <div class="grid grid-2">
        <section class="card">
          <h3>🔔 Notification preferences</h3>
          <p class="small muted intro">
            Choose how you hear about outbids, closing auctions and results. In-app notifications always appear in this
            portal.
          </p>
          <form [formGroup]="form" (ngSubmit)="save()">
            <label class="check-row">
              <input type="checkbox" formControlName="prefInapp" />
              <span>In-app notifications</span>
            </label>
            <label class="check-row">
              <input type="checkbox" formControlName="prefEmail" />
              <span>Email</span>
            </label>
            <label class="check-row">
              <input type="checkbox" formControlName="prefSms" />
              <span>SMS</span>
            </label>

            @if (saveError()) {
              <div class="notice err" role="alert">{{ saveError() }}</div>
            }

            <button type="submit" class="btn btn-primary btn-sm" [disabled]="saving() || form.pristine">
              {{ saving() ? 'Saving...' : 'Save preferences' }}
            </button>
          </form>
        </section>

        <section class="card">
          <h3>🔐 Security and session</h3>
          <div class="row">
            <div>
              <strong>Password</strong>
              <p class="small muted">Managed in your HLMS account settings, outside the bidder portal.</p>
            </div>
            <a class="btn btn-outline btn-sm" [href]="accountUrl">Open account settings</a>
          </div>

          <div class="row">
            <div>
              <strong>Signed in as</strong>
              <p class="small muted">{{ email() }}</p>
            </div>
            <button type="button" class="btn btn-danger btn-sm" (click)="signOut()">Sign out</button>
          </div>

          <p class="small muted foot">
            Your session ends automatically when the token issued at login expires. Bids already placed are binding and
            are not affected by signing out.
          </p>
        </section>
      </div>
    </hlms-state-block>
  `,
  styles: [
    `
      .intro { margin: 0 0 14px; line-height: 1.5; }
      .row {
        display: flex; align-items: center; justify-content: space-between; gap: 14px;
        padding: 14px 0; border-bottom: 1px solid var(--border);
      }
      .row:last-of-type { border-bottom: none; }
      .row strong { font-size: 13.5px; color: var(--navy); }
      .row p { margin: 4px 0 0; }
      .foot { margin-top: 6px; line-height: 1.5; }
    `,
  ],
})
export class BidderSettingsComponent implements OnInit {
  private readonly profiles = inject(ProfileService);
  private readonly auth = inject(BIDDER_AUTH);
  private readonly toasts = inject(ToastService);
  private readonly fb = inject(FormBuilder);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly saveError = signal<string | null>(null);
  readonly saving = signal(false);
  readonly user = signal<AppUser | null>(null);

  /** Host shell route for credential management. */
  readonly accountUrl = '/account/security';

  readonly form = this.fb.nonNullable.group({
    prefInapp: [true],
    prefEmail: [true],
    prefSms: [true],
  });

  ngOnInit(): void {
    this.load();
  }

  email(): string {
    return this.user()?.email ?? this.auth.session()?.email ?? '—';
  }

  load(): void {
    const email = this.auth.session()?.email;
    if (!email) {
      this.error.set('No signed-in bidder.');
      this.loading.set(false);
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    this.profiles.get(email).subscribe({
      next: (user) => {
        this.user.set(user);
        this.form.reset({
          prefInapp: user.prefInapp ?? true,
          prefEmail: user.prefEmail ?? true,
          prefSms: user.prefSms ?? true,
        });
        this.loading.set(false);
      },
      error: (err: PortalError) => {
        this.error.set(err.message ?? 'Unable to load your settings.');
        this.loading.set(false);
      },
    });
  }

  save(): void {
    const user = this.user();
    if (!user || this.saving()) {
      return;
    }
    this.saving.set(true);
    this.saveError.set(null);
    const prefs = this.form.getRawValue();

    // name and mobile ride along unchanged - updateUser copies all five fields.
    this.profiles
      .update(user.email, {
        name: user.name,
        mobile: user.mobile,
        prefSms: prefs.prefSms,
        prefEmail: prefs.prefEmail,
        prefInapp: prefs.prefInapp,
      })
      .subscribe({
        next: (updated) => {
          this.user.set(updated);
          this.form.reset({
            prefInapp: updated.prefInapp,
            prefEmail: updated.prefEmail,
            prefSms: updated.prefSms,
          });
          this.saving.set(false);
          this.toasts.success('Preferences saved', 'HLMS will contact you the way you chose.');
        },
        error: (err: PortalError) => {
          this.saving.set(false);
          this.saveError.set(err.message);
        },
      });
  }

  signOut(): void {
    this.auth.signOut('user');
  }
}
