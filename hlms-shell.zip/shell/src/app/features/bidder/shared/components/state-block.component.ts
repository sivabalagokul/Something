import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

/**
 * The four states every API-backed screen has to answer for: loading, failed,
 * empty, ready. Centralised so the wording and spacing stay identical across
 * the portal instead of being re-invented per screen.
 *
 * Usage:
 *   <hlms-state-block [loading]="loading()" [error]="error()" [empty]="rows().length === 0"
 *                     loadingText="Loading auctions..." emptyText="No auctions are open for bidding."
 *                     (retry)="load()">
 *     ...content when ready...
 *   </hlms-state-block>
 */
@Component({
  selector: 'hlms-state-block',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (loading()) {
      <div class="empty-state" role="status" aria-live="polite">
        <div class="skeleton" style="width: 40%; margin: 0 auto 14px;"></div>
        <div class="skeleton" style="width: 70%; margin: 0 auto 10px;"></div>
        <div class="skeleton" style="width: 55%; margin: 0 auto;"></div>
        <div style="margin-top: 14px;">{{ loadingText() }}</div>
      </div>
    } @else if (error()) {
      <div class="empty-state" role="alert">
        <div class="ic">⚠️</div>
        <div>{{ error() }}</div>
        @if (showRetry()) {
          <div class="action">
            <button type="button" class="btn btn-outline btn-sm" (click)="retry.emit()">Try again</button>
          </div>
        }
      </div>
    } @else if (empty()) {
      <div class="empty-state">
        <div class="ic">{{ emptyIcon() }}</div>
        <div>{{ emptyText() }}</div>
        <ng-content select="[emptyAction]"></ng-content>
      </div>
    } @else {
      <ng-content></ng-content>
    }
  `,
})
export class StateBlockComponent {
  readonly loading = input(false);
  readonly error = input<string | null>(null);
  readonly empty = input(false);
  readonly loadingText = input('Loading...');
  readonly emptyText = input('Nothing to show yet.');
  readonly emptyIcon = input('📭');
  readonly showRetry = input(true);
  readonly retry = output<void>();
}
