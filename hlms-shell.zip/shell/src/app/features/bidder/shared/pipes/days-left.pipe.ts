import { Pipe, PipeTransform } from '@angular/core';

/**
 * Whole days to the auction date.
 *
 * Deliberately day-resolution: `auction_case.auction_date` is a DATE column,
 * so an hour-and-minute countdown would be invented precision. When the
 * backend gains a real end timestamp this becomes a live countdown
 * (BACKEND-GAPS.md #3).
 */
@Pipe({ name: 'daysLeft', standalone: true })
export class DaysLeftPipe implements PipeTransform {
  transform(days: number | null | undefined): string {
    if (days === null || days === undefined) {
      return 'Date to be announced';
    }
    if (days < 0) {
      return 'Bidding closed';
    }
    if (days === 0) {
      return 'Closing today';
    }
    return days === 1 ? '1 day left' : `${days} days left`;
  }
}
