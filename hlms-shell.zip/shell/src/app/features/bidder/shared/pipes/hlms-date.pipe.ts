import { Pipe, PipeTransform } from '@angular/core';

/** Dates as '14 Mar 2026'. Handles both LocalDate and OffsetDateTime strings. */
@Pipe({ name: 'hlmsDate', standalone: true })
export class HlmsDatePipe implements PipeTransform {
  transform(value: string | null | undefined, withTime = false): string {
    if (!value) {
      return '—';
    }
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return '—';
    }
    const day = date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    if (!withTime) {
      return day;
    }
    return `${day}, ${date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`;
  }
}
