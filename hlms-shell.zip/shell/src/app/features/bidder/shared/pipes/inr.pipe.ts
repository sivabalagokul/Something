import { Pipe, PipeTransform } from '@angular/core';

/**
 * Indian-format currency, matching how the rest of HLMS prints money
 * (₹25,00,000 rather than ₹2,500,000).
 */
@Pipe({ name: 'inr', standalone: true })
export class InrPipe implements PipeTransform {
  private static readonly formatter = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  });

  transform(value: number | null | undefined, fallback = '—'): string {
    if (value === null || value === undefined || Number.isNaN(value)) {
      return fallback;
    }
    return InrPipe.formatter.format(value);
  }
}
