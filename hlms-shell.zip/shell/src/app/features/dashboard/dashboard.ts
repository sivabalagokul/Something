import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { NotificationService } from '../../core/services/notification.service';
import { LoanApplication, Notification } from '../../core/models/models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Welcome back, {{ (auth.currentUser()?.name || '').split(' ')[0] || 'there' }} 👋</h1>
      <p>Here's a snapshot of your housing loan journey with HLMS.</p>
    </div>

    @if (loading()) {
      <div class="page-loading"><span class="spinner dark"></span> Loading your dashboard…</div>
    } @else {
      @if (loadError()) {
        <div class="inline-error">{{ loadError() }}</div>
      }

      <div class="grid grid-4">
        <div class="card"><div class="stat"><span class="lbl">Total Applications</span><span class="val teal">{{ apps().length }}</span></div></div>
        <div class="card"><div class="stat"><span class="lbl">Active Applications</span><span class="val">{{ activeCount() }}</span></div></div>
        <div class="card"><div class="stat"><span class="lbl">Disbursed Loans</span><span class="val green">{{ disbursedCount() }}</span></div></div>
        <div class="card"><div class="stat"><span class="lbl">Unread Notifications</span><span class="val orange">{{ unread().length }}</span></div></div>
      </div>

      <div class="grid grid-2">
        <div class="card">
          <h3>📄 Your Applications</h3>
          @if (apps().length === 0) {
            <div class="empty-state">
              <div class="ic">📝</div>
              <p>You haven't started a loan application yet.</p>
              <button class="btn btn-primary btn-sm" routerLink="/apply">Apply for a Loan</button>
            </div>
          } @else {
            <table>
              <thead><tr><th>App ID</th><th>Product</th><th>Amount</th><th>Status</th><th></th></tr></thead>
              <tbody>
                @for (a of apps().slice(0, 6); track a.appId) {
                  <tr class="clickable-row" [routerLink]="['/tracking', a.appId]">
                    <td>{{ a.trackingNo || a.appId }}</td>
                    <td>{{ a.productId || '—' }}</td>
                    <td>{{ a.loanAmount ? ('₹' + a.loanAmount) : '—' }}</td>
                    <td><span class="badge" [class]="badgeClass(a.status)">{{ a.status }}</span></td>
                    <td><span class="btn-link">View →</span></td>
                  </tr>
                }
              </tbody>
            </table>
          }
        </div>

        <div class="card">
          <h3>⚡ Quick Links</h3>
          <div class="quick-links" style="height:auto;max-height:none;">
            <a routerLink="/eligibility">Check Eligibility <span class="arrow">→</span></a>
            <a routerLink="/apply">Apply for a New Loan <span class="arrow">→</span></a>
            <a routerLink="/repayment">View Repayment Schedule <span class="arrow">→</span></a>
            <a routerLink="/documents">Manage Documents <span class="arrow">→</span></a>
            <a routerLink="/support">Contact Support <span class="arrow">→</span></a>
          </div>
        </div>
      </div>

      <div class="card">
        <h3>🔔 Recent Notifications</h3>
        @if (unread().length === 0) {
          <div class="empty-state"><p>You're all caught up — no unread notifications.</p></div>
        } @else {
          @for (n of unread().slice(0, 5); track n.notificationId) {
            <div class="note-item">
              <div class="dt">{{ n.createdAt | date: 'medium' }}</div>
              <strong>{{ n.title }}</strong> — {{ n.body }}
            </div>
          }
        }
      </div>
    }
  `
})
export class Dashboard {
  auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private notifSvc = inject(NotificationService);

  loading = signal(true);
  loadError = signal('');
  apps = signal<LoanApplication[]>([]);
  unread = signal<Notification[]>([]);

  constructor() {
    const email = this.auth.currentUser()?.email;
    if (!email) {
      this.loading.set(false);
      return;
    }

    let pending = 2;
    const done = () => {
      pending -= 1;
      if (pending <= 0) this.loading.set(false);
    };

    this.loanSvc.listForUser(email).subscribe({
      next: (list) => {
        this.apps.set(list);
        done();
      },
      error: () => {
        this.loadError.set('Could not load your applications from loan-service. Is the backend running?');
        done();
      }
    });

    this.notifSvc.unread(email).subscribe({
      next: (list) => {
        this.unread.set(list);
        done();
      },
      error: () => done()
    });
  }

  activeCount(): number {
    return this.apps().filter((a) => !['Draft', 'Disbursed', 'Rejected', 'Withdrawn'].includes(a.status))
      .length;
  }

  disbursedCount(): number {
    return this.apps().filter((a) => a.status === 'Disbursed').length;
  }

  badgeClass(status: string): string {
    if (status === 'Disbursed') return 'badge-green';
    if (status === 'Rejected') return 'badge-red';
    if (status === 'Draft') return 'badge-gray';
    return 'badge-orange';
  }
}
