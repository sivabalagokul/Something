// Mirrors the backend DTOs/entities exactly (field-for-field) so JSON from
// the gateway deserializes straight into these interfaces with no mapping.

export interface AppUser {
  email: string;
  name: string;
  mobile: string;
  role: string; // CUSTOMER | LEGAL | BANK_OFFICER | BIDDER | ADMIN
  active?: boolean; // optional: shell's AuthService.currentUser() may omit it
  idType?: string;
  idNumber?: string;
  prefSms?: boolean;
  prefEmail?: boolean;
  prefInapp?: boolean;
  createdAt?: string;
}

export interface LoanApplication {
  appId: string;
  trackingNo: string;
  userEmail: string;
  productId?: string;
  loanAmount?: number;
  tenureYears?: number;
  purpose?: string;
  interestRate?: number;
  status: string;
  stageIndex: number;
  currentStep: number;
  formData?: string;
  savedAt?: string;
  createdAt?: string;
  applicantName?: string;
  applicantMobile?: string;
  applicantPan?: string;
  addrDoorNo?: string;
  addrStreet?: string;
  addrCity?: string;
  addrState?: string;
  addrPincode?: string;
  employmentType?: string;
  employer?: string;
  monthlyIncome?: number;
  otherEmis?: number;
  propertyAddress?: string;
  propertyType?: string;
  propertyValue?: number;
  deletedAt?: string | null;
}

export interface LegalVerificationDTO {
  verificationId?: number | null;
  appId: string;
  decision: string | null; // null | 'Approved' | 'Query Raised' | 'Rejected'
  decisionDate?: string | null;
  officerEmail?: string | null;
  remarks?: string;
  infoRequested?: boolean;
  infoRequestDetails?: string;
  infoRequestedAt?: string | null;
}

export interface LegalChecklistItemDTO {
  checklistItemId?: string | null;
  appId: string;
  checklistKey: string;
  status: string; // Pending | Verified | Discrepancy
}

export interface LegalNoticeDTO {
  noticeId?: string | null;
  noticeNo: string;
  appId?: string | null;
  noticeType: string;
  issueDate: string;
  dueDate?: string | null;
  status: string; // Active | Closed
  officerEmail: string;
  content: string;
}

export interface BankOfficeDecisionDTO {
  decisionId?: number | null;
  appId: string;
  status: string;
  officerEmail?: string;
  decisionDate?: string;
  reason?: string;
  remarks?: string;
}

export interface AuctionCaseDTO {
  auctionId?: number | null;
  appId: string;
  stage: string; // None | Notice Issued | Possession | Auction Scheduled | Resolved
  noticeDate?: string | null;
  noticeDueDate?: string | null;
  demandAmount?: number | null;
  possessionDate?: string | null;
  auctionDate?: string | null;
  reservePrice?: number | null;
}

export interface AuctionNoteDTO {
  noteId?: string | null;
  appId: string;
  noteText: string;
}

export interface BidDTO {
  bidId?: string | null;
  appId: string;
  bidderEmail: string;
  bidAmount: number;
}

export interface ApplicationDocumentEntity {
  documentId: string;
  appId: string;
  docType: string;
  fileName: string;
  fileData?: string; // base64
  fileSize?: number;
  uploadedAt?: string;
  verificationStatus?: string; // Pending | Verified | Rejected
  verifiedBy?: string;
  verifiedAt?: string;
  remarks?: string;
  deletedAt?: string | null;
}

export interface PostDisbursementDocumentEntity {
  pdDocId: string;
  appId: string;
  docType: string;
  fileName: string;
  fileData?: string;
  fileSize?: number;
  note?: string;
  status: string; // Pending | Verified | Rejected
  uploadedAt?: string;
  verifiedBy?: string;
  verifiedAt?: string;
  remarks?: string;
  deletedAt?: string | null;
}

export interface NotificationDTO {
  notificationId?: string;
  userEmail: string;
  title: string;
  body: string;
  channels?: string[];
  isRead?: boolean;
  createdAt?: string;
  deletedAt?: string | null;
}

export interface EmiInstallmentDTO {
  installmentId?: string;
  appId: string;
  installmentNo: number;
  dueDate: string;
  emiAmount: number;
  principalComponent?: number;
  interestComponent?: number;
  closingBalance?: number;
  status: string; // Paid | Pending | Overdue
  paidDate?: string | null;
}

// ---- UI-only composed types ----

export const LEGAL_CHECKLIST: { key: string; label: string }[] = [
  { key: 'titleDeed', label: 'Title Deed / Ownership Document' },
  { key: 'encumbrance', label: 'Encumbrance Certificate (13 yrs)' },
  { key: 'saleDeed', label: 'Sale Deed / Agreement to Sell' },
  { key: 'noc', label: 'NOC from Society / Builder / Competent Authority' },
  { key: 'valuation', label: 'Property Valuation Report' },
  { key: 'taxReceipt', label: 'Latest Property Tax Receipt' }
];

export interface LegalQueueRow {
  app: LoanApplication;
  verification: LegalVerificationDTO | null;
  locked: boolean;
}

export interface OverdueAccount {
  app: LoanApplication;
  auction: AuctionCaseDTO;
  outstandingBalance: number;
  overdueCount: number;
}
