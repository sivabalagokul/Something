import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { AuctionCaseDTO, AuctionNoteDTO, BidDTO } from '../models/models';

@Injectable({ providedIn: 'root' })
export class AuctionService {
  private base = `${environment.apiBase}/repayment-service/api/auctions`;

  constructor(private http: HttpClient) {}

  listAll(): Observable<AuctionCaseDTO[]> {
    return this.http.get<AuctionCaseDTO[]>(this.base);
  }

  getByApplication(appId: string): Observable<AuctionCaseDTO | null> {
    return this.http.get<AuctionCaseDTO>(`${this.base}/by-application/${appId}`).pipe(
      catchError(() => of(null))
    );
  }

  create(dto: AuctionCaseDTO): Observable<AuctionCaseDTO> {
    return this.http.post<AuctionCaseDTO>(this.base, dto);
  }

  update(auctionId: number, dto: AuctionCaseDTO): Observable<AuctionCaseDTO> {
    return this.http.put<AuctionCaseDTO>(`${this.base}/${auctionId}`, dto);
  }

  addNote(appId: string, note: AuctionNoteDTO): Observable<AuctionNoteDTO> {
    return this.http.post<AuctionNoteDTO>(`${this.base}/${appId}/notes`, note);
  }

  getNotes(appId: string): Observable<AuctionNoteDTO[]> {
    return this.http.get<AuctionNoteDTO[]>(`${this.base}/${appId}/notes`);
  }

  getBids(appId: string): Observable<BidDTO[]> {
    return this.http.get<BidDTO[]>(`${this.base}/${appId}/bids`);
  }
}
