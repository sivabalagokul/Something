import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { ApplicationDocumentEntity, PostDisbursementDocumentEntity } from '../models/models';

@Injectable({ providedIn: 'root' })
export class DocumentService {
  private appDocsBase = `${environment.apiBase}/document-service/api/application-documents`;
  private pdDocsBase = `${environment.apiBase}/document-service/api/post-disbursement-documents`;

  constructor(private http: HttpClient) {}

  listApplicationDocuments(appId: string): Observable<ApplicationDocumentEntity[]> {
    return this.http.get<ApplicationDocumentEntity[]>(`${this.appDocsBase}/app/${appId}`);
  }

  listAllApplicationDocuments(): Observable<ApplicationDocumentEntity[]> {
    return this.http.get<ApplicationDocumentEntity[]>(this.appDocsBase);
  }

  listAllPostDisbursementDocuments(): Observable<PostDisbursementDocumentEntity[]> {
    return this.http.get<PostDisbursementDocumentEntity[]>(this.pdDocsBase);
  }

  listPostDisbursementDocuments(appId: string): Observable<PostDisbursementDocumentEntity[]> {
    return this.http.get<PostDisbursementDocumentEntity[]>(`${this.pdDocsBase}/app/${appId}`);
  }

  /**
   * The backend has no dedicated "verify" / "reject" endpoint for either document
   * type — only generic CRUD (POST create / PUT-less update is actually missing too,
   * see README_API_GAPS.md). We work around it here with a full re-save via POST,
   * which the service treats as an upsert-by-id in the demo data model; if your
   * document-service instead requires a PUT for updates, adjust these two calls.
   */
  verifyPostDisbursementDocument(doc: PostDisbursementDocumentEntity, verifiedBy: string): Observable<PostDisbursementDocumentEntity> {
    const updated: PostDisbursementDocumentEntity = { ...doc, status: 'Verified', verifiedBy, verifiedAt: new Date().toISOString(), remarks: '' };
    return this.http.post<PostDisbursementDocumentEntity>(this.pdDocsBase, updated);
  }

  rejectPostDisbursementDocument(doc: PostDisbursementDocumentEntity, verifiedBy: string, remarks: string): Observable<PostDisbursementDocumentEntity> {
    const updated: PostDisbursementDocumentEntity = { ...doc, status: 'Rejected', verifiedBy, verifiedAt: new Date().toISOString(), remarks };
    return this.http.post<PostDisbursementDocumentEntity>(this.pdDocsBase, updated);
  }

  /** Opens a base64-embedded document (fileData) in a new tab for viewing. */
  openInlineDocument(doc: { fileData?: string; fileName: string }): void {
    if (!doc.fileData) return;
    try {
      const byteChars = atob(doc.fileData);
      const byteNumbers = new Array(byteChars.length);
      for (let i = 0; i < byteChars.length; i++) byteNumbers[i] = byteChars.charCodeAt(i);
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray]);
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
    } catch {
      // fileData wasn't valid base64 — nothing sensible to open.
    }
  }
}
