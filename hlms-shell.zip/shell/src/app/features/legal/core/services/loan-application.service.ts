import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { LoanApplication } from '../models/models';

@Injectable({ providedIn: 'root' })
export class LoanApplicationService {
  private base = `${environment.apiBase}/loan-service/api/loan-applications`;

  constructor(private http: HttpClient) {}

  listAll(): Observable<LoanApplication[]> {
    return this.http.get<LoanApplication[]>(`${this.base}/all`);
  }

  get(appId: string): Observable<LoanApplication> {
    return this.http.get<LoanApplication>(`${this.base}/${appId}`);
  }

  workflowStages(): Observable<string[]> {
    return this.http.get<string[]>(`${this.base}/workflow-stages`);
  }

  /** Moves an application to a new workflow stage / status (used when Legal approves a case). */
  updateStage(appId: string, stageIndex: number, status: string): Observable<LoanApplication> {
    return this.http.patch<LoanApplication>(`${this.base}/${appId}/stage`, { stageIndex, status });
  }
}
