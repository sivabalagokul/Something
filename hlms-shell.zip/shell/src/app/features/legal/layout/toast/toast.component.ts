import { Component } from '@angular/core';
import { ToastService } from '../../core/services/toast.service';

@Component({
  selector: 'app-toast',
  standalone: true,
  template: `
    <div class="toast-wrap">
      @for (t of toastSvc.toasts(); track t.id) {
        <div class="toast" [class.success]="t.type==='success'" [class.error]="t.type==='error'" (click)="toastSvc.dismiss(t.id)">
          <strong>{{ t.title }}</strong>
          @if (t.body) { <div>{{ t.body }}</div> }
        </div>
      }
    </div>
  `
})
export class ToastComponent {
  constructor(public toastSvc: ToastService) {}
}
