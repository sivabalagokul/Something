import { Routes } from '@angular/router';

/** Everything under /legal. Role-gated in app.routes.ts (roleGuard(['LEGAL'])). */
export const LEGAL_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./layout/shell/shell.component').then((m) => m.ShellComponent),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      {
        path: 'dashboard',
        loadComponent: () => import('./pages/dashboard/legal-dashboard.component').then((m) => m.LegalDashboardComponent)
      },
      {
        path: 'queue',
        loadComponent: () => import('./pages/queue/legal-queue.component').then((m) => m.LegalQueueComponent)
      },
      {
        path: 'case/:appId',
        loadComponent: () => import('./pages/case-detail/legal-case-detail.component').then((m) => m.LegalCaseDetailComponent)
      },
      {
        path: 'documents',
        loadComponent: () => import('./pages/documents/legal-documents.component').then((m) => m.LegalDocumentsComponent)
      },
      {
        path: 'auction',
        loadComponent: () => import('./pages/auction/legal-auction.component').then((m) => m.LegalAuctionComponent)
      },
      {
        path: 'notices',
        loadComponent: () => import('./pages/notices/legal-notices.component').then((m) => m.LegalNoticesComponent)
      },
      {
        path: 'profile',
        loadComponent: () => import('./pages/profile/legal-profile.component').then((m) => m.LegalProfileComponent)
      }
    ]
  }
];
