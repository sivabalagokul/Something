import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { AuthService } from '../../../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { AuctionService } from '../../core/services/auction.service';
import { LoanApplicationService } from '../../core/services/loan-application.service';
import { LegalDataService } from '../../core/services/legal-data.service';
import { NotificationService } from '../../core/services/notification.service';
import { AuctionCaseDTO, AuctionNoteDTO, BidDTO, LoanApplication, OverdueAccount } from '../../core/models/models';

interface AuctionRow extends AuctionCaseDTO { app: LoanApplication; }

interface CombinedRow {
  kind: 'watch' | 'case';
  app: LoanApplication;
  stage: string;
  overdueCount: number;
  outstandingBalance: number;
  propertyValue?: number;
  noticeDate?: string | null;
  noticeDueDate?: string | null;
  demandAmount?: number | null;
  auctionDate?: string | null;
  reservePrice?: number | null;
  watch?: OverdueAccount;
  case?: AuctionRow;
}

const STAGE_ORDER = ['None', 'Notice Issued', 'Possession', 'Auction Scheduled', 'Resolved'];

@Component({
  selector: 'app-legal-auction',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './legal-auction.component.html'
})
export class LegalAuctionComponent implements OnInit {
  loading = signal(true);
  watchlist = signal<OverdueAccount[]>([]);
  activeCases = signal<AuctionRow[]>([]);

  noticeModalOpen = signal(false);
  noticeTarget = signal<OverdueAccount | null>(null);
  noticeDueDays = 60;

  combinedRows = computed<CombinedRow[]>(() => [
    ...this.activeCases().map((c) => ({
      kind: 'case' as const,
      app: c.app,
      stage: c.stage,
      overdueCount: 0,
      outstandingBalance: c.demandAmount || 0,
      noticeDate: c.noticeDate,
      noticeDueDate: c.noticeDueDate,
      demandAmount: c.demandAmount,
      auctionDate: c.auctionDate,
      reservePrice: c.reservePrice,
      case: c
    })),
    ...this.watchlist().map((w) => ({
      kind: 'watch' as const,
      app: w.app,
      stage: 'None',
      overdueCount: w.overdueCount,
      outstandingBalance: w.outstandingBalance,
      propertyValue: w.app.propertyValue,
      watch: w
    }))
  ]);

  selectedCase = signal<AuctionRow | null>(null);
  notes = signal<AuctionNoteDTO[]>([]);
  bids = signal<BidDTO[]>([]);
  newNote = '';
  auctionDateDraft = '';
  reservePriceDraft: number | null = null;

  constructor(
    public auth: AuthService,
    private toast: ToastService,
    private auctionSvc: AuctionService,
    private loanSvc: LoanApplicationService,
    private legalData: LegalDataService,
    private notifSvc: NotificationService
  ) {}

  ngOnInit(): void {
    this.loadAll();
  }

  private loadAll(): void {
    this.loading.set(true);
    forkJoin({
      overdue: this.legalData.getOverdueAccounts(),
      auctions: this.auctionSvc.listAll(),
      apps: this.loanSvc.listAll()
    }).subscribe(({ overdue, auctions, apps }) => {
      const byId = new Map<string, LoanApplication>(apps.map((a) => [a.appId, a]));
      const activeAuctions = auctions.filter((a) => a.stage !== 'None');
      this.activeCases.set(
        activeAuctions
          .map((a) => ({ ...a, app: byId.get(a.appId)! }))
          .filter((r) => !!r.app)
      );
      const casedAppIds = new Set(activeAuctions.map((a) => a.appId));
      this.watchlist.set(overdue.filter((o) => !casedAppIds.has(o.app.appId)));
      this.loading.set(false);
    });
  }

  stageBadgeClass(stage: string): string {
    if (stage === 'Notice Issued') return 'badge-orange';
    if (stage === 'Possession' || stage === 'Auction Scheduled') return 'badge-red';
    if (stage === 'Resolved') return 'badge-green';
    return 'badge-gray';
  }

  nextStage(stage: string): string | null {
    const idx = STAGE_ORDER.indexOf(stage);
    return idx >= 0 && idx < STAGE_ORDER.length - 1 ? STAGE_ORDER[idx + 1] : null;
  }

  // ---- Issue Notice (creates a new auction/SARFAESI case) ----
  openNoticeModal(o: OverdueAccount): void {
    this.noticeTarget.set(o);
    this.noticeDueDays = 60;
    this.noticeModalOpen.set(true);
  }

  closeNoticeModal(): void {
    this.noticeModalOpen.set(false);
    this.noticeTarget.set(null);
  }

  confirmIssueNotice(): void {
    const o = this.noticeTarget();
    if (!o) return;
    const now = new Date();
    const due = new Date(now.getTime() + this.noticeDueDays * 24 * 60 * 60 * 1000);
    const dto: AuctionCaseDTO = {
      appId: o.app.appId,
      stage: 'Notice Issued',
      noticeDate: now.toISOString(),
      noticeDueDate: due.toISOString(),
      demandAmount: o.outstandingBalance
    };
    this.auctionSvc.create(dto).subscribe({
      next: () => {
        this.toast.success('Legal Notice Issued', o.app.trackingNo);
        this.notifSvc.send(o.app.userEmail, 'Legal Notice — Loan Default',
          `A legal notice has been issued on your loan ${o.app.trackingNo} due to overdue installments. Outstanding demand: ₹${o.outstandingBalance.toLocaleString('en-IN')}. Please contact the bank immediately to avoid further recovery action.`).subscribe();
        this.closeNoticeModal();
        this.loadAll();
      },
      error: () => this.toast.error('Could not issue notice', 'Please try again.')
    });
  }

  // ---- Advance stage ----
  advanceStage(row: AuctionRow): void {
    const next = this.nextStage(row.stage);
    if (!next || !row.auctionId) return;
    const dto: AuctionCaseDTO = { ...row };
    if (next === 'Auction Scheduled' && this.auctionDateDraft) dto.auctionDate = this.auctionDateDraft;
    if (next === 'Auction Scheduled' && this.reservePriceDraft) dto.reservePrice = this.reservePriceDraft;
    if (next === 'Possession') dto.possessionDate = new Date().toISOString();
    dto.stage = next;
    this.auctionSvc.update(row.auctionId, dto).subscribe({
      next: () => {
        this.toast.success('Stage Updated', `${row.app.trackingNo} moved to "${next}".`);
        this.notifSvc.send(row.app.userEmail, 'Recovery Proceedings Update',
          `Your loan ${row.app.trackingNo} recovery case has moved to stage: ${next}.`).subscribe();
        this.loadAll();
        this.selectedCase.set(null);
      },
      error: () => this.toast.error('Could not update stage', 'Please try again.')
    });
  }

  // ---- One-click stage actions (mirrors old Legal Team UI buttons) ----
  recordPossession(row: CombinedRow): void {
    const c = row.case;
    if (!c || !c.auctionId) return;
    const dto: AuctionCaseDTO = { ...c, stage: 'Possession', possessionDate: new Date().toISOString() };
    this.auctionSvc.update(c.auctionId, dto).subscribe({
      next: () => {
        this.toast.success('Possession Recorded', row.app.trackingNo);
        this.notifSvc.send(row.app.userEmail, 'Possession Notice',
          `Symbolic possession of the secured property under loan account ${row.app.trackingNo} has been recorded.`).subscribe();
        this.loadAll();
      },
      error: () => this.toast.error('Could not update stage', 'Please try again.')
    });
  }

  markResolved(row: CombinedRow): void {
    const c = row.case;
    if (!c || !c.auctionId) return;
    const dto: AuctionCaseDTO = { ...c, stage: 'Resolved' };
    this.auctionSvc.update(c.auctionId, dto).subscribe({
      next: () => {
        this.toast.success('Marked Resolved', row.app.trackingNo);
        this.notifSvc.send(row.app.userEmail, 'Recovery Proceedings Resolved',
          `Recovery proceedings on your loan account ${row.app.trackingNo} have been resolved.`).subscribe();
        this.loadAll();
      },
      error: () => this.toast.error('Could not update stage', 'Please try again.')
    });
  }

  openScheduleModal(row: CombinedRow): void {
    if (!row.case) return;
    this.openCase(row.case);
    this.auctionDateDraft = '';
    this.reservePriceDraft = row.app.propertyValue ? Math.round(row.app.propertyValue * 0.8) : null;
  }

  // ---- Notes / Bids panel ----
  openCase(row: AuctionRow): void {
    this.selectedCase.set(row);
    this.auctionDateDraft = row.auctionDate ? row.auctionDate.substring(0, 10) : '';
    this.reservePriceDraft = row.reservePrice ?? null;
    this.notes.set([]);
    this.bids.set([]);
    this.auctionSvc.getNotes(row.appId).subscribe((n) => this.notes.set(n));
    if (row.stage === 'Auction Scheduled' || row.stage === 'Resolved') {
      this.auctionSvc.getBids(row.appId).subscribe((b) => this.bids.set(b));
    }
  }

  closeCase(): void {
    this.selectedCase.set(null);
  }

  addNote(): void {
    const row = this.selectedCase();
    if (!row || !this.newNote.trim()) return;
    this.auctionSvc.addNote(row.appId, { appId: row.appId, noteText: this.newNote.trim() }).subscribe({
      next: (note) => {
        this.notes.set([note, ...this.notes()]);
        this.newNote = '';
      },
      error: () => this.toast.error('Could not add note', 'Please try again.')
    });
  }
}
