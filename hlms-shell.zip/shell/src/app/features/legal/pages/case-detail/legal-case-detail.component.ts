import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { forkJoin, of, switchMap } from 'rxjs';

import { AuthService } from '../../../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { LoanApplicationService } from '../../core/services/loan-application.service';
import { LegalVerificationService } from '../../core/services/legal-verification.service';
import { LegalChecklistService } from '../../core/services/legal-checklist.service';
import { LegalDataService } from '../../core/services/legal-data.service';
import { DocumentService } from '../../core/services/document.service';
import { NotificationService } from '../../core/services/notification.service';
import {
  ApplicationDocumentEntity,
  LEGAL_CHECKLIST,
  LegalChecklistItemDTO,
  LegalVerificationDTO,
  LoanApplication
} from '../../core/models/models';

@Component({
  selector: 'app-legal-case-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './legal-case-detail.component.html'
})
export class LegalCaseDetailComponent implements OnInit {
  loading = signal(true);
  notFound = signal(false);
  appId = '';
  legalStageIndex = 3;

  app = signal<LoanApplication | null>(null);
  verification = signal<LegalVerificationDTO | null>(null);
  checklist = signal<LegalChecklistItemDTO[]>([]);
  documents = signal<ApplicationDocumentEntity[]>([]);
  remarksDraft = signal('');
  savingRemarks = signal(false);
  decisionInProgress = signal(false);

  checklistDefs = LEGAL_CHECKLIST;

  allVerified = computed(() => this.checklistDefs.every((c) => this.statusFor(c.key) === 'Verified'));
  anyDiscrepancy = computed(() => this.checklistDefs.some((c) => this.statusFor(c.key) === 'Discrepancy'));

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public auth: AuthService,
    private toast: ToastService,
    private loanSvc: LoanApplicationService,
    private verificationSvc: LegalVerificationService,
    private checklistSvc: LegalChecklistService,
    private legalData: LegalDataService,
    private docSvc: DocumentService,
    private notifSvc: NotificationService
  ) {}

  ngOnInit(): void {
    this.appId = this.route.snapshot.paramMap.get('appId') || '';
    this.legalData.getLegalStageIndex().subscribe((idx) => (this.legalStageIndex = idx));
    this.loadAll();
  }

  private loadAll(): void {
    this.loading.set(true);
    forkJoin({
      app: this.loanSvc.get(this.appId),
      verification: this.verificationSvc.getByApplication(this.appId),
      checklist: this.checklistSvc.listByApplication(this.appId),
      documents: this.docSvc.listApplicationDocuments(this.appId)
    }).subscribe({
      next: ({ app, verification, checklist, documents }) => {
        this.app.set(app);
        this.verification.set(verification);
        this.remarksDraft.set(verification?.remarks || '');
        this.documents.set(documents);
        this.ensureChecklistRows(checklist);
        this.loading.set(false);
      },
      error: () => {
        this.notFound.set(true);
        this.loading.set(false);
      }
    });
  }

  /** Creates any of the 6 required checklist rows that don't exist yet for this application (defaults to Pending). */
  private ensureChecklistRows(existing: LegalChecklistItemDTO[]): void {
    const missingDefs = this.checklistDefs.filter((def) => !existing.some((e) => e.checklistKey === def.key));
    if (missingDefs.length === 0) {
      this.checklist.set(existing);
      return;
    }
    forkJoin(
      missingDefs.map((def) =>
        this.checklistSvc.create({ appId: this.appId, checklistKey: def.key, status: 'Pending' })
      )
    ).subscribe((created) => this.checklist.set([...existing, ...created]));
  }

  statusFor(key: string): string {
    return this.checklist().find((c) => c.checklistKey === key)?.status || 'Pending';
  }

  onChecklistChange(key: string, value: string): void {
    const item = this.checklist().find((c) => c.checklistKey === key);
    if (!item || !item.checklistItemId) return;
    const updated: LegalChecklistItemDTO = { ...item, status: value };
    this.checklistSvc.update(item.checklistItemId, updated).subscribe({
      next: (saved) => {
        this.checklist.set(this.checklist().map((c) => (c.checklistKey === key ? saved : c)));
      },
      error: () => this.toast.error('Could not update checklist item', 'Please try again.')
    });
  }

  saveRemarks(): void {
    this.savingRemarks.set(true);
    const current = this.verification();
    const dto: LegalVerificationDTO = {
      appId: this.appId,
      decision: current?.decision ?? null,
      decisionDate: current?.decisionDate ?? null,
      officerEmail: current?.officerEmail ?? null,
      remarks: this.remarksDraft()
    };
    const req = current?.verificationId
      ? this.verificationSvc.update(current.verificationId, dto)
      : this.verificationSvc.create(dto);
    req.subscribe({
      next: (saved) => {
        this.verification.set(saved);
        this.savingRemarks.set(false);
        this.toast.success('Remarks Saved', 'Legal remarks have been updated.');
      },
      error: () => {
        this.savingRemarks.set(false);
        this.toast.error('Could not save remarks', 'Please try again.');
      }
    });
  }

  decide(decision: 'Approved' | 'Query Raised' | 'Rejected'): void {
    const app = this.app();
    const officer = this.auth.currentUser();
    if (!app || !officer) return;

    if (decision === 'Approved' && !this.allVerified()) {
      this.toast.error('Cannot Approve', 'Please mark all checklist items as Verified first.');
      return;
    }

    this.decisionInProgress.set(true);
    const current = this.verification();
    const dto: LegalVerificationDTO = {
      appId: this.appId,
      decision,
      decisionDate: new Date().toISOString(),
      officerEmail: officer.email,
      remarks: this.remarksDraft()
    };
    const saveReq = current?.verificationId
      ? this.verificationSvc.update(current.verificationId, dto)
      : this.verificationSvc.create(dto);

    saveReq.pipe(
      switchMap((saved) => {
        this.verification.set(saved);
        if (decision === 'Approved') {
          return this.loanSvc.updateStage(this.appId, this.legalStageIndex + 1, 'Under Review');
        } else if (decision === 'Rejected') {
          return this.loanSvc.updateStage(this.appId, app.stageIndex, 'Rejected');
        }
        return of(app);
      })
    ).subscribe({
      next: (updatedApp) => {
        this.app.set(updatedApp);
        this.decisionInProgress.set(false);
        this.notifyBorrower(app, decision);
        if (decision === 'Approved') this.toast.success('Case Approved', app.trackingNo + ' forwarded to Final Approval.');
        else if (decision === 'Query Raised') this.toast.success('Query Raised', 'Applicant has been notified.');
        else this.toast.success('Case Rejected', app.trackingNo + ' has been rejected.');
      },
      error: () => {
        this.decisionInProgress.set(false);
        this.toast.error('Could not record decision', 'Please try again.');
      }
    });
  }

  private notifyBorrower(app: LoanApplication, decision: string): void {
    if (decision === 'Approved') {
      this.notifSvc.send(app.userEmail, 'Legal Verification Completed',
        `Your application ${app.trackingNo} has cleared legal & property verification and moved to Final Approval.`).subscribe();
    } else if (decision === 'Query Raised') {
      this.notifSvc.send(app.userEmail, 'Additional Information Required',
        `The Legal team has raised a query on your application ${app.trackingNo}. Please check remarks: ${this.remarksDraft() || 'See portal for details.'}`).subscribe();
    } else if (decision === 'Rejected') {
      this.notifSvc.send(app.userEmail, 'Application Rejected',
        `Your application ${app.trackingNo} could not be approved due to legal/title verification issues. Remarks: ${this.remarksDraft() || 'Contact support for details.'}`).subscribe();
    }
  }

  viewDocument(doc: ApplicationDocumentEntity): void {
    this.docSvc.openInlineDocument(doc);
  }

  ltv(): string {
    const app = this.app();
    if (!app || !app.propertyValue) return '—';
    return Math.round(((app.loanAmount || 0) / app.propertyValue) * 100) + '%';
  }
}
