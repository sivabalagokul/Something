import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { RepaymentService } from '../../core/services/repayment.service';
import { ToastService } from '../../core/services/toast.service';
import { Disbursement, EmiInstallment, InsurancePolicy, LoanApplication } from '../../core/models/models';

@Component({
  selector: 'app-repayment',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Repayment</h1>
      <p>View your EMI schedule, disbursement details and insurance policy status.</p>
    </div>

    @if (!appId()) {
      <div class="card">
        @if (listLoading()) {
          <div class="page-loading"><span class="spinner dark"></span> Loading your applications…</div>
        } @else if (eligibleApps().length === 0) {
          <div class="empty-state"><p>No disbursed loans found yet. Repayment details appear here once your loan is disbursed.</p></div>
        } @else {
          <p class="muted">Select an application to view its repayment schedule.</p>
          <table>
            <thead><tr><th>App ID</th><th>Product</th><th>Status</th><th></th></tr></thead>
            <tbody>
              @for (a of eligibleApps(); track a.appId) {
                <tr class="clickable-row" [routerLink]="['/repayment', a.appId]">
                  <td>{{ a.trackingNo || a.appId }}</td><td>{{ a.productId }}</td>
                  <td><span class="badge badge-green">{{ a.status }}</span></td>
                  <td><span class="btn-link">View →</span></td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    } @else {
      <button class="back-link" routerLink="/repayment">← All Applications</button>

      @if (errorMsg()) {
        <div class="inline-error">{{ errorMsg() }}</div>
      }

      @if (disbursement(); as d) {
        <div class="card">
          <h3>💰 Disbursement</h3>
          <div class="grid grid-4">
            <div class="stat"><span class="lbl">Amount</span><span class="val teal">₹{{ d.amount | number: '1.0-0' }}</span></div>
            <div class="stat"><span class="lbl">Date</span><span class="val">{{ d.disbursedDate | date }}</span></div>
            <div class="stat"><span class="lbl">Reference No.</span><span class="val">{{ d.refNo }}</span></div>
            <div class="stat"><span class="lbl">Mode</span><span class="val">{{ d.mode }}</span></div>
          </div>
        </div>
      }

      <div class="card">
        <h3>📅 EMI Schedule</h3>
        @if (scheduleLoading()) {
          <div class="page-loading"><span class="spinner dark"></span> Loading schedule…</div>
        } @else if (schedule().length === 0) {
          <div class="empty-state"><p>No EMI schedule found for this application yet.</p></div>
        } @else {
          <table>
            <thead><tr><th>#</th><th>Due Date</th><th>EMI</th><th>Principal</th><th>Interest</th><th>Balance</th><th>Status</th><th></th></tr></thead>
            <tbody>
              @for (i of schedule(); track i.installmentId) {
                <tr>
                  <td>{{ i.installmentNo }}</td>
                  <td>{{ i.dueDate | date }}</td>
                  <td>₹{{ i.emiAmount | number: '1.0-0' }}</td>
                  <td>₹{{ i.principalComponent | number: '1.0-0' }}</td>
                  <td>₹{{ i.interestComponent | number: '1.0-0' }}</td>
                  <td>₹{{ i.closingBalance | number: '1.0-0' }}</td>
                  <td><span class="badge" [class]="i.status === 'Paid' ? 'badge-green' : (i.status === 'Overdue' ? 'badge-red' : 'badge-orange')">{{ i.status }}</span></td>
                  <td>
                    @if (i.status !== 'Paid') {
                      <button class="btn btn-teal btn-sm" (click)="pay(i)" [disabled]="paying() === i.installmentId">
                        @if (paying() === i.installmentId) { <span class="spinner"></span> } @else { Pay Now }
                      </button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>

      @if (insurancePolicies().length > 0) {
        <div class="card">
          <h3>🛡 Insurance Policies</h3>
          <table>
            <thead><tr><th>Policy ID</th><th>Type</th><th>Status</th><th>Valid Till</th></tr></thead>
            <tbody>
              @for (p of insurancePolicies(); track p.policyId) {
                <tr>
                  <td>{{ p.policyId }}</td><td>{{ p.policyType }}</td>
                  <td><span class="policy-status">{{ p.status }}</span></td>
                  <td>{{ p.validTill | date }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
    }
  `
})
export class Repayment {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private repaySvc = inject(RepaymentService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);

  appId = signal<string | null>(null);
  listLoading = signal(true);
  eligibleApps = signal<LoanApplication[]>([]);

  errorMsg = signal('');
  scheduleLoading = signal(true);
  schedule = signal<EmiInstallment[]>([]);
  disbursement = signal<Disbursement | null>(null);
  insurancePolicies = signal<InsurancePolicy[]>([]);
  paying = signal<string | null>(null);

  constructor() {
    const routeAppId = this.route.snapshot.paramMap.get('appId');
    if (routeAppId) {
      this.appId.set(routeAppId);
      this.loadDetail(routeAppId);
      this.listLoading.set(false);
    } else {
      const email = this.auth.currentUser()?.email;
      if (email) {
        this.loanSvc.listForUser(email).subscribe({
          next: (list) => {
            this.eligibleApps.set(list.filter((a) => a.status !== 'Draft'));
            this.listLoading.set(false);
          },
          error: () => this.listLoading.set(false)
        });
      } else {
        this.listLoading.set(false);
      }
    }
  }

private loadDetail(appId: string): void {
  this.errorMsg.set('');
  this.scheduleLoading.set(true);

  this.loanSvc.getDisbursementByApp(appId).subscribe({
    next: (d) => {
      this.disbursement.set(d);
      this.loadSchedule(appId);
    },
    error: () => {
      this.loanSvc.createOrUpdateDisbursement({
        appId,
        mode: 'BANK_TRANSFER'
      }).subscribe({
        next: (d) => {
          this.disbursement.set(d);
          this.toast.success('Disbursement created');
          this.loadSchedule(appId);
        },
        error: (err) => {
          this.scheduleLoading.set(false);
          this.errorMsg.set(
            err?.error?.message ||
              err?.error?.error ||
              'Could not create disbursement. Please check whether bank account number is saved in the loan application.'
          );
        }
      });
    }
  });

  this.repaySvc.allInsurancePolicies().subscribe({
    next: (all) => this.insurancePolicies.set(all.filter((p) => p.appId === appId)),
    error: () => {}
  });
}


private loadSchedule(appId: string): void {
  this.repaySvc.schedule(appId).subscribe({
    next: (s) => {
      this.schedule.set(s);
      this.scheduleLoading.set(false);
    },
    error: () => {
      this.schedule.set([]);
      this.scheduleLoading.set(false);
    }
  });
}
  pay(installment: EmiInstallment): void {
    if (!installment.installmentId) return;
    this.paying.set(installment.installmentId);
    this.repaySvc.markInstallmentPaid(installment).subscribe({
      next: (updated) => {
        this.schedule.update((list) =>
          list.map((i) => (i.installmentId === updated.installmentId ? updated : i))
        );
        this.paying.set(null);
        this.toast.success('EMI paid', `Installment #${installment.installmentNo} marked as paid.`);
      },
      error: () => {
        this.paying.set(null);
        this.toast.error('Payment failed', 'Please try again.');
      }
    });
  }
}
