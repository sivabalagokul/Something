import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-unauthorized',
  standalone: true,
  template: `
    <div style="max-width:420px;margin:15vh auto;text-align:center;font-family:sans-serif">
      <h1 style="font-size:1.4rem;margin-bottom:.5rem">Access denied</h1>
      <p style="color:#666;margin-bottom:1.5rem">
        Your account role doesn't have access to that area of HLMS.
      </p>
      <button (click)="goHome()" style="padding:.6rem 1.2rem;border-radius:6px;border:0;background:#0f3d5c;color:#fff;cursor:pointer">
        Go to my dashboard
      </button>
    </div>
  `
})
export class Unauthorized {
  private auth = inject(AuthService);
  private router = inject(Router);

  goHome(): void {
    const landing: Record<string, string> = {
      CUSTOMER: '/customer/dashboard',
      ADMIN: '/admin/dashboard',
      BIDDER: '/bidder/dashboard',
      LEGAL: '/legal/dashboard',
      BANK_OFFICER: '/bankoffice/bodash'
    };
    this.router.navigateByUrl(landing[this.auth.currentUser()?.role ?? ''] ?? '/');
  }
}
