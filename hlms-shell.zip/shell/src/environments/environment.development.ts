export const environment = {
  production: false,
  apiBase: 'http://localhost:8080',
  apiBaseUrl: 'http://localhost:8080',
  auth: {
    tokenStorageKey: 'hlms_token',
    storage: 'local' as 'local' | 'session',
    loginUrl: '/login'
  }
};
