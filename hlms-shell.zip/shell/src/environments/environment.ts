export const environment = {
  production: true,
  apiBase: 'http://localhost:8080',
  // alias kept for feature modules (bidder/legal/bankoffice) ported in from
  // standalone apps that referenced environment.apiBaseUrl
  apiBaseUrl: 'http://localhost:8080',
  auth: {
    tokenStorageKey: 'hlms_token',
    storage: 'local' as 'local' | 'session',
    loginUrl: '/login'
  },
  // gateway service-name prefixes (StripPrefix=1) — used by the bidder module's api-urls.ts
  services: {
    user: '/user-service',
    loan: '/loan-service',
    repayment: '/repayment-service',
    notification: '/notification-service'
  },
  /** Minimum bid increment above the current highest bid, in rupees (front-end guidance only). */
  bidIncrement: 5000
};
