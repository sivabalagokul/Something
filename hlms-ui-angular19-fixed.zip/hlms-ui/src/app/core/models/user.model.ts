export type UserRole = 'admin' | 'employee' | 'legal' | 'bankoffice' | 'customer' | 'bidder';

export interface AppUser {
  id?: number;
  fullName: string;
  email: string;
  phone?: string;
  password?: string;
  role: UserRole;
  active?: boolean;
  createdAt?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  role: UserRole;
}
