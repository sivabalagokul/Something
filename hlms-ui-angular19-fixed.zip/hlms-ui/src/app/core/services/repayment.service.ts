import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { EmiInstallment, Disbursement, InsurancePolicy } from '../models/repayment.model';
import { AuctionCase, Bid } from '../models/auction.model';

@Injectable({ providedIn: 'root' })
export class RepaymentService {
  private readonly emi = `${environment.apiBaseUrl}/repayment-service/api/emi`;
  private readonly disbursements = `${environment.apiBaseUrl}/repayment-service/api/disbursements`;
  private readonly insurance = `${environment.apiBaseUrl}/repayment-service/api/insurance-policies`;
  private readonly auctions = `${environment.apiBaseUrl}/repayment-service/api/auctions`;
  private readonly auctionNotes = `${environment.apiBaseUrl}/repayment-service/api/auction-notes`;
  private readonly bids = `${environment.apiBaseUrl}/repayment-service/api/bids`;
  private readonly defaultMgmt = `${environment.apiBaseUrl}/repayment-service/api/default-management`;

  constructor(private http: HttpClient) {}

  // ---- EMI ----
  getSchedule(appId: number): Observable<EmiInstallment[]> {
    return this.http.get<EmiInstallment[]>(`${this.emi}/${appId}/schedule`);
  }

  getInstallments(): Observable<EmiInstallment[]> {
    return this.http.get<EmiInstallment[]>(`${this.emi}/installments`);
  }

  getInstallment(id: number): Observable<EmiInstallment> {
    return this.http.get<EmiInstallment>(`${this.emi}/installments/${id}`);
  }

  createInstallment(payload: Partial<EmiInstallment>): Observable<EmiInstallment> {
    return this.http.post<EmiInstallment>(`${this.emi}/installments`, payload);
  }

  updateInstallment(id: number, payload: Partial<EmiInstallment>): Observable<EmiInstallment> {
    return this.http.put<EmiInstallment>(`${this.emi}/installments/${id}`, payload);
  }

  // ---- Disbursements ----
  getDisbursementsForApp(appId: number): Observable<Disbursement[]> {
    return this.http.get<Disbursement[]>(`${this.disbursements}/by-application/${appId}`);
  }

  getAllDisbursements(): Observable<Disbursement[]> {
    return this.http.get<Disbursement[]>(this.disbursements);
  }

  createDisbursement(payload: Partial<Disbursement>): Observable<Disbursement> {
    return this.http.post<Disbursement>(this.disbursements, payload);
  }

  // ---- Insurance ----
  getInsurancePolicies(): Observable<InsurancePolicy[]> {
    return this.http.get<InsurancePolicy[]>(this.insurance);
  }

  createInsurancePolicy(payload: Partial<InsurancePolicy>): Observable<InsurancePolicy> {
    return this.http.post<InsurancePolicy>(this.insurance, payload);
  }

  // ---- Auctions & bids ----
  getAuctions(): Observable<AuctionCase[]> {
    return this.http.get<AuctionCase[]>(this.auctions);
  }

  getAuctionsForApp(appId: number): Observable<AuctionCase[]> {
    return this.http.get<AuctionCase[]>(`${this.auctions}/by-application/${appId}`);
  }

  getAuction(auctionId: number): Observable<AuctionCase> {
    return this.http.get<AuctionCase>(`${this.auctions}/${auctionId}`);
  }

  createAuction(payload: Partial<AuctionCase>): Observable<AuctionCase> {
    return this.http.post<AuctionCase>(this.auctions, payload);
  }

  placeBid(appId: number, payload: Partial<Bid>): Observable<Bid> {
    return this.http.post<Bid>(`${this.auctions}/${appId}/bids`, payload);
  }

  getBidsForApp(appId: number): Observable<Bid[]> {
    return this.http.get<Bid[]>(`${this.auctions}/${appId}/bids`);
  }

  // NOTE: BidController's GET /api/bids (repayment-service) returns every
  // bid - it doesn't support filtering by bidder. Filtering client-side here
  // until a "?bidderEmail=" query param is added server-side.
  getMyBids(bidderEmail: string): Observable<Bid[]> {
    return this.http.get<Bid[]>(this.bids).pipe(
      map((all) => all.filter((b) => b.bidderEmail === bidderEmail))
    );
  }

  // ---- Default management ----
  getDefaultStatus(appId: number): Observable<unknown> {
    return this.http.get(`${this.defaultMgmt}/status/${appId}`);
  }

  getEscalation(appId: number): Observable<unknown> {
    return this.http.get(`${this.defaultMgmt}/escalation/${appId}`);
  }

  getOverdue(): Observable<unknown[]> {
    return this.http.get<unknown[]>(`${this.defaultMgmt}/overdue`);
  }
}
