import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AppUser, UserRole } from '../models/user.model';

/** Shape user-service's appUserEntity actually serializes as - see AuthService for the same mapping. */
interface BackendUser {
  email: string;
  name: string;
  mobile: string;
  role: 'CUSTOMER' | 'LEGAL' | 'BANK_OFFICER' | 'BIDDER' | 'ADMIN';
  active?: boolean;
  createdAt?: string;
}

const TO_UI_ROLE: Record<BackendUser['role'], UserRole> = {
  CUSTOMER: 'customer',
  LEGAL: 'legal',
  BANK_OFFICER: 'bankoffice',
  BIDDER: 'bidder',
  ADMIN: 'admin'
};

function toAppUser(u: BackendUser): AppUser {
  return {
    fullName: u.name,
    email: u.email,
    phone: u.mobile,
    role: TO_UI_ROLE[u.role] ?? 'customer',
    active: u.active,
    createdAt: u.createdAt
  };
}

@Injectable({ providedIn: 'root' })
export class UserAdminService {
  private readonly baseUrl = `${environment.apiBaseUrl}/user-service/api/users`;
  private readonly profileUrl = `${environment.apiBaseUrl}/user-service/api/customer-profile`;
  private readonly rolesUrl = `${environment.apiBaseUrl}/user-service/api/role-permissions`;

  constructor(private http: HttpClient) {}

  getUser(email: string): Observable<AppUser> {
    return this.http.get<BackendUser>(`${this.baseUrl}/${encodeURIComponent(email)}`).pipe(map(toAppUser));
  }

  // NOTE: appUserService.updateUser only persists name/mobile/notification
  // prefs server-side - it silently ignores "active" and "role" in the
  // request body. There is currently no way to (re)activate an account or
  // change its role through this endpoint; deleteUser() below is a soft
  // delete (sets deletedAt) and there's no matching "reactivate" endpoint.
  updateUser(email: string, payload: Partial<AppUser>): Observable<AppUser> {
    const body = {
      name: payload.fullName,
      mobile: payload.phone
    };
    return this.http.put<BackendUser>(`${this.baseUrl}/${encodeURIComponent(email)}`, body).pipe(map(toAppUser));
  }

  deleteUser(email: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${encodeURIComponent(email)}`);
  }

  // ---- Customer employment profile ----
  createEmploymentProfile(payload: unknown): Observable<unknown> {
    return this.http.post(this.profileUrl, payload);
  }

  getEmploymentProfile(email: string): Observable<unknown> {
    return this.http.get(`${this.profileUrl}/${encodeURIComponent(email)}`);
  }

  getAllEmploymentProfiles(): Observable<unknown[]> {
    return this.http.get<unknown[]>(`${this.profileUrl}/all`);
  }

  updateEmploymentProfile(email: string, payload: unknown): Observable<unknown> {
    return this.http.put(`${this.profileUrl}/${encodeURIComponent(email)}`, payload);
  }

  // ---- Role permissions ----
  getRolePermissions(): Observable<unknown[]> {
    return this.http.get<unknown[]>(this.rolesUrl);
  }

  createRolePermission(payload: unknown): Observable<unknown> {
    return this.http.post(this.rolesUrl, payload);
  }

  updateRolePermission(id: number, payload: unknown): Observable<unknown> {
    return this.http.put(`${this.rolesUrl}/${id}`, payload);
  }

  deleteRolePermission(id: number): Observable<void> {
    return this.http.delete<void>(`${this.rolesUrl}/${id}`);
  }
}
