import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { ServiceRequest } from '../../../core/models/notification.model';

@Component({
  selector: 'app-support',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './support.component.html'
})
export class SupportComponent implements OnInit {
  private auth = inject(AuthService);
  private notificationService = inject(NotificationService);
  private toast = inject(ToastService);

  requests = signal<ServiceRequest[]>([]);
  loading = signal(true);
  sending = signal(false);

  subject = '';
  message = '';

  ngOnInit(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.refresh(email);
  }

  refresh(email: string) {
    this.notificationService.getRequestsForUser(email).subscribe({
      next: (list) => { this.requests.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  send() {
    const email = this.auth.currentUser()?.email;
    if (!email || !this.subject.trim() || !this.message.trim()) {
      this.toast.show('Missing details', 'Please fill in subject and message.', 'error');
      return;
    }
    this.sending.set(true);
    // ServiceRequestController's create() reads "requestType"/"description" from the
    // body, not "subject"/"message" - map field names accordingly. NOTE: it also
    // requires a real "appId" (it verifies the application exists via loan-service
    // before saving) - this general contact form doesn't collect one, so submissions
    // will likely fail server-side until this screen is tied to a specific application.
    this.notificationService.createRequest({
      userEmail: email,
      requestType: this.subject,
      description: this.message
    }).subscribe({
      next: () => {
        this.sending.set(false);
        this.subject = '';
        this.message = '';
        this.toast.show('Request sent', 'Our support team will get back to you shortly.', 'success');
        this.refresh(email);
      },
      error: () => this.sending.set(false)
    });
  }
}
