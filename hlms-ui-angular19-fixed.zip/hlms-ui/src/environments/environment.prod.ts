export const environment = {
  production: true,
  // Prod build has no dev-server proxy, so this must be the API Gateway's
  // real origin. The gateway has CORS enabled (see api-gateway/application.properties)
  // so this can point at a different host/port than the one serving this app.
  apiBaseUrl: 'http://localhost:8080'
};
