# HLMS UI — Angular 19

Angular 19 (standalone components, signals, new `@if`/`@for` control-flow syntax)
rewrite of the original static `integration-2.html/css/js` front end, wired to the
`hlms-microservices` Spring Boot backend through the API Gateway.

## 1. Getting started

```bash
npm install
npm start        # ng serve, with a dev proxy so /api calls reach the gateway
```

The app serves on `http://localhost:4200`. Requests to `/api/**` are proxied to
`http://localhost:8080` (see `proxy.conf.json`) — start your `api-gateway`
(and Eureka + the other services) locally first.

If you call the API from a different host/port, edit
`src/environments/environment.ts` / `environment.prod.ts`
(`apiBaseUrl`).

```bash
npm run build     # production build -> dist/hlms-ui
```

## 2. Project structure

```
src/app/
  core/
    models/           TypeScript interfaces for every domain object
    services/          One Angular service per backend concern:
                         auth, loan, document, repayment, legal, notification, user-admin
    guards/            authGuard (must be logged in), roleGuard (role-based route access)
    interceptors/       JWT attach + global error-toast interceptor
  layout/
    shell/              Top-level authenticated layout (topbar + sidebar + <router-outlet>)
    sidebar/             Role-aware navigation (mirrors the old sidebarItemsFor())
    topbar/              Search bar, notifications bell, user chip
  features/
    home/                Public landing page
    auth/                login / register / forgot-password (email → OTP → reset)
    customer/            dashboard, eligibility, guidance, apply, tracking, repayment,
                         postdisb, documents, auction, profile, support
    admin/               admin-dashboard, user-management, employee-management, role-permissions
    legal/               legal-dashboard, legal-queue, legal-case-detail, legal-documents,
                         legal-auction, legal-notices
    bankoffice/           bo-dashboard, bo-applications, bo-app-detail, bo-portfolio,
                         bo-disbursement, bo-npa, bo-docs, bo-auction, bo-reports, bo-settings
    bidder/              bidder-dashboard, bidder-listings, bidder-listing-detail,
                         bidder-bids, bidder-settings
  shared/
    components/toast/    Global toast notifications (used by the error interceptor)
  app.routes.ts          All routes — lazy-loaded standalone components, guarded by role
  app.config.ts          Router, HttpClient + interceptors, animations providers
```

Every feature route lives under `/app/...` and is protected by `authGuard`; most
are additionally protected by `roleGuard` using `data: { roles: [...] }` on the
route, e.g. only `admin` can reach `/app/admindash`.

`styles.scss` is a straight port of your original `integration-2.css`, plus a
small "Supplemental styles" block at the bottom for a few Angular-specific
utility classes (`.view-header`, `.stat`, `.table`, `.two-col`, `.req`) that the
original single-page app didn't need because everything was hand-templated in
JS. All original class names (`.card`, `.badge`, `.btn`, `.field`, `.stepper`,
`.sidebar`, `.topbar`, home-page classes, auth-page classes, etc.) are untouched.

## 3. How the API mapping was built

Every method in `core/services/*.service.ts` was written against the actual
`@GetMapping` / `@PostMapping` / etc. annotations found in your
`hlms-microservices` controllers, using the API Gateway's route prefix
(`/api/**` → `http://localhost:8080`, per `api-gateway/src/main/resources/application.yml`).
Nothing was invented — if a screen needed an endpoint that doesn't exist yet on
the backend, that's called out below instead of being faked.

| Service | Backend controller(s) |
|---|---|
| `AuthService` | `user-service` — register/login/forgot-password/reset-password, `otp-service` endpoints |
| `LoanService` | `loan-service` — loan-applications, loan-products, eligibility, mortgage, loan-guidance |
| `DocumentService` | `hlms-document-service` — application-documents, post-disbursement-documents, audit-logs |
| `RepaymentService` | `repayment-service` — emi, disbursements, insurance-policies, auctions, bids, default-management |
| `LegalService` | `legal-service` — legal/verifications, legal/checklist-items, legal-notices, bank-office/decisions |
| `NotificationService` | `hlms-notification-service` — notifications, service-requests |
| `UserAdminService` | `user-service` — user CRUD by email, customer-profile, role-permissions |

## 4. Known backend gaps (found during conversion, not fabricated)

- **No "list all users" endpoint.** `user-service` only exposes register / login /
  get-by-email / update-by-email / delete-by-email. The Admin "Customer/Bidder
  Management" screens are therefore search-by-email tools rather than paged
  tables. If you want a browsable user list, add a `GET /api/users` (or
  `/api/users?role=...`) endpoint and the screen is a small change to switch
  from search to a table.
- **No document status-update endpoint.** `hlms-document-service`'s
  `ApplicationDocumentController` supports upload / get / list / delete, but not
  a `PUT`/`PATCH` to change a document's `status` (Pending → Verified/Rejected).
  The Bank Office "Document Verification" screen currently only *displays*
  document status for this reason; it doesn't let staff verify/reject in-app
  until that endpoint exists.

Everything else (loan applications, eligibility, mortgage, disbursements, EMI
schedules, legal verifications/notices, auctions/bids, service requests,
role-permissions CRUD) is wired to real, existing endpoints.

## 5. Notes on translation choices

- The original app was a single 3,500-line vanilla-JS file that manually built
  HTML strings per "view" and stored everything in `localStorage`. This rewrite
  keeps the same visual structure and CSS, but replaces the hand-rolled
  view-switching with Angular's router (one lazy-loaded standalone component
  per view) and replaces `localStorage`-as-database with real HTTP calls to
  your microservices. The current logged-in user is still cached in
  `localStorage` (just the session, not app data) so a page refresh doesn't
  log you out — see `AuthService`.
- Forms use Angular Reactive Forms where validation matters (login, register,
  apply, eligibility) and simple two-way `[(ngModel)]` bindings for
  simpler CRUD-style screens (auction case creation, legal notices, etc.),
  matching the complexity of the original JS.
- Role-based sidebar items are generated in `layout/sidebar/sidebar.config.ts`,
  a direct port of your `sidebarItemsFor(role)` function.

## 6. Next steps you may want

- Swap the JWT the backend actually issues into `AuthService.login()` (right
  now it stores whatever `res.token` comes back, if any — confirm your
  `user-service` login response shape matches `LoginResponse` in
  `core/models/user.model.ts` and adjust if it differs).
- Add the two backend endpoints noted in section 4 to unlock the admin
  user-listing and document-verification screens fully.
- Add e2e/unit tests (none were in scope for this conversion).
