import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/home/home.component').then(m => m.HomeComponent)
  },
  {
    path: 'auth',
    children: [
      { path: 'login', loadComponent: () => import('./features/auth/login/login.component').then(m => m.LoginComponent) },
      { path: 'register', loadComponent: () => import('./features/auth/register/register.component').then(m => m.RegisterComponent) },
      { path: 'forgot-password', loadComponent: () => import('./features/auth/forgot-password/forgot-password.component').then(m => m.ForgotPasswordComponent) },
      { path: '', redirectTo: 'login', pathMatch: 'full' }
    ]
  },
  {
    path: 'app',
    canActivate: [authGuard],
    loadComponent: () => import('./layout/shell/shell.component').then(m => m.ShellComponent),
    children: [
      // ---------------- Customer ----------------
      { path: 'dashboard', canActivate: [roleGuard], data: { roles: ['customer'] }, loadComponent: () => import('./features/customer/dashboard/dashboard.component').then(m => m.DashboardComponent) },
      { path: 'eligibility', canActivate: [roleGuard], data: { roles: ['customer'] }, loadComponent: () => import('./features/customer/eligibility/eligibility.component').then(m => m.EligibilityComponent) },
      { path: 'guidance', canActivate: [roleGuard], data: { roles: ['customer'] }, loadComponent: () => import('./features/customer/guidance/guidance.component').then(m => m.GuidanceComponent) },
      { path: 'apply', canActivate: [roleGuard], data: { roles: ['customer'] }, loadComponent: () => import('./features/customer/apply/apply.component').then(m => m.ApplyComponent) },
      { path: 'tracking', canActivate: [roleGuard], data: { roles: ['customer'] }, loadComponent: () => import('./features/customer/tracking/tracking.component').then(m => m.TrackingComponent) },
      { path: 'repayment', canActivate: [roleGuard], data: { roles: ['customer'] }, loadComponent: () => import('./features/customer/repayment/repayment.component').then(m => m.RepaymentComponent) },
      { path: 'postdisb', canActivate: [roleGuard], data: { roles: ['customer'] }, loadComponent: () => import('./features/customer/postdisb/postdisb.component').then(m => m.PostdisbComponent) },
      { path: 'auction', loadComponent: () => import('./features/customer/auction/auction.component').then(m => m.AuctionComponent) },
      { path: 'documents', canActivate: [roleGuard], data: { roles: ['customer'] }, loadComponent: () => import('./features/customer/documents/documents.component').then(m => m.DocumentsComponent) },
      { path: 'support', canActivate: [roleGuard], data: { roles: ['customer'] }, loadComponent: () => import('./features/customer/support/support.component').then(m => m.SupportComponent) },
      { path: 'profile', loadComponent: () => import('./features/customer/profile/profile.component').then(m => m.ProfileComponent) },

      // ---------------- Admin ----------------
      { path: 'admindash', canActivate: [roleGuard], data: { roles: ['admin'] }, loadComponent: () => import('./features/admin/admin-dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent) },
      { path: 'adminmgmt', canActivate: [roleGuard], data: { roles: ['admin'], roleFilter: 'customer' }, loadComponent: () => import('./features/admin/user-management/user-management.component').then(m => m.UserManagementComponent) },
      { path: 'biddermgmt', canActivate: [roleGuard], data: { roles: ['admin'], roleFilter: 'bidder' }, loadComponent: () => import('./features/admin/user-management/user-management.component').then(m => m.UserManagementComponent) },
      { path: 'employeemgmt', canActivate: [roleGuard], data: { roles: ['admin'], roleFilter: 'employee' }, loadComponent: () => import('./features/admin/employee-management/employee-management.component').then(m => m.EmployeeManagementComponent) },
      { path: 'legalmgmt', canActivate: [roleGuard], data: { roles: ['admin'], roleFilter: 'legal' }, loadComponent: () => import('./features/admin/employee-management/employee-management.component').then(m => m.EmployeeManagementComponent) },
      { path: 'bankofficemgmt', canActivate: [roleGuard], data: { roles: ['admin'], roleFilter: 'bankoffice' }, loadComponent: () => import('./features/admin/employee-management/employee-management.component').then(m => m.EmployeeManagementComponent) },
      { path: 'roles', canActivate: [roleGuard], data: { roles: ['admin'] }, loadComponent: () => import('./features/admin/role-permissions/role-permissions.component').then(m => m.RolePermissionsComponent) },

      // ---------------- Legal ----------------
      { path: 'legaldash', canActivate: [roleGuard], data: { roles: ['legal'] }, loadComponent: () => import('./features/legal/legal-dashboard/legal-dashboard.component').then(m => m.LegalDashboardComponent) },
      { path: 'legalqueue', canActivate: [roleGuard], data: { roles: ['legal'] }, loadComponent: () => import('./features/legal/legal-queue/legal-queue.component').then(m => m.LegalQueueComponent) },
      { path: 'legalcasedetail/:appId', canActivate: [roleGuard], data: { roles: ['legal'] }, loadComponent: () => import('./features/legal/legal-case-detail/legal-case-detail.component').then(m => m.LegalCaseDetailComponent) },
      { path: 'legaldocuments', canActivate: [roleGuard], data: { roles: ['legal'] }, loadComponent: () => import('./features/legal/legal-documents/legal-documents.component').then(m => m.LegalDocumentsComponent) },
      { path: 'legalauction', canActivate: [roleGuard], data: { roles: ['legal'] }, loadComponent: () => import('./features/legal/legal-auction/legal-auction.component').then(m => m.LegalAuctionComponent) },
      { path: 'legalnotices', canActivate: [roleGuard], data: { roles: ['legal'] }, loadComponent: () => import('./features/legal/legal-notices/legal-notices.component').then(m => m.LegalNoticesComponent) },

      // ---------------- Bank Office ----------------
      { path: 'bodash', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-dashboard/bo-dashboard.component').then(m => m.BoDashboardComponent) },
      { path: 'boapplications', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-applications/bo-applications.component').then(m => m.BoApplicationsComponent) },
      { path: 'boappdetail/:appId', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-app-detail/bo-app-detail.component').then(m => m.BoAppDetailComponent) },
      { path: 'boportfolio', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-portfolio/bo-portfolio.component').then(m => m.BoPortfolioComponent) },
      { path: 'bodisbursement', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-disbursement/bo-disbursement.component').then(m => m.BoDisbursementComponent) },
      { path: 'bonpa', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-npa/bo-npa.component').then(m => m.BoNpaComponent) },
      { path: 'bodocs', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-docs/bo-docs.component').then(m => m.BoDocsComponent) },
      { path: 'boauction', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-auction/bo-auction.component').then(m => m.BoAuctionComponent) },
      { path: 'boreports', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-reports/bo-reports.component').then(m => m.BoReportsComponent) },
      { path: 'bosettings', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-settings/bo-settings.component').then(m => m.BoSettingsComponent) },

      // ---------------- Bidder ----------------
      { path: 'bidderdash', canActivate: [roleGuard], data: { roles: ['bidder'] }, loadComponent: () => import('./features/bidder/bidder-dashboard/bidder-dashboard.component').then(m => m.BidderDashboardComponent) },
      { path: 'bidderlistings', canActivate: [roleGuard], data: { roles: ['bidder'] }, loadComponent: () => import('./features/bidder/bidder-listings/bidder-listings.component').then(m => m.BidderListingsComponent) },
      { path: 'bidderlistingdetail/:auctionId', canActivate: [roleGuard], data: { roles: ['bidder'] }, loadComponent: () => import('./features/bidder/bidder-listing-detail/bidder-listing-detail.component').then(m => m.BidderListingDetailComponent) },
      { path: 'bidderbids', canActivate: [roleGuard], data: { roles: ['bidder'] }, loadComponent: () => import('./features/bidder/bidder-bids/bidder-bids.component').then(m => m.BidderBidsComponent) },
      { path: 'biddersettings', canActivate: [roleGuard], data: { roles: ['bidder'] }, loadComponent: () => import('./features/bidder/bidder-settings/bidder-settings.component').then(m => m.BidderSettingsComponent) },

      { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
    ]
  },
  { path: '**', redirectTo: '' }
];
