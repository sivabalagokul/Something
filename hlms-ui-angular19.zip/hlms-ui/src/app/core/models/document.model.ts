export interface ApplicationDocument {
  documentId?: number;
  appId: number;
  docType: string;
  fileName?: string;
  status: 'Pending' | 'Verified' | 'Rejected';
  uploadedAt?: string;
  remarks?: string;
}

export interface PostDisbursementDocument {
  documentId?: number;
  appId: number;
  docType: string;
  fileName?: string;
  status: 'Pending' | 'Verified' | 'Rejected';
  uploadedAt?: string;
}
