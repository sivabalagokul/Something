export interface LegalVerification {
  verificationId?: number;
  appId: number;
  assignedTo?: string;
  status: 'Pending' | 'In Progress' | 'Completed' | 'Flagged';
  remarks?: string;
  verifiedAt?: string;
}

export interface LegalChecklistItem {
  checklistItemId?: number;
  appId: number;
  itemName: string;
  completed: boolean;
  remarks?: string;
}

export interface LegalNotice {
  noticeId?: number;
  appId: number;
  noticeType: string;
  issuedDate: string;
  description?: string;
}

export interface BankOfficeDecision {
  decisionId?: number;
  appId: number;
  decision: 'Approved' | 'Rejected' | 'Pending';
  decidedBy?: string;
  remarks?: string;
  decidedAt?: string;
}
