export interface LoanApplication {
  appId?: number;
  trackingNo?: string;
  applicantEmail: string;
  applicantName?: string;
  loanProductId?: number;
  loanAmount: number;
  tenureYears: number;
  monthlyIncome?: number;
  otherEMIs?: number;
  propertyAddress?: string;
  propertyValue?: number;
  stage?: string;
  stageIndex?: number;
  status?: 'Draft' | 'Submitted' | 'In Progress' | 'Approved' | 'Rejected' | 'Disbursed' | 'Closed';
  submittedAt?: string;
  createdAt?: string;
  updatedAt?: string;
}

export const WORKFLOW_STAGES = [
  'Application Submitted',
  'Document Verification',
  'Eligibility & Credit Check',
  'Mortgage / Property Verification',
  'Final Approval',
  'Disbursement'
];
