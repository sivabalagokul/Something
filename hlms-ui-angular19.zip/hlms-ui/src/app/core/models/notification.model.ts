export interface Notification {
  notificationId?: number;
  userEmail: string;
  title: string;
  body: string;
  read: boolean;
  createdAt?: string;
}

export interface ServiceRequest {
  requestId?: number;
  appId?: number;
  userEmail: string;
  subject: string;
  message: string;
  status?: 'Open' | 'Resolved';
  createdAt?: string;
}
