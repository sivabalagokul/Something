export interface EmiInstallment {
  installmentId?: number;
  appId: number;
  installmentNo: number;
  dueDate: string;
  emiAmount: number;
  principalComponent: number;
  interestComponent: number;
  status: 'Pending' | 'Paid' | 'Overdue';
  paidDate?: string;
}

export interface Disbursement {
  disbursementId?: number;
  appId: number;
  amount: number;
  disbursementDate: string;
  installmentStage?: string;
  remarks?: string;
}

export interface InsurancePolicy {
  policyId?: number;
  appId: number;
  provider: string;
  policyNumber: string;
  coverAmount: number;
  premium: number;
  startDate: string;
  endDate: string;
}
