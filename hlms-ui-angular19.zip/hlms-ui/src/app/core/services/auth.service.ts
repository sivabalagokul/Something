import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AppUser, LoginRequest, LoginResponse, RegisterRequest } from '../models/user.model';

const STORAGE_KEY = 'hlms_session_v1';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly baseUrl = `${environment.apiBaseUrl}/users`;
  private readonly otpUrl = `${environment.apiBaseUrl}/otp`;

  /** Currently logged-in user, restored from localStorage on app start. */
  readonly currentUser = signal<AppUser | null>(this.restoreSession());
  readonly isLoggedIn = computed(() => !!this.currentUser());
  readonly role = computed(() => this.currentUser()?.role ?? null);

  constructor(private http: HttpClient) {}

  private restoreSession(): AppUser | null {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) as AppUser : null;
    } catch {
      return null;
    }
  }

  private persist(user: AppUser | null) {
    if (user) localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    else localStorage.removeItem(STORAGE_KEY);
  }

  login(payload: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.baseUrl}/login`, payload).pipe(
      tap((res) => {
        this.currentUser.set(res.user);
        this.persist(res.user);
        if (res.token) localStorage.setItem('hlms_token', res.token);
      })
    );
  }

  register(payload: RegisterRequest): Observable<AppUser> {
    return this.http.post<AppUser>(`${this.baseUrl}/register`, payload);
  }

  generateOtp(email: string): Observable<unknown> {
    return this.http.post(`${this.otpUrl}/generate`, { email });
  }

  verifyOtp(email: string, otp: string): Observable<unknown> {
    return this.http.post(`${this.otpUrl}/verify`, { email, otp });
  }

  forgotPassword(email: string): Observable<unknown> {
    return this.http.post(`${this.baseUrl}/forgot-password`, { email });
  }

  resetPassword(email: string, newPassword: string): Observable<unknown> {
    return this.http.post(`${this.baseUrl}/reset-password`, { email, newPassword });
  }

  updateProfile(email: string, changes: Partial<AppUser>): Observable<AppUser> {
    return this.http.put<AppUser>(`${this.baseUrl}/${email}`, changes).pipe(
      tap((updated) => {
        this.currentUser.set(updated);
        this.persist(updated);
      })
    );
  }

  logout(): void {
    this.currentUser.set(null);
    this.persist(null);
    localStorage.removeItem('hlms_token');
  }
}
