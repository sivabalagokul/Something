import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApplicationDocument, PostDisbursementDocument } from '../models/document.model';

@Injectable({ providedIn: 'root' })
export class DocumentService {
  private readonly appDocs = `${environment.apiBaseUrl}/application-documents`;
  private readonly postDisbDocs = `${environment.apiBaseUrl}/post-disbursement-documents`;
  private readonly auditLogs = `${environment.apiBaseUrl}/audit-logs`;

  constructor(private http: HttpClient) {}

  // ---- Application documents ----
  getContext(appId: number): Observable<unknown> {
    return this.http.get(`${this.appDocs}/app/${appId}/context`);
  }

  uploadDocument(payload: Partial<ApplicationDocument>): Observable<ApplicationDocument> {
    return this.http.post<ApplicationDocument>(this.appDocs, payload);
  }

  getDocument(documentId: number): Observable<ApplicationDocument> {
    return this.http.get<ApplicationDocument>(`${this.appDocs}/${documentId}`);
  }

  getDocumentsForApp(appId: number): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(`${this.appDocs}/app/${appId}`);
  }

  getAllDocuments(): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(this.appDocs);
  }

  deleteDocument(documentId: number): Observable<void> {
    return this.http.delete<void>(`${this.appDocs}/${documentId}`);
  }

  // ---- Post-disbursement documents ----
  uploadPostDisbDocument(payload: Partial<PostDisbursementDocument>): Observable<PostDisbursementDocument> {
    return this.http.post<PostDisbursementDocument>(this.postDisbDocs, payload);
  }

  getPostDisbDocument(documentId: number): Observable<PostDisbursementDocument> {
    return this.http.get<PostDisbursementDocument>(`${this.postDisbDocs}/${documentId}`);
  }

  getPostDisbDocumentsForApp(appId: number): Observable<PostDisbursementDocument[]> {
    return this.http.get<PostDisbursementDocument[]>(`${this.postDisbDocs}/app/${appId}`);
  }

  getAllPostDisbDocuments(): Observable<PostDisbursementDocument[]> {
    return this.http.get<PostDisbursementDocument[]>(this.postDisbDocs);
  }

  deletePostDisbDocument(documentId: number): Observable<void> {
    return this.http.delete<void>(`${this.postDisbDocs}/${documentId}`);
  }

  // ---- Audit logs ----
  getAuditLogs(): Observable<unknown[]> {
    return this.http.get<unknown[]>(this.auditLogs);
  }
}
