import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { LegalVerification, LegalChecklistItem, LegalNotice, BankOfficeDecision } from '../models/legal.model';

@Injectable({ providedIn: 'root' })
export class LegalService {
  private readonly verifications = `${environment.apiBaseUrl}/legal/verifications`;
  private readonly checklist = `${environment.apiBaseUrl}/legal/checklist-items`;
  private readonly notices = `${environment.apiBaseUrl}/legal-notices`;
  private readonly decisions = `${environment.apiBaseUrl}/bank-office/decisions`;

  constructor(private http: HttpClient) {}

  // ---- Verifications ----
  getVerificationContext(appId: number): Observable<unknown> {
    return this.http.get(`${this.verifications}/by-application/${appId}/context`);
  }

  getVerificationsForApp(appId: number): Observable<LegalVerification[]> {
    return this.http.get<LegalVerification[]>(`${this.verifications}/by-application/${appId}`);
  }

  getAllVerifications(): Observable<LegalVerification[]> {
    return this.http.get<LegalVerification[]>(this.verifications);
  }

  createVerification(payload: Partial<LegalVerification>): Observable<LegalVerification> {
    return this.http.post<LegalVerification>(this.verifications, payload);
  }

  updateVerification(id: number, payload: Partial<LegalVerification>): Observable<LegalVerification> {
    return this.http.put<LegalVerification>(`${this.verifications}/${id}`, payload);
  }

  deleteVerification(id: number): Observable<void> {
    return this.http.delete<void>(`${this.verifications}/${id}`);
  }

  // ---- Checklist items ----
  getChecklistItems(): Observable<LegalChecklistItem[]> {
    return this.http.get<LegalChecklistItem[]>(this.checklist);
  }

  createChecklistItem(payload: Partial<LegalChecklistItem>): Observable<LegalChecklistItem> {
    return this.http.post<LegalChecklistItem>(this.checklist, payload);
  }

  updateChecklistItem(id: number, payload: Partial<LegalChecklistItem>): Observable<LegalChecklistItem> {
    return this.http.put<LegalChecklistItem>(`${this.checklist}/${id}`, payload);
  }

  // ---- Legal notices ----
  getNotices(): Observable<LegalNotice[]> {
    return this.http.get<LegalNotice[]>(this.notices);
  }

  createNotice(payload: Partial<LegalNotice>): Observable<LegalNotice> {
    return this.http.post<LegalNotice>(this.notices, payload);
  }

  updateNotice(id: number, payload: Partial<LegalNotice>): Observable<LegalNotice> {
    return this.http.put<LegalNotice>(`${this.notices}/${id}`, payload);
  }

  // ---- Bank office decisions ----
  getDecisionsForApp(appId: number): Observable<BankOfficeDecision[]> {
    return this.http.get<BankOfficeDecision[]>(`${this.decisions}/by-application/${appId}`);
  }

  getAllDecisions(): Observable<BankOfficeDecision[]> {
    return this.http.get<BankOfficeDecision[]>(this.decisions);
  }

  createDecision(payload: Partial<BankOfficeDecision>): Observable<BankOfficeDecision> {
    return this.http.post<BankOfficeDecision>(this.decisions, payload);
  }
}
