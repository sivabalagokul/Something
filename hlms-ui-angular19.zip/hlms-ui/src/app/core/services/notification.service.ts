import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Notification, ServiceRequest } from '../models/notification.model';

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private readonly notifUrl = `${environment.apiBaseUrl}/notifications`;
  private readonly requestUrl = `${environment.apiBaseUrl}/service-requests`;

  readonly notifications = signal<Notification[]>([]);
  readonly unreadCount = signal(0);

  constructor(private http: HttpClient) {}

  loadForUser(email: string): Observable<Notification[]> {
    return this.http.get<Notification[]>(this.notifUrl, { params: { userEmail: email } }).pipe(
      tap((list) => {
        this.notifications.set(list);
        this.unreadCount.set(list.filter(n => !n.read).length);
      })
    );
  }

  markRead(notificationId: number): Observable<Notification> {
    return this.http.put<Notification>(`${this.notifUrl}/${notificationId}/read`, {});
  }

  delete(notificationId: number): Observable<void> {
    return this.http.delete<void>(`${this.notifUrl}/${notificationId}`);
  }

  // ---- Support / service requests ----
  getRequestContext(appId: number): Observable<unknown> {
    return this.http.get(`${this.requestUrl}/application/${appId}/context`);
  }

  createRequest(payload: Partial<ServiceRequest>): Observable<ServiceRequest> {
    return this.http.post<ServiceRequest>(this.requestUrl, payload);
  }

  updateRequest(payload: Partial<ServiceRequest>): Observable<ServiceRequest> {
    return this.http.put<ServiceRequest>(this.requestUrl, payload);
  }

  getRequestsForUser(email: string): Observable<ServiceRequest[]> {
    return this.http.get<ServiceRequest[]>(`${this.requestUrl}/user/${email}`);
  }

  getRequestsForApp(appId: number): Observable<ServiceRequest[]> {
    return this.http.get<ServiceRequest[]>(`${this.requestUrl}/application/${appId}`);
  }
}
