import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { EmiInstallment, Disbursement, InsurancePolicy } from '../models/repayment.model';
import { AuctionCase, Bid } from '../models/auction.model';

@Injectable({ providedIn: 'root' })
export class RepaymentService {
  private readonly emi = `${environment.apiBaseUrl}/emi`;
  private readonly disbursements = `${environment.apiBaseUrl}/disbursements`;
  private readonly insurance = `${environment.apiBaseUrl}/insurance-policies`;
  private readonly auctions = `${environment.apiBaseUrl}/auctions`;
  private readonly auctionNotes = `${environment.apiBaseUrl}/auction-notes`;
  private readonly bids = `${environment.apiBaseUrl}/bids`;
  private readonly defaultMgmt = `${environment.apiBaseUrl}/default-management`;

  constructor(private http: HttpClient) {}

  // ---- EMI ----
  getSchedule(appId: number): Observable<EmiInstallment[]> {
    return this.http.get<EmiInstallment[]>(`${this.emi}/${appId}/schedule`);
  }

  getInstallments(): Observable<EmiInstallment[]> {
    return this.http.get<EmiInstallment[]>(`${this.emi}/installments`);
  }

  getInstallment(id: number): Observable<EmiInstallment> {
    return this.http.get<EmiInstallment>(`${this.emi}/installments/${id}`);
  }

  createInstallment(payload: Partial<EmiInstallment>): Observable<EmiInstallment> {
    return this.http.post<EmiInstallment>(`${this.emi}/installments`, payload);
  }

  updateInstallment(id: number, payload: Partial<EmiInstallment>): Observable<EmiInstallment> {
    return this.http.put<EmiInstallment>(`${this.emi}/installments/${id}`, payload);
  }

  // ---- Disbursements ----
  getDisbursementsForApp(appId: number): Observable<Disbursement[]> {
    return this.http.get<Disbursement[]>(`${this.disbursements}/by-application/${appId}`);
  }

  getAllDisbursements(): Observable<Disbursement[]> {
    return this.http.get<Disbursement[]>(this.disbursements);
  }

  createDisbursement(payload: Partial<Disbursement>): Observable<Disbursement> {
    return this.http.post<Disbursement>(this.disbursements, payload);
  }

  // ---- Insurance ----
  getInsurancePolicies(): Observable<InsurancePolicy[]> {
    return this.http.get<InsurancePolicy[]>(this.insurance);
  }

  createInsurancePolicy(payload: Partial<InsurancePolicy>): Observable<InsurancePolicy> {
    return this.http.post<InsurancePolicy>(this.insurance, payload);
  }

  // ---- Auctions & bids ----
  getAuctions(): Observable<AuctionCase[]> {
    return this.http.get<AuctionCase[]>(this.auctions);
  }

  getAuctionsForApp(appId: number): Observable<AuctionCase[]> {
    return this.http.get<AuctionCase[]>(`${this.auctions}/by-application/${appId}`);
  }

  getAuction(auctionId: number): Observable<AuctionCase> {
    return this.http.get<AuctionCase>(`${this.auctions}/${auctionId}`);
  }

  createAuction(payload: Partial<AuctionCase>): Observable<AuctionCase> {
    return this.http.post<AuctionCase>(this.auctions, payload);
  }

  placeBid(appId: number, payload: Partial<Bid>): Observable<Bid> {
    return this.http.post<Bid>(`${this.auctions}/${appId}/bids`, payload);
  }

  getBidsForApp(appId: number): Observable<Bid[]> {
    return this.http.get<Bid[]>(`${this.auctions}/${appId}/bids`);
  }

  getMyBids(bidderEmail: string): Observable<Bid[]> {
    return this.http.get<Bid[]>(this.bids, { params: { bidderEmail } });
  }

  // ---- Default management ----
  getDefaultStatus(appId: number): Observable<unknown> {
    return this.http.get(`${this.defaultMgmt}/status/${appId}`);
  }

  getEscalation(appId: number): Observable<unknown> {
    return this.http.get(`${this.defaultMgmt}/escalation/${appId}`);
  }

  getOverdue(): Observable<unknown[]> {
    return this.http.get<unknown[]>(`${this.defaultMgmt}/overdue`);
  }
}
