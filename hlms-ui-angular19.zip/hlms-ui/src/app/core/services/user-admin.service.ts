import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AppUser } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class UserAdminService {
  private readonly baseUrl = `${environment.apiBaseUrl}/users`;
  private readonly profileUrl = `${environment.apiBaseUrl}/customer-profile`;
  private readonly rolesUrl = `${environment.apiBaseUrl}/role-permissions`;

  constructor(private http: HttpClient) {}

  getUser(email: string): Observable<AppUser> {
    return this.http.get<AppUser>(`${this.baseUrl}/${email}`);
  }

  updateUser(email: string, payload: Partial<AppUser>): Observable<AppUser> {
    return this.http.put<AppUser>(`${this.baseUrl}/${email}`, payload);
  }

  deleteUser(email: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${email}`);
  }

  // ---- Customer employment profile ----
  createEmploymentProfile(payload: unknown): Observable<unknown> {
    return this.http.post(this.profileUrl, payload);
  }

  getEmploymentProfile(email: string): Observable<unknown> {
    return this.http.get(`${this.profileUrl}/${email}`);
  }

  getAllEmploymentProfiles(): Observable<unknown[]> {
    return this.http.get<unknown[]>(`${this.profileUrl}/all`);
  }

  updateEmploymentProfile(email: string, payload: unknown): Observable<unknown> {
    return this.http.put(`${this.profileUrl}/${email}`, payload);
  }

  // ---- Role permissions ----
  getRolePermissions(): Observable<unknown[]> {
    return this.http.get<unknown[]>(this.rolesUrl);
  }

  createRolePermission(payload: unknown): Observable<unknown> {
    return this.http.post(this.rolesUrl, payload);
  }

  updateRolePermission(id: number, payload: unknown): Observable<unknown> {
    return this.http.put(`${this.rolesUrl}/${id}`, payload);
  }

  deleteRolePermission(id: number): Observable<void> {
    return this.http.delete<void>(`${this.rolesUrl}/${id}`);
  }
}
