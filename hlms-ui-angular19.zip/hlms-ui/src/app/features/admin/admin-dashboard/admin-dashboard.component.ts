import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoanService } from '../../../core/services/loan.service';
import { LoanApplication } from '../../../core/models/loan-application.model';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-dashboard.component.html'
})
export class AdminDashboardComponent implements OnInit {
  private loanService = inject(LoanService);

  applications = signal<LoanApplication[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    this.loanService.getAllApplications().subscribe({
      next: (apps) => { this.applications.set(apps); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  countByStatus(status: string): number {
    return this.applications().filter(a => a.status === status).length;
  }
}
