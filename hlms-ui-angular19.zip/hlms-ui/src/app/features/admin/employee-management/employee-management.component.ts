import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { UserAdminService } from '../../../core/services/user-admin.service';
import { ToastService } from '../../../core/services/toast.service';
import { UserRole } from '../../../core/models/user.model';

@Component({
  selector: 'app-employee-management',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './employee-management.component.html'
})
export class EmployeeManagementComponent {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private userAdmin = inject(UserAdminService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);

  roleFilter = (this.route.snapshot.data['roleFilter'] as UserRole) ?? 'employee';
  creating = signal(false);

  get title(): string {
    const labels: Record<string, string> = { legal: 'Legal Team', bankoffice: 'Bank Office', employee: 'Employee' };
    return `${labels[this.roleFilter] ?? 'Employee'} Management`;
  }

  form = this.fb.nonNullable.group({
    fullName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
    password: ['', [Validators.required, Validators.minLength(8)]]
  });

  createStaffAccount() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.creating.set(true);
    this.auth.register({ ...this.form.getRawValue(), role: this.roleFilter }).subscribe({
      next: () => {
        this.creating.set(false);
        this.form.reset();
        this.toast.show('Account created', `New ${this.roleFilter} account has been created.`, 'success');
      },
      error: () => this.creating.set(false)
    });
  }
}
