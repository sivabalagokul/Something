import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserAdminService } from '../../../core/services/user-admin.service';
import { ToastService } from '../../../core/services/toast.service';

interface RolePermission {
  id?: number;
  role: string;
  permission: string;
  [key: string]: unknown;
}

@Component({
  selector: 'app-role-permissions',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './role-permissions.component.html'
})
export class RolePermissionsComponent implements OnInit {
  private userAdmin = inject(UserAdminService);
  private toast = inject(ToastService);

  permissions = signal<RolePermission[]>([]);
  loading = signal(true);

  newRole = 'employee';
  newPermission = '';

  ngOnInit(): void {
    this.refresh();
  }

  refresh() {
    this.loading.set(true);
    this.userAdmin.getRolePermissions().subscribe({
      next: (list) => { this.permissions.set(list as RolePermission[]); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  add() {
    if (!this.newPermission.trim()) return;
    this.userAdmin.createRolePermission({ role: this.newRole, permission: this.newPermission }).subscribe({
      next: () => {
        this.newPermission = '';
        this.toast.show('Permission added', 'Role permission created.', 'success');
        this.refresh();
      }
    });
  }

  remove(id?: number) {
    if (!id) return;
    this.userAdmin.deleteRolePermission(id).subscribe({
      next: () => {
        this.toast.show('Removed', 'Role permission deleted.', 'success');
        this.refresh();
      }
    });
  }
}
