import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { UserAdminService } from '../../../core/services/user-admin.service';
import { ToastService } from '../../../core/services/toast.service';
import { AppUser } from '../../../core/models/user.model';

@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user-management.component.html'
})
export class UserManagementComponent {
  private userAdmin = inject(UserAdminService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);

  roleFilter = (this.route.snapshot.data['roleFilter'] as string) ?? 'customer';
  searchEmail = '';
  loading = signal(false);
  user = signal<AppUser | null>(null);

  get title(): string {
    return this.roleFilter === 'bidder' ? 'Bidder Management' : 'Customer Management';
  }

  search() {
    if (!this.searchEmail.trim()) return;
    this.loading.set(true);
    this.userAdmin.getUser(this.searchEmail.trim()).subscribe({
      next: (u) => { this.user.set(u); this.loading.set(false); },
      error: () => { this.user.set(null); this.loading.set(false); }
    });
  }

  toggleActive() {
    const u = this.user();
    if (!u) return;
    this.userAdmin.updateUser(u.email, { active: !u.active }).subscribe({
      next: (updated) => {
        this.user.set(updated);
        this.toast.show('Updated', `Account ${updated.active ? 'activated' : 'deactivated'}.`, 'success');
      }
    });
  }

  deleteUser() {
    const u = this.user();
    if (!u) return;
    this.userAdmin.deleteUser(u.email).subscribe({
      next: () => {
        this.toast.show('Deleted', 'User account removed.', 'success');
        this.user.set(null);
        this.searchEmail = '';
      }
    });
  }
}
