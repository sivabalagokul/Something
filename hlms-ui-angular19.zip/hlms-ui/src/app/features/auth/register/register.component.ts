import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

function passwordsMatch(control: AbstractControl): ValidationErrors | null {
  const pass = control.get('password')?.value;
  const confirm = control.get('confirmPassword')?.value;
  return pass && confirm && pass !== confirm ? { mismatch: true } : null;
}

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './register.component.html'
})
export class RegisterComponent {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private toast = inject(ToastService);
  private router = inject(Router);

  loading = signal(false);
  policyAccepted = signal(false);

  form = this.fb.nonNullable.group({
    role: ['customer', Validators.required],
    fullName: ['', Validators.required],
    phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]],
    confirmPassword: ['', Validators.required]
  }, { validators: passwordsMatch });

  acceptPolicy() {
    this.policyAccepted.set(true);
  }

  submit() {
    if (this.form.invalid || !this.policyAccepted()) {
      this.form.markAllAsTouched();
      if (!this.policyAccepted()) {
        this.toast.show('Privacy Policy', 'Please accept the privacy policy to continue.', 'error');
      }
      return;
    }
    this.loading.set(true);
    const { role, fullName, phone, email, password } = this.form.getRawValue();
    this.auth.register({ fullName, email, phone, password, role: role as any }).subscribe({
      next: () => {
        this.loading.set(false);
        this.toast.show('Account created', 'You can now log in with your credentials.', 'success');
        this.router.navigate(['/auth/login']);
      },
      error: () => this.loading.set(false)
    });
  }
}
