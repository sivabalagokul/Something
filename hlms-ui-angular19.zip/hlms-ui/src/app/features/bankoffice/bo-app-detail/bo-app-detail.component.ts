import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { LoanService } from '../../../core/services/loan.service';
import { LegalService } from '../../../core/services/legal.service';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoanApplication } from '../../../core/models/loan-application.model';
import { BankOfficeDecision } from '../../../core/models/legal.model';

@Component({
  selector: 'app-bo-app-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bo-app-detail.component.html'
})
export class BoAppDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private loanService = inject(LoanService);
  private legalService = inject(LegalService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);

  appId = Number(this.route.snapshot.paramMap.get('appId'));
  application = signal<LoanApplication | null>(null);
  decisions = signal<BankOfficeDecision[]>([]);
  loading = signal(true);

  decisionValue: BankOfficeDecision['decision'] = 'Approved';
  remarks = '';

  ngOnInit(): void {
    this.loanService.getApplication(this.appId).subscribe({
      next: (app) => { this.application.set(app); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
    this.refreshDecisions();
  }

  refreshDecisions() {
    this.legalService.getDecisionsForApp(this.appId).subscribe({
      next: (list) => this.decisions.set(list)
    });
  }

  recordDecision() {
    this.legalService.createDecision({
      appId: this.appId,
      decision: this.decisionValue,
      decidedBy: this.auth.currentUser()?.email,
      remarks: this.remarks,
      decidedAt: new Date().toISOString()
    }).subscribe({
      next: () => {
        this.toast.show('Decision recorded', 'Bank office decision has been logged.', 'success');
        this.remarks = '';
        this.refreshDecisions();
      }
    });
  }

  advanceStage(stage: string) {
    this.loanService.advanceStage(this.appId, stage).subscribe({
      next: (updated) => {
        this.application.set(updated);
        this.toast.show('Stage updated', `Application moved to "${stage}".`, 'success');
      }
    });
  }
}
