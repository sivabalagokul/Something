import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { LoanService } from '../../../core/services/loan.service';
import { LoanApplication } from '../../../core/models/loan-application.model';

@Component({
  selector: 'app-bo-applications',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-applications.component.html'
})
export class BoApplicationsComponent implements OnInit {
  private loanService = inject(LoanService);
  private router = inject(Router);

  applications = signal<LoanApplication[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    this.loanService.getAllApplications().subscribe({
      next: (apps) => { this.applications.set(apps); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  open(appId?: number) {
    if (appId) this.router.navigate(['/app/boappdetail', appId]);
  }
}
