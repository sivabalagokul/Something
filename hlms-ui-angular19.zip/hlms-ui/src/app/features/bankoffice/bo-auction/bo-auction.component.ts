import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RepaymentService } from '../../../core/services/repayment.service';
import { AuctionCase } from '../../../core/models/auction.model';

@Component({
  selector: 'app-bo-auction',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-auction.component.html'
})
export class BoAuctionComponent implements OnInit {
  private repaymentService = inject(RepaymentService);

  auctions = signal<AuctionCase[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    this.repaymentService.getAuctions().subscribe({
      next: (list) => { this.auctions.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
}
