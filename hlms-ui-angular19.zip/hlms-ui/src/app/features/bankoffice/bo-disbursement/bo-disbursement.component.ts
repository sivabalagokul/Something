import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RepaymentService } from '../../../core/services/repayment.service';
import { ToastService } from '../../../core/services/toast.service';
import { Disbursement } from '../../../core/models/repayment.model';

@Component({
  selector: 'app-bo-disbursement',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bo-disbursement.component.html'
})
export class BoDisbursementComponent implements OnInit {
  private repaymentService = inject(RepaymentService);
  private toast = inject(ToastService);

  disbursements = signal<Disbursement[]>([]);
  loading = signal(true);

  newAppId: number | null = null;
  newAmount: number | null = null;
  newStage = 'Full Disbursement';

  ngOnInit(): void {
    this.refresh();
  }

  refresh() {
    this.repaymentService.getAllDisbursements().subscribe({
      next: (list) => { this.disbursements.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  create() {
    if (!this.newAppId || !this.newAmount) {
      this.toast.show('Missing details', 'Please enter application ID and amount.', 'error');
      return;
    }
    this.repaymentService.createDisbursement({
      appId: this.newAppId,
      amount: this.newAmount,
      disbursementDate: new Date().toISOString(),
      installmentStage: this.newStage
    }).subscribe({
      next: () => {
        this.toast.show('Disbursement recorded', 'Funds disbursement has been logged.', 'success');
        this.newAppId = null;
        this.newAmount = null;
        this.refresh();
      }
    });
  }
}
