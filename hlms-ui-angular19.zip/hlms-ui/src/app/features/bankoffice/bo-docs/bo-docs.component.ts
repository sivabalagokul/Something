import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocumentService } from '../../../core/services/document.service';
import { ApplicationDocument } from '../../../core/models/document.model';

@Component({
  selector: 'app-bo-docs',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-docs.component.html'
})
export class BoDocsComponent implements OnInit {
  private documentService = inject(DocumentService);

  documents = signal<ApplicationDocument[]>([]);
  loading = signal(true);
  pendingOnly = signal(true);

  ngOnInit(): void {
    this.documentService.getAllDocuments().subscribe({
      next: (docs) => { this.documents.set(docs); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  filtered(): ApplicationDocument[] {
    return this.pendingOnly() ? this.documents().filter(d => d.status === 'Pending') : this.documents();
  }
}
