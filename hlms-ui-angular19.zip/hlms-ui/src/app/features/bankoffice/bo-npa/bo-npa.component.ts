import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RepaymentService } from '../../../core/services/repayment.service';

@Component({
  selector: 'app-bo-npa',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-npa.component.html'
})
export class BoNpaComponent implements OnInit {
  private repaymentService = inject(RepaymentService);

  overdue = signal<any[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    this.repaymentService.getOverdue().subscribe({
      next: (list) => { this.overdue.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
}
