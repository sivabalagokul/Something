import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoanService } from '../../../core/services/loan.service';

@Component({
  selector: 'app-bo-reports',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-reports.component.html'
})
export class BoReportsComponent implements OnInit {
  private loanService = inject(LoanService);

  turnaroundReport = signal<unknown>(null);
  loading = signal(true);

  ngOnInit(): void {
    this.loanService.getTurnaroundReport().subscribe({
      next: (report) => { this.turnaroundReport.set(report); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
}
