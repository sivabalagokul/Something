import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { RepaymentService } from '../../../core/services/repayment.service';
import { Bid } from '../../../core/models/auction.model';

@Component({
  selector: 'app-bidder-bids',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bidder-bids.component.html'
})
export class BidderBidsComponent implements OnInit {
  private auth = inject(AuthService);
  private repaymentService = inject(RepaymentService);

  bids = signal<Bid[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) { this.loading.set(false); return; }
    this.repaymentService.getMyBids(email).subscribe({
      next: (list) => { this.bids.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
}
