import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { RepaymentService } from '../../../core/services/repayment.service';
import { AuctionCase, Bid } from '../../../core/models/auction.model';

@Component({
  selector: 'app-bidder-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bidder-dashboard.component.html'
})
export class BidderDashboardComponent implements OnInit {
  private auth = inject(AuthService);
  private repaymentService = inject(RepaymentService);

  auctions = signal<AuctionCase[]>([]);
  myBids = signal<Bid[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    this.repaymentService.getAuctions().subscribe({
      next: (list) => { this.auctions.set(list.filter(a => a.stage === 'Scheduled' || a.stage === 'In Progress')); },
      error: () => {}
    });
    const email = this.auth.currentUser()?.email;
    if (email) {
      this.repaymentService.getMyBids(email).subscribe({
        next: (bids) => { this.myBids.set(bids); this.loading.set(false); },
        error: () => this.loading.set(false)
      });
    } else {
      this.loading.set(false);
    }
  }

  highestBid(): number {
    return this.myBids().reduce((max, b) => Math.max(max, b.amount || 0), 0);
  }
}
