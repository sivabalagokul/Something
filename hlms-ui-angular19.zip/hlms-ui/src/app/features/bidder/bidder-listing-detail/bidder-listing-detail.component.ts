import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { RepaymentService } from '../../../core/services/repayment.service';
import { ToastService } from '../../../core/services/toast.service';
import { AuctionCase, Bid } from '../../../core/models/auction.model';

@Component({
  selector: 'app-bidder-listing-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bidder-listing-detail.component.html'
})
export class BidderListingDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private auth = inject(AuthService);
  private repaymentService = inject(RepaymentService);
  private toast = inject(ToastService);

  auctionId = Number(this.route.snapshot.paramMap.get('auctionId'));
  auction = signal<AuctionCase | null>(null);
  bids = signal<Bid[]>([]);
  loading = signal(true);
  bidAmount: number | null = null;

  ngOnInit(): void {
    this.repaymentService.getAuction(this.auctionId).subscribe({
      next: (a) => { this.auction.set(a); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
    this.refreshBids();
  }

  refreshBids() {
    const app = this.auction()?.appId;
    if (app) {
      this.repaymentService.getBidsForApp(app).subscribe(bids => this.bids.set(bids));
    }
  }

  placeBid() {
    const email = this.auth.currentUser()?.email;
    const appId = this.auction()?.appId;
    if (!email || !appId || !this.bidAmount) {
      this.toast.show('Missing details', 'Please enter a bid amount.', 'error');
      return;
    }
    this.repaymentService.placeBid(appId, { bidderEmail: email, amount: this.bidAmount }).subscribe({
      next: () => {
        this.toast.show('Bid placed', 'Your bid has been submitted.', 'success');
        this.bidAmount = null;
        this.refreshBids();
      }
    });
  }
}
