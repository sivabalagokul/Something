import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { LoanService } from '../../../core/services/loan.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-apply',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './apply.component.html'
})
export class ApplyComponent {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private loanService = inject(LoanService);
  private toast = inject(ToastService);
  private router = inject(Router);

  saving = signal(false);
  submitting = signal(false);
  draftAppId = signal<number | null>(null);

  form = this.fb.nonNullable.group({
    loanAmount: [3500000, [Validators.required, Validators.min(1)]],
    tenureYears: [20, [Validators.required, Validators.min(1), Validators.max(30)]],
    monthlyIncome: [75000, [Validators.required, Validators.min(1)]],
    otherEMIs: [0, [Validators.required, Validators.min(0)]],
    propertyAddress: ['', Validators.required],
    propertyValue: [4000000, [Validators.required, Validators.min(1)]]
  });

  saveDraft() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving.set(true);
    const email = this.auth.currentUser()?.email!;
    this.loanService.saveDraft({ ...this.form.getRawValue(), applicantEmail: email }).subscribe({
      next: (app) => {
        this.saving.set(false);
        this.draftAppId.set(app.appId ?? null);
        this.toast.show('Draft saved', 'Your application draft has been saved.', 'success');
      },
      error: () => this.saving.set(false)
    });
  }

  submit() {
    const appId = this.draftAppId();
    if (!appId) {
      this.toast.show('Save draft first', 'Please save your application as a draft before submitting.', 'error');
      return;
    }
    this.submitting.set(true);
    this.loanService.submitApplication(appId).subscribe({
      next: () => {
        this.submitting.set(false);
        this.toast.show('Application submitted', 'Your loan application has been submitted successfully.', 'success');
        this.router.navigate(['/app/tracking']);
      },
      error: () => this.submitting.set(false)
    });
  }
}
