import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { LoanService } from '../../../core/services/loan.service';
import { LoanApplication } from '../../../core/models/loan-application.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit {
  private auth = inject(AuthService);
  private loanService = inject(LoanService);

  applications = signal<LoanApplication[]>([]);
  loading = signal(true);

  get user() {
    return this.auth.currentUser();
  }

  get activeApplication(): LoanApplication | undefined {
    return this.applications().find(a => a.status !== 'Draft' && a.status !== 'Closed');
  }

  approvedCount(): number {
    return this.applications().filter(a => a.status === 'Approved' || a.status === 'Disbursed').length;
  }

  ngOnInit(): void {
    const email = this.user?.email;
    if (!email) return;
    this.loanService.getMyApplications(email).subscribe({
      next: (apps) => { this.applications.set(apps); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
}
