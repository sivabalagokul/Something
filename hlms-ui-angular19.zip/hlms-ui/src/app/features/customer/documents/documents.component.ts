import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { LoanService } from '../../../core/services/loan.service';
import { DocumentService } from '../../../core/services/document.service';
import { ApplicationDocument } from '../../../core/models/document.model';

const DOC_TYPES = ['PAN Card', 'Aadhaar Card', 'Salary Slips (3 months)', 'Bank Statement (6 months)', 'Property Documents', 'Photograph'];

@Component({
  selector: 'app-documents',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './documents.component.html'
})
export class DocumentsComponent implements OnInit {
  private auth = inject(AuthService);
  private loanService = inject(LoanService);
  private documentService = inject(DocumentService);

  docTypes = DOC_TYPES;
  appId = signal<number | null>(null);
  documents = signal<ApplicationDocument[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.loanService.getMyApplications(email).subscribe({
      next: (apps) => {
        const active = apps.find(a => a.status !== 'Draft' && a.status !== 'Closed');
        if (active?.appId) {
          this.appId.set(active.appId);
          this.refresh(active.appId);
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  refresh(appId: number) {
    this.documentService.getDocumentsForApp(appId).subscribe(docs => this.documents.set(docs));
  }

  statusFor(docType: string): string {
    return this.documents().find(d => d.docType === docType)?.status ?? 'Not Uploaded';
  }

  upload(docType: string) {
    const appId = this.appId();
    if (!appId) return;
    this.documentService.uploadDocument({ appId, docType, status: 'Pending' }).subscribe(() => this.refresh(appId));
  }
}
