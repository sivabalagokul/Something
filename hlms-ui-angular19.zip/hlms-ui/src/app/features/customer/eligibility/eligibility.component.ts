import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { LoanService } from '../../../core/services/loan.service';
import { EligibilityResult } from '../../../core/models/eligibility.model';

@Component({
  selector: 'app-eligibility',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './eligibility.component.html'
})
export class EligibilityComponent {
  private fb = inject(FormBuilder);
  private loanService = inject(LoanService);

  loading = signal(false);
  result = signal<EligibilityResult | null>(null);

  form = this.fb.nonNullable.group({
    monthlyIncome: [75000, [Validators.required, Validators.min(1)]],
    otherEMIs: [0, [Validators.required, Validators.min(0)]],
    loanAmount: [3500000, [Validators.required, Validators.min(1)]],
    tenureYears: [20, [Validators.required, Validators.min(1), Validators.max(30)]]
  });

  check() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.loading.set(true);
    this.loanService.assessEligibility(this.form.getRawValue()).subscribe({
      next: (res) => { this.result.set(res); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
}
