import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LoanService } from '../../../core/services/loan.service';

@Component({
  selector: 'app-guidance',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './guidance.component.html'
})
export class GuidanceComponent {
  private loanService = inject(LoanService);

  loading = signal(false);
  recommendations = signal<any>(null);

  loanAmount = 3500000;
  tenureYears = 20;
  monthlyIncome = 75000;

  emiQuestion = '';
  emiAnswer = signal<any>(null);
  emiLoading = signal(false);

  getRecommendations() {
    this.loading.set(true);
    this.loanService.getRecommendations({
      loanAmount: this.loanAmount,
      tenureYears: this.tenureYears,
      monthlyIncome: this.monthlyIncome
    }).subscribe({
      next: (res) => { this.recommendations.set(res); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  askEmiAssistant() {
    if (!this.emiQuestion.trim()) return;
    this.emiLoading.set(true);
    this.loanService.emiAssistant({ question: this.emiQuestion }).subscribe({
      next: (res) => { this.emiAnswer.set(res); this.emiLoading.set(false); },
      error: () => this.emiLoading.set(false)
    });
  }
}
