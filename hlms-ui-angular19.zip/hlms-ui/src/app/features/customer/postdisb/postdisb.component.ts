import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { LoanService } from '../../../core/services/loan.service';
import { DocumentService } from '../../../core/services/document.service';
import { RepaymentService } from '../../../core/services/repayment.service';
import { PostDisbursementDocument } from '../../../core/models/document.model';
import { Disbursement } from '../../../core/models/repayment.model';

const PD_DOC_TYPES = ['Property Insurance', 'Occupancy Certificate', 'Registered Sale Deed Copy', 'Latest Property Tax Receipt'];

@Component({
  selector: 'app-postdisb',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './postdisb.component.html'
})
export class PostdisbComponent implements OnInit {
  private auth = inject(AuthService);
  private loanService = inject(LoanService);
  private documentService = inject(DocumentService);
  private repaymentService = inject(RepaymentService);

  docTypes = PD_DOC_TYPES;
  appId = signal<number | null>(null);
  documents = signal<PostDisbursementDocument[]>([]);
  disbursements = signal<Disbursement[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.loanService.getMyApplications(email).subscribe({
      next: (apps) => {
        const active = apps.find(a => a.status === 'Disbursed');
        if (active?.appId) {
          this.appId.set(active.appId);
          this.documentService.getPostDisbDocumentsForApp(active.appId).subscribe(docs => this.documents.set(docs));
          this.repaymentService.getDisbursementsForApp(active.appId).subscribe(d => this.disbursements.set(d));
        }
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  statusFor(docType: string): string {
    return this.documents().find(d => d.docType === docType)?.status ?? 'Not Uploaded';
  }

  upload(docType: string) {
    const appId = this.appId();
    if (!appId) return;
    this.documentService.uploadPostDisbDocument({ appId, docType, status: 'Pending' }).subscribe(() => {
      this.documentService.getPostDisbDocumentsForApp(appId).subscribe(docs => this.documents.set(docs));
    });
  }
}
