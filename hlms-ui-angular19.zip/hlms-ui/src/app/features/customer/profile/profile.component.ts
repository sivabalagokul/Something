import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './profile.component.html'
})
export class ProfileComponent {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private toast = inject(ToastService);

  saving = signal(false);
  user = this.auth.currentUser();

  form = this.fb.nonNullable.group({
    fullName: [this.user?.fullName ?? '', Validators.required],
    phone: [this.user?.phone ?? '', Validators.required]
  });

  save() {
    if (this.form.invalid || !this.user) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving.set(true);
    this.auth.updateProfile(this.user.email, this.form.getRawValue()).subscribe({
      next: () => {
        this.saving.set(false);
        this.toast.show('Profile updated', 'Your changes have been saved.', 'success');
      },
      error: () => this.saving.set(false)
    });
  }
}
