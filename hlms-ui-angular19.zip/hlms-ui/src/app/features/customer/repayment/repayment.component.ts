import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { LoanService } from '../../../core/services/loan.service';
import { RepaymentService } from '../../../core/services/repayment.service';
import { EmiInstallment } from '../../../core/models/repayment.model';

@Component({
  selector: 'app-repayment',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './repayment.component.html'
})
export class RepaymentComponent implements OnInit {
  private auth = inject(AuthService);
  private loanService = inject(LoanService);
  private repaymentService = inject(RepaymentService);

  schedule = signal<EmiInstallment[]>([]);
  loading = signal(true);
  appId = signal<number | null>(null);

  ngOnInit(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.loanService.getMyApplications(email).subscribe({
      next: (apps) => {
        const active = apps.find(a => a.status === 'Disbursed' || a.status === 'Approved');
        if (active?.appId) {
          this.appId.set(active.appId);
          this.repaymentService.getSchedule(active.appId).subscribe({
            next: (sched) => { this.schedule.set(sched); this.loading.set(false); },
            error: () => this.loading.set(false)
          });
        } else {
          this.loading.set(false);
        }
      },
      error: () => this.loading.set(false)
    });
  }

  totalPaid(): number {
    return this.schedule().filter(i => i.status === 'Paid').reduce((sum, i) => sum + i.emiAmount, 0);
  }

  outstanding(): number {
    return this.schedule().filter(i => i.status !== 'Paid').reduce((sum, i) => sum + i.emiAmount, 0);
  }
}
