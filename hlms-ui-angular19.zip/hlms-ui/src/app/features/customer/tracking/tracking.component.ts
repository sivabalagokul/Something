import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { LoanService } from '../../../core/services/loan.service';
import { LoanApplication, WORKFLOW_STAGES } from '../../../core/models/loan-application.model';

@Component({
  selector: 'app-tracking',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './tracking.component.html'
})
export class TrackingComponent implements OnInit {
  private auth = inject(AuthService);
  private loanService = inject(LoanService);

  stages = WORKFLOW_STAGES;
  applications = signal<LoanApplication[]>([]);
  selected = signal<LoanApplication | null>(null);
  timeline = signal<unknown>(null);
  loading = signal(true);

  ngOnInit(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.loanService.getMyApplications(email).subscribe({
      next: (apps) => {
        this.applications.set(apps);
        this.loading.set(false);
        const first = apps.find(a => a.status !== 'Draft');
        if (first) this.select(first);
      },
      error: () => this.loading.set(false)
    });
  }

  select(app: LoanApplication) {
    this.selected.set(app);
    if (app.appId) {
      this.loanService.getTimeline(app.appId).subscribe({
        next: (t) => this.timeline.set(t),
        error: () => this.timeline.set(null)
      });
    }
  }

  stageIndex(): number {
    const stage = this.selected()?.stage;
    return stage ? this.stages.indexOf(stage) : -1;
  }
}
