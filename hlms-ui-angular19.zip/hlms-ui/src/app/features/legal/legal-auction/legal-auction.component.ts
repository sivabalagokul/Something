import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RepaymentService } from '../../../core/services/repayment.service';
import { ToastService } from '../../../core/services/toast.service';
import { AuctionCase } from '../../../core/models/auction.model';

@Component({
  selector: 'app-legal-auction',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './legal-auction.component.html'
})
export class LegalAuctionComponent implements OnInit {
  private repaymentService = inject(RepaymentService);
  private toast = inject(ToastService);

  auctions = signal<AuctionCase[]>([]);
  loading = signal(true);

  newAppId: number | null = null;
  newPropertyAddress = '';
  newReservePrice: number | null = null;
  newAuctionDate = '';

  ngOnInit(): void {
    this.refresh();
  }

  refresh() {
    this.repaymentService.getAuctions().subscribe({
      next: (list) => { this.auctions.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  createAuction() {
    if (!this.newAppId || !this.newPropertyAddress || !this.newReservePrice || !this.newAuctionDate) {
      this.toast.show('Missing details', 'Please fill in all auction case fields.', 'error');
      return;
    }
    this.repaymentService.createAuction({
      appId: this.newAppId,
      propertyAddress: this.newPropertyAddress,
      reservePrice: this.newReservePrice,
      auctionDate: this.newAuctionDate,
      stage: 'Notice Issued'
    }).subscribe({
      next: () => {
        this.toast.show('Auction case created', 'SARFAESI auction case has been logged.', 'success');
        this.newAppId = null;
        this.newPropertyAddress = '';
        this.newReservePrice = null;
        this.newAuctionDate = '';
        this.refresh();
      }
    });
  }
}
