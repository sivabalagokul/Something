import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { LegalService } from '../../../core/services/legal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LegalVerification, LegalChecklistItem } from '../../../core/models/legal.model';

@Component({
  selector: 'app-legal-case-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './legal-case-detail.component.html'
})
export class LegalCaseDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private legalService = inject(LegalService);
  private toast = inject(ToastService);

  appId = Number(this.route.snapshot.paramMap.get('appId'));
  context = signal<unknown>(null);
  verifications = signal<LegalVerification[]>([]);
  loading = signal(true);

  remarks = '';
  status: LegalVerification['status'] = 'In Progress';

  ngOnInit(): void {
    this.legalService.getVerificationContext(this.appId).subscribe({
      next: (ctx) => this.context.set(ctx),
      error: () => {}
    });
    this.refresh();
  }

  refresh() {
    this.legalService.getVerificationsForApp(this.appId).subscribe({
      next: (list) => { this.verifications.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  submitVerification() {
    this.legalService.createVerification({ appId: this.appId, status: this.status, remarks: this.remarks }).subscribe({
      next: () => {
        this.toast.show('Verification recorded', 'Your legal verification has been logged.', 'success');
        this.remarks = '';
        this.refresh();
      }
    });
  }
}
