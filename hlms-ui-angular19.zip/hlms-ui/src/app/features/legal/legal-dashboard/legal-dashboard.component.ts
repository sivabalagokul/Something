import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LegalService } from '../../../core/services/legal.service';
import { LegalVerification } from '../../../core/models/legal.model';

@Component({
  selector: 'app-legal-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './legal-dashboard.component.html'
})
export class LegalDashboardComponent implements OnInit {
  private legalService = inject(LegalService);

  verifications = signal<LegalVerification[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    this.legalService.getAllVerifications().subscribe({
      next: (list) => { this.verifications.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  countByStatus(status: string): number {
    return this.verifications().filter(v => v.status === status).length;
  }
}
