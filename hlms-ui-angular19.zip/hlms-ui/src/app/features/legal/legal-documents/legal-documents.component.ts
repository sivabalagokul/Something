import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocumentService } from '../../../core/services/document.service';
import { ApplicationDocument, PostDisbursementDocument } from '../../../core/models/document.model';

@Component({
  selector: 'app-legal-documents',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './legal-documents.component.html'
})
export class LegalDocumentsComponent implements OnInit {
  private documentService = inject(DocumentService);

  appDocuments = signal<ApplicationDocument[]>([]);
  postDisbDocuments = signal<PostDisbursementDocument[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    this.documentService.getAllDocuments().subscribe({
      next: (docs) => this.appDocuments.set(docs),
      error: () => {}
    });
    this.documentService.getAllPostDisbDocuments().subscribe({
      next: (docs) => { this.postDisbDocuments.set(docs); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
}
