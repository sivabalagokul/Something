import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LegalService } from '../../../core/services/legal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LegalNotice } from '../../../core/models/legal.model';

@Component({
  selector: 'app-legal-notices',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './legal-notices.component.html'
})
export class LegalNoticesComponent implements OnInit {
  private legalService = inject(LegalService);
  private toast = inject(ToastService);

  notices = signal<LegalNotice[]>([]);
  loading = signal(true);

  newAppId: number | null = null;
  newNoticeType = 'Demand Notice';
  newDescription = '';

  ngOnInit(): void {
    this.refresh();
  }

  refresh() {
    this.legalService.getNotices().subscribe({
      next: (list) => { this.notices.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  issueNotice() {
    if (!this.newAppId) {
      this.toast.show('Missing App ID', 'Please enter an application ID.', 'error');
      return;
    }
    this.legalService.createNotice({
      appId: this.newAppId,
      noticeType: this.newNoticeType,
      issuedDate: new Date().toISOString(),
      description: this.newDescription
    }).subscribe({
      next: () => {
        this.toast.show('Notice issued', 'Legal notice has been logged.', 'success');
        this.newAppId = null;
        this.newDescription = '';
        this.refresh();
      }
    });
  }
}
