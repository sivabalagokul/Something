import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { LegalService } from '../../../core/services/legal.service';
import { LegalVerification } from '../../../core/models/legal.model';

@Component({
  selector: 'app-legal-queue',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './legal-queue.component.html'
})
export class LegalQueueComponent implements OnInit {
  private legalService = inject(LegalService);
  private router = inject(Router);

  verifications = signal<LegalVerification[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    this.legalService.getAllVerifications().subscribe({
      next: (list) => {
        this.verifications.set(list.filter(v => v.status === 'Pending' || v.status === 'In Progress'));
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  open(appId: number) {
    this.router.navigate(['/app/legalcasedetail', appId]);
  }
}
