import { UserRole } from '../../core/models/user.model';

export interface NavItem {
  view: string;      // route segment under /app/
  icon: string;
  label: string;
}

export function sidebarItemsFor(role: UserRole | null): NavItem[] {
  switch (role) {
    case 'admin':
      return [
        { view: 'admindash', icon: '▦', label: 'Dashboard' },
        { view: 'biddermgmt', icon: '🔨', label: 'Bidder Management' },
        { view: 'employeemgmt', icon: '🧑‍💼', label: 'Employee Management' },
        { view: 'roles', icon: '☰', label: 'Roles & Permissions' },
        { view: 'profile', icon: '◍', label: 'Profile' }
      ];
    case 'legal':
      return [
        { view: 'legaldash', icon: '▦', label: 'Dashboard' },
        { view: 'legalqueue', icon: '☑', label: 'Legal Review Queue' },
        { view: 'legaldocuments', icon: '▯', label: 'Document Center' },
        { view: 'legalauction', icon: '☆', label: 'Auction & SARFAESI' },
        { view: 'legalnotices', icon: '✉', label: 'Legal Notices Log' },
        { view: 'profile', icon: '◍', label: 'Profile Settings' }
      ];
    case 'bankoffice':
      return [
        { view: 'bodash', icon: '▦', label: 'Dashboard' },
        { view: 'boapplications', icon: '▤', label: 'Loan Applications' },
        { view: 'boportfolio', icon: '👥', label: 'Customer Portfolio' },
        { view: 'bodisbursement', icon: '💳', label: 'Disbursement Queue' },
        { view: 'bonpa', icon: '⚠', label: 'Overdue & NPA Tracking' },
        { view: 'bodocs', icon: '▯', label: 'Document Verification' },
        { view: 'boauction', icon: '☆', label: 'Auction Management' },
        { view: 'boreports', icon: '📊', label: 'Reports & Analytics' },
        { view: 'bosettings', icon: '⚙', label: 'Settings' }
      ];
    case 'bidder':
      return [
        { view: 'bidderdash', icon: '▦', label: 'Dashboard' },
        { view: 'bidderlistings', icon: '☆', label: 'Auction Listings' },
        { view: 'bidderbids', icon: '💰', label: 'My Bids' },
        { view: 'biddersettings', icon: '⚙', label: 'Settings' }
      ];
    default: // customer
      return [
        { view: 'dashboard', icon: '▦', label: 'Dashboard' },
        { view: 'eligibility', icon: '☑', label: 'Check Eligibility' },
        { view: 'guidance', icon: '◷', label: 'Loan Guidance' },
        { view: 'apply', icon: '▤', label: 'Apply for Loan' },
        { view: 'tracking', icon: '↗', label: 'Loan Status Tracking' },
        { view: 'repayment', icon: 'Ⓡ', label: 'Repayment' },
        { view: 'postdisb', icon: '⌂', label: 'Post Disbursement' },
        { view: 'auction', icon: '☆', label: 'Auction Management' },
        { view: 'documents', icon: '▯', label: 'Documents' },
        { view: 'profile', icon: '◍', label: 'Profile Settings' },
        { view: 'support', icon: '?', label: 'Support / Help' }
      ];
  }
}
