export const environment = {
  production: false,
  // API Gateway base URL (see hlms-microservices/api-gateway application.yml)
  apiBaseUrl: 'http://localhost:8080/api'
};
