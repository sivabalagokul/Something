import re, os

SRC = "/home/claude/work/hlms2/daoimpl"
OUT = "/home/claude/hlms-tests/src/test/java/hlms/daoimpl"

# entity class -> (id_param_list) parsed per-file from delete() signature
files = sorted(f for f in os.listdir(SRC) if f.endswith("DAOImpl.java"))

TEMPLATE_STANDARD = '''package hlms.daoimpl;

import hlms.entity.{entity};
import hlms.util.DAOException;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {clazz}.
 *
 * DBConnection.getConnection() is intercepted via a static mock (see
 * {{@link JdbcDaoTestBase}}) so every test runs against mocked
 * Connection/PreparedStatement/ResultSet objects instead of a real
 * PostgreSQL database.
 */
class {clazz}Test extends JdbcDaoTestBase {{

    private final {clazz} dao = new {clazz}();

    // ---------------------------------------------------------------
    // insert
    // ---------------------------------------------------------------

    @Test
    void insert_success_returnsSameEntity() throws Exception {{
        {entity} entity = new {entity}();

        {entity} result = dao.insert(entity);

        assertSame(entity, result);
        verify(preparedStatement, times(1)).executeUpdate();
    }}

    @Test
    void insert_sqlException_wrappedAsDAOException() throws Exception {{
        {entity} entity = new {entity}();
        when(preparedStatement.executeUpdate()).thenThrow(new SQLException("insert failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.insert(entity));
        assertTrue(ex.getMessage().contains("Failed to insert {entity}"));
        assertTrue(ex.getCause() instanceof SQLException);
    }}

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_success_returnsSameEntity() throws Exception {{
        {entity} entity = new {entity}();
        when(preparedStatement.executeUpdate()).thenReturn(1);

        {entity} result = dao.update(entity);

        assertSame(entity, result);
    }}

    @Test
    void update_zeroRowsAffected_throwsDAOException() throws Exception {{
        {entity} entity = new {entity}();
        when(preparedStatement.executeUpdate()).thenReturn(0);

        DAOException ex = assertThrows(DAOException.class, () -> dao.update(entity));
        assertTrue(ex.getMessage().contains("No {entity} found to update"));
    }}

    @Test
    void update_sqlException_wrappedAsDAOException() throws Exception {{
        {entity} entity = new {entity}();
        when(preparedStatement.executeUpdate()).thenThrow(new SQLException("update failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.update(entity));
        assertTrue(ex.getMessage().contains("Failed to update {entity}"));
        assertTrue(ex.getCause() instanceof SQLException);
    }}

    // ---------------------------------------------------------------
    // delete
    // ---------------------------------------------------------------

    @Test
    void delete_rowsAffected_returnsTrue() throws Exception {{
        when(preparedStatement.executeUpdate()).thenReturn(1);

        assertTrue(dao.delete({delete_args}));
    }}

    @Test
    void delete_noRowsAffected_returnsFalse() throws Exception {{
        when(preparedStatement.executeUpdate()).thenReturn(0);

        assertFalse(dao.delete({delete_args}));
    }}

    @Test
    void delete_sqlException_wrappedAsDAOException() throws Exception {{
        when(preparedStatement.executeUpdate()).thenThrow(new SQLException("delete failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.delete({delete_args}));
        assertTrue(ex.getMessage().contains("Failed to delete {entity}"));
        assertTrue(ex.getCause() instanceof SQLException);
    }}

    // ---------------------------------------------------------------
    // findById
    // ---------------------------------------------------------------

    @Test
    void findById_found_returnsMappedEntity() throws Exception {{
        when(resultSet.next()).thenReturn(true);

        {entity} result = dao.findById({delete_args});

        assertNotNull(result);
    }}

    @Test
    void findById_notFound_returnsNull() throws Exception {{
        when(resultSet.next()).thenReturn(false);

        {entity} result = dao.findById({delete_args});

        assertNull(result);
    }}

    @Test
    void findById_sqlException_wrappedAsDAOException() throws Exception {{
        when(preparedStatement.executeQuery()).thenThrow(new SQLException("query failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.findById({delete_args}));
        assertTrue(ex.getMessage().contains("Failed to fetch {entity}"));
        assertTrue(ex.getCause() instanceof SQLException);
    }}

    // ---------------------------------------------------------------
    // findAll
    // ---------------------------------------------------------------

    @Test
    void findAll_multipleRows_returnsAllMappedEntities() throws Exception {{
        when(resultSet.next()).thenReturn(true, true, false);

        List<{entity}> result = dao.findAll();

        assertEquals(2, result.size());
    }}

    @Test
    void findAll_noRows_returnsEmptyList() throws Exception {{
        when(resultSet.next()).thenReturn(false);

        List<{entity}> result = dao.findAll();

        assertTrue(result.isEmpty());
    }}

    @Test
    void findAll_sqlException_wrappedAsDAOException() throws Exception {{
        when(preparedStatement.executeQuery()).thenThrow(new SQLException("query failed"));

        DAOException ex = assertThrows(DAOException.class, dao::findAll);
        assertTrue(ex.getMessage().contains("Failed to fetch {entity} list"));
        assertTrue(ex.getCause() instanceof SQLException);
    }}
}}
'''

count = 0
for fname in files:
    clazz = fname[:-5]  # strip .java
    entity = clazz.replace("DAOImpl", "")
    if entity in ("AuditLog", "RolePermission"):
        continue  # handled by hand

    path = os.path.join(SRC, fname)
    src = open(path).read()
    m = re.search(r"boolean delete\((\w+) (\w+)\)", src)
    if not m:
        print("SKIP (no delete sig match):", fname)
        continue
    id_type, id_name = m.group(1), m.group(2)
    if id_type == "String":
        delete_args = '"id-1"'
    elif id_type in ("Long",):
        delete_args = "1L"
    elif id_type in ("Integer", "int"):
        delete_args = "1"
    else:
        delete_args = '"id-1"'

    out = TEMPLATE_STANDARD.format(entity=entity, clazz=clazz, delete_args=delete_args)
    outpath = os.path.join(OUT, clazz + "Test.java")
    with open(outpath, "w") as f:
        f.write(out)
    count += 1

print("Generated", count, "standard DAO test files")
