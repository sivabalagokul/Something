package hlms.daoimpl;

import hlms.entity.AuditLog;
import hlms.util.DAOException;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link AuditLogDAOImpl}.
 *
 * This DAO is a structural outlier vs. the other 19: insert() uses
 * "INSERT ... RETURNING log_id" and reads the generated key back via
 * ps.executeQuery() + rs.getLong(1) instead of ps.executeUpdate().
 */
class AuditLogDAOImplTest extends JdbcDaoTestBase {

    private final AuditLogDAOImpl dao = new AuditLogDAOImpl();

    // ---------------------------------------------------------------
    // insert (RETURNING log_id)
    // ---------------------------------------------------------------

    @Test
    void insert_success_populatesGeneratedLogId() throws Exception {
        AuditLog entity = new AuditLog();
        when(resultSet.next()).thenReturn(true);
        when(resultSet.getLong(1)).thenReturn(42L);

        AuditLog result = dao.insert(entity);

        assertSame(entity, result);
        assertEquals(42L, result.getLogId());
        verify(preparedStatement, times(1)).executeQuery();
    }

    @Test
    void insert_noGeneratedKeyReturned_logIdLeftUnset() throws Exception {
        AuditLog entity = new AuditLog();
        when(resultSet.next()).thenReturn(false);

        AuditLog result = dao.insert(entity);

        assertSame(entity, result);
        assertNull(result.getLogId());
    }

    @Test
    void insert_sqlException_wrappedAsDAOException() throws Exception {
        AuditLog entity = new AuditLog();
        when(preparedStatement.executeQuery()).thenThrow(new SQLException("insert failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.insert(entity));
        assertTrue(ex.getMessage().contains("Failed to insert AuditLog"));
        assertTrue(ex.getCause() instanceof SQLException);
    }

    // ---------------------------------------------------------------
    // update (audit logs are otherwise updatable at the DAO level even
    // though the service layer may forbid it - see AuditLogServiceImplTest)
    // ---------------------------------------------------------------

    @Test
    void update_success_returnsSameEntity() throws Exception {
        AuditLog entity = new AuditLog();
        when(preparedStatement.executeUpdate()).thenReturn(1);

        AuditLog result = dao.update(entity);

        assertSame(entity, result);
    }

    @Test
    void update_zeroRowsAffected_throwsDAOException() throws Exception {
        AuditLog entity = new AuditLog();
        when(preparedStatement.executeUpdate()).thenReturn(0);

        DAOException ex = assertThrows(DAOException.class, () -> dao.update(entity));
        assertTrue(ex.getMessage().contains("No AuditLog found to update"));
    }

    @Test
    void update_sqlException_wrappedAsDAOException() throws Exception {
        AuditLog entity = new AuditLog();
        when(preparedStatement.executeUpdate()).thenThrow(new SQLException("update failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.update(entity));
        assertTrue(ex.getMessage().contains("Failed to update AuditLog"));
        assertTrue(ex.getCause() instanceof SQLException);
    }

    // ---------------------------------------------------------------
    // delete (Long id)
    // ---------------------------------------------------------------

    @Test
    void delete_rowsAffected_returnsTrue() throws Exception {
        when(preparedStatement.executeUpdate()).thenReturn(1);

        assertTrue(dao.delete(1L));
    }

    @Test
    void delete_noRowsAffected_returnsFalse() throws Exception {
        when(preparedStatement.executeUpdate()).thenReturn(0);

        assertFalse(dao.delete(1L));
    }

    @Test
    void delete_sqlException_wrappedAsDAOException() throws Exception {
        when(preparedStatement.executeUpdate()).thenThrow(new SQLException("delete failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.delete(1L));
        assertTrue(ex.getMessage().contains("Failed to delete AuditLog"));
        assertTrue(ex.getCause() instanceof SQLException);
    }

    // ---------------------------------------------------------------
    // findById
    // ---------------------------------------------------------------

    @Test
    void findById_found_returnsMappedEntity() throws Exception {
        when(resultSet.next()).thenReturn(true);

        AuditLog result = dao.findById(1L);

        assertNotNull(result);
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(resultSet.next()).thenReturn(false);

        AuditLog result = dao.findById(1L);

        assertNull(result);
    }

    @Test
    void findById_sqlException_wrappedAsDAOException() throws Exception {
        when(preparedStatement.executeQuery()).thenThrow(new SQLException("query failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.findById(1L));
        assertTrue(ex.getMessage().contains("Failed to fetch AuditLog"));
        assertTrue(ex.getCause() instanceof SQLException);
    }

    // ---------------------------------------------------------------
    // findAll
    // ---------------------------------------------------------------

    @Test
    void findAll_multipleRows_returnsAllMappedEntities() throws Exception {
        when(resultSet.next()).thenReturn(true, true, false);

        List<AuditLog> result = dao.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_noRows_returnsEmptyList() throws Exception {
        when(resultSet.next()).thenReturn(false);

        List<AuditLog> result = dao.findAll();

        assertTrue(result.isEmpty());
    }

    @Test
    void findAll_sqlException_wrappedAsDAOException() throws Exception {
        when(preparedStatement.executeQuery()).thenThrow(new SQLException("query failed"));

        DAOException ex = assertThrows(DAOException.class, dao::findAll);
        assertTrue(ex.getMessage().contains("Failed to fetch AuditLog list"));
        assertTrue(ex.getCause() instanceof SQLException);
    }
}
