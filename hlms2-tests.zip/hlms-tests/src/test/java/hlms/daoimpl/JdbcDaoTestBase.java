package hlms.daoimpl;

import hlms.util.DBConnection;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.MockedStatic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Shared plumbing for every *DAOImplTest.
 *
 * Every generated DAOImpl obtains its JDBC {@link Connection} from the
 * static {@link DBConnection#getConnection()} method, so each test needs
 * to intercept that static call and hand back Mockito mocks instead of a
 * real database connection. This base class centralizes that setup/teardown
 * so individual DAO tests only have to worry about PreparedStatement /
 * ResultSet behaviour that is specific to the method under test.
 */
public abstract class JdbcDaoTestBase {

    protected MockedStatic<DBConnection> dbConnectionMockedStatic;
    protected Connection connection;
    protected PreparedStatement preparedStatement;
    protected ResultSet resultSet;

    @BeforeEach
    void setUpJdbcMocks() throws Exception {
        connection = mock(Connection.class);
        preparedStatement = mock(PreparedStatement.class);
        resultSet = mock(ResultSet.class);

        when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
        when(preparedStatement.executeQuery()).thenReturn(resultSet);

        dbConnectionMockedStatic = mockStatic(DBConnection.class);
        dbConnectionMockedStatic.when(DBConnection::getConnection).thenReturn(connection);
    }

    @AfterEach
    void tearDownJdbcMocks() {
        if (dbConnectionMockedStatic != null) {
            dbConnectionMockedStatic.close();
        }
    }
}
