package hlms.daoimpl;

import hlms.entity.PostDisbursementDocument;
import hlms.util.DAOException;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for PostDisbursementDocumentDAOImpl.
 *
 * DBConnection.getConnection() is intercepted via a static mock (see
 * {@link JdbcDaoTestBase}) so every test runs against mocked
 * Connection/PreparedStatement/ResultSet objects instead of a real
 * PostgreSQL database.
 */
class PostDisbursementDocumentDAOImplTest extends JdbcDaoTestBase {

    private final PostDisbursementDocumentDAOImpl dao = new PostDisbursementDocumentDAOImpl();

    // ---------------------------------------------------------------
    // insert
    // ---------------------------------------------------------------

    @Test
    void insert_success_returnsSameEntity() throws Exception {
        PostDisbursementDocument entity = new PostDisbursementDocument();

        PostDisbursementDocument result = dao.insert(entity);

        assertSame(entity, result);
        verify(preparedStatement, times(1)).executeUpdate();
    }

    @Test
    void insert_sqlException_wrappedAsDAOException() throws Exception {
        PostDisbursementDocument entity = new PostDisbursementDocument();
        when(preparedStatement.executeUpdate()).thenThrow(new SQLException("insert failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.insert(entity));
        assertTrue(ex.getMessage().contains("Failed to insert PostDisbursementDocument"));
        assertTrue(ex.getCause() instanceof SQLException);
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_success_returnsSameEntity() throws Exception {
        PostDisbursementDocument entity = new PostDisbursementDocument();
        when(preparedStatement.executeUpdate()).thenReturn(1);

        PostDisbursementDocument result = dao.update(entity);

        assertSame(entity, result);
    }

    @Test
    void update_zeroRowsAffected_throwsDAOException() throws Exception {
        PostDisbursementDocument entity = new PostDisbursementDocument();
        when(preparedStatement.executeUpdate()).thenReturn(0);

        DAOException ex = assertThrows(DAOException.class, () -> dao.update(entity));
        assertTrue(ex.getMessage().contains("No PostDisbursementDocument found to update"));
    }

    @Test
    void update_sqlException_wrappedAsDAOException() throws Exception {
        PostDisbursementDocument entity = new PostDisbursementDocument();
        when(preparedStatement.executeUpdate()).thenThrow(new SQLException("update failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.update(entity));
        assertTrue(ex.getMessage().contains("Failed to update PostDisbursementDocument"));
        assertTrue(ex.getCause() instanceof SQLException);
    }

    // ---------------------------------------------------------------
    // delete
    // ---------------------------------------------------------------

    @Test
    void delete_rowsAffected_returnsTrue() throws Exception {
        when(preparedStatement.executeUpdate()).thenReturn(1);

        assertTrue(dao.delete("id-1"));
    }

    @Test
    void delete_noRowsAffected_returnsFalse() throws Exception {
        when(preparedStatement.executeUpdate()).thenReturn(0);

        assertFalse(dao.delete("id-1"));
    }

    @Test
    void delete_sqlException_wrappedAsDAOException() throws Exception {
        when(preparedStatement.executeUpdate()).thenThrow(new SQLException("delete failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.delete("id-1"));
        assertTrue(ex.getMessage().contains("Failed to delete PostDisbursementDocument"));
        assertTrue(ex.getCause() instanceof SQLException);
    }

    // ---------------------------------------------------------------
    // findById
    // ---------------------------------------------------------------

    @Test
    void findById_found_returnsMappedEntity() throws Exception {
        when(resultSet.next()).thenReturn(true);

        PostDisbursementDocument result = dao.findById("id-1");

        assertNotNull(result);
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(resultSet.next()).thenReturn(false);

        PostDisbursementDocument result = dao.findById("id-1");

        assertNull(result);
    }

    @Test
    void findById_sqlException_wrappedAsDAOException() throws Exception {
        when(preparedStatement.executeQuery()).thenThrow(new SQLException("query failed"));

        DAOException ex = assertThrows(DAOException.class, () -> dao.findById("id-1"));
        assertTrue(ex.getMessage().contains("Failed to fetch PostDisbursementDocument"));
        assertTrue(ex.getCause() instanceof SQLException);
    }

    // ---------------------------------------------------------------
    // findAll
    // ---------------------------------------------------------------

    @Test
    void findAll_multipleRows_returnsAllMappedEntities() throws Exception {
        when(resultSet.next()).thenReturn(true, true, false);

        List<PostDisbursementDocument> result = dao.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_noRows_returnsEmptyList() throws Exception {
        when(resultSet.next()).thenReturn(false);

        List<PostDisbursementDocument> result = dao.findAll();

        assertTrue(result.isEmpty());
    }

    @Test
    void findAll_sqlException_wrappedAsDAOException() throws Exception {
        when(preparedStatement.executeQuery()).thenThrow(new SQLException("query failed"));

        DAOException ex = assertThrows(DAOException.class, dao::findAll);
        assertTrue(ex.getMessage().contains("Failed to fetch PostDisbursementDocument list"));
        assertTrue(ex.getCause() instanceof SQLException);
    }
}
