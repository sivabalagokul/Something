package hlms.serviceimpl;

import hlms.dao.AuctionCaseDAO;
import hlms.dto.AuctionCaseDTO;
import hlms.entity.AuctionCase;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link AuctionCaseServiceImpl}.
 *
 * Key business rule under test (US-AM-01/US-AM-02): notice/possession/
 * auction dates must fall in chronological order, and stage defaults to
 * "Notice Issued" on create.
 */
@ExtendWith(MockitoExtension.class)
class AuctionCaseServiceImplTest {

    @Mock
    private AuctionCaseDAO dao;

    private AuctionCaseServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new AuctionCaseServiceImpl(dao);
    }

    private AuctionCaseDTO validDto() {
        AuctionCaseDTO dto = new AuctionCaseDTO();
        dto.setAppId("APP-1");
        dto.setNoticeDate(LocalDate.now());
        dto.setNoticeDueDate(LocalDate.now().plusDays(30));
        dto.setDemandAmount(new BigDecimal("500000"));
        dto.setReservePrice(new BigDecimal("450000"));
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_valid_defaultsStageToNoticeIssued() throws Exception {
        AuctionCaseDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(null);
        when(dao.insert(any(AuctionCase.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionCaseDTO result = service.create(dto);

        assertEquals("Notice Issued", result.getStage());
    }

    @Test
    void create_alreadyExists_throwsValidationException() throws Exception {
        AuctionCaseDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(new AuctionCase());

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        AuctionCaseDTO dto = validDto();
        dto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_invalidStage_throwsValidationException() throws Exception {
        AuctionCaseDTO dto = validDto();
        dto.setStage("Cancelled");
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_missingNoticeDate_throwsValidationException() throws Exception {
        AuctionCaseDTO dto = validDto();
        dto.setNoticeDate(null);
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_noticeDueDateBeforeNoticeDate_throwsValidationException() throws Exception {
        AuctionCaseDTO dto = validDto();
        dto.setNoticeDueDate(dto.getNoticeDate().minusDays(1));
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_nonPositiveDemandAmount_throwsValidationException() throws Exception {
        AuctionCaseDTO dto = validDto();
        dto.setDemandAmount(BigDecimal.ZERO);
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_nonPositiveReservePrice_throwsValidationException() throws Exception {
        AuctionCaseDTO dto = validDto();
        dto.setReservePrice(BigDecimal.ZERO);
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_possessionDateBeforeNoticeDueDate_throwsValidationException() throws Exception {
        AuctionCaseDTO dto = validDto();
        dto.setPossessionDate(dto.getNoticeDueDate().minusDays(1));
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_auctionDateBeforePossessionDate_throwsValidationException() throws Exception {
        AuctionCaseDTO dto = validDto();
        dto.setPossessionDate(dto.getNoticeDueDate().plusDays(10));
        dto.setAuctionDate(dto.getPossessionDate().minusDays(1));
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_fullyChronologicalDates_succeeds() throws Exception {
        AuctionCaseDTO dto = validDto();
        dto.setPossessionDate(dto.getNoticeDueDate().plusDays(10));
        dto.setAuctionDate(dto.getPossessionDate().plusDays(10));
        when(dao.findById("APP-1")).thenReturn(null);
        when(dao.insert(any(AuctionCase.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionCaseDTO result = service.create(dto);

        assertNotNull(result.getAuctionDate());
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existing_delegatesToDao() throws Exception {
        AuctionCaseDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(new AuctionCase());
        when(dao.update(any(AuctionCase.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionCaseDTO result = service.update(dto);

        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void update_nonExistent_throwsValidationException() throws Exception {
        AuctionCaseDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    // ---------------------------------------------------------------
    // delete / findById / findAll
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("APP-1")).thenReturn(true);

        assertTrue(service.delete("APP-1"));
    }

    @Test
    void delete_nullAppId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null));
        verifyNoInteractions(dao);
    }

    @Test
    void findById_found_returnsDto() throws Exception {
        AuctionCase entity = new AuctionCase();
        entity.setAppId("APP-1");
        when(dao.findById("APP-1")).thenReturn(entity);

        AuctionCaseDTO result = service.findById("APP-1");

        assertNotNull(result);
        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("APP-1")).thenReturn(null);

        assertNull(service.findById("APP-1"));
    }

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        AuctionCase e1 = new AuctionCase();
        e1.setAppId("APP-1");
        AuctionCase e2 = new AuctionCase();
        e2.setAppId("APP-2");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<AuctionCaseDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
