package hlms.serviceimpl;

import hlms.dao.AuctionNoteDAO;
import hlms.dto.AuctionNoteDTO;
import hlms.entity.AuctionNote;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuctionNoteServiceImplTest {

    @Mock
    private AuctionNoteDAO dao;

    private AuctionNoteServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new AuctionNoteServiceImpl(dao);
    }

    private AuctionNoteDTO validDto() {
        AuctionNoteDTO dto = new AuctionNoteDTO();
        dto.setAppId("APP-1");
        dto.setNoteText("Site visit completed.");
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_valid_generatesNoteIdAndDate() throws Exception {
        AuctionNoteDTO dto = validDto();
        when(dao.insert(any(AuctionNote.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionNoteDTO result = service.create(dto);

        assertNotNull(result.getNoteId());
        assertTrue(result.getNoteId().startsWith("ANT-"));
        assertNotNull(result.getNoteDate());
        verify(dao, times(1)).insert(any(AuctionNote.class));
    }

    @Test
    void create_explicitNoteId_isPreserved() throws Exception {
        AuctionNoteDTO dto = validDto();
        dto.setNoteId("ANT-CUSTOM1");
        when(dao.insert(any(AuctionNote.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionNoteDTO result = service.create(dto);

        assertEquals("ANT-CUSTOM1", result.getNoteId());
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        AuctionNoteDTO dto = validDto();
        dto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_missingNoteText_throwsValidationException() {
        AuctionNoteDTO dto = validDto();
        dto.setNoteText(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_noteTextTooLong_throwsValidationException() {
        AuctionNoteDTO dto = validDto();
        dto.setNoteText("x".repeat(4001));

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existingNote_delegatesToDao() throws Exception {
        AuctionNoteDTO dto = validDto();
        dto.setNoteId("ANT-1");
        when(dao.findById("ANT-1")).thenReturn(new AuctionNote());
        when(dao.update(any(AuctionNote.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionNoteDTO result = service.update(dto);

        assertEquals("ANT-1", result.getNoteId());
        verify(dao).update(any(AuctionNote.class));
    }

    @Test
    void update_missingNoteId_throwsValidationException() {
        AuctionNoteDTO dto = validDto();

        assertThrows(ValidationException.class, () -> service.update(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void update_nonExistentNote_throwsValidationException() throws Exception {
        AuctionNoteDTO dto = validDto();
        dto.setNoteId("ANT-404");
        when(dao.findById("ANT-404")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    // ---------------------------------------------------------------
    // delete
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("ANT-1")).thenReturn(true);

        assertTrue(service.delete("ANT-1"));
    }

    @Test
    void delete_blankId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(" "));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // findById
    // ---------------------------------------------------------------

    @Test
    void findById_found_returnsDto() throws Exception {
        AuctionNote entity = new AuctionNote();
        entity.setNoteId("ANT-1");
        when(dao.findById("ANT-1")).thenReturn(entity);

        AuctionNoteDTO result = service.findById("ANT-1");

        assertNotNull(result);
        assertEquals("ANT-1", result.getNoteId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("ANT-1")).thenReturn(null);

        assertNull(service.findById("ANT-1"));
    }

    // ---------------------------------------------------------------
    // findAll
    // ---------------------------------------------------------------

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        AuctionNote e1 = new AuctionNote();
        e1.setNoteId("ANT-1");
        AuctionNote e2 = new AuctionNote();
        e2.setNoteId("ANT-2");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<AuctionNoteDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
