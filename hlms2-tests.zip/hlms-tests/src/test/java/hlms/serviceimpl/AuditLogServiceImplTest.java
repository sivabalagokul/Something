package hlms.serviceimpl;

import hlms.dao.AuditLogDAO;
import hlms.dto.AuditLogDTO;
import hlms.entity.AppUser;
import hlms.entity.AuditLog;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link AuditLogServiceImpl}.
 *
 * Key business rule under test: audit log rows are append-only, so
 * update() must always fail regardless of input.
 */
@ExtendWith(MockitoExtension.class)
class AuditLogServiceImplTest {

    @Mock
    private AuditLogDAO dao;

    private AuditLogServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new AuditLogServiceImpl(dao);
    }

    private AuditLogDTO validDto() {
        AuditLogDTO dto = new AuditLogDTO();
        dto.setEntityType("LOAN_APPLICATION");
        dto.setEntityId("APP-1");
        dto.setAction("CREATE");
        dto.setActorEmail("actor@example.com");
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_valid_delegatesToDaoAndReturnsDto() throws Exception {
        AuditLogDTO dto = validDto();
        AuditLog saved = new AuditLog();
        saved.setLogId(1L);
        saved.setEntityType("LOAN_APPLICATION");
        saved.setEntityId("APP-1");
        saved.setAction("CREATE");
        AppUser actor = new AppUser();
        actor.setEmail("actor@example.com");
        saved.setActor(actor);
        when(dao.insert(any(AuditLog.class))).thenReturn(saved);

        AuditLogDTO result = service.create(dto);

        assertEquals(1L, result.getLogId());
        assertEquals("actor@example.com", result.getActorEmail());
        verify(dao, times(1)).insert(any(AuditLog.class));
    }

    @Test
    void create_setsCreatedAtWhenMissing() throws Exception {
        AuditLogDTO dto = validDto();
        assertNull(dto.getCreatedAt());
        when(dao.insert(any(AuditLog.class))).thenAnswer(inv -> inv.getArgument(0));

        AuditLogDTO result = service.create(dto);

        assertNotNull(result.getCreatedAt());
    }

    @Test
    void create_preservesExplicitCreatedAt() throws Exception {
        AuditLogDTO dto = validDto();
        OffsetDateTime explicit = OffsetDateTime.parse("2024-01-01T00:00:00Z");
        dto.setCreatedAt(explicit);
        when(dao.insert(any(AuditLog.class))).thenAnswer(inv -> inv.getArgument(0));

        AuditLogDTO result = service.create(dto);

        assertEquals(explicit, result.getCreatedAt());
    }

    @Test
    void create_missingEntityType_throwsValidationException() {
        AuditLogDTO dto = validDto();
        dto.setEntityType(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_missingEntityId_throwsValidationException() {
        AuditLogDTO dto = validDto();
        dto.setEntityId(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_invalidAction_throwsValidationException() {
        AuditLogDTO dto = validDto();
        dto.setAction("DESTROY");

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_missingActorEmail_throwsValidationException() {
        AuditLogDTO dto = validDto();
        dto.setActorEmail(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // update - always unsupported
    // ---------------------------------------------------------------

    @Test
    void update_alwaysThrowsValidationException() {
        AuditLogDTO dto = validDto();

        ValidationException ex = assertThrows(ValidationException.class, () -> service.update(dto));
        assertTrue(ex.getMessage().toLowerCase().contains("immutable"));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // delete
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete(1L)).thenReturn(true);

        assertTrue(service.delete(1L));
        verify(dao).delete(1L);
    }

    @Test
    void delete_nullId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // findById
    // ---------------------------------------------------------------

    @Test
    void findById_found_returnsDto() throws Exception {
        AuditLog entity = new AuditLog();
        entity.setLogId(1L);
        entity.setEntityType("LOAN_APPLICATION");
        when(dao.findById(1L)).thenReturn(entity);

        AuditLogDTO result = service.findById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getLogId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById(1L)).thenReturn(null);

        assertNull(service.findById(1L));
    }

    @Test
    void findById_nullId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.findById(null));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // findAll
    // ---------------------------------------------------------------

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        AuditLog e1 = new AuditLog();
        e1.setLogId(1L);
        AuditLog e2 = new AuditLog();
        e2.setLogId(2L);
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<AuditLogDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
