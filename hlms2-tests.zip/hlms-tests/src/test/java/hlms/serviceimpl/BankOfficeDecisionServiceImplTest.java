package hlms.serviceimpl;

import hlms.dao.BankOfficeDecisionDAO;
import hlms.dto.BankOfficeDecisionDTO;
import hlms.entity.BankOfficeDecision;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link BankOfficeDecisionServiceImpl}.
 *
 * Key business rule under test (US-EL-05): a decision other than APPROVED
 * (i.e. REJECTED or CONDITIONALLY_APPROVED) must always carry a reason.
 */
@ExtendWith(MockitoExtension.class)
class BankOfficeDecisionServiceImplTest {

    @Mock
    private BankOfficeDecisionDAO dao;

    private BankOfficeDecisionServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new BankOfficeDecisionServiceImpl(dao);
    }

    private BankOfficeDecisionDTO validDto() {
        BankOfficeDecisionDTO dto = new BankOfficeDecisionDTO();
        dto.setAppId("APP-1");
        dto.setDecision("APPROVED");
        dto.setOfficerEmail("officer@example.com");
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_approved_doesNotRequireReason() throws Exception {
        BankOfficeDecisionDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(null);
        when(dao.insert(any(BankOfficeDecision.class))).thenAnswer(inv -> inv.getArgument(0));

        BankOfficeDecisionDTO result = service.create(dto);

        assertNotNull(result.getDecisionDate());
        assertEquals("APPROVED", result.getDecision());
    }

    @Test
    void create_alreadyExists_throwsValidationException() throws Exception {
        BankOfficeDecisionDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(new BankOfficeDecision());

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        BankOfficeDecisionDTO dto = validDto();
        dto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_invalidDecision_throwsValidationException() throws Exception {
        BankOfficeDecisionDTO dto = validDto();
        dto.setDecision("MAYBE");
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_missingOfficerEmail_throwsValidationException() throws Exception {
        BankOfficeDecisionDTO dto = validDto();
        dto.setOfficerEmail(null);
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_rejectedWithoutReason_throwsValidationException() throws Exception {
        BankOfficeDecisionDTO dto = validDto();
        dto.setDecision("REJECTED");
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_conditionallyApprovedWithoutReason_throwsValidationException() throws Exception {
        BankOfficeDecisionDTO dto = validDto();
        dto.setDecision("CONDITIONALLY_APPROVED");
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_rejectedWithReason_succeeds() throws Exception {
        BankOfficeDecisionDTO dto = validDto();
        dto.setDecision("REJECTED");
        dto.setReason("Income insufficient.");
        when(dao.findById("APP-1")).thenReturn(null);
        when(dao.insert(any(BankOfficeDecision.class))).thenAnswer(inv -> inv.getArgument(0));

        BankOfficeDecisionDTO result = service.create(dto);

        assertEquals("REJECTED", result.getDecision());
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existing_delegatesToDao() throws Exception {
        BankOfficeDecisionDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(new BankOfficeDecision());
        when(dao.update(any(BankOfficeDecision.class))).thenAnswer(inv -> inv.getArgument(0));

        BankOfficeDecisionDTO result = service.update(dto);

        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void update_nonExistent_throwsValidationException() throws Exception {
        BankOfficeDecisionDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    // ---------------------------------------------------------------
    // delete / findById / findAll
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("APP-1")).thenReturn(true);

        assertTrue(service.delete("APP-1"));
    }

    @Test
    void delete_nullAppId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null));
        verifyNoInteractions(dao);
    }

    @Test
    void findById_found_returnsDto() throws Exception {
        BankOfficeDecision entity = new BankOfficeDecision();
        entity.setAppId("APP-1");
        when(dao.findById("APP-1")).thenReturn(entity);

        BankOfficeDecisionDTO result = service.findById("APP-1");

        assertNotNull(result);
        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("APP-1")).thenReturn(null);

        assertNull(service.findById("APP-1"));
    }

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        BankOfficeDecision e1 = new BankOfficeDecision();
        e1.setAppId("APP-1");
        BankOfficeDecision e2 = new BankOfficeDecision();
        e2.setAppId("APP-2");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<BankOfficeDecisionDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
