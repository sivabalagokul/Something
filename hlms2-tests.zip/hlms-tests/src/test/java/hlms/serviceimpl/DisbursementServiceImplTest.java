package hlms.serviceimpl;

import hlms.dao.DisbursementDAO;
import hlms.dto.DisbursementDTO;
import hlms.entity.Disbursement;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DisbursementServiceImplTest {

    @Mock
    private DisbursementDAO dao;

    private DisbursementServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new DisbursementServiceImpl(dao);
    }

    private DisbursementDTO validDto() {
        DisbursementDTO dto = new DisbursementDTO();
        dto.setAppId("APP-1");
        dto.setAmount(new BigDecimal("500000"));
        dto.setRefNo("REF-123");
        dto.setMode("NEFT");
        dto.setBankDetails("HDFC Bank, A/C 1234");
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_valid_delegatesToDaoAndDefaultsDate() throws Exception {
        DisbursementDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(null);
        when(dao.insert(any(Disbursement.class))).thenAnswer(inv -> inv.getArgument(0));

        DisbursementDTO result = service.create(dto);

        assertNotNull(result.getDisbursedDate());
        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void create_alreadyExists_throwsValidationException() throws Exception {
        DisbursementDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(new Disbursement());

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        DisbursementDTO dto = validDto();
        dto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_nonPositiveAmount_throwsValidationException() throws Exception {
        DisbursementDTO dto = validDto();
        dto.setAmount(BigDecimal.ZERO);
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_missingRefNo_throwsValidationException() throws Exception {
        DisbursementDTO dto = validDto();
        dto.setRefNo(null);
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_invalidMode_throwsValidationException() throws Exception {
        DisbursementDTO dto = validDto();
        dto.setMode("CASH");
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_missingBankDetails_throwsValidationException() throws Exception {
        DisbursementDTO dto = validDto();
        dto.setBankDetails(null);
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_futureDisbursedDate_throwsValidationException() throws Exception {
        DisbursementDTO dto = validDto();
        dto.setDisbursedDate(OffsetDateTime.now().plusDays(1));
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existing_delegatesToDao() throws Exception {
        DisbursementDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(new Disbursement());
        when(dao.update(any(Disbursement.class))).thenAnswer(inv -> inv.getArgument(0));

        DisbursementDTO result = service.update(dto);

        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void update_nonExistent_throwsValidationException() throws Exception {
        DisbursementDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    // ---------------------------------------------------------------
    // delete
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("APP-1")).thenReturn(true);

        assertTrue(service.delete("APP-1"));
    }

    @Test
    void delete_nullAppId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // findById / findAll
    // ---------------------------------------------------------------

    @Test
    void findById_found_returnsDto() throws Exception {
        Disbursement entity = new Disbursement();
        entity.setAppId("APP-1");
        when(dao.findById("APP-1")).thenReturn(entity);

        DisbursementDTO result = service.findById("APP-1");

        assertNotNull(result);
        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("APP-1")).thenReturn(null);

        assertNull(service.findById("APP-1"));
    }

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        Disbursement e1 = new Disbursement();
        e1.setAppId("APP-1");
        Disbursement e2 = new Disbursement();
        e2.setAppId("APP-2");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<DisbursementDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
