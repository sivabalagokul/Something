package hlms.serviceimpl;

import hlms.dao.InsurancePolicyDAO;
import hlms.dto.InsurancePolicyDTO;
import hlms.entity.InsurancePolicy;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InsurancePolicyServiceImplTest {

    @Mock
    private InsurancePolicyDAO dao;

    private InsurancePolicyServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new InsurancePolicyServiceImpl(dao);
    }

    private InsurancePolicyDTO validDto() {
        InsurancePolicyDTO dto = new InsurancePolicyDTO();
        dto.setAppId("APP-1");
        dto.setPolicyType("property");
        dto.setValidTill(LocalDate.now().plusYears(1));
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_valid_generatesIdAndDefaultsStatusToActive() throws Exception {
        InsurancePolicyDTO dto = validDto();
        when(dao.insert(any(InsurancePolicy.class))).thenAnswer(inv -> inv.getArgument(0));

        InsurancePolicyDTO result = service.create(dto);

        assertNotNull(result.getPolicyId());
        assertTrue(result.getPolicyId().startsWith("POL-"));
        assertEquals("Active", result.getStatus());
    }

    @Test
    void create_invalidPolicyType_throwsValidationException() {
        InsurancePolicyDTO dto = validDto();
        dto.setPolicyType("vehicle");

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_invalidStatus_throwsValidationException() {
        InsurancePolicyDTO dto = validDto();
        dto.setStatus("Pending");

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_pastValidTill_throwsValidationException() {
        InsurancePolicyDTO dto = validDto();
        dto.setValidTill(LocalDate.now().minusDays(1));

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_activeStatusWithValidTillToday_succeeds() throws Exception {
        InsurancePolicyDTO dto = validDto();
        dto.setStatus("Active");
        dto.setValidTill(LocalDate.now());
        when(dao.insert(any(InsurancePolicy.class))).thenAnswer(inv -> inv.getArgument(0));

        InsurancePolicyDTO result = service.create(dto);

        assertEquals("Active", result.getStatus());
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        InsurancePolicyDTO dto = validDto();
        dto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existing_delegatesToDao() throws Exception {
        InsurancePolicyDTO dto = validDto();
        dto.setPolicyId("POL-1");
        when(dao.findById("POL-1")).thenReturn(new InsurancePolicy());
        when(dao.update(any(InsurancePolicy.class))).thenAnswer(inv -> inv.getArgument(0));

        InsurancePolicyDTO result = service.update(dto);

        assertEquals("POL-1", result.getPolicyId());
    }

    @Test
    void update_missingPolicyId_throwsValidationException() {
        InsurancePolicyDTO dto = validDto();

        assertThrows(ValidationException.class, () -> service.update(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void update_nonExistent_throwsValidationException() throws Exception {
        InsurancePolicyDTO dto = validDto();
        dto.setPolicyId("POL-404");
        when(dao.findById("POL-404")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    // ---------------------------------------------------------------
    // delete / findById / findAll
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("POL-1")).thenReturn(true);

        assertTrue(service.delete("POL-1"));
    }

    @Test
    void delete_nullId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null));
        verifyNoInteractions(dao);
    }

    @Test
    void findById_found_returnsDto() throws Exception {
        InsurancePolicy entity = new InsurancePolicy();
        entity.setPolicyId("POL-1");
        when(dao.findById("POL-1")).thenReturn(entity);

        InsurancePolicyDTO result = service.findById("POL-1");

        assertNotNull(result);
        assertEquals("POL-1", result.getPolicyId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("POL-1")).thenReturn(null);

        assertNull(service.findById("POL-1"));
    }

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        InsurancePolicy e1 = new InsurancePolicy();
        e1.setPolicyId("POL-1");
        InsurancePolicy e2 = new InsurancePolicy();
        e2.setPolicyId("POL-2");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<InsurancePolicyDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
