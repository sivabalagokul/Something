package hlms.serviceimpl;

import hlms.dao.LegalChecklistItemDAO;
import hlms.dto.LegalChecklistItemDTO;
import hlms.entity.LegalChecklistItem;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LegalChecklistItemServiceImplTest {

    @Mock
    private LegalChecklistItemDAO dao;

    private LegalChecklistItemServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new LegalChecklistItemServiceImpl(dao);
    }

    private LegalChecklistItemDTO validDto() {
        LegalChecklistItemDTO dto = new LegalChecklistItemDTO();
        dto.setAppId("APP-1");
        dto.setChecklistKey("TITLE_DEED");
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_valid_defaultsStatusToPendingAndGeneratesId() throws Exception {
        LegalChecklistItemDTO dto = validDto();
        when(dao.insert(any(LegalChecklistItem.class))).thenAnswer(inv -> inv.getArgument(0));

        LegalChecklistItemDTO result = service.create(dto);

        assertNotNull(result.getChecklistItemId());
        assertTrue(result.getChecklistItemId().startsWith("CHK-"));
        assertEquals("PENDING", result.getStatus());
    }

    @Test
    void create_explicitStatus_isPreserved() throws Exception {
        LegalChecklistItemDTO dto = validDto();
        dto.setStatus("COMPLETED");
        when(dao.insert(any(LegalChecklistItem.class))).thenAnswer(inv -> inv.getArgument(0));

        LegalChecklistItemDTO result = service.create(dto);

        assertEquals("COMPLETED", result.getStatus());
    }

    @Test
    void create_invalidStatus_throwsValidationException() {
        LegalChecklistItemDTO dto = validDto();
        dto.setStatus("BOGUS");

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        LegalChecklistItemDTO dto = validDto();
        dto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_missingChecklistKey_throwsValidationException() {
        LegalChecklistItemDTO dto = validDto();
        dto.setChecklistKey(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existingItem_delegatesToDao() throws Exception {
        LegalChecklistItemDTO dto = validDto();
        dto.setChecklistItemId("CHK-1");
        dto.setStatus("COMPLETED");
        when(dao.findById("CHK-1")).thenReturn(new LegalChecklistItem());
        when(dao.update(any(LegalChecklistItem.class))).thenAnswer(inv -> inv.getArgument(0));

        LegalChecklistItemDTO result = service.update(dto);

        assertEquals("CHK-1", result.getChecklistItemId());
    }

    @Test
    void update_missingChecklistItemId_throwsValidationException() {
        LegalChecklistItemDTO dto = validDto();

        assertThrows(ValidationException.class, () -> service.update(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void update_nonExistentItem_throwsValidationException() throws Exception {
        LegalChecklistItemDTO dto = validDto();
        dto.setChecklistItemId("CHK-404");
        when(dao.findById("CHK-404")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    // ---------------------------------------------------------------
    // delete
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("CHK-1")).thenReturn(true);

        assertTrue(service.delete("CHK-1"));
    }

    @Test
    void delete_nullId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // findById
    // ---------------------------------------------------------------

    @Test
    void findById_found_returnsDto() throws Exception {
        LegalChecklistItem entity = new LegalChecklistItem();
        entity.setChecklistItemId("CHK-1");
        when(dao.findById("CHK-1")).thenReturn(entity);

        LegalChecklistItemDTO result = service.findById("CHK-1");

        assertNotNull(result);
        assertEquals("CHK-1", result.getChecklistItemId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("CHK-1")).thenReturn(null);

        assertNull(service.findById("CHK-1"));
    }

    // ---------------------------------------------------------------
    // findAll
    // ---------------------------------------------------------------

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        LegalChecklistItem e1 = new LegalChecklistItem();
        e1.setChecklistItemId("CHK-1");
        LegalChecklistItem e2 = new LegalChecklistItem();
        e2.setChecklistItemId("CHK-2");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<LegalChecklistItemDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
