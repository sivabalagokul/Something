package hlms.serviceimpl;

import hlms.dao.LegalVerificationDAO;
import hlms.dto.LegalVerificationDTO;
import hlms.entity.LegalVerification;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link LegalVerificationServiceImpl}.
 *
 * Key business rule under test (US-MRC-02/US-LT-03): a REJECTED decision
 * must always carry remarks; officerEmail is always mandatory.
 */
@ExtendWith(MockitoExtension.class)
class LegalVerificationServiceImplTest {

    @Mock
    private LegalVerificationDAO dao;

    private LegalVerificationServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new LegalVerificationServiceImpl(dao);
    }

    private LegalVerificationDTO validDto() {
        LegalVerificationDTO dto = new LegalVerificationDTO();
        dto.setAppId("APP-1");
        dto.setDecision("APPROVED");
        dto.setOfficerEmail("legal@example.com");
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_approved_delegatesToDaoAndDefaultsDecisionDate() throws Exception {
        LegalVerificationDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(null);
        when(dao.insert(any(LegalVerification.class))).thenAnswer(inv -> inv.getArgument(0));

        LegalVerificationDTO result = service.create(dto);

        assertNotNull(result.getDecisionDate());
        assertEquals("APPROVED", result.getDecision());
    }

    @Test
    void create_alreadyExists_throwsValidationException() throws Exception {
        LegalVerificationDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(new LegalVerification());

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        LegalVerificationDTO dto = validDto();
        dto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_invalidDecision_throwsValidationException() throws Exception {
        LegalVerificationDTO dto = validDto();
        dto.setDecision("MAYBE");
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_missingOfficerEmail_throwsValidationException() throws Exception {
        LegalVerificationDTO dto = validDto();
        dto.setOfficerEmail(null);
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_rejectedWithoutRemarks_throwsValidationException() throws Exception {
        LegalVerificationDTO dto = validDto();
        dto.setDecision("REJECTED");
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_rejectedWithRemarks_succeeds() throws Exception {
        LegalVerificationDTO dto = validDto();
        dto.setDecision("REJECTED");
        dto.setRemarks("Title deed mismatch.");
        when(dao.findById("APP-1")).thenReturn(null);
        when(dao.insert(any(LegalVerification.class))).thenAnswer(inv -> inv.getArgument(0));

        LegalVerificationDTO result = service.create(dto);

        assertEquals("REJECTED", result.getDecision());
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existing_delegatesToDao() throws Exception {
        LegalVerificationDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(new LegalVerification());
        when(dao.update(any(LegalVerification.class))).thenAnswer(inv -> inv.getArgument(0));

        LegalVerificationDTO result = service.update(dto);

        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void update_nonExistent_throwsValidationException() throws Exception {
        LegalVerificationDTO dto = validDto();
        when(dao.findById("APP-1")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    // ---------------------------------------------------------------
    // delete / findById / findAll
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("APP-1")).thenReturn(true);

        assertTrue(service.delete("APP-1"));
    }

    @Test
    void delete_nullAppId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null));
        verifyNoInteractions(dao);
    }

    @Test
    void findById_found_returnsDto() throws Exception {
        LegalVerification entity = new LegalVerification();
        entity.setAppId("APP-1");
        when(dao.findById("APP-1")).thenReturn(entity);

        LegalVerificationDTO result = service.findById("APP-1");

        assertNotNull(result);
        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("APP-1")).thenReturn(null);

        assertNull(service.findById("APP-1"));
    }

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        LegalVerification e1 = new LegalVerification();
        e1.setAppId("APP-1");
        LegalVerification e2 = new LegalVerification();
        e2.setAppId("APP-2");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<LegalVerificationDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
