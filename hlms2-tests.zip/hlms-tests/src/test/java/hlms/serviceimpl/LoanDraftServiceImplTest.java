package hlms.serviceimpl;

import hlms.dao.LoanDraftDAO;
import hlms.dto.LoanDraftDTO;
import hlms.entity.LoanDraft;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoanDraftServiceImplTest {

    @Mock
    private LoanDraftDAO dao;

    private LoanDraftServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new LoanDraftServiceImpl(dao);
    }

    private LoanDraftDTO validDto() {
        LoanDraftDTO dto = new LoanDraftDTO();
        dto.setUserEmail("customer@example.com");
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_minimalDraft_generatesIdAndDefaultsStep() throws Exception {
        LoanDraftDTO dto = validDto();
        when(dao.insert(any(LoanDraft.class))).thenAnswer(inv -> inv.getArgument(0));

        LoanDraftDTO result = service.create(dto);

        assertNotNull(result.getDraftId());
        assertTrue(result.getDraftId().startsWith("DRF-"));
        assertEquals(1, result.getCurrentStep());
        assertNotNull(result.getSavedAt());
    }

    @Test
    void create_explicitStep_isPreserved() throws Exception {
        LoanDraftDTO dto = validDto();
        dto.setCurrentStep(3);
        when(dao.insert(any(LoanDraft.class))).thenAnswer(inv -> inv.getArgument(0));

        LoanDraftDTO result = service.create(dto);

        assertEquals(3, result.getCurrentStep());
    }

    @Test
    void create_missingUserEmail_throwsValidationException() {
        LoanDraftDTO dto = validDto();
        dto.setUserEmail(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_zeroCurrentStep_throwsValidationException() {
        LoanDraftDTO dto = validDto();
        dto.setCurrentStep(0);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_negativeLoanAmount_throwsValidationException() {
        LoanDraftDTO dto = validDto();
        dto.setLoanAmount(new BigDecimal("-1"));

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_zeroTenureYears_throwsValidationException() {
        LoanDraftDTO dto = validDto();
        dto.setTenureYears(0);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existing_bumpsSavedAt() throws Exception {
        LoanDraftDTO dto = validDto();
        dto.setDraftId("DRF-1");
        when(dao.findById("DRF-1")).thenReturn(new LoanDraft());
        when(dao.update(any(LoanDraft.class))).thenAnswer(inv -> inv.getArgument(0));

        LoanDraftDTO result = service.update(dto);

        assertNotNull(result.getSavedAt());
    }

    @Test
    void update_missingDraftId_throwsValidationException() {
        LoanDraftDTO dto = validDto();

        assertThrows(ValidationException.class, () -> service.update(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void update_nonExistent_throwsValidationException() throws Exception {
        LoanDraftDTO dto = validDto();
        dto.setDraftId("DRF-404");
        when(dao.findById("DRF-404")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    // ---------------------------------------------------------------
    // delete / findById / findAll
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("DRF-1")).thenReturn(true);

        assertTrue(service.delete("DRF-1"));
    }

    @Test
    void delete_nullId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null));
        verifyNoInteractions(dao);
    }

    @Test
    void findById_found_returnsDto() throws Exception {
        LoanDraft entity = new LoanDraft();
        entity.setDraftId("DRF-1");
        when(dao.findById("DRF-1")).thenReturn(entity);

        LoanDraftDTO result = service.findById("DRF-1");

        assertNotNull(result);
        assertEquals("DRF-1", result.getDraftId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("DRF-1")).thenReturn(null);

        assertNull(service.findById("DRF-1"));
    }

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        LoanDraft e1 = new LoanDraft();
        e1.setDraftId("DRF-1");
        LoanDraft e2 = new LoanDraft();
        e2.setDraftId("DRF-2");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<LoanDraftDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
