package hlms.serviceimpl;

import hlms.dao.LoanProductDAO;
import hlms.dto.LoanProductDTO;
import hlms.entity.LoanProduct;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoanProductServiceImplTest {

    @Mock
    private LoanProductDAO dao;

    private LoanProductServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new LoanProductServiceImpl(dao);
    }

    private LoanProductDTO validDto() {
        LoanProductDTO dto = new LoanProductDTO();
        dto.setName("Home Purchase Loan");
        dto.setCategory("HOME_PURCHASE");
        dto.setInterestRate(new BigDecimal("8.5"));
        dto.setMaxTenureYears(20);
        dto.setMaxLtv(new BigDecimal("80"));
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_valid_generatesProductId() throws Exception {
        LoanProductDTO dto = validDto();
        when(dao.insert(any(LoanProduct.class))).thenAnswer(inv -> inv.getArgument(0));

        LoanProductDTO result = service.create(dto);

        assertNotNull(result.getProductId());
        assertTrue(result.getProductId().startsWith("PRD-"));
    }

    @Test
    void create_missingName_throwsValidationException() {
        LoanProductDTO dto = validDto();
        dto.setName(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_invalidCategory_throwsValidationException() {
        LoanProductDTO dto = validDto();
        dto.setCategory("PERSONAL_LOAN");

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_nonPositiveInterestRate_throwsValidationException() {
        LoanProductDTO dto = validDto();
        dto.setInterestRate(BigDecimal.ZERO);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_interestRateTooHigh_throwsValidationException() {
        LoanProductDTO dto = validDto();
        dto.setInterestRate(new BigDecimal("31"));

        ValidationException ex = assertThrows(ValidationException.class, () -> service.create(dto));
        assertTrue(ex.getMessage().contains("interestRate"));
        verifyNoInteractions(dao);
    }

    @Test
    void create_interestRateAtBoundary_succeeds() throws Exception {
        LoanProductDTO dto = validDto();
        dto.setInterestRate(new BigDecimal("30"));
        when(dao.insert(any(LoanProduct.class))).thenAnswer(inv -> inv.getArgument(0));

        LoanProductDTO result = service.create(dto);

        assertEquals(new BigDecimal("30"), result.getInterestRate());
    }

    @Test
    void create_nonPositiveTenure_throwsValidationException() {
        LoanProductDTO dto = validDto();
        dto.setMaxTenureYears(0);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_tenureExceeds30Years_throwsValidationException() {
        LoanProductDTO dto = validDto();
        dto.setMaxTenureYears(31);

        ValidationException ex = assertThrows(ValidationException.class, () -> service.create(dto));
        assertTrue(ex.getMessage().contains("maxTenureYears"));
        verifyNoInteractions(dao);
    }

    @Test
    void create_missingMaxLtv_throwsValidationException() {
        LoanProductDTO dto = validDto();
        dto.setMaxLtv(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existing_delegatesToDao() throws Exception {
        LoanProductDTO dto = validDto();
        dto.setProductId("PRD-1");
        when(dao.findById("PRD-1")).thenReturn(new LoanProduct());
        when(dao.update(any(LoanProduct.class))).thenAnswer(inv -> inv.getArgument(0));

        LoanProductDTO result = service.update(dto);

        assertEquals("PRD-1", result.getProductId());
    }

    @Test
    void update_missingProductId_throwsValidationException() {
        LoanProductDTO dto = validDto();

        assertThrows(ValidationException.class, () -> service.update(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void update_nonExistent_throwsValidationException() throws Exception {
        LoanProductDTO dto = validDto();
        dto.setProductId("PRD-404");
        when(dao.findById("PRD-404")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    // ---------------------------------------------------------------
    // delete / findById / findAll
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("PRD-1")).thenReturn(true);

        assertTrue(service.delete("PRD-1"));
    }

    @Test
    void delete_nullId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null));
        verifyNoInteractions(dao);
    }

    @Test
    void findById_found_returnsDto() throws Exception {
        LoanProduct entity = new LoanProduct();
        entity.setProductId("PRD-1");
        when(dao.findById("PRD-1")).thenReturn(entity);

        LoanProductDTO result = service.findById("PRD-1");

        assertNotNull(result);
        assertEquals("PRD-1", result.getProductId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("PRD-1")).thenReturn(null);

        assertNull(service.findById("PRD-1"));
    }

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        LoanProduct e1 = new LoanProduct();
        e1.setProductId("PRD-1");
        LoanProduct e2 = new LoanProduct();
        e2.setProductId("PRD-2");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<LoanProductDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
