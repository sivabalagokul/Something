package hlms.serviceimpl;

import hlms.dao.NotificationDAO;
import hlms.dto.NotificationDTO;
import hlms.entity.Notification;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationServiceImplTest {

    @Mock
    private NotificationDAO dao;

    private NotificationServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new NotificationServiceImpl(dao);
    }

    private NotificationDTO validDto() {
        NotificationDTO dto = new NotificationDTO();
        dto.setUserEmail("customer@example.com");
        dto.setTitle("Application update");
        dto.setBody("Your application has moved to the next stage.");
        dto.setChannels(new String[]{"EMAIL", "SMS"});
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_valid_generatesIdAndDefaultsIsReadAndCreatedAt() throws Exception {
        NotificationDTO dto = validDto();
        when(dao.insert(any(Notification.class))).thenAnswer(inv -> inv.getArgument(0));

        NotificationDTO result = service.create(dto);

        assertNotNull(result.getNotificationId());
        assertTrue(result.getNotificationId().startsWith("NTF-"));
        assertEquals(Boolean.FALSE, result.getIsRead());
        assertNotNull(result.getCreatedAt());
    }

    @Test
    void create_missingUserEmail_throwsValidationException() {
        NotificationDTO dto = validDto();
        dto.setUserEmail(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_missingTitle_throwsValidationException() {
        NotificationDTO dto = validDto();
        dto.setTitle(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_missingBody_throwsValidationException() {
        NotificationDTO dto = validDto();
        dto.setBody(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_noChannels_throwsValidationException() {
        NotificationDTO dto = validDto();
        dto.setChannels(new String[0]);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_nullChannels_throwsValidationException() {
        NotificationDTO dto = validDto();
        dto.setChannels(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_unsupportedChannel_throwsValidationException() {
        NotificationDTO dto = validDto();
        dto.setChannels(new String[]{"FAX"});

        ValidationException ex = assertThrows(ValidationException.class, () -> service.create(dto));
        assertTrue(ex.getMessage().contains("Unsupported channel"));
        verifyNoInteractions(dao);
    }

    @Test
    void create_singleValidChannel_succeeds() throws Exception {
        NotificationDTO dto = validDto();
        dto.setChannels(new String[]{"INAPP"});
        when(dao.insert(any(Notification.class))).thenAnswer(inv -> inv.getArgument(0));

        NotificationDTO result = service.create(dto);

        assertArrayEquals(new String[]{"INAPP"}, result.getChannels());
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existing_delegatesToDao() throws Exception {
        NotificationDTO dto = validDto();
        dto.setNotificationId("NTF-1");
        when(dao.findById("NTF-1")).thenReturn(new Notification());
        when(dao.update(any(Notification.class))).thenAnswer(inv -> inv.getArgument(0));

        NotificationDTO result = service.update(dto);

        assertEquals("NTF-1", result.getNotificationId());
    }

    @Test
    void update_missingNotificationId_throwsValidationException() {
        NotificationDTO dto = validDto();

        assertThrows(ValidationException.class, () -> service.update(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void update_nonExistent_throwsValidationException() throws Exception {
        NotificationDTO dto = validDto();
        dto.setNotificationId("NTF-404");
        when(dao.findById("NTF-404")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    // ---------------------------------------------------------------
    // delete / findById / findAll
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("NTF-1")).thenReturn(true);

        assertTrue(service.delete("NTF-1"));
    }

    @Test
    void delete_nullId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null));
        verifyNoInteractions(dao);
    }

    @Test
    void findById_found_returnsDto() throws Exception {
        Notification entity = new Notification();
        entity.setNotificationId("NTF-1");
        when(dao.findById("NTF-1")).thenReturn(entity);

        NotificationDTO result = service.findById("NTF-1");

        assertNotNull(result);
        assertEquals("NTF-1", result.getNotificationId());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("NTF-1")).thenReturn(null);

        assertNull(service.findById("NTF-1"));
    }

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        Notification e1 = new Notification();
        e1.setNotificationId("NTF-1");
        Notification e2 = new Notification();
        e2.setNotificationId("NTF-2");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<NotificationDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
