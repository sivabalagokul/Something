package hlms.serviceimpl;

import hlms.dao.RolePermissionDAO;
import hlms.dto.RolePermissionDTO;
import hlms.entity.RolePermission;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link RolePermissionServiceImpl}.
 *
 * Key business rule under test (US-UM-01): canView must be true whenever
 * canAdd/canEdit/canDelete is granted, and create()/update() enforce
 * existence semantics against the composite (role, module) key.
 */
@ExtendWith(MockitoExtension.class)
class RolePermissionServiceImplTest {

    @Mock
    private RolePermissionDAO dao;

    private RolePermissionServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new RolePermissionServiceImpl(dao);
    }

    private RolePermissionDTO validDto() {
        RolePermissionDTO dto = new RolePermissionDTO();
        dto.setRole("admin");
        dto.setModule("LOAN_APPLICATION");
        dto.setCanView(true);
        return dto;
    }

    // ---------------------------------------------------------------
    // create
    // ---------------------------------------------------------------

    @Test
    void create_valid_delegatesToDao() throws Exception {
        RolePermissionDTO dto = validDto();
        when(dao.findById("admin", "LOAN_APPLICATION")).thenReturn(null);
        when(dao.insert(any(RolePermission.class))).thenAnswer(inv -> inv.getArgument(0));

        RolePermissionDTO result = service.create(dto);

        assertEquals("admin", result.getRole());
        assertTrue(result.getCanView());
    }

    @Test
    void create_defaultsNullFlagsToFalse() throws Exception {
        RolePermissionDTO dto = validDto();
        when(dao.findById("admin", "LOAN_APPLICATION")).thenReturn(null);
        when(dao.insert(any(RolePermission.class))).thenAnswer(inv -> inv.getArgument(0));

        RolePermissionDTO result = service.create(dto);

        assertFalse(result.getCanAdd());
        assertFalse(result.getCanEdit());
        assertFalse(result.getCanDelete());
    }

    @Test
    void create_alreadyExists_throwsValidationException() throws Exception {
        RolePermissionDTO dto = validDto();
        when(dao.findById("admin", "LOAN_APPLICATION")).thenReturn(new RolePermission());

        assertThrows(ValidationException.class, () -> service.create(dto));
        verify(dao, never()).insert(any());
    }

    @Test
    void create_invalidRole_throwsValidationException() {
        RolePermissionDTO dto = validDto();
        dto.setRole("superuser");

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_missingModule_throwsValidationException() {
        RolePermissionDTO dto = validDto();
        dto.setModule(null);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_canAddWithoutCanView_throwsValidationException() {
        RolePermissionDTO dto = validDto();
        dto.setCanView(false);
        dto.setCanAdd(true);

        ValidationException ex = assertThrows(ValidationException.class, () -> service.create(dto));
        assertTrue(ex.getMessage().contains("canView"));
        verifyNoInteractions(dao);
    }

    @Test
    void create_canEditWithoutCanView_throwsValidationException() {
        RolePermissionDTO dto = validDto();
        dto.setCanView(null);
        dto.setCanEdit(true);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_canDeleteWithoutCanView_throwsValidationException() {
        RolePermissionDTO dto = validDto();
        dto.setCanView(false);
        dto.setCanDelete(true);

        assertThrows(ValidationException.class, () -> service.create(dto));
        verifyNoInteractions(dao);
    }

    @Test
    void create_fullPermissionsWithView_succeeds() throws Exception {
        RolePermissionDTO dto = validDto();
        dto.setCanAdd(true);
        dto.setCanEdit(true);
        dto.setCanDelete(true);
        when(dao.findById("admin", "LOAN_APPLICATION")).thenReturn(null);
        when(dao.insert(any(RolePermission.class))).thenAnswer(inv -> inv.getArgument(0));

        RolePermissionDTO result = service.create(dto);

        assertTrue(result.getCanAdd());
        assertTrue(result.getCanEdit());
        assertTrue(result.getCanDelete());
    }

    // ---------------------------------------------------------------
    // update
    // ---------------------------------------------------------------

    @Test
    void update_existingRow_delegatesToDao() throws Exception {
        RolePermissionDTO dto = validDto();
        when(dao.findById("admin", "LOAN_APPLICATION")).thenReturn(new RolePermission());
        when(dao.update(any(RolePermission.class))).thenAnswer(inv -> inv.getArgument(0));

        RolePermissionDTO result = service.update(dto);

        assertEquals("admin", result.getRole());
    }

    @Test
    void update_nonExistentRow_throwsValidationException() throws Exception {
        RolePermissionDTO dto = validDto();
        when(dao.findById("admin", "LOAN_APPLICATION")).thenReturn(null);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verify(dao, never()).update(any());
    }

    @Test
    void update_violatesViewRule_throwsValidationException() {
        RolePermissionDTO dto = validDto();
        dto.setCanView(false);
        dto.setCanEdit(true);

        assertThrows(ValidationException.class, () -> service.update(dto));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // delete
    // ---------------------------------------------------------------

    @Test
    void delete_valid_delegatesToDao() throws Exception {
        when(dao.delete("admin", "LOAN_APPLICATION")).thenReturn(true);

        assertTrue(service.delete("admin", "LOAN_APPLICATION"));
    }

    @Test
    void delete_missingRole_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete(null, "LOAN_APPLICATION"));
        verifyNoInteractions(dao);
    }

    @Test
    void delete_missingModule_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.delete("admin", null));
        verifyNoInteractions(dao);
    }

    // ---------------------------------------------------------------
    // findById
    // ---------------------------------------------------------------

    @Test
    void findById_found_returnsDto() throws Exception {
        RolePermission entity = new RolePermission();
        entity.setRole("admin");
        entity.setModule("LOAN_APPLICATION");
        when(dao.findById("admin", "LOAN_APPLICATION")).thenReturn(entity);

        RolePermissionDTO result = service.findById("admin", "LOAN_APPLICATION");

        assertNotNull(result);
        assertEquals("admin", result.getRole());
    }

    @Test
    void findById_notFound_returnsNull() throws Exception {
        when(dao.findById("admin", "LOAN_APPLICATION")).thenReturn(null);

        assertNull(service.findById("admin", "LOAN_APPLICATION"));
    }

    // ---------------------------------------------------------------
    // findAll
    // ---------------------------------------------------------------

    @Test
    void findAll_mapsAllEntitiesToDtos() throws Exception {
        RolePermission e1 = new RolePermission();
        e1.setRole("admin");
        e1.setModule("MOD_A");
        RolePermission e2 = new RolePermission();
        e2.setRole("customer");
        e2.setModule("MOD_B");
        when(dao.findAll()).thenReturn(List.of(e1, e2));

        List<RolePermissionDTO> result = service.findAll();

        assertEquals(2, result.size());
    }

    @Test
    void findAll_daoException_propagates() throws Exception {
        when(dao.findAll()).thenThrow(new DAOException("db down"));

        assertThrows(DAOException.class, () -> service.findAll());
    }
}
