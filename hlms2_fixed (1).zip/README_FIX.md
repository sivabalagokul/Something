# Fix: recurring `violates check constraint` errors

## Update (2nd pass)

The same pattern hit a second table: `auction_case_stage_check` failed
on `stage = 'NOTICE_ISSUED'` for the exact same reason as the
`app_user` one below — the entity-layer demo had been inserting the
old-style value `"Notice Issued"` (which the DB constraint still
allowed), while `AuctionCaseServiceImpl` sends the canonical
`"NOTICE_ISSUED"`, which the constraint rejected.

Rather than fix these one table at a time as they surface, run
**`db/fix_check_constraints_full.sql`** — it updates every table in
the schema that has this same kind of stale check constraint (17
constraints across `app_user`, `role_permission`,
`application_document`, `auction_case`, `bank_office_decision`,
`disbursement`, `emi_installment`, `insurance_policy`,
`legal_checklist_item`, `legal_notice`, `legal_verification`,
`loan_application`, `customer_employment_profile`, `loan_product`,
`post_disbursement_document`, `service_request`, `audit_log`) in one
pass, based on each `*ServiceImpl`'s `VALID_*` list. The earlier
`fix_app_user_role_check.sql` is now superseded by this file (its fix
is included in it).

`hlms2/main/HlmsFullDemoMain.java` was also updated so the
entity-layer `AuctionCase` demo uses `"NOTICE_ISSUED"` instead of
`"Notice Issued"`, matching the service layer and the new constraint.

Run it the same way:
```bash
psql -U <your_user> -d <your_database> -f db/fix_check_constraints_full.sql
```
If it fails partway through with another check-constraint error,
that means a leftover row from an earlier aborted run has an
old-style value in that column — see the note at the bottom of the
SQL file for how to find and clear it, then re-run.

---

## Original notes: `app_user_role_check` constraint violation

## What the error means

```
ERROR: new row for relation "app_user" violates check constraint "app_user_role_check"
Detail: Failing row contains (demo.customer@hlms.local, Demo Customer, 9000000001, ..., CUSTOMER, ...)
```

Part 1 of the demo (`runEntityLayerDemo`) inserted a user with role
`"customer"` (lowercase) and it worked. Part 2 (`runServiceLayerDemo`)
inserted a user with role `"CUSTOMER"` (uppercase, produced by
`AppUserServiceImpl`, which enforces the fixed role enum from
US-UM-02: `ADMIN, CUSTOMER, LOAN_OFFICER, LEGAL_OFFICER, ENGINEER, MANAGER`)
and it failed.

That's the tell: the **database's check constraint** was written
against the old, lowercase role scheme (`'customer'`, `'bankoffice'`,
...) and was never updated when the Java code moved to the new
uppercase role enum. It's a schema/code mismatch, not a bug in your
Java classes.

## What was changed

1. **`db/fix_app_user_role_check.sql`** (new) — drops the stale
   constraint and recreates it to allow the roles the app actually
   uses: `ADMIN`, `CUSTOMER`, `LOAN_OFFICER`, `LEGAL_OFFICER`,
   `ENGINEER`, `MANAGER`.
2. **`hlms2/main/HlmsFullDemoMain.java`** — updated the two
   entity-layer inserts that were still using the legacy lowercase
   values (`"customer"` → `"CUSTOMER"`, `"bankoffice"` →
   `"LOAN_OFFICER"`) so Part 1 and Part 2 of the demo use the same
   canonical role values and stay consistent going forward.
   (`RolePermission.role` values were left untouched — that column
   has no check constraint, it's a free-form module/permission
   mapping, not the `app_user.role` enum.)

## How to run

1. **Run the SQL fix first**, against the same Postgres database your
   app connects to (check `DBConnection`/your `.properties` file for
   host/db name):
   ```bash
   psql -U <your_user> -d <your_database> -f db/fix_app_user_role_check.sql
   ```
   Or open `db/fix_app_user_role_check.sql` in your SQL client
   (pgAdmin, DBeaver, Eclipse Data Source Explorer, etc.) and execute
   it.

2. **If you already have leftover rows** from previous failed test
   runs with old-style values, uncomment the two `UPDATE` lines near
   the bottom of the script before running it, so those rows also
   satisfy the new constraint.

3. **Re-run `HlmsFullDemoMain`** from Eclipse as before. Both
   `runEntityLayerDemo()` and `runServiceLayerDemo()` should now
   complete and print `=== Done. ===`.

If you hit the same kind of error on a different table later, it's
worth checking the same way: compare what value the Java code is
actually sending against what the table's `CHECK` constraint allows
(`\d app_user` in `psql`, or the constraint's definition in
`information_schema.check_constraints`).
