-- =====================================================================
-- Fix for: ERROR: new row for relation "app_user" violates check
--          constraint "app_user_role_check"
--
-- ROOT CAUSE
-- ----------
-- The app_user table's CHECK constraint was written against an old,
-- lowercase role scheme (e.g. 'customer', 'bankoffice'). The Java code
-- (AppUserServiceImpl.VALID_ROLES, per user story US-UM-02) now uses a
-- fixed, UPPERCASE role enum:
--     ADMIN, CUSTOMER, LOAN_OFFICER, LEGAL_OFFICER, ENGINEER, MANAGER
-- The database constraint was never updated to match, so any insert
-- with role = 'CUSTOMER' (uppercase) is rejected while the old
-- lowercase 'customer' still slips through.
--
-- FIX
-- ---
-- Drop the stale constraint and recreate it against the canonical
-- uppercase role list that the application actually uses.
-- =====================================================================

BEGIN;

ALTER TABLE app_user DROP CONSTRAINT IF EXISTS app_user_role_check;

ALTER TABLE app_user
    ADD CONSTRAINT app_user_role_check
    CHECK (role IN ('ADMIN', 'CUSTOMER', 'LOAN_OFFICER', 'LEGAL_OFFICER', 'ENGINEER', 'MANAGER'));

-- Optional: if you already have old rows with lowercase/legacy values
-- ('customer', 'bankoffice', etc.) left over from earlier test runs,
-- normalize them so they satisfy the new constraint too:
-- UPDATE app_user SET role = 'CUSTOMER'     WHERE role = 'customer';
-- UPDATE app_user SET role = 'LOAN_OFFICER' WHERE role = 'bankoffice';

COMMIT;
