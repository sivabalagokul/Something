-- =====================================================================
-- Fix for repeated "violates check constraint" errors
--
-- ROOT CAUSE (same pattern every time)
-- -------------------------------------------------------------------
-- Each *ServiceImpl class defines a canonical, fixed vocabulary for
-- its status/type/stage/role columns (e.g. AuctionCaseServiceImpl.
-- VALID_STAGES = NOTICE_ISSUED, POSSESSION_TAKEN, ...). The database
-- CHECK constraints on those columns were written earlier, against
-- older/looser values (e.g. 'Notice Issued' with spaces and mixed
-- case), and were never updated when the service layer's enums were
-- finalized. Every table below can throw the same class of error the
-- first time the *service* layer (not the raw entity/DAO demo) tries
-- to insert its canonical value.
--
-- This script brings EVERY such constraint in line with what the
-- service layer actually sends, in one pass, instead of fixing them
-- one crash at a time.
--
-- NOTE: constraint names below use Postgres's default auto-generated
-- naming convention (<table>_<column>_check), which is what the two
-- constraints we already hit (app_user_role_check,
-- auction_case_stage_check) followed. If your DB has custom names,
-- `DROP CONSTRAINT IF EXISTS` on the guessed name will just no-op --
-- run `\d <table>` in psql to find the real name and adjust.
-- =====================================================================

BEGIN;

-- 1. app_user.role
ALTER TABLE app_user DROP CONSTRAINT IF EXISTS app_user_role_check;
ALTER TABLE app_user ADD CONSTRAINT app_user_role_check
    CHECK (role IN ('ADMIN', 'CUSTOMER', 'LOAN_OFFICER', 'LEGAL_OFFICER', 'ENGINEER', 'MANAGER'));

-- 2. role_permission.role
ALTER TABLE role_permission DROP CONSTRAINT IF EXISTS role_permission_role_check;
ALTER TABLE role_permission ADD CONSTRAINT role_permission_role_check
    CHECK (role IN ('ADMIN', 'CUSTOMER', 'LOAN_OFFICER', 'LEGAL_OFFICER', 'ENGINEER', 'MANAGER'));

-- 3. application_document.doc_type / verification_status
ALTER TABLE application_document DROP CONSTRAINT IF EXISTS application_document_doc_type_check;
ALTER TABLE application_document ADD CONSTRAINT application_document_doc_type_check
    CHECK (doc_type IN ('INCOME_PROOF', 'EMPLOYMENT_PROOF', 'PROPERTY_DOCUMENT', 'IDENTITY_PROOF', 'ADDRESS_PROOF', 'BANK_STATEMENT'));

ALTER TABLE application_document DROP CONSTRAINT IF EXISTS application_document_verification_status_check;
ALTER TABLE application_document ADD CONSTRAINT application_document_verification_status_check
    CHECK (verification_status IS NULL OR verification_status IN ('PENDING', 'VERIFIED', 'REJECTED'));

-- 4. auction_case.stage
ALTER TABLE auction_case DROP CONSTRAINT IF EXISTS auction_case_stage_check;
ALTER TABLE auction_case ADD CONSTRAINT auction_case_stage_check
    CHECK (stage IN ('NOTICE_ISSUED', 'POSSESSION_TAKEN', 'AUCTION_SCHEDULED', 'AUCTION_COMPLETED', 'RECOVERY_CLOSED'));

-- 5. bank_office_decision.decision
ALTER TABLE bank_office_decision DROP CONSTRAINT IF EXISTS bank_office_decision_decision_check;
ALTER TABLE bank_office_decision ADD CONSTRAINT bank_office_decision_decision_check
    CHECK (decision IN ('APPROVED', 'CONDITIONALLY_APPROVED', 'REJECTED'));

-- 6. disbursement.mode
ALTER TABLE disbursement DROP CONSTRAINT IF EXISTS disbursement_mode_check;
ALTER TABLE disbursement ADD CONSTRAINT disbursement_mode_check
    CHECK (mode IN ('NEFT', 'RTGS', 'CHEQUE', 'UPI'));

-- 7. emi_installment.status
ALTER TABLE emi_installment DROP CONSTRAINT IF EXISTS emi_installment_status_check;
ALTER TABLE emi_installment ADD CONSTRAINT emi_installment_status_check
    CHECK (status IS NULL OR status IN ('PENDING', 'PAID', 'OVERDUE'));

-- 8. insurance_policy.policy_type / status
ALTER TABLE insurance_policy DROP CONSTRAINT IF EXISTS insurance_policy_policy_type_check;
ALTER TABLE insurance_policy ADD CONSTRAINT insurance_policy_policy_type_check
    CHECK (policy_type IN ('LIFE', 'PROPERTY', 'TERM'));

ALTER TABLE insurance_policy DROP CONSTRAINT IF EXISTS insurance_policy_status_check;
ALTER TABLE insurance_policy ADD CONSTRAINT insurance_policy_status_check
    CHECK (status IS NULL OR status IN ('ACTIVE', 'EXPIRED', 'CANCELLED'));

-- 9. legal_checklist_item.status
ALTER TABLE legal_checklist_item DROP CONSTRAINT IF EXISTS legal_checklist_item_status_check;
ALTER TABLE legal_checklist_item ADD CONSTRAINT legal_checklist_item_status_check
    CHECK (status IS NULL OR status IN ('PENDING', 'COMPLETED', 'NOT_APPLICABLE'));

-- 10. legal_notice.notice_type / status
ALTER TABLE legal_notice DROP CONSTRAINT IF EXISTS legal_notice_notice_type_check;
ALTER TABLE legal_notice ADD CONSTRAINT legal_notice_notice_type_check
    CHECK (notice_type IN ('DEFAULT_NOTICE', 'DEMAND_NOTICE', 'AUCTION_NOTICE', 'LEGAL_NOTICE'));

ALTER TABLE legal_notice DROP CONSTRAINT IF EXISTS legal_notice_status_check;
ALTER TABLE legal_notice ADD CONSTRAINT legal_notice_status_check
    CHECK (status IS NULL OR status IN ('DRAFT', 'SENT', 'DELIVERED', 'FAILED'));

-- 11. legal_verification.decision
ALTER TABLE legal_verification DROP CONSTRAINT IF EXISTS legal_verification_decision_check;
ALTER TABLE legal_verification ADD CONSTRAINT legal_verification_decision_check
    CHECK (decision IS NULL OR decision IN ('PENDING', 'APPROVED', 'REJECTED'));

-- 12. loan_application.status / employment_type
ALTER TABLE loan_application DROP CONSTRAINT IF EXISTS loan_application_status_check;
ALTER TABLE loan_application ADD CONSTRAINT loan_application_status_check
    CHECK (status IS NULL OR status IN ('DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'DOCUMENT_PENDING', 'LEGAL_VERIFICATION',
                                         'APPROVED', 'CONDITIONALLY_APPROVED', 'REJECTED', 'DISBURSED', 'CLOSED', 'DEFAULTED'));

ALTER TABLE loan_application DROP CONSTRAINT IF EXISTS loan_application_employment_type_check;
ALTER TABLE loan_application ADD CONSTRAINT loan_application_employment_type_check
    CHECK (employment_type IS NULL OR employment_type IN ('SALARIED', 'SELF_EMPLOYED', 'BUSINESS'));

-- 13. customer_employment_profile.employment_type
ALTER TABLE customer_employment_profile DROP CONSTRAINT IF EXISTS customer_employment_profile_employment_type_check;
ALTER TABLE customer_employment_profile ADD CONSTRAINT customer_employment_profile_employment_type_check
    CHECK (employment_type IN ('SALARIED', 'SELF_EMPLOYED', 'BUSINESS'));

-- 14. loan_product.category
ALTER TABLE loan_product DROP CONSTRAINT IF EXISTS loan_product_category_check;
ALTER TABLE loan_product ADD CONSTRAINT loan_product_category_check
    CHECK (category IN ('HOME_PURCHASE', 'CONSTRUCTION', 'RENOVATION', 'PLOT_LOAN', 'BALANCE_TRANSFER', 'TOP_UP'));

-- 15. post_disbursement_document.doc_type / status
ALTER TABLE post_disbursement_document DROP CONSTRAINT IF EXISTS post_disbursement_document_doc_type_check;
ALTER TABLE post_disbursement_document ADD CONSTRAINT post_disbursement_document_doc_type_check
    CHECK (doc_type IN ('INSPECTION_REPORT', 'APPROVAL_SIGNOFF', 'NOC', 'PROPERTY_UPDATE', 'OTHER'));

ALTER TABLE post_disbursement_document DROP CONSTRAINT IF EXISTS post_disbursement_document_status_check;
ALTER TABLE post_disbursement_document ADD CONSTRAINT post_disbursement_document_status_check
    CHECK (status IS NULL OR status IN ('PENDING', 'APPROVED', 'REJECTED'));

-- 16. service_request.request_type / status
ALTER TABLE service_request DROP CONSTRAINT IF EXISTS service_request_request_type_check;
ALTER TABLE service_request ADD CONSTRAINT service_request_request_type_check
    CHECK (request_type IN ('ENGINEER_INSPECTION', 'DOCUMENT_EXCHANGE', 'NOC_REQUEST', 'FORECLOSURE', 'GENERAL_QUERY'));

ALTER TABLE service_request DROP CONSTRAINT IF EXISTS service_request_status_check;
ALTER TABLE service_request ADD CONSTRAINT service_request_status_check
    CHECK (status IS NULL OR status IN ('SUBMITTED', 'ASSIGNED', 'IN_PROGRESS', 'COMPLETED', 'REJECTED'));

-- 17. audit_log.action
ALTER TABLE audit_log DROP CONSTRAINT IF EXISTS audit_log_action_check;
ALTER TABLE audit_log ADD CONSTRAINT audit_log_action_check
    CHECK (action IN ('CREATE', 'UPDATE', 'DELETE', 'APPROVE', 'REJECT', 'LOGIN', 'LOGOUT'));

COMMIT;

-- If COMMIT fails with another "violates check constraint" error, it
-- means there is leftover data in that table (from an earlier aborted
-- run) whose value doesn't match the new list above. Find it with:
--   SELECT DISTINCT <column> FROM <table>;
-- then either delete/update that row or add the value to the CHECK
-- list, and re-run.
