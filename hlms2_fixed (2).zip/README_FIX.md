# Fix: `app_user_role_check` constraint violation (code-side fix)

## Root cause

Your real schema (`hlms_schema_corrected.sql`) defines the role enum
as:

```sql
role VARCHAR(30) NOT NULL CHECK (role IN (
    'customer', 'legal', 'bankoffice', 'bidder', 'admin'
))
```

But `AppUserServiceImpl` had its own, different role list:
`ADMIN, CUSTOMER, LOAN_OFFICER, LEGAL_OFFICER, ENGINEER, MANAGER`,
and it uppercased every role before saving. Since `'CUSTOMER'` isn't
in the schema's allowed set, the insert was rejected — the DB was
right, the service layer was out of sync with it.

This fix changes the **Java code only**; your schema/constraints are
untouched.

## What changed

**`hlms2/serviceimpl/AppUserServiceImpl.java`**
- `VALID_ROLES` now matches the schema exactly: `customer`, `legal`,
  `bankoffice`, `bidder`, `admin`.
- `register()` now defaults to and normalizes roles to **lowercase**
  (was uppercase) before validating/saving.
- `assignRole()` now normalizes the incoming role to lowercase
  *before* validating it (previously it validated the raw, possibly
  differently-cased input, which would have rejected e.g. `"Admin"`
  even though `"admin"` is valid).

**`hlms2/main/HlmsFullDemoMain.java`**
- All `AppUser`/`AppUserDTO` role values updated to the schema's
  actual values:
  - `"CUSTOMER"` → `"customer"`
  - `"LOAN_OFFICER"` → `"bankoffice"`
  - the demo "bidder" user now uses the dedicated `"bidder"` role
    (previously it incorrectly reused `"CUSTOMER"`)
- `RolePermission.role` values (`"customer"`, `"bankoffice"`) were
  already correct and untouched — that table has no check constraint
  in your schema.

## How to run

No database changes needed. Just recompile/re-run:

1. Import/replace the two updated files in your Eclipse project:
   - `hlms2/serviceimpl/AppUserServiceImpl.java`
   - `hlms2/main/HlmsFullDemoMain.java`
2. Run `HlmsFullDemoMain` as before.

Both `runEntityLayerDemo()` and `runServiceLayerDemo()` should now
insert successfully and print `=== Done. ===`, since every role value
the app sends now matches what `app_user_role_check` actually allows.
