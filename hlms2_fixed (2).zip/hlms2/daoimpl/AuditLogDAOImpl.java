package hlms.daoimpl;

import hlms.dao.AuditLogDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;
import org.postgresql.util.PGobject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of AuditLogDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class AuditLogDAOImpl implements AuditLogDAO {

    private static final String INSERT_SQL =
            "INSERT INTO audit_log (entity_type, entity_id, action, actor_email, before_data, after_data, created_at) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING log_id";

    private static final String UPDATE_SQL =
            "UPDATE audit_log SET entity_type = ?, entity_id = ?, action = ?, actor_email = ?, before_data = ?, after_data = ?, created_at = ? WHERE log_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM audit_log WHERE log_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM audit_log WHERE log_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM audit_log";

    @Override
    public AuditLog insert(AuditLog entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getEntityType());
            ps.setObject(2, entity.getEntityId());
            ps.setObject(3, entity.getAction());
            ps.setObject(4, entity.getActor() == null ? null : entity.getActor().getEmail());
            setJsonb(ps, 5, entity.getBeforeData());
            setJsonb(ps, 6, entity.getAfterData());
            ps.setObject(7, entity.getCreatedAt());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    entity.setLogId(rs.getLong(1));
                }
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert AuditLog: " + e.getMessage(), e);
        }
    }

    @Override
    public AuditLog update(AuditLog entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getEntityType());
            ps.setObject(2, entity.getEntityId());
            ps.setObject(3, entity.getAction());
            ps.setObject(4, entity.getActor() == null ? null : entity.getActor().getEmail());
            setJsonb(ps, 5, entity.getBeforeData());
            setJsonb(ps, 6, entity.getAfterData());
            ps.setObject(7, entity.getCreatedAt());
            ps.setObject(8, entity.getLogId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No AuditLog found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update AuditLog: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(Long logId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, logId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete AuditLog: " + e.getMessage(), e);
        }
    }

    @Override
    public AuditLog findById(Long logId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, logId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch AuditLog: " + e.getMessage(), e);
        }
    }

    @Override
    public List<AuditLog> findAll() throws DAOException {
        List<AuditLog> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch AuditLog list: " + e.getMessage(), e);
        }
    }

    /**
     * Binds a JSON string to a jsonb column. The PostgreSQL JDBC driver
     * cannot implicitly cast a plain String/VARCHAR to jsonb, so the value
     * must be wrapped in a PGobject with an explicit "jsonb" type -- passing
     * a raw String via setObject(...) throws "column is of type jsonb but
     * expression is of type character varying".
     */
    private static void setJsonb(PreparedStatement ps, int index, String json) throws SQLException {
        if (json == null) {
            ps.setNull(index, Types.OTHER);
            return;
        }
        PGobject pgObject = new PGobject();
        pgObject.setType("jsonb");
        pgObject.setValue(json);
        ps.setObject(index, pgObject);
    }

    /**
     * Maps one ResultSet row to a AuditLog. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private AuditLog mapRow(ResultSet rs) throws SQLException {
        AuditLog entity = new AuditLog();
        entity.setLogId(rs.getObject("log_id") == null ? null : rs.getLong("log_id"));
        entity.setEntityType(rs.getString("entity_type"));
        entity.setEntityId(rs.getString("entity_id"));
        entity.setAction(rs.getString("action"));
        String actorRef = rs.getString("actor_email");
        if (actorRef != null) {
            AppUser actor = new AppUser();
            actor.setEmail(actorRef);
            entity.setActor(actor);
        }
        entity.setBeforeData(rs.getString("before_data"));
        entity.setAfterData(rs.getString("after_data"));
        entity.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        return entity;
    }
}
