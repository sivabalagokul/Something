package hlms.service;

import hlms.dto.AppUserDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for AppUser. Sits between Main (or any other caller) and
 * AppUserDAO: everything in and out of this layer is a AppUserDTO, never a
 * hlms.entity.AppUser. Raw passwords are accepted only by the dedicated
 * register/login/changePassword/resetPassword methods below and are never
 * part of AppUserDTO (see US-UM-02, US-UM-03, US-UM-04).
 */
public interface AppUserService {

    /** US-UM-02: Customer registration. Validates + hashes rawPassword, never returns it. */
    AppUserDTO register(AppUserDTO dto, String rawPassword) throws DAOException;

    /** US-UM-03: Authenticates email + password. Returns the user on success. */
    AppUserDTO login(String email, String rawPassword) throws DAOException;

    /** US-UM-03: Verifies a previously generated OTP for a login attempt. */
    boolean verifyOtp(String email, String otp, String expectedOtp) throws DAOException;

    /** US-UM-04: Change password while logged in (knows the current password). */
    AppUserDTO changePassword(String email, String oldPassword, String newPassword) throws DAOException;

    /** US-UM-04: Reset password via forgot-password flow (identity already verified via OTP). */
    AppUserDTO resetPassword(String email, String newPassword) throws DAOException;

    /** US-UM-01: Assign/change a user's role. */
    AppUserDTO assignRole(String email, String role) throws DAOException;

    /** US-UM-05: Update profile fields (name, mobile, preferences) - never touches the password. */
    AppUserDTO update(AppUserDTO dto) throws DAOException;

    boolean delete(String email) throws DAOException;

    AppUserDTO findById(String email) throws DAOException;

    List<AppUserDTO> findAll() throws DAOException;
}
