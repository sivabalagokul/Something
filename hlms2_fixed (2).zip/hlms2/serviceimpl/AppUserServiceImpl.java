package hlms.serviceimpl;

import hlms.dao.AppUserDAO;
import hlms.daoimpl.AppUserDAOImpl;
import hlms.dto.AppUserDTO;
import hlms.entity.*;
import hlms.service.AppUserService;
import hlms.util.DAOException;
import hlms.util.PasswordUtil;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of AppUserService. Converts AppUserDTO <-> hlms.entity.AppUser
 * and delegates persistence to AppUserDAOImpl.
 *
 * Business logic implemented here (Product Backlog "1. Authentication & User
 * Management" / Sprint-01 US-UM-01..05):
 *  - registration validates email/mobile/PAN-or-Aadhaar format, rejects
 *    duplicate emails and hashes the password before it ever reaches the DAO
 *  - login verifies the salted hash and that the account is active
 *  - OTP verification, password change/reset and role assignment are all
 *    dedicated operations instead of a generic "update everything" call, so
 *    the password can never be smuggled in/out through a plain DTO field.
 */
public class AppUserServiceImpl implements AppUserService {

    // Must match the app_user_role_check constraint in hlms_schema_corrected.sql
    private static final List<String> VALID_ROLES =
            List.of("customer", "legal", "bankoffice", "bidder", "admin");

    private final AppUserDAO dao;

    public AppUserServiceImpl() {
        this.dao = new AppUserDAOImpl();
    }

    public AppUserServiceImpl(AppUserDAO dao) {
        this.dao = dao;
    }

    @Override
    public AppUserDTO register(AppUserDTO dto, String rawPassword) throws DAOException {
        Validators.required(dto, "user");
        Validators.email(dto.getEmail(), "email");
        Validators.required(dto.getName(), "name");
        Validators.mobile(dto.getMobile(), "mobile");
        Validators.identityDocument(dto.getIdType(), dto.getIdNumber());
        PasswordUtil.validateStrength(rawPassword);

        String role = dto.getRole() == null || dto.getRole().isBlank() ? "customer" : dto.getRole().trim().toLowerCase();
        Validators.oneOf(role, "role", VALID_ROLES.toArray(new String[0]));

        if (dao.findById(dto.getEmail().trim().toLowerCase()) != null) {
            throw new ValidationException("An account with this email already exists.");
        }

        AppUser entity = new AppUser();
        entity.setEmail(dto.getEmail().trim().toLowerCase());
        entity.setName(dto.getName().trim());
        entity.setMobile(dto.getMobile().trim());
        entity.setPasswordHash(PasswordUtil.hash(rawPassword));
        entity.setRole(role);
        entity.setActive(true);
        entity.setIdType(dto.getIdType().trim().toUpperCase());
        entity.setIdNumber(dto.getIdNumber().trim().toUpperCase());
        entity.setPrefSms(dto.getPrefSms() != null ? dto.getPrefSms() : Boolean.TRUE);
        entity.setPrefEmail(dto.getPrefEmail() != null ? dto.getPrefEmail() : Boolean.TRUE);
        entity.setPrefInapp(dto.getPrefInapp() != null ? dto.getPrefInapp() : Boolean.TRUE);
        entity.setCreatedAt(OffsetDateTime.now());

        return toDto(dao.insert(entity));
    }

    @Override
    public AppUserDTO login(String email, String rawPassword) throws DAOException {
        Validators.email(email, "email");
        Validators.required(rawPassword, "password");

        AppUser entity = dao.findById(email.trim().toLowerCase());
        if (entity == null || !PasswordUtil.matches(rawPassword, entity.getPasswordHash())) {
            throw new ValidationException("Invalid email or password.");
        }
        if (entity.getActive() == null || !entity.getActive()) {
            throw new ValidationException("This account is deactivated. Contact support.");
        }
        return toDto(entity);
    }

    @Override
    public boolean verifyOtp(String email, String otp, String expectedOtp) throws DAOException {
        Validators.email(email, "email");
        Validators.required(otp, "otp");
        Validators.required(expectedOtp, "expectedOtp");
        return otp.trim().equals(expectedOtp.trim());
    }

    @Override
    public AppUserDTO changePassword(String email, String oldPassword, String newPassword) throws DAOException {
        Validators.email(email, "email");
        Validators.required(oldPassword, "oldPassword");
        PasswordUtil.validateStrength(newPassword);

        AppUser entity = dao.findById(email.trim().toLowerCase());
        if (entity == null) {
            throw new ValidationException("No account found for this email.");
        }
        if (!PasswordUtil.matches(oldPassword, entity.getPasswordHash())) {
            throw new ValidationException("Current password is incorrect.");
        }
        entity.setPasswordHash(PasswordUtil.hash(newPassword));
        return toDto(dao.update(entity));
    }

    @Override
    public AppUserDTO resetPassword(String email, String newPassword) throws DAOException {
        Validators.email(email, "email");
        PasswordUtil.validateStrength(newPassword);

        AppUser entity = dao.findById(email.trim().toLowerCase());
        if (entity == null) {
            throw new ValidationException("No account found for this email.");
        }
        entity.setPasswordHash(PasswordUtil.hash(newPassword));
        return toDto(dao.update(entity));
    }

    @Override
    public AppUserDTO assignRole(String email, String role) throws DAOException {
        Validators.email(email, "email");
        Validators.required(role, "role");
        String normalizedRole = role.trim().toLowerCase();
        Validators.oneOf(normalizedRole, "role", VALID_ROLES.toArray(new String[0]));

        AppUser entity = dao.findById(email.trim().toLowerCase());
        if (entity == null) {
            throw new ValidationException("No account found for this email.");
        }
        entity.setRole(normalizedRole);
        return toDto(dao.update(entity));
    }

    @Override
    public AppUserDTO update(AppUserDTO dto) throws DAOException {
        Validators.email(dto.getEmail(), "email");
        Validators.required(dto.getName(), "name");
        Validators.mobile(dto.getMobile(), "mobile");

        AppUser existing = dao.findById(dto.getEmail().trim().toLowerCase());
        if (existing == null) {
            throw new ValidationException("No account found for this email.");
        }

        existing.setName(dto.getName().trim());
        existing.setMobile(dto.getMobile().trim());
        existing.setPrefSms(dto.getPrefSms() != null ? dto.getPrefSms() : existing.getPrefSms());
        existing.setPrefEmail(dto.getPrefEmail() != null ? dto.getPrefEmail() : existing.getPrefEmail());
        existing.setPrefInapp(dto.getPrefInapp() != null ? dto.getPrefInapp() : existing.getPrefInapp());
        if (dto.getActive() != null) {
            existing.setActive(dto.getActive());
        }
        // idType/idNumber, role and password are deliberately NOT editable through this
        // generic profile update - they go through assignRole/changePassword instead.

        return toDto(dao.update(existing));
    }

    @Override
    public boolean delete(String email) throws DAOException {
        Validators.email(email, "email");
        return dao.delete(email.trim().toLowerCase());
    }

    @Override
    public AppUserDTO findById(String email) throws DAOException {
        Validators.email(email, "email");
        AppUser entity = dao.findById(email.trim().toLowerCase());
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<AppUserDTO> findAll() throws DAOException {
        List<AppUser> entities = dao.findAll();
        List<AppUserDTO> result = new ArrayList<>();
        for (AppUser entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private AppUserDTO toDto(AppUser entity) {
        AppUserDTO dto = new AppUserDTO();
        dto.setEmail(entity.getEmail());
        dto.setName(entity.getName());
        dto.setMobile(entity.getMobile());
        dto.setRole(entity.getRole());
        dto.setActive(entity.getActive());
        dto.setIdType(entity.getIdType());
        dto.setIdNumber(entity.getIdNumber());
        dto.setPrefSms(entity.getPrefSms());
        dto.setPrefEmail(entity.getPrefEmail());
        dto.setPrefInapp(entity.getPrefInapp());
        dto.setCreatedAt(entity.getCreatedAt());
        return dto;
    }
}
