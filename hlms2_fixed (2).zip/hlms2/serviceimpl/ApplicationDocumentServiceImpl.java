package hlms.serviceimpl;

import hlms.dao.ApplicationDocumentDAO;
import hlms.daoimpl.ApplicationDocumentDAOImpl;
import hlms.dto.ApplicationDocumentDTO;
import hlms.entity.*;
import hlms.service.ApplicationDocumentService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of ApplicationDocumentService. Converts ApplicationDocumentDTO <-> hlms.entity.ApplicationDocument
 * and delegates persistence to ApplicationDocumentDAOImpl.
 *
 * Business logic (US-LA-02, US-LA-03): validates document type/size limits
 * and defaults every freshly uploaded document to PENDING verification.
 */
public class ApplicationDocumentServiceImpl implements ApplicationDocumentService {

    private static final List<String> VALID_DOC_TYPES = List.of(
            "INCOME_PROOF", "EMPLOYMENT_PROOF", "PROPERTY_DOCUMENT", "IDENTITY_PROOF", "ADDRESS_PROOF", "BANK_STATEMENT");
    private static final List<String> VALID_STATUSES = List.of("PENDING", "VERIFIED", "REJECTED");
    private static final int MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB, US-LA-02

    private final ApplicationDocumentDAO dao;

    public ApplicationDocumentServiceImpl() {
        this.dao = new ApplicationDocumentDAOImpl();
    }

    public ApplicationDocumentServiceImpl(ApplicationDocumentDAO dao) {
        this.dao = dao;
    }

    @Override
    public ApplicationDocumentDTO create(ApplicationDocumentDTO dto) throws DAOException {
        validate(dto);
        ApplicationDocument entity = toEntity(dto);
        if (entity.getDocumentId() == null || entity.getDocumentId().isBlank()) {
            entity.setDocumentId("DOC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setUploadedAt(entity.getUploadedAt() == null ? OffsetDateTime.now() : entity.getUploadedAt());
        entity.setVerificationStatus(entity.getVerificationStatus() == null ? "PENDING" : entity.getVerificationStatus());
        ApplicationDocument saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public ApplicationDocumentDTO update(ApplicationDocumentDTO dto) throws DAOException {
        Validators.required(dto.getDocumentId(), "documentId");
        ApplicationDocument existing = dao.findById(dto.getDocumentId());
        if (existing == null) {
            throw new ValidationException("Document " + dto.getDocumentId() + " does not exist.");
        }
        validate(dto);
        // US-LA-03: verifying/rejecting a document must record who did it and when.
        if (("VERIFIED".equalsIgnoreCase(dto.getVerificationStatus()) || "REJECTED".equalsIgnoreCase(dto.getVerificationStatus()))
                && dto.getVerifiedByEmail() == null) {
            throw new ValidationException("verifiedByEmail is required when marking a document VERIFIED or REJECTED.");
        }
        ApplicationDocument entity = toEntity(dto);
        entity.setUploadedAt(existing.getUploadedAt());
        if (dto.getVerifiedByEmail() != null && dto.getVerifiedAt() == null) {
            entity.setVerifiedAt(OffsetDateTime.now());
        }
        ApplicationDocument saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String documentId) throws DAOException {
        Validators.required(documentId, "documentId");
        return dao.delete(documentId);
    }

    @Override
    public ApplicationDocumentDTO findById(String documentId) throws DAOException {
        Validators.required(documentId, "documentId");
        ApplicationDocument entity = dao.findById(documentId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<ApplicationDocumentDTO> findAll() throws DAOException {
        List<ApplicationDocument> entities = dao.findAll();
        List<ApplicationDocumentDTO> result = new ArrayList<>();
        for (ApplicationDocument entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(ApplicationDocumentDTO dto) throws ValidationException {
        Validators.required(dto.getAppId(), "appId");
        Validators.oneOf(dto.getDocType(), "docType", VALID_DOC_TYPES.toArray(new String[0]));
        Validators.required(dto.getFileName(), "fileName");
        Validators.positive(dto.getFileSize(), "fileSize");
        if (dto.getFileSize() != null && dto.getFileSize() > MAX_FILE_SIZE_BYTES) {
            throw new ValidationException("fileSize exceeds the 10 MB upload limit.");
        }
        if (dto.getVerificationStatus() != null) {
            Validators.oneOf(dto.getVerificationStatus(), "verificationStatus", VALID_STATUSES.toArray(new String[0]));
        }
    }

    private ApplicationDocument toEntity(ApplicationDocumentDTO dto) {
        ApplicationDocument entity = new ApplicationDocument();
        entity.setDocumentId(dto.getDocumentId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setDocType(dto.getDocType());
        entity.setFileName(dto.getFileName());
        entity.setFileSize(dto.getFileSize());
        entity.setUploadedAt(dto.getUploadedAt());
        entity.setVerificationStatus(dto.getVerificationStatus());
        if (dto.getVerifiedByEmail() != null) {
            AppUser verifiedByRef = new AppUser();
            verifiedByRef.setEmail(dto.getVerifiedByEmail());
            entity.setVerifiedBy(verifiedByRef);
        }
        entity.setVerifiedAt(dto.getVerifiedAt());
        entity.setRemarks(dto.getRemarks());
        return entity;
    }

    private ApplicationDocumentDTO toDto(ApplicationDocument entity) {
        ApplicationDocumentDTO dto = new ApplicationDocumentDTO();
        dto.setDocumentId(entity.getDocumentId());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setDocType(entity.getDocType());
        dto.setFileName(entity.getFileName());
        dto.setFileSize(entity.getFileSize());
        dto.setUploadedAt(entity.getUploadedAt());
        dto.setVerificationStatus(entity.getVerificationStatus());
        dto.setVerifiedByEmail(entity.getVerifiedBy() == null ? null : entity.getVerifiedBy().getEmail());
        dto.setVerifiedAt(entity.getVerifiedAt());
        dto.setRemarks(entity.getRemarks());
        return dto;
    }
}
