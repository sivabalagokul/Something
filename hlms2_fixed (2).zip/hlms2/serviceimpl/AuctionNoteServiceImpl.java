package hlms.serviceimpl;

import hlms.dao.AuctionNoteDAO;
import hlms.daoimpl.AuctionNoteDAOImpl;
import hlms.dto.AuctionNoteDTO;
import hlms.entity.*;
import hlms.service.AuctionNoteService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of AuctionNoteService. Converts AuctionNoteDTO <-> hlms.entity.AuctionNote
 * and delegates persistence to AuctionNoteDAOImpl.
 *
 * Business logic (US-AM-05): every auction case activity must be captured
 * as an auditable, timestamped note with real content.
 */
public class AuctionNoteServiceImpl implements AuctionNoteService {

    private final AuctionNoteDAO dao;

    public AuctionNoteServiceImpl() {
        this.dao = new AuctionNoteDAOImpl();
    }

    public AuctionNoteServiceImpl(AuctionNoteDAO dao) {
        this.dao = dao;
    }

    @Override
    public AuctionNoteDTO create(AuctionNoteDTO dto) throws DAOException {
        validate(dto);
        AuctionNote entity = toEntity(dto);
        if (entity.getNoteId() == null || entity.getNoteId().isBlank()) {
            entity.setNoteId("ANT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setNoteDate(entity.getNoteDate() == null ? OffsetDateTime.now() : entity.getNoteDate());
        AuctionNote saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public AuctionNoteDTO update(AuctionNoteDTO dto) throws DAOException {
        Validators.required(dto.getNoteId(), "noteId");
        if (dao.findById(dto.getNoteId()) == null) {
            throw new ValidationException("Auction note " + dto.getNoteId() + " does not exist.");
        }
        validate(dto);
        AuctionNote entity = toEntity(dto);
        AuctionNote saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String noteId) throws DAOException {
        Validators.required(noteId, "noteId");
        return dao.delete(noteId);
    }

    @Override
    public AuctionNoteDTO findById(String noteId) throws DAOException {
        Validators.required(noteId, "noteId");
        AuctionNote entity = dao.findById(noteId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<AuctionNoteDTO> findAll() throws DAOException {
        List<AuctionNote> entities = dao.findAll();
        List<AuctionNoteDTO> result = new ArrayList<>();
        for (AuctionNote entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(AuctionNoteDTO dto) throws ValidationException {
        Validators.required(dto.getAppId(), "appId");
        Validators.required(dto.getNoteText(), "noteText");
        Validators.maxLength(dto.getNoteText(), "noteText", 4000);
    }

    private AuctionNote toEntity(AuctionNoteDTO dto) {
        AuctionNote entity = new AuctionNote();
        entity.setNoteId(dto.getNoteId());
        if (dto.getAppId() != null) {
            AuctionCase auctionCaseRef = new AuctionCase();
            auctionCaseRef.setAppId(dto.getAppId());
            entity.setAuctionCase(auctionCaseRef);
        }
        entity.setNoteDate(dto.getNoteDate());
        entity.setNoteText(dto.getNoteText());
        return entity;
    }

    private AuctionNoteDTO toDto(AuctionNote entity) {
        AuctionNoteDTO dto = new AuctionNoteDTO();
        dto.setNoteId(entity.getNoteId());
        dto.setAppId(entity.getAuctionCase() == null ? null : entity.getAuctionCase().getAppId());
        dto.setNoteDate(entity.getNoteDate());
        dto.setNoteText(entity.getNoteText());
        return dto;
    }
}
