package hlms.serviceimpl;

import hlms.dao.AuditLogDAO;
import hlms.daoimpl.AuditLogDAOImpl;
import hlms.dto.AuditLogDTO;
import hlms.entity.*;
import hlms.service.AuditLogService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of AuditLogService. Converts AuditLogDTO <-> hlms.entity.AuditLog
 * and delegates persistence to AuditLogDAOImpl.
 *
 * Business logic: audit log rows are append-only. "update" is intentionally
 * unsupported - the whole point of an audit trail is that once a decision
 * is recorded, it cannot be silently rewritten (mirrors US-LRM-05's
 * "records cannot be modified without authorization" for payment history).
 */
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogDAO dao;

    public AuditLogServiceImpl() {
        this.dao = new AuditLogDAOImpl();
    }

    public AuditLogServiceImpl(AuditLogDAO dao) {
        this.dao = dao;
    }

    @Override
    public AuditLogDTO create(AuditLogDTO dto) throws DAOException {
        Validators.required(dto.getEntityType(), "entityType");
        Validators.required(dto.getEntityId(), "entityId");
        Validators.oneOf(dto.getAction(), "action", "CREATE", "UPDATE", "DELETE", "APPROVE", "REJECT", "LOGIN", "LOGOUT");
        Validators.required(dto.getActorEmail(), "actorEmail");

        AuditLog entity = toEntity(dto);
        entity.setCreatedAt(entity.getCreatedAt() == null ? OffsetDateTime.now() : entity.getCreatedAt());
        AuditLog saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public AuditLogDTO update(AuditLogDTO dto) throws DAOException {
        throw new ValidationException("Audit log entries are immutable and cannot be updated.");
    }

    @Override
    public boolean delete(Long logId) throws DAOException {
        Validators.required(logId, "logId");
        return dao.delete(logId);
    }

    @Override
    public AuditLogDTO findById(Long logId) throws DAOException {
        Validators.required(logId, "logId");
        AuditLog entity = dao.findById(logId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<AuditLogDTO> findAll() throws DAOException {
        List<AuditLog> entities = dao.findAll();
        List<AuditLogDTO> result = new ArrayList<>();
        for (AuditLog entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private AuditLog toEntity(AuditLogDTO dto) {
        AuditLog entity = new AuditLog();
        entity.setLogId(dto.getLogId());
        entity.setEntityType(dto.getEntityType());
        entity.setEntityId(dto.getEntityId());
        entity.setAction(dto.getAction());
        if (dto.getActorEmail() != null) {
            AppUser actorRef = new AppUser();
            actorRef.setEmail(dto.getActorEmail());
            entity.setActor(actorRef);
        }
        entity.setBeforeData(dto.getBeforeData());
        entity.setAfterData(dto.getAfterData());
        entity.setCreatedAt(dto.getCreatedAt());
        return entity;
    }

    private AuditLogDTO toDto(AuditLog entity) {
        AuditLogDTO dto = new AuditLogDTO();
        dto.setLogId(entity.getLogId());
        dto.setEntityType(entity.getEntityType());
        dto.setEntityId(entity.getEntityId());
        dto.setAction(entity.getAction());
        dto.setActorEmail(entity.getActor() == null ? null : entity.getActor().getEmail());
        dto.setBeforeData(entity.getBeforeData());
        dto.setAfterData(entity.getAfterData());
        dto.setCreatedAt(entity.getCreatedAt());
        return dto;
    }
}
