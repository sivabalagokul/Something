package hlms.serviceimpl;

import hlms.dao.BankOfficeDecisionDAO;
import hlms.daoimpl.BankOfficeDecisionDAOImpl;
import hlms.dto.BankOfficeDecisionDTO;
import hlms.entity.*;
import hlms.service.BankOfficeDecisionService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of BankOfficeDecisionService. Converts BankOfficeDecisionDTO <-> hlms.entity.BankOfficeDecision
 * and delegates persistence to BankOfficeDecisionDAOImpl.
 *
 * Business logic (US-EL-05): rejected or conditionally-approved decisions
 * must always carry a reason, per the "Eligibility Explanation Engine" story.
 */
public class BankOfficeDecisionServiceImpl implements BankOfficeDecisionService {

    private static final List<String> VALID_DECISIONS = List.of("APPROVED", "CONDITIONALLY_APPROVED", "REJECTED");

    private final BankOfficeDecisionDAO dao;

    public BankOfficeDecisionServiceImpl() {
        this.dao = new BankOfficeDecisionDAOImpl();
    }

    public BankOfficeDecisionServiceImpl(BankOfficeDecisionDAO dao) {
        this.dao = dao;
    }

    @Override
    public BankOfficeDecisionDTO create(BankOfficeDecisionDTO dto) throws DAOException {
        Validators.required(dto.getAppId(), "appId");
        if (dao.findById(dto.getAppId()) != null) {
            throw new ValidationException("A bank office decision already exists for application " + dto.getAppId() + ".");
        }
        validate(dto);
        BankOfficeDecision entity = toEntity(dto);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        BankOfficeDecision saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public BankOfficeDecisionDTO update(BankOfficeDecisionDTO dto) throws DAOException {
        Validators.required(dto.getAppId(), "appId");
        if (dao.findById(dto.getAppId()) == null) {
            throw new ValidationException("No bank office decision found for application " + dto.getAppId() + ".");
        }
        validate(dto);
        BankOfficeDecision entity = toEntity(dto);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        BankOfficeDecision saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        Validators.required(appId, "appId");
        return dao.delete(appId);
    }

    @Override
    public BankOfficeDecisionDTO findById(String appId) throws DAOException {
        Validators.required(appId, "appId");
        BankOfficeDecision entity = dao.findById(appId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<BankOfficeDecisionDTO> findAll() throws DAOException {
        List<BankOfficeDecision> entities = dao.findAll();
        List<BankOfficeDecisionDTO> result = new ArrayList<>();
        for (BankOfficeDecision entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(BankOfficeDecisionDTO dto) throws ValidationException {
        Validators.oneOf(dto.getDecision(), "decision", VALID_DECISIONS.toArray(new String[0]));
        Validators.required(dto.getOfficerEmail(), "officerEmail");
        // US-EL-05: rejection or conditional approval must always be explained to the customer.
        if (!"APPROVED".equalsIgnoreCase(dto.getDecision())) {
            Validators.required(dto.getReason(), "reason");
        }
    }

    private BankOfficeDecision toEntity(BankOfficeDecisionDTO dto) {
        BankOfficeDecision entity = new BankOfficeDecision();
        entity.setAppId(dto.getAppId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setDecision(dto.getDecision());
        if (dto.getOfficerEmail() != null) {
            AppUser officerRef = new AppUser();
            officerRef.setEmail(dto.getOfficerEmail());
            entity.setOfficer(officerRef);
        }
        entity.setDecisionDate(dto.getDecisionDate());
        entity.setReason(dto.getReason());
        entity.setRemarks(dto.getRemarks());
        return entity;
    }

    private BankOfficeDecisionDTO toDto(BankOfficeDecision entity) {
        BankOfficeDecisionDTO dto = new BankOfficeDecisionDTO();
        dto.setAppId(entity.getAppId());
        dto.setDecision(entity.getDecision());
        dto.setOfficerEmail(entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
        dto.setDecisionDate(entity.getDecisionDate());
        dto.setReason(entity.getReason());
        dto.setRemarks(entity.getRemarks());
        return dto;
    }
}
