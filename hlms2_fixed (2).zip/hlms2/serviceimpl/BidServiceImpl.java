package hlms.serviceimpl;

import hlms.dao.AuctionCaseDAO;
import hlms.dao.BidDAO;
import hlms.daoimpl.AuctionCaseDAOImpl;
import hlms.daoimpl.BidDAOImpl;
import hlms.dto.BidDTO;
import hlms.entity.*;
import hlms.service.BidService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of BidService. Converts BidDTO <-> hlms.entity.Bid
 * and delegates persistence to BidDAOImpl.
 *
 * Business logic (US-AM-02..04): a bid is only valid if it is placed against
 * an existing auction case, is at least the reserve price, and strictly
 * beats the current highest bid recorded for that auction.
 */
public class BidServiceImpl implements BidService {

    private final BidDAO dao;
    private final AuctionCaseDAO auctionCaseDao;

    public BidServiceImpl() {
        this.dao = new BidDAOImpl();
        this.auctionCaseDao = new AuctionCaseDAOImpl();
    }

    public BidServiceImpl(BidDAO dao, AuctionCaseDAO auctionCaseDao) {
        this.dao = dao;
        this.auctionCaseDao = auctionCaseDao;
    }

    @Override
    public BidDTO create(BidDTO dto) throws DAOException {
        validate(dto);
        Bid entity = toEntity(dto);
        if (entity.getBidId() == null || entity.getBidId().isBlank()) {
            entity.setBidId("BID-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setCreatedAt(entity.getCreatedAt() == null ? OffsetDateTime.now() : entity.getCreatedAt());
        Bid saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public BidDTO update(BidDTO dto) throws DAOException {
        Validators.required(dto.getBidId(), "bidId");
        if (dao.findById(dto.getBidId()) == null) {
            throw new ValidationException("Bid " + dto.getBidId() + " does not exist.");
        }
        validate(dto);
        Bid entity = toEntity(dto);
        Bid saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String bidId) throws DAOException {
        Validators.required(bidId, "bidId");
        return dao.delete(bidId);
    }

    @Override
    public BidDTO findById(String bidId) throws DAOException {
        Validators.required(bidId, "bidId");
        Bid entity = dao.findById(bidId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<BidDTO> findAll() throws DAOException {
        List<Bid> entities = dao.findAll();
        List<BidDTO> result = new ArrayList<>();
        for (Bid entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(BidDTO dto) throws DAOException {
        Validators.required(dto.getAppId(), "appId");
        Validators.required(dto.getBidderEmail(), "bidderEmail");
        Validators.positive(dto.getBidAmount(), "bidAmount");

        AuctionCase auctionCase = auctionCaseDao.findById(dto.getAppId());
        if (auctionCase == null) {
            throw new ValidationException("No auction case found for application " + dto.getAppId() + ".");
        }
        if (auctionCase.getReservePrice() != null && dto.getBidAmount().compareTo(auctionCase.getReservePrice()) < 0) {
            throw new ValidationException("bidAmount must be at least the reserve price of " + auctionCase.getReservePrice() + ".");
        }
        BigDecimal highestSoFar = highestBid(dto.getAppId());
        if (highestSoFar != null && dto.getBidAmount().compareTo(highestSoFar) <= 0) {
            throw new ValidationException("bidAmount must be higher than the current highest bid of " + highestSoFar + ".");
        }
    }

    private BigDecimal highestBid(String appId) throws DAOException {
        BigDecimal highest = null;
        for (Bid b : dao.findAll()) {
            if (b.getAuctionCase() != null && appId.equals(b.getAuctionCase().getAppId())) {
                if (highest == null || b.getBidAmount().compareTo(highest) > 0) {
                    highest = b.getBidAmount();
                }
            }
        }
        return highest;
    }

    private Bid toEntity(BidDTO dto) {
        Bid entity = new Bid();
        entity.setBidId(dto.getBidId());
        if (dto.getAppId() != null) {
            AuctionCase auctionCaseRef = new AuctionCase();
            auctionCaseRef.setAppId(dto.getAppId());
            entity.setAuctionCase(auctionCaseRef);
        }
        if (dto.getBidderEmail() != null) {
            AppUser bidderRef = new AppUser();
            bidderRef.setEmail(dto.getBidderEmail());
            entity.setBidder(bidderRef);
        }
        entity.setBidAmount(dto.getBidAmount());
        entity.setCreatedAt(dto.getCreatedAt());
        return entity;
    }

    private BidDTO toDto(Bid entity) {
        BidDTO dto = new BidDTO();
        dto.setBidId(entity.getBidId());
        dto.setAppId(entity.getAuctionCase() == null ? null : entity.getAuctionCase().getAppId());
        dto.setBidderEmail(entity.getBidder() == null ? null : entity.getBidder().getEmail());
        dto.setBidAmount(entity.getBidAmount());
        dto.setCreatedAt(entity.getCreatedAt());
        return dto;
    }
}
