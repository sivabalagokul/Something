package hlms.serviceimpl;

import hlms.dao.CustomerEmploymentProfileDAO;
import hlms.daoimpl.CustomerEmploymentProfileDAOImpl;
import hlms.dto.CustomerEmploymentProfileDTO;
import hlms.entity.*;
import hlms.service.CustomerEmploymentProfileService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of CustomerEmploymentProfileService. Converts CustomerEmploymentProfileDTO <-> hlms.entity.CustomerEmploymentProfile
 * and delegates persistence to CustomerEmploymentProfileDAOImpl.
 *
 * Business logic (US-UM-05, US-EL-01..08):
 *  - validates employment/income/PAN details
 *  - exposes the Debt-to-Income ratio and a mortgage-free eligibility
 *    calculation used by the loan-eligibility assessment feature.
 */
public class CustomerEmploymentProfileServiceImpl implements CustomerEmploymentProfileService {

    /** Banking-guideline multiplier: unsecured eligible amount = 60x net monthly surplus. US-EL-08. */
    private static final BigDecimal MORTGAGE_FREE_MULTIPLIER = BigDecimal.valueOf(60);
    /** Max acceptable Debt-to-Income ratio (including the new EMI) for a clean "Eligible" result. US-EL-03/04. */
    private static final BigDecimal MAX_HEALTHY_DTI = BigDecimal.valueOf(0.50);

    private final CustomerEmploymentProfileDAO dao;

    public CustomerEmploymentProfileServiceImpl() {
        this.dao = new CustomerEmploymentProfileDAOImpl();
    }

    public CustomerEmploymentProfileServiceImpl(CustomerEmploymentProfileDAO dao) {
        this.dao = dao;
    }

    @Override
    public CustomerEmploymentProfileDTO create(CustomerEmploymentProfileDTO dto) throws DAOException {
        validate(dto);
        if (dao.findById(dto.getUserEmail()) != null) {
            throw new ValidationException("An employment profile already exists for this user.");
        }
        CustomerEmploymentProfile entity = toEntity(dto);
        CustomerEmploymentProfile saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public CustomerEmploymentProfileDTO update(CustomerEmploymentProfileDTO dto) throws DAOException {
        validate(dto);
        if (dao.findById(dto.getUserEmail()) == null) {
            throw new ValidationException("No employment profile found for this user.");
        }
        CustomerEmploymentProfile entity = toEntity(dto);
        CustomerEmploymentProfile saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String userEmail) throws DAOException {
        Validators.required(userEmail, "userEmail");
        return dao.delete(userEmail);
    }

    @Override
    public CustomerEmploymentProfileDTO findById(String userEmail) throws DAOException {
        Validators.required(userEmail, "userEmail");
        CustomerEmploymentProfile entity = dao.findById(userEmail);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<CustomerEmploymentProfileDTO> findAll() throws DAOException {
        List<CustomerEmploymentProfile> entities = dao.findAll();
        List<CustomerEmploymentProfileDTO> result = new ArrayList<>();
        for (CustomerEmploymentProfile entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(CustomerEmploymentProfileDTO dto) throws ValidationException {
        Validators.required(dto.getUserEmail(), "userEmail");
        Validators.oneOf(dto.getEmploymentType(), "employmentType", "SALARIED", "SELF_EMPLOYED", "BUSINESS");
        Validators.required(dto.getEmployer(), "employer");
        Validators.positive(dto.getMonthlyIncome(), "monthlyIncome");
        Validators.nonNegative(dto.getOtherEmis(), "otherEmis");
        Validators.positive(dto.getDesiredAmount(), "desiredAmount");
        Validators.pan(dto.getPan(), "pan");
        if (dto.getOtherEmis() != null && dto.getMonthlyIncome() != null
                && dto.getOtherEmis().compareTo(dto.getMonthlyIncome()) >= 0) {
            throw new ValidationException("otherEmis cannot be greater than or equal to monthlyIncome.");
        }
    }

    /**
     * US-EL-03: Debt-to-Income ratio = (existing EMIs + proposed EMI) / monthly income.
     * A proposedEmi of zero gives the customer's current DTI before any new loan.
     */
    public BigDecimal calculateDti(CustomerEmploymentProfileDTO dto, BigDecimal proposedEmi) throws ValidationException {
        Validators.positive(dto.getMonthlyIncome(), "monthlyIncome");
        BigDecimal existing = dto.getOtherEmis() == null ? BigDecimal.ZERO : dto.getOtherEmis();
        BigDecimal proposed = proposedEmi == null ? BigDecimal.ZERO : proposedEmi;
        return existing.add(proposed).divide(dto.getMonthlyIncome(), 4, RoundingMode.HALF_UP);
    }

    /**
     * US-EL-08: maximum housing loan amount approvable WITHOUT a mortgage,
     * based on free monthly surplus (income - existing EMIs) x a fixed multiplier.
     */
    public BigDecimal calculateMortgageFreeMaxLoan(CustomerEmploymentProfileDTO dto) throws ValidationException {
        Validators.positive(dto.getMonthlyIncome(), "monthlyIncome");
        BigDecimal existing = dto.getOtherEmis() == null ? BigDecimal.ZERO : dto.getOtherEmis();
        BigDecimal surplus = dto.getMonthlyIncome().subtract(existing);
        if (surplus.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        return surplus.multiply(MORTGAGE_FREE_MULTIPLIER).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * US-EL-01/EL-04: Eligible / Conditionally Eligible / Not Eligible based on
     * DTI against the requested EMI. US-EL-05 explanation reasons are appended.
     */
    public String assessEligibility(CustomerEmploymentProfileDTO dto, BigDecimal proposedEmi) throws ValidationException {
        BigDecimal dti = calculateDti(dto, proposedEmi);
        if (dti.compareTo(MAX_HEALTHY_DTI) <= 0) {
            return "ELIGIBLE";
        } else if (dti.compareTo(BigDecimal.valueOf(0.65)) <= 0) {
            return "CONDITIONALLY_ELIGIBLE";
        }
        return "NOT_ELIGIBLE";
    }

    private CustomerEmploymentProfile toEntity(CustomerEmploymentProfileDTO dto) {
        CustomerEmploymentProfile entity = new CustomerEmploymentProfile();
        entity.setUserEmail(dto.getUserEmail());
        if (dto.getUserEmail() != null) {
            AppUser userRef = new AppUser();
            userRef.setEmail(dto.getUserEmail());
            entity.setUser(userRef);
        }
        entity.setEmploymentType(dto.getEmploymentType());
        entity.setEmployer(dto.getEmployer());
        entity.setMonthlyIncome(dto.getMonthlyIncome());
        entity.setOtherEmis(dto.getOtherEmis());
        entity.setDesiredAmount(dto.getDesiredAmount());
        entity.setPan(dto.getPan());
        return entity;
    }

    private CustomerEmploymentProfileDTO toDto(CustomerEmploymentProfile entity) {
        CustomerEmploymentProfileDTO dto = new CustomerEmploymentProfileDTO();
        dto.setUserEmail(entity.getUserEmail());
        dto.setEmploymentType(entity.getEmploymentType());
        dto.setEmployer(entity.getEmployer());
        dto.setMonthlyIncome(entity.getMonthlyIncome());
        dto.setOtherEmis(entity.getOtherEmis());
        dto.setDesiredAmount(entity.getDesiredAmount());
        dto.setPan(entity.getPan());
        return dto;
    }
}
