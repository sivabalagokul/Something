package hlms.serviceimpl;

import hlms.dao.DisbursementDAO;
import hlms.daoimpl.DisbursementDAOImpl;
import hlms.dto.DisbursementDTO;
import hlms.entity.*;
import hlms.service.DisbursementService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of DisbursementService. Converts DisbursementDTO <-> hlms.entity.Disbursement
 * and delegates persistence to DisbursementDAOImpl.
 *
 * Business logic: a loan can only be disbursed once (appId is the primary
 * key here), the amount/mode/reference must be well formed, and the
 * disbursed date can never be in the future.
 */
public class DisbursementServiceImpl implements DisbursementService {

    private static final List<String> VALID_MODES = List.of("NEFT", "RTGS", "CHEQUE", "UPI");

    private final DisbursementDAO dao;

    public DisbursementServiceImpl() {
        this.dao = new DisbursementDAOImpl();
    }

    public DisbursementServiceImpl(DisbursementDAO dao) {
        this.dao = dao;
    }

    @Override
    public DisbursementDTO create(DisbursementDTO dto) throws DAOException {
        Validators.required(dto.getAppId(), "appId");
        if (dao.findById(dto.getAppId()) != null) {
            throw new ValidationException("A disbursement already exists for application " + dto.getAppId() + ".");
        }
        validate(dto);
        Disbursement entity = toEntity(dto);
        entity.setDisbursedDate(entity.getDisbursedDate() == null ? OffsetDateTime.now() : entity.getDisbursedDate());
        Disbursement saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public DisbursementDTO update(DisbursementDTO dto) throws DAOException {
        Validators.required(dto.getAppId(), "appId");
        if (dao.findById(dto.getAppId()) == null) {
            throw new ValidationException("No disbursement found for application " + dto.getAppId() + ".");
        }
        validate(dto);
        Disbursement entity = toEntity(dto);
        Disbursement saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        Validators.required(appId, "appId");
        return dao.delete(appId);
    }

    @Override
    public DisbursementDTO findById(String appId) throws DAOException {
        Validators.required(appId, "appId");
        Disbursement entity = dao.findById(appId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<DisbursementDTO> findAll() throws DAOException {
        List<Disbursement> entities = dao.findAll();
        List<DisbursementDTO> result = new ArrayList<>();
        for (Disbursement entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(DisbursementDTO dto) throws ValidationException {
        Validators.positive(dto.getAmount(), "amount");
        Validators.required(dto.getRefNo(), "refNo");
        Validators.oneOf(dto.getMode(), "mode", VALID_MODES.toArray(new String[0]));
        Validators.required(dto.getBankDetails(), "bankDetails");
        if (dto.getDisbursedDate() != null && dto.getDisbursedDate().isAfter(OffsetDateTime.now())) {
            throw new ValidationException("disbursedDate cannot be in the future.");
        }
    }

    private Disbursement toEntity(DisbursementDTO dto) {
        Disbursement entity = new Disbursement();
        entity.setAppId(dto.getAppId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setDisbursedDate(dto.getDisbursedDate());
        entity.setAmount(dto.getAmount());
        entity.setRefNo(dto.getRefNo());
        entity.setMode(dto.getMode());
        entity.setBankDetails(dto.getBankDetails());
        return entity;
    }

    private DisbursementDTO toDto(Disbursement entity) {
        DisbursementDTO dto = new DisbursementDTO();
        dto.setAppId(entity.getAppId());
        dto.setDisbursedDate(entity.getDisbursedDate());
        dto.setAmount(entity.getAmount());
        dto.setRefNo(entity.getRefNo());
        dto.setMode(entity.getMode());
        dto.setBankDetails(entity.getBankDetails());
        return dto;
    }
}
