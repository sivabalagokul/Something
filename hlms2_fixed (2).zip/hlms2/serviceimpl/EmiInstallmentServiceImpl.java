package hlms.serviceimpl;

import hlms.dao.EmiInstallmentDAO;
import hlms.daoimpl.EmiInstallmentDAOImpl;
import hlms.dto.EmiInstallmentDTO;
import hlms.entity.*;
import hlms.service.EmiInstallmentService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of EmiInstallmentService. Converts EmiInstallmentDTO <-> hlms.entity.EmiInstallment
 * and delegates persistence to EmiInstallmentDAOImpl.
 *
 * Business logic (US-LRM-01..04): validates EMI math, guarantees the
 * outstanding balance can never go negative, and automatically flags
 * OVERDUE installments whose due date has passed unpaid.
 */
public class EmiInstallmentServiceImpl implements EmiInstallmentService {

    private static final List<String> VALID_STATUSES = List.of("PENDING", "PAID", "OVERDUE");
    private static final BigDecimal ROUNDING_TOLERANCE = BigDecimal.valueOf(1); // allow re paise/rounding drift

    private final EmiInstallmentDAO dao;

    public EmiInstallmentServiceImpl() {
        this.dao = new EmiInstallmentDAOImpl();
    }

    public EmiInstallmentServiceImpl(EmiInstallmentDAO dao) {
        this.dao = dao;
    }

    @Override
    public EmiInstallmentDTO create(EmiInstallmentDTO dto) throws DAOException {
        validate(dto);
        EmiInstallment entity = toEntity(dto);
        if (entity.getInstallmentId() == null || entity.getInstallmentId().isBlank()) {
            entity.setInstallmentId("EMI-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setStatus(deriveStatus(entity));
        EmiInstallment saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public EmiInstallmentDTO update(EmiInstallmentDTO dto) throws DAOException {
        Validators.required(dto.getInstallmentId(), "installmentId");
        if (dao.findById(dto.getInstallmentId()) == null) {
            throw new ValidationException("EMI installment " + dto.getInstallmentId() + " does not exist.");
        }
        validate(dto);
        EmiInstallment entity = toEntity(dto);
        // US-LRM-01: an invalid/duplicate payment cannot be recorded against an already-paid installment.
        entity.setStatus(deriveStatus(entity));
        EmiInstallment saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String installmentId) throws DAOException {
        Validators.required(installmentId, "installmentId");
        return dao.delete(installmentId);
    }

    @Override
    public EmiInstallmentDTO findById(String installmentId) throws DAOException {
        Validators.required(installmentId, "installmentId");
        EmiInstallment entity = dao.findById(installmentId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<EmiInstallmentDTO> findAll() throws DAOException {
        List<EmiInstallment> entities = dao.findAll();
        List<EmiInstallmentDTO> result = new ArrayList<>();
        for (EmiInstallment entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(EmiInstallmentDTO dto) throws ValidationException {
        Validators.required(dto.getAppId(), "appId");
        Validators.positive(dto.getInstallmentNo(), "installmentNo");
        Validators.required(dto.getDueDate(), "dueDate");
        Validators.positive(dto.getEmiAmount(), "emiAmount");
        Validators.nonNegative(dto.getPrincipalComponent(), "principalComponent");
        Validators.nonNegative(dto.getInterestComponent(), "interestComponent");
        // US-LRM-03: outstanding balance can never become negative.
        Validators.nonNegative(dto.getClosingBalance(), "closingBalance");

        BigDecimal sumComponents = dto.getPrincipalComponent().add(dto.getInterestComponent());
        if (sumComponents.subtract(dto.getEmiAmount()).abs().compareTo(ROUNDING_TOLERANCE) > 0) {
            throw new ValidationException("principalComponent + interestComponent must equal emiAmount.");
        }
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
        if ("PAID".equalsIgnoreCase(dto.getStatus()) && dto.getPaidDate() == null) {
            throw new ValidationException("paidDate is required when status is PAID.");
        }
    }

    /** US-LRM-04: overdue status is derived automatically rather than trusted from the caller. */
    private String deriveStatus(EmiInstallment entity) {
        if (entity.getPaidDate() != null) {
            return "PAID";
        }
        if (entity.getDueDate() != null && entity.getDueDate().isBefore(LocalDate.now())) {
            return "OVERDUE";
        }
        return "PENDING";
    }

    private EmiInstallment toEntity(EmiInstallmentDTO dto) {
        EmiInstallment entity = new EmiInstallment();
        entity.setInstallmentId(dto.getInstallmentId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setInstallmentNo(dto.getInstallmentNo());
        entity.setDueDate(dto.getDueDate());
        entity.setEmiAmount(dto.getEmiAmount());
        entity.setPrincipalComponent(dto.getPrincipalComponent());
        entity.setInterestComponent(dto.getInterestComponent());
        entity.setClosingBalance(dto.getClosingBalance());
        entity.setStatus(dto.getStatus());
        entity.setPaidDate(dto.getPaidDate());
        return entity;
    }

    private EmiInstallmentDTO toDto(EmiInstallment entity) {
        EmiInstallmentDTO dto = new EmiInstallmentDTO();
        dto.setInstallmentId(entity.getInstallmentId());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setInstallmentNo(entity.getInstallmentNo());
        dto.setDueDate(entity.getDueDate());
        dto.setEmiAmount(entity.getEmiAmount());
        dto.setPrincipalComponent(entity.getPrincipalComponent());
        dto.setInterestComponent(entity.getInterestComponent());
        dto.setClosingBalance(entity.getClosingBalance());
        dto.setStatus(entity.getStatus());
        dto.setPaidDate(entity.getPaidDate());
        return dto;
    }
}
