package hlms.serviceimpl;

import hlms.dao.InsurancePolicyDAO;
import hlms.daoimpl.InsurancePolicyDAOImpl;
import hlms.dto.InsurancePolicyDTO;
import hlms.entity.*;
import hlms.service.InsurancePolicyService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of InsurancePolicyService. Converts InsurancePolicyDTO <-> hlms.entity.InsurancePolicy
 * and delegates persistence to InsurancePolicyDAOImpl.
 *
 * Business logic: validates policy type/status and keeps validTill honest
 * (a policy created as ACTIVE cannot already be expired).
 */
public class InsurancePolicyServiceImpl implements InsurancePolicyService {

    private static final List<String> VALID_TYPES = List.of("LIFE", "PROPERTY", "TERM");
    private static final List<String> VALID_STATUSES = List.of("ACTIVE", "EXPIRED", "CANCELLED");

    private final InsurancePolicyDAO dao;

    public InsurancePolicyServiceImpl() {
        this.dao = new InsurancePolicyDAOImpl();
    }

    public InsurancePolicyServiceImpl(InsurancePolicyDAO dao) {
        this.dao = dao;
    }

    @Override
    public InsurancePolicyDTO create(InsurancePolicyDTO dto) throws DAOException {
        validate(dto);
        InsurancePolicy entity = toEntity(dto);
        if (entity.getPolicyId() == null || entity.getPolicyId().isBlank()) {
            entity.setPolicyId("POL-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setStatus(entity.getStatus() == null ? "ACTIVE" : entity.getStatus());
        InsurancePolicy saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public InsurancePolicyDTO update(InsurancePolicyDTO dto) throws DAOException {
        Validators.required(dto.getPolicyId(), "policyId");
        if (dao.findById(dto.getPolicyId()) == null) {
            throw new ValidationException("Insurance policy " + dto.getPolicyId() + " does not exist.");
        }
        validate(dto);
        InsurancePolicy entity = toEntity(dto);
        InsurancePolicy saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String policyId) throws DAOException {
        Validators.required(policyId, "policyId");
        return dao.delete(policyId);
    }

    @Override
    public InsurancePolicyDTO findById(String policyId) throws DAOException {
        Validators.required(policyId, "policyId");
        InsurancePolicy entity = dao.findById(policyId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<InsurancePolicyDTO> findAll() throws DAOException {
        List<InsurancePolicy> entities = dao.findAll();
        List<InsurancePolicyDTO> result = new ArrayList<>();
        for (InsurancePolicy entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(InsurancePolicyDTO dto) throws ValidationException {
        Validators.required(dto.getAppId(), "appId");
        Validators.oneOf(dto.getPolicyType(), "policyType", VALID_TYPES.toArray(new String[0]));
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
        Validators.futureOrToday(dto.getValidTill(), "validTill");
        if ("ACTIVE".equalsIgnoreCase(dto.getStatus()) && dto.getValidTill() != null
                && dto.getValidTill().isBefore(java.time.LocalDate.now())) {
            throw new ValidationException("An ACTIVE policy cannot have a validTill date in the past.");
        }
    }

    private InsurancePolicy toEntity(InsurancePolicyDTO dto) {
        InsurancePolicy entity = new InsurancePolicy();
        entity.setPolicyId(dto.getPolicyId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setPolicyType(dto.getPolicyType());
        entity.setStatus(dto.getStatus());
        entity.setValidTill(dto.getValidTill());
        return entity;
    }

    private InsurancePolicyDTO toDto(InsurancePolicy entity) {
        InsurancePolicyDTO dto = new InsurancePolicyDTO();
        dto.setPolicyId(entity.getPolicyId());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setPolicyType(entity.getPolicyType());
        dto.setStatus(entity.getStatus());
        dto.setValidTill(entity.getValidTill());
        return dto;
    }
}
