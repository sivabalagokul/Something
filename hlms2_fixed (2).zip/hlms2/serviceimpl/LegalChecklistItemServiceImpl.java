package hlms.serviceimpl;

import hlms.dao.LegalChecklistItemDAO;
import hlms.daoimpl.LegalChecklistItemDAOImpl;
import hlms.dto.LegalChecklistItemDTO;
import hlms.entity.*;
import hlms.service.LegalChecklistItemService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of LegalChecklistItemService. Converts LegalChecklistItemDTO <-> hlms.entity.LegalChecklistItem
 * and delegates persistence to LegalChecklistItemDAOImpl.
 *
 * Business logic (US-MRC-05): validates checklist key/status and defaults a
 * newly created item to PENDING.
 */
public class LegalChecklistItemServiceImpl implements LegalChecklistItemService {

    private static final List<String> VALID_STATUSES = List.of("PENDING", "COMPLETED", "NOT_APPLICABLE");

    private final LegalChecklistItemDAO dao;

    public LegalChecklistItemServiceImpl() {
        this.dao = new LegalChecklistItemDAOImpl();
    }

    public LegalChecklistItemServiceImpl(LegalChecklistItemDAO dao) {
        this.dao = dao;
    }

    @Override
    public LegalChecklistItemDTO create(LegalChecklistItemDTO dto) throws DAOException {
        validate(dto);
        LegalChecklistItem entity = toEntity(dto);
        if (entity.getChecklistItemId() == null || entity.getChecklistItemId().isBlank()) {
            entity.setChecklistItemId("CHK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setStatus(entity.getStatus() == null ? "PENDING" : entity.getStatus());
        LegalChecklistItem saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LegalChecklistItemDTO update(LegalChecklistItemDTO dto) throws DAOException {
        Validators.required(dto.getChecklistItemId(), "checklistItemId");
        if (dao.findById(dto.getChecklistItemId()) == null) {
            throw new ValidationException("Checklist item " + dto.getChecklistItemId() + " does not exist.");
        }
        validate(dto);
        LegalChecklistItem entity = toEntity(dto);
        LegalChecklistItem saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String checklistItemId) throws DAOException {
        Validators.required(checklistItemId, "checklistItemId");
        return dao.delete(checklistItemId);
    }

    @Override
    public LegalChecklistItemDTO findById(String checklistItemId) throws DAOException {
        Validators.required(checklistItemId, "checklistItemId");
        LegalChecklistItem entity = dao.findById(checklistItemId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LegalChecklistItemDTO> findAll() throws DAOException {
        List<LegalChecklistItem> entities = dao.findAll();
        List<LegalChecklistItemDTO> result = new ArrayList<>();
        for (LegalChecklistItem entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(LegalChecklistItemDTO dto) throws ValidationException {
        Validators.required(dto.getAppId(), "appId");
        Validators.required(dto.getChecklistKey(), "checklistKey");
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
    }

    private LegalChecklistItem toEntity(LegalChecklistItemDTO dto) {
        LegalChecklistItem entity = new LegalChecklistItem();
        entity.setChecklistItemId(dto.getChecklistItemId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setChecklistKey(dto.getChecklistKey());
        entity.setStatus(dto.getStatus());
        return entity;
    }

    private LegalChecklistItemDTO toDto(LegalChecklistItem entity) {
        LegalChecklistItemDTO dto = new LegalChecklistItemDTO();
        dto.setChecklistItemId(entity.getChecklistItemId());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setChecklistKey(entity.getChecklistKey());
        dto.setStatus(entity.getStatus());
        return dto;
    }
}
