package hlms.serviceimpl;

import hlms.dao.LegalNoticeDAO;
import hlms.daoimpl.LegalNoticeDAOImpl;
import hlms.dto.LegalNoticeDTO;
import hlms.entity.*;
import hlms.service.LegalNoticeService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of LegalNoticeService. Converts LegalNoticeDTO <-> hlms.entity.LegalNotice
 * and delegates persistence to LegalNoticeDAOImpl.
 *
 * Business logic (US-DMNG-02, US-DMNG-03): auto-generates a unique notice
 * number, validates the notice window (dueDate must be after issueDate) and
 * restricts status to the Sent/Delivered/Failed lifecycle the backlog calls for.
 */
public class LegalNoticeServiceImpl implements LegalNoticeService {

    private static final List<String> VALID_TYPES = List.of("DEFAULT_NOTICE", "DEMAND_NOTICE", "AUCTION_NOTICE", "LEGAL_NOTICE");
    private static final List<String> VALID_STATUSES = List.of("DRAFT", "SENT", "DELIVERED", "FAILED");

    private final LegalNoticeDAO dao;

    public LegalNoticeServiceImpl() {
        this.dao = new LegalNoticeDAOImpl();
    }

    public LegalNoticeServiceImpl(LegalNoticeDAO dao) {
        this.dao = dao;
    }

    @Override
    public LegalNoticeDTO create(LegalNoticeDTO dto) throws DAOException {
        validate(dto);
        LegalNotice entity = toEntity(dto);
        if (entity.getNoticeId() == null || entity.getNoticeId().isBlank()) {
            entity.setNoticeId("NOT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        // US-DMNG-02: unique, trackable notice number generated automatically.
        entity.setNoticeNo("NOTICE-" + entity.getIssueDate() + "-" + entity.getNoticeId().substring(entity.getNoticeId().length() - 4));
        entity.setStatus(entity.getStatus() == null ? "DRAFT" : entity.getStatus());
        LegalNotice saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LegalNoticeDTO update(LegalNoticeDTO dto) throws DAOException {
        Validators.required(dto.getNoticeId(), "noticeId");
        LegalNotice existing = dao.findById(dto.getNoticeId());
        if (existing == null) {
            throw new ValidationException("Notice " + dto.getNoticeId() + " does not exist.");
        }
        validate(dto);
        LegalNotice entity = toEntity(dto);
        entity.setNoticeNo(dto.getNoticeNo() != null ? dto.getNoticeNo() : existing.getNoticeNo());
        LegalNotice saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String noticeId) throws DAOException {
        Validators.required(noticeId, "noticeId");
        return dao.delete(noticeId);
    }

    @Override
    public LegalNoticeDTO findById(String noticeId) throws DAOException {
        Validators.required(noticeId, "noticeId");
        LegalNotice entity = dao.findById(noticeId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LegalNoticeDTO> findAll() throws DAOException {
        List<LegalNotice> entities = dao.findAll();
        List<LegalNoticeDTO> result = new ArrayList<>();
        for (LegalNotice entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(LegalNoticeDTO dto) throws ValidationException {
        Validators.required(dto.getAppId(), "appId");
        Validators.oneOf(dto.getNoticeType(), "noticeType", VALID_TYPES.toArray(new String[0]));
        Validators.required(dto.getIssueDate(), "issueDate");
        Validators.afterOrEqual(dto.getDueDate(), dto.getIssueDate(), "dueDate", "issueDate");
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
        Validators.required(dto.getOfficerEmail(), "officerEmail");
        Validators.required(dto.getContent(), "content");
    }

    private LegalNotice toEntity(LegalNoticeDTO dto) {
        LegalNotice entity = new LegalNotice();
        entity.setNoticeId(dto.getNoticeId());
        entity.setNoticeNo(dto.getNoticeNo());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setNoticeType(dto.getNoticeType());
        entity.setIssueDate(dto.getIssueDate());
        entity.setDueDate(dto.getDueDate());
        entity.setStatus(dto.getStatus());
        if (dto.getOfficerEmail() != null) {
            AppUser officerRef = new AppUser();
            officerRef.setEmail(dto.getOfficerEmail());
            entity.setOfficer(officerRef);
        }
        entity.setContent(dto.getContent());
        return entity;
    }

    private LegalNoticeDTO toDto(LegalNotice entity) {
        LegalNoticeDTO dto = new LegalNoticeDTO();
        dto.setNoticeId(entity.getNoticeId());
        dto.setNoticeNo(entity.getNoticeNo());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setNoticeType(entity.getNoticeType());
        dto.setIssueDate(entity.getIssueDate());
        dto.setDueDate(entity.getDueDate());
        dto.setStatus(entity.getStatus());
        dto.setOfficerEmail(entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
        dto.setContent(entity.getContent());
        return dto;
    }
}
