package hlms.serviceimpl;

import hlms.dao.LoanApplicationDAO;
import hlms.daoimpl.LoanApplicationDAOImpl;
import hlms.dto.LoanApplicationDTO;
import hlms.entity.*;
import hlms.service.LoanApplicationService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of LoanApplicationService. Converts LoanApplicationDTO <-> hlms.entity.LoanApplication
 * and delegates persistence to LoanApplicationDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how LoanApplicationDAOImpl itself hydrates
 * related objects when reading rows back.
 *
 * Business logic (US-LA-01..06):
 *  - validates all mandatory application fields before anything is persisted
 *  - auto-generates the appId and a unique human-readable tracking number
 *    (US-LA-05) on create
 *  - defaults a freshly submitted application into the SUBMITTED status at
 *    workflow stage 0 (US-LA-01, US-LT-02)
 */
public class LoanApplicationServiceImpl implements LoanApplicationService {

    private static final List<String> VALID_STATUSES = List.of(
            "DRAFT", "SUBMITTED", "UNDER_REVIEW", "DOCUMENT_PENDING", "LEGAL_VERIFICATION",
            "APPROVED", "CONDITIONALLY_APPROVED", "REJECTED", "DISBURSED", "CLOSED", "DEFAULTED");

    private final LoanApplicationDAO dao;

    public LoanApplicationServiceImpl() {
        this.dao = new LoanApplicationDAOImpl();
    }

    public LoanApplicationServiceImpl(LoanApplicationDAO dao) {
        this.dao = dao;
    }

    @Override
    public LoanApplicationDTO create(LoanApplicationDTO dto) throws DAOException {
        validateApplication(dto, true);

        LoanApplication entity = toEntity(dto);
        if (entity.getAppId() == null || entity.getAppId().isBlank()) {
            entity.setAppId("APP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        // US-LA-05: unique, customer-facing tracking number generated automatically.
        entity.setTrackingNo("TRK-" + System.currentTimeMillis() + "-" + entity.getAppId().substring(entity.getAppId().length() - 4));
        entity.setStatus(entity.getStatus() == null || entity.getStatus().isBlank() ? "SUBMITTED" : entity.getStatus());
        entity.setStageIndex(entity.getStageIndex() == null ? 0 : entity.getStageIndex());
        entity.setCreatedAt(entity.getCreatedAt() == null ? OffsetDateTime.now() : entity.getCreatedAt());

        LoanApplication saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LoanApplicationDTO update(LoanApplicationDTO dto) throws DAOException {
        Validators.required(dto.getAppId(), "appId");
        LoanApplication existing = dao.findById(dto.getAppId());
        if (existing == null) {
            throw new ValidationException("Loan application " + dto.getAppId() + " does not exist.");
        }
        validateApplication(dto, false);
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }

        LoanApplication entity = toEntity(dto);
        // Tracking number and creation timestamp are immutable once assigned.
        entity.setTrackingNo(dto.getTrackingNo() != null ? dto.getTrackingNo() : existing.getTrackingNo());
        entity.setCreatedAt(existing.getCreatedAt());

        LoanApplication saved = dao.update(entity);
        return toDto(saved);
    }

    /**
     * US-LA-01 / US-LA-03: validates mandatory applicant, address, employment
     * and property details before an application can be submitted.
     */
    private void validateApplication(LoanApplicationDTO dto, boolean isCreate) throws ValidationException {
        Validators.required(dto.getUserEmail(), "userEmail");
        Validators.required(dto.getProductId(), "productId");
        Validators.positive(dto.getLoanAmount(), "loanAmount");
        Validators.positive(dto.getTenureYears(), "tenureYears");
        Validators.required(dto.getPurpose(), "purpose");
        Validators.required(dto.getApplicantName(), "applicantName");
        Validators.mobile(dto.getApplicantMobile(), "applicantMobile");
        Validators.pan(dto.getApplicantPan(), "applicantPan");
        Validators.required(dto.getAddrDoorNo(), "addrDoorNo");
        Validators.required(dto.getAddrStreet(), "addrStreet");
        Validators.required(dto.getAddrCity(), "addrCity");
        Validators.required(dto.getAddrState(), "addrState");
        Validators.required(dto.getAddrPincode(), "addrPincode");
        Validators.oneOf(dto.getEmploymentType(), "employmentType", "SALARIED", "SELF_EMPLOYED", "BUSINESS");
        Validators.positive(dto.getMonthlyIncome(), "monthlyIncome");
        Validators.nonNegative(dto.getOtherEmis(), "otherEmis");
        if (dto.getPropertyValue() != null) {
            Validators.positive(dto.getPropertyValue(), "propertyValue");
        }
        if (dto.getInterestRate() != null && dto.getInterestRate().compareTo(BigDecimal.ZERO) < 0) {
            throw new ValidationException("interestRate cannot be negative.");
        }
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        return dao.delete(appId);
    }

    @Override
    public LoanApplicationDTO findById(String appId) throws DAOException {
        LoanApplication entity = dao.findById(appId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LoanApplicationDTO> findAll() throws DAOException {
        List<LoanApplication> entities = dao.findAll();
        List<LoanApplicationDTO> result = new ArrayList<>();
        for (LoanApplication entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private LoanApplication toEntity(LoanApplicationDTO dto) {
        LoanApplication entity = new LoanApplication();
        entity.setAppId(dto.getAppId());
        entity.setTrackingNo(dto.getTrackingNo());
        if (dto.getUserEmail() != null) {
            AppUser userRef = new AppUser();
            userRef.setEmail(dto.getUserEmail());
            entity.setUser(userRef);
        }
        if (dto.getProductId() != null) {
            LoanProduct productRef = new LoanProduct();
            productRef.setProductId(dto.getProductId());
            entity.setProduct(productRef);
        }
        entity.setLoanAmount(dto.getLoanAmount());
        entity.setTenureYears(dto.getTenureYears());
        entity.setPurpose(dto.getPurpose());
        entity.setInterestRate(dto.getInterestRate());
        entity.setStatus(dto.getStatus());
        entity.setStageIndex(dto.getStageIndex());
        entity.setCreatedAt(dto.getCreatedAt());
        entity.setApplicantName(dto.getApplicantName());
        entity.setApplicantMobile(dto.getApplicantMobile());
        entity.setApplicantPan(dto.getApplicantPan());
        entity.setAddrDoorNo(dto.getAddrDoorNo());
        entity.setAddrStreet(dto.getAddrStreet());
        entity.setAddrCity(dto.getAddrCity());
        entity.setAddrState(dto.getAddrState());
        entity.setAddrPincode(dto.getAddrPincode());
        entity.setEmploymentType(dto.getEmploymentType());
        entity.setEmployer(dto.getEmployer());
        entity.setMonthlyIncome(dto.getMonthlyIncome());
        entity.setOtherEmis(dto.getOtherEmis());
        entity.setPropertyAddress(dto.getPropertyAddress());
        entity.setPropertyType(dto.getPropertyType());
        entity.setPropertyValue(dto.getPropertyValue());
        return entity;
    }

    private LoanApplicationDTO toDto(LoanApplication entity) {
        LoanApplicationDTO dto = new LoanApplicationDTO();
        dto.setAppId(entity.getAppId());
        dto.setTrackingNo(entity.getTrackingNo());
        dto.setUserEmail(entity.getUser() == null ? null : entity.getUser().getEmail());
        dto.setProductId(entity.getProduct() == null ? null : entity.getProduct().getProductId());
        dto.setLoanAmount(entity.getLoanAmount());
        dto.setTenureYears(entity.getTenureYears());
        dto.setPurpose(entity.getPurpose());
        dto.setInterestRate(entity.getInterestRate());
        dto.setStatus(entity.getStatus());
        dto.setStageIndex(entity.getStageIndex());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setApplicantName(entity.getApplicantName());
        dto.setApplicantMobile(entity.getApplicantMobile());
        dto.setApplicantPan(entity.getApplicantPan());
        dto.setAddrDoorNo(entity.getAddrDoorNo());
        dto.setAddrStreet(entity.getAddrStreet());
        dto.setAddrCity(entity.getAddrCity());
        dto.setAddrState(entity.getAddrState());
        dto.setAddrPincode(entity.getAddrPincode());
        dto.setEmploymentType(entity.getEmploymentType());
        dto.setEmployer(entity.getEmployer());
        dto.setMonthlyIncome(entity.getMonthlyIncome());
        dto.setOtherEmis(entity.getOtherEmis());
        dto.setPropertyAddress(entity.getPropertyAddress());
        dto.setPropertyType(entity.getPropertyType());
        dto.setPropertyValue(entity.getPropertyValue());
        return dto;
    }
}
