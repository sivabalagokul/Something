package hlms.serviceimpl;

import hlms.dao.LoanDraftDAO;
import hlms.daoimpl.LoanDraftDAOImpl;
import hlms.dto.LoanDraftDTO;
import hlms.entity.*;
import hlms.service.LoanDraftService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of LoanDraftService. Converts LoanDraftDTO <-> hlms.entity.LoanDraft
 * and delegates persistence to LoanDraftDAOImpl.
 *
 * Business logic (US-LA-06): a draft only needs a user + step to be saved
 * (that is the point of a draft - incomplete data is expected), but whatever
 * IS supplied must be well-formed, and draftId/savedAt are managed here
 * instead of trusting the caller.
 */
public class LoanDraftServiceImpl implements LoanDraftService {

    private final LoanDraftDAO dao;

    public LoanDraftServiceImpl() {
        this.dao = new LoanDraftDAOImpl();
    }

    public LoanDraftServiceImpl(LoanDraftDAO dao) {
        this.dao = dao;
    }

    @Override
    public LoanDraftDTO create(LoanDraftDTO dto) throws DAOException {
        validate(dto);
        LoanDraft entity = toEntity(dto);
        if (entity.getDraftId() == null || entity.getDraftId().isBlank()) {
            entity.setDraftId("DRF-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setSavedAt(OffsetDateTime.now());
        entity.setCurrentStep(entity.getCurrentStep() == null ? 1 : entity.getCurrentStep());
        LoanDraft saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LoanDraftDTO update(LoanDraftDTO dto) throws DAOException {
        Validators.required(dto.getDraftId(), "draftId");
        if (dao.findById(dto.getDraftId()) == null) {
            throw new ValidationException("Draft " + dto.getDraftId() + " does not exist.");
        }
        validate(dto);
        LoanDraft entity = toEntity(dto);
        entity.setSavedAt(OffsetDateTime.now()); // US-LA-06: resume-and-save always bumps savedAt.
        LoanDraft saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String draftId) throws DAOException {
        Validators.required(draftId, "draftId");
        return dao.delete(draftId);
    }

    @Override
    public LoanDraftDTO findById(String draftId) throws DAOException {
        Validators.required(draftId, "draftId");
        LoanDraft entity = dao.findById(draftId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LoanDraftDTO> findAll() throws DAOException {
        List<LoanDraft> entities = dao.findAll();
        List<LoanDraftDTO> result = new ArrayList<>();
        for (LoanDraft entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(LoanDraftDTO dto) throws ValidationException {
        Validators.required(dto.getUserEmail(), "userEmail");
        if (dto.getCurrentStep() != null && dto.getCurrentStep() <= 0) {
            throw new ValidationException("currentStep must be greater than zero.");
        }
        if (dto.getLoanAmount() != null && dto.getLoanAmount().signum() < 0) {
            throw new ValidationException("loanAmount cannot be negative.");
        }
        if (dto.getTenureYears() != null && dto.getTenureYears() <= 0) {
            throw new ValidationException("tenureYears must be greater than zero.");
        }
    }

    private LoanDraft toEntity(LoanDraftDTO dto) {
        LoanDraft entity = new LoanDraft();
        entity.setDraftId(dto.getDraftId());
        if (dto.getUserEmail() != null) {
            AppUser userRef = new AppUser();
            userRef.setEmail(dto.getUserEmail());
            entity.setUser(userRef);
        }
        entity.setCurrentStep(dto.getCurrentStep());
        entity.setSavedAt(dto.getSavedAt());
        entity.setLoanType(dto.getLoanType());
        entity.setLoanAmount(dto.getLoanAmount());
        entity.setTenureYears(dto.getTenureYears());
        entity.setFormData(dto.getFormData());
        return entity;
    }

    private LoanDraftDTO toDto(LoanDraft entity) {
        LoanDraftDTO dto = new LoanDraftDTO();
        dto.setDraftId(entity.getDraftId());
        dto.setUserEmail(entity.getUser() == null ? null : entity.getUser().getEmail());
        dto.setCurrentStep(entity.getCurrentStep());
        dto.setSavedAt(entity.getSavedAt());
        dto.setLoanType(entity.getLoanType());
        dto.setLoanAmount(entity.getLoanAmount());
        dto.setTenureYears(entity.getTenureYears());
        dto.setFormData(entity.getFormData());
        return dto;
    }
}
