package hlms.serviceimpl;

import hlms.dao.LoanProductDAO;
import hlms.daoimpl.LoanProductDAOImpl;
import hlms.dto.LoanProductDTO;
import hlms.entity.*;
import hlms.service.LoanProductService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of LoanProductService. Converts LoanProductDTO <-> hlms.entity.LoanProduct
 * and delegates persistence to LoanProductDAOImpl.
 *
 * Business logic (US-LG-01, US-LG-02): validates catalog data and normalises
 * the product category into the fixed set of loan types the guidance module
 * filters by.
 */
public class LoanProductServiceImpl implements LoanProductService {

    private static final List<String> VALID_CATEGORIES =
            List.of("HOME_PURCHASE", "CONSTRUCTION", "RENOVATION", "PLOT_LOAN", "BALANCE_TRANSFER", "TOP_UP");

    private final LoanProductDAO dao;

    public LoanProductServiceImpl() {
        this.dao = new LoanProductDAOImpl();
    }

    public LoanProductServiceImpl(LoanProductDAO dao) {
        this.dao = dao;
    }

    @Override
    public LoanProductDTO create(LoanProductDTO dto) throws DAOException {
        validate(dto);
        LoanProduct entity = toEntity(dto);
        if (entity.getProductId() == null || entity.getProductId().isBlank()) {
            entity.setProductId("PRD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        LoanProduct saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LoanProductDTO update(LoanProductDTO dto) throws DAOException {
        Validators.required(dto.getProductId(), "productId");
        if (dao.findById(dto.getProductId()) == null) {
            throw new ValidationException("Loan product " + dto.getProductId() + " does not exist.");
        }
        validate(dto);
        LoanProduct entity = toEntity(dto);
        LoanProduct saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String productId) throws DAOException {
        Validators.required(productId, "productId");
        return dao.delete(productId);
    }

    @Override
    public LoanProductDTO findById(String productId) throws DAOException {
        Validators.required(productId, "productId");
        LoanProduct entity = dao.findById(productId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LoanProductDTO> findAll() throws DAOException {
        List<LoanProduct> entities = dao.findAll();
        List<LoanProductDTO> result = new ArrayList<>();
        for (LoanProduct entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(LoanProductDTO dto) throws ValidationException {
        Validators.required(dto.getName(), "name");
        Validators.oneOf(dto.getCategory(), "category", VALID_CATEGORIES.toArray(new String[0]));
        Validators.positive(dto.getInterestRate(), "interestRate");
        if (dto.getInterestRate() != null && dto.getInterestRate().compareTo(BigDecimal.valueOf(30)) > 0) {
            throw new ValidationException("interestRate looks implausibly high (>30%).");
        }
        Validators.positive(dto.getMaxTenureYears(), "maxTenureYears");
        if (dto.getMaxTenureYears() != null && dto.getMaxTenureYears() > 30) {
            throw new ValidationException("maxTenureYears cannot exceed 30 years.");
        }
        Validators.required(dto.getMaxLtv(), "maxLtv");
    }

    private LoanProduct toEntity(LoanProductDTO dto) {
        LoanProduct entity = new LoanProduct();
        entity.setProductId(dto.getProductId());
        entity.setName(dto.getName());
        entity.setCategory(dto.getCategory());
        entity.setInterestRate(dto.getInterestRate());
        entity.setMaxTenureYears(dto.getMaxTenureYears());
        entity.setMaxLtv(dto.getMaxLtv());
        entity.setDescription(dto.getDescription());
        return entity;
    }

    private LoanProductDTO toDto(LoanProduct entity) {
        LoanProductDTO dto = new LoanProductDTO();
        dto.setProductId(entity.getProductId());
        dto.setName(entity.getName());
        dto.setCategory(entity.getCategory());
        dto.setInterestRate(entity.getInterestRate());
        dto.setMaxTenureYears(entity.getMaxTenureYears());
        dto.setMaxLtv(entity.getMaxLtv());
        dto.setDescription(entity.getDescription());
        return dto;
    }
}
