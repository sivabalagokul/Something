package hlms.serviceimpl;

import hlms.dao.NotificationDAO;
import hlms.daoimpl.NotificationDAOImpl;
import hlms.dto.NotificationDTO;
import hlms.entity.*;
import hlms.service.NotificationService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of NotificationService. Converts NotificationDTO <-> hlms.entity.Notification
 * and delegates persistence to NotificationDAOImpl.
 *
 * Business logic (US-NM-01..05): validates that every notification has real
 * content and only uses supported channels (SMS/EMAIL/INAPP), and defaults
 * isRead/createdAt so callers never have to think about them.
 */
public class NotificationServiceImpl implements NotificationService {

    private static final List<String> VALID_CHANNELS = List.of("SMS", "EMAIL", "INAPP");

    private final NotificationDAO dao;

    public NotificationServiceImpl() {
        this.dao = new NotificationDAOImpl();
    }

    public NotificationServiceImpl(NotificationDAO dao) {
        this.dao = dao;
    }

    @Override
    public NotificationDTO create(NotificationDTO dto) throws DAOException {
        validate(dto);
        Notification entity = toEntity(dto);
        if (entity.getNotificationId() == null || entity.getNotificationId().isBlank()) {
            entity.setNotificationId("NTF-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setIsRead(entity.getIsRead() == null ? Boolean.FALSE : entity.getIsRead());
        entity.setCreatedAt(entity.getCreatedAt() == null ? OffsetDateTime.now() : entity.getCreatedAt());
        Notification saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public NotificationDTO update(NotificationDTO dto) throws DAOException {
        Validators.required(dto.getNotificationId(), "notificationId");
        if (dao.findById(dto.getNotificationId()) == null) {
            throw new ValidationException("Notification " + dto.getNotificationId() + " does not exist.");
        }
        validate(dto);
        Notification entity = toEntity(dto);
        Notification saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String notificationId) throws DAOException {
        Validators.required(notificationId, "notificationId");
        return dao.delete(notificationId);
    }

    @Override
    public NotificationDTO findById(String notificationId) throws DAOException {
        Validators.required(notificationId, "notificationId");
        Notification entity = dao.findById(notificationId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<NotificationDTO> findAll() throws DAOException {
        List<Notification> entities = dao.findAll();
        List<NotificationDTO> result = new ArrayList<>();
        for (Notification entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(NotificationDTO dto) throws ValidationException {
        Validators.required(dto.getUserEmail(), "userEmail");
        Validators.required(dto.getTitle(), "title");
        Validators.required(dto.getBody(), "body");
        if (dto.getChannels() == null || dto.getChannels().length == 0) {
            throw new ValidationException("At least one notification channel is required.");
        }
        for (String channel : dto.getChannels()) {
            if (channel == null || !VALID_CHANNELS.contains(channel.toUpperCase())) {
                throw new ValidationException("Unsupported channel '" + channel + "'. Allowed: " + VALID_CHANNELS + ".");
            }
        }
    }

    private Notification toEntity(NotificationDTO dto) {
        Notification entity = new Notification();
        entity.setNotificationId(dto.getNotificationId());
        if (dto.getUserEmail() != null) {
            AppUser userRef = new AppUser();
            userRef.setEmail(dto.getUserEmail());
            entity.setUser(userRef);
        }
        entity.setTitle(dto.getTitle());
        entity.setBody(dto.getBody());
        entity.setChannels(dto.getChannels());
        entity.setIsRead(dto.getIsRead());
        entity.setCreatedAt(dto.getCreatedAt());
        return entity;
    }

    private NotificationDTO toDto(Notification entity) {
        NotificationDTO dto = new NotificationDTO();
        dto.setNotificationId(entity.getNotificationId());
        dto.setUserEmail(entity.getUser() == null ? null : entity.getUser().getEmail());
        dto.setTitle(entity.getTitle());
        dto.setBody(entity.getBody());
        dto.setChannels(entity.getChannels());
        dto.setIsRead(entity.getIsRead());
        dto.setCreatedAt(entity.getCreatedAt());
        return dto;
    }
}
