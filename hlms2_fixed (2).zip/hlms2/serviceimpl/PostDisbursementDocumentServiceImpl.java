package hlms.serviceimpl;

import hlms.dao.PostDisbursementDocumentDAO;
import hlms.daoimpl.PostDisbursementDocumentDAOImpl;
import hlms.dto.PostDisbursementDocumentDTO;
import hlms.entity.*;
import hlms.service.PostDisbursementDocumentService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of PostDisbursementDocumentService. Converts PostDisbursementDocumentDTO <-> hlms.entity.PostDisbursementDocument
 * and delegates persistence to PostDisbursementDocumentDAOImpl.
 *
 * Business logic (US-PD-04, US-PD-08): validates uploaded post-disbursement
 * documents (inspection reports, sign-offs, exchanged paperwork) the same
 * way pre-disbursement documents are validated.
 */
public class PostDisbursementDocumentServiceImpl implements PostDisbursementDocumentService {

    private static final List<String> VALID_DOC_TYPES = List.of(
            "INSPECTION_REPORT", "APPROVAL_SIGNOFF", "NOC", "PROPERTY_UPDATE", "OTHER");
    private static final List<String> VALID_STATUSES = List.of("PENDING", "APPROVED", "REJECTED");
    private static final int MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024;

    private final PostDisbursementDocumentDAO dao;

    public PostDisbursementDocumentServiceImpl() {
        this.dao = new PostDisbursementDocumentDAOImpl();
    }

    public PostDisbursementDocumentServiceImpl(PostDisbursementDocumentDAO dao) {
        this.dao = dao;
    }

    @Override
    public PostDisbursementDocumentDTO create(PostDisbursementDocumentDTO dto) throws DAOException {
        validate(dto);
        PostDisbursementDocument entity = toEntity(dto);
        if (entity.getPdDocId() == null || entity.getPdDocId().isBlank()) {
            entity.setPdDocId("PDD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setUploadedAt(entity.getUploadedAt() == null ? OffsetDateTime.now() : entity.getUploadedAt());
        entity.setStatus(entity.getStatus() == null ? "PENDING" : entity.getStatus());
        PostDisbursementDocument saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public PostDisbursementDocumentDTO update(PostDisbursementDocumentDTO dto) throws DAOException {
        Validators.required(dto.getPdDocId(), "pdDocId");
        PostDisbursementDocument existing = dao.findById(dto.getPdDocId());
        if (existing == null) {
            throw new ValidationException("Post-disbursement document " + dto.getPdDocId() + " does not exist.");
        }
        validate(dto);
        if (("APPROVED".equalsIgnoreCase(dto.getStatus()) || "REJECTED".equalsIgnoreCase(dto.getStatus()))
                && dto.getVerifiedByEmail() == null) {
            throw new ValidationException("verifiedByEmail is required when marking a document APPROVED or REJECTED.");
        }
        PostDisbursementDocument entity = toEntity(dto);
        entity.setUploadedAt(existing.getUploadedAt());
        if (dto.getVerifiedByEmail() != null && dto.getVerifiedAt() == null) {
            entity.setVerifiedAt(OffsetDateTime.now());
        }
        PostDisbursementDocument saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String pdDocId) throws DAOException {
        Validators.required(pdDocId, "pdDocId");
        return dao.delete(pdDocId);
    }

    @Override
    public PostDisbursementDocumentDTO findById(String pdDocId) throws DAOException {
        Validators.required(pdDocId, "pdDocId");
        PostDisbursementDocument entity = dao.findById(pdDocId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<PostDisbursementDocumentDTO> findAll() throws DAOException {
        List<PostDisbursementDocument> entities = dao.findAll();
        List<PostDisbursementDocumentDTO> result = new ArrayList<>();
        for (PostDisbursementDocument entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(PostDisbursementDocumentDTO dto) throws ValidationException {
        Validators.required(dto.getAppId(), "appId");
        Validators.oneOf(dto.getDocType(), "docType", VALID_DOC_TYPES.toArray(new String[0]));
        Validators.required(dto.getFileName(), "fileName");
        Validators.positive(dto.getFileSize(), "fileSize");
        if (dto.getFileSize() != null && dto.getFileSize() > MAX_FILE_SIZE_BYTES) {
            throw new ValidationException("fileSize exceeds the 10 MB upload limit.");
        }
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
    }

    private PostDisbursementDocument toEntity(PostDisbursementDocumentDTO dto) {
        PostDisbursementDocument entity = new PostDisbursementDocument();
        entity.setPdDocId(dto.getPdDocId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setDocType(dto.getDocType());
        entity.setFileName(dto.getFileName());
        entity.setFileSize(dto.getFileSize());
        entity.setNote(dto.getNote());
        entity.setStatus(dto.getStatus());
        entity.setUploadedAt(dto.getUploadedAt());
        if (dto.getVerifiedByEmail() != null) {
            AppUser verifiedByRef = new AppUser();
            verifiedByRef.setEmail(dto.getVerifiedByEmail());
            entity.setVerifiedBy(verifiedByRef);
        }
        entity.setVerifiedAt(dto.getVerifiedAt());
        entity.setRemarks(dto.getRemarks());
        return entity;
    }

    private PostDisbursementDocumentDTO toDto(PostDisbursementDocument entity) {
        PostDisbursementDocumentDTO dto = new PostDisbursementDocumentDTO();
        dto.setPdDocId(entity.getPdDocId());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setDocType(entity.getDocType());
        dto.setFileName(entity.getFileName());
        dto.setFileSize(entity.getFileSize());
        dto.setNote(entity.getNote());
        dto.setStatus(entity.getStatus());
        dto.setUploadedAt(entity.getUploadedAt());
        dto.setVerifiedByEmail(entity.getVerifiedBy() == null ? null : entity.getVerifiedBy().getEmail());
        dto.setVerifiedAt(entity.getVerifiedAt());
        dto.setRemarks(entity.getRemarks());
        return dto;
    }
}
