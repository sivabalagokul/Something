package hlms.serviceimpl;

import hlms.dao.ServiceRequestDAO;
import hlms.daoimpl.ServiceRequestDAOImpl;
import hlms.dto.ServiceRequestDTO;
import hlms.entity.*;
import hlms.service.ServiceRequestService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Default implementation of ServiceRequestService. Converts ServiceRequestDTO <-> hlms.entity.ServiceRequest
 * and delegates persistence to ServiceRequestDAOImpl.
 *
 * Business logic (US-PD-01..08): validates request type/description and
 * auto-generates a customer-facing reference number, mirroring the loan
 * application tracking number pattern (US-LA-05).
 */
public class ServiceRequestServiceImpl implements ServiceRequestService {

    private static final List<String> VALID_TYPES = List.of(
            "ENGINEER_INSPECTION", "DOCUMENT_EXCHANGE", "NOC_REQUEST", "FORECLOSURE", "GENERAL_QUERY");
    private static final List<String> VALID_STATUSES = List.of("SUBMITTED", "ASSIGNED", "IN_PROGRESS", "COMPLETED", "REJECTED");

    private final ServiceRequestDAO dao;

    public ServiceRequestServiceImpl() {
        this.dao = new ServiceRequestDAOImpl();
    }

    public ServiceRequestServiceImpl(ServiceRequestDAO dao) {
        this.dao = dao;
    }

    @Override
    public ServiceRequestDTO create(ServiceRequestDTO dto) throws DAOException {
        validate(dto);
        ServiceRequest entity = toEntity(dto);
        if (entity.getRequestId() == null || entity.getRequestId().isBlank()) {
            entity.setRequestId("SR-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        // US-PD-01: unique tracking reference generated automatically.
        entity.setRefNo("REF-" + System.currentTimeMillis() + "-" + entity.getRequestId().substring(entity.getRequestId().length() - 4));
        entity.setStatus(entity.getStatus() == null ? "SUBMITTED" : entity.getStatus());
        entity.setCreatedAt(entity.getCreatedAt() == null ? OffsetDateTime.now() : entity.getCreatedAt());
        ServiceRequest saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public ServiceRequestDTO update(ServiceRequestDTO dto) throws DAOException {
        Validators.required(dto.getRequestId(), "requestId");
        ServiceRequest existing = dao.findById(dto.getRequestId());
        if (existing == null) {
            throw new ValidationException("Service request " + dto.getRequestId() + " does not exist.");
        }
        validate(dto);
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
        ServiceRequest entity = toEntity(dto);
        entity.setRefNo(dto.getRefNo() != null ? dto.getRefNo() : existing.getRefNo());
        entity.setCreatedAt(existing.getCreatedAt());
        ServiceRequest saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String requestId) throws DAOException {
        Validators.required(requestId, "requestId");
        return dao.delete(requestId);
    }

    @Override
    public ServiceRequestDTO findById(String requestId) throws DAOException {
        Validators.required(requestId, "requestId");
        ServiceRequest entity = dao.findById(requestId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<ServiceRequestDTO> findAll() throws DAOException {
        List<ServiceRequest> entities = dao.findAll();
        List<ServiceRequestDTO> result = new ArrayList<>();
        for (ServiceRequest entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(ServiceRequestDTO dto) throws ValidationException {
        Validators.required(dto.getUserEmail(), "userEmail");
        Validators.oneOf(dto.getRequestType(), "requestType", VALID_TYPES.toArray(new String[0]));
        Validators.required(dto.getDescription(), "description");
        Validators.maxLength(dto.getDescription(), "description", 2000);
    }

    private ServiceRequest toEntity(ServiceRequestDTO dto) {
        ServiceRequest entity = new ServiceRequest();
        entity.setRequestId(dto.getRequestId());
        entity.setRefNo(dto.getRefNo());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        if (dto.getUserEmail() != null) {
            AppUser userRef = new AppUser();
            userRef.setEmail(dto.getUserEmail());
            entity.setUser(userRef);
        }
        entity.setRequestType(dto.getRequestType());
        entity.setDescription(dto.getDescription());
        entity.setStatus(dto.getStatus());
        entity.setCreatedAt(dto.getCreatedAt());
        return entity;
    }

    private ServiceRequestDTO toDto(ServiceRequest entity) {
        ServiceRequestDTO dto = new ServiceRequestDTO();
        dto.setRequestId(entity.getRequestId());
        dto.setRefNo(entity.getRefNo());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setUserEmail(entity.getUser() == null ? null : entity.getUser().getEmail());
        dto.setRequestType(entity.getRequestType());
        dto.setDescription(entity.getDescription());
        dto.setStatus(entity.getStatus());
        dto.setCreatedAt(entity.getCreatedAt());
        return dto;
    }
}
