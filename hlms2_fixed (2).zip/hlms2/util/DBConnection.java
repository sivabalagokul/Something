package hlms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Central place to obtain a JDBC connection to the PostgreSQL "hlms" database.
 *
 * Update DB_URL / DB_USER / DB_PASSWORD below to match your local PostgreSQL
 * setup, or replace the hard-coded values with a properties file /
 * environment variables if you prefer.
 *
 * A brand new Connection is returned on every call; callers are expected to
 * use try-with-resources (as all the generated DAOImpl classes do) so the
 * connection is closed automatically after each operation.
 */
public class DBConnection {

    private static final String DB_URL =
            "jdbc:postgresql://10.23.240.29:5432/Housing_Loan_db";
    private static final String DB_USER = "Housing_Loan_user";
    private static final String DB_PASSWORD = "Loan_Tata@123";

    static {
        try {
            // Not strictly required with JDBC 4+ / the pgjdbc driver on the
            // classpath, but keeping it makes the failure mode explicit if
            // the driver jar is missing.
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(
                    "PostgreSQL JDBC driver not found on classpath. " +
                    "Add the postgresql-42.x.x.jar dependency.", e);
        }
    }

    private DBConnection() {
        // utility class, no instances
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }
}
