package hlms.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.regex.Pattern;

/**
 * Salted SHA-256 password hashing. The stored format is
 * "{salt-base64}:{hash-base64}" so a single VARCHAR column (password_hash)
 * can hold both parts. No plaintext password is ever persisted or returned
 * from the service layer.
 */
public final class PasswordUtil {

    private PasswordUtil() {
    }

    // At least 8 chars, one letter and one digit - matches US-UM-04 "new password validation".
    private static final Pattern STRONG_PASSWORD =
            Pattern.compile("^(?=.*[A-Za-z])(?=.*\\d).{8,}$");

    public static void validateStrength(String rawPassword) throws ValidationException {
        if (rawPassword == null || !STRONG_PASSWORD.matcher(rawPassword).matches()) {
            throw new ValidationException(
                    "Password must be at least 8 characters long and contain at least one letter and one digit.");
        }
    }

    public static String hash(String rawPassword) {
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            byte[] digest = digest(rawPassword, salt);
            return Base64.getEncoder().encodeToString(salt) + ":" + Base64.getEncoder().encodeToString(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    public static boolean matches(String rawPassword, String storedHash) {
        if (storedHash == null || !storedHash.contains(":")) {
            return false;
        }
        try {
            String[] parts = storedHash.split(":", 2);
            byte[] salt = Base64.getDecoder().decode(parts[0]);
            byte[] expected = Base64.getDecoder().decode(parts[1]);
            byte[] actual = digest(rawPassword, salt);
            return MessageDigest.isEqual(expected, actual);
        } catch (Exception e) {
            return false;
        }
    }

    private static byte[] digest(String rawPassword, byte[] salt) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(salt);
        return md.digest(rawPassword.getBytes());
    }
}
