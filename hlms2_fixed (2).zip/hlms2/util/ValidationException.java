package hlms.util;

/**
 * Thrown by the service layer when a DTO fails business/field validation
 * before it is ever handed to a DAO. Extends DAOException so existing
 * callers that already catch DAOException continue to work unchanged.
 */
public class ValidationException extends DAOException {

    public ValidationException(String message) {
        super(message);
    }
}
