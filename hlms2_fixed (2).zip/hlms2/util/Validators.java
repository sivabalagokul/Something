package hlms.util;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.regex.Pattern;

/**
 * Central place for the field-level and simple business-rule checks that
 * every ServiceImpl needs (required fields, formats, ranges, enums).
 * Keeping them here avoids duplicating the same regex / null-check logic
 * in twenty different ServiceImpl classes.
 */
public final class Validators {

    private Validators() {
    }

    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern MOBILE = Pattern.compile("^[6-9]\\d{9}$");
    private static final Pattern PAN = Pattern.compile("^[A-Z]{5}[0-9]{4}[A-Z]$");
    private static final Pattern AADHAAR = Pattern.compile("^\\d{12}$");

    public static void required(Object value, String fieldName) throws ValidationException {
        if (value == null || (value instanceof String && ((String) value).trim().isEmpty())) {
            throw new ValidationException(fieldName + " is required.");
        }
    }

    public static void email(String value, String fieldName) throws ValidationException {
        required(value, fieldName);
        if (!EMAIL.matcher(value.trim()).matches()) {
            throw new ValidationException(fieldName + " must be a valid email address.");
        }
    }

    public static void mobile(String value, String fieldName) throws ValidationException {
        required(value, fieldName);
        if (!MOBILE.matcher(value.trim()).matches()) {
            throw new ValidationException(fieldName + " must be a valid 10-digit Indian mobile number.");
        }
    }

    public static void pan(String value, String fieldName) throws ValidationException {
        required(value, fieldName);
        if (!PAN.matcher(value.trim().toUpperCase()).matches()) {
            throw new ValidationException(fieldName + " must be a valid PAN (e.g. ABCDE1234F).");
        }
    }

    public static void aadhaar(String value, String fieldName) throws ValidationException {
        required(value, fieldName);
        if (!AADHAAR.matcher(value.trim()).matches()) {
            throw new ValidationException(fieldName + " must be a valid 12-digit Aadhaar number.");
        }
    }

    /** Validates identity document number based on the declared idType (PAN or AADHAAR). */
    public static void identityDocument(String idType, String idNumber) throws ValidationException {
        required(idType, "idType");
        String type = idType.trim().toUpperCase();
        if (type.equals("PAN")) {
            pan(idNumber, "idNumber");
        } else if (type.equals("AADHAAR")) {
            aadhaar(idNumber, "idNumber");
        } else {
            throw new ValidationException("idType must be one of PAN, AADHAAR.");
        }
    }

    public static void oneOf(String value, String fieldName, String... allowed) throws ValidationException {
        required(value, fieldName);
        for (String a : allowed) {
            if (a.equalsIgnoreCase(value.trim())) {
                return;
            }
        }
        throw new ValidationException(fieldName + " must be one of " + String.join(", ", allowed) + ".");
    }

    public static void positive(BigDecimal value, String fieldName) throws ValidationException {
        required(value, fieldName);
        if (value.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ValidationException(fieldName + " must be greater than zero.");
        }
    }

    public static void nonNegative(BigDecimal value, String fieldName) throws ValidationException {
        required(value, fieldName);
        if (value.compareTo(BigDecimal.ZERO) < 0) {
            throw new ValidationException(fieldName + " cannot be negative.");
        }
    }

    public static void positive(Integer value, String fieldName) throws ValidationException {
        required(value, fieldName);
        if (value <= 0) {
            throw new ValidationException(fieldName + " must be greater than zero.");
        }
    }

    public static void maxLength(String value, String fieldName, int max) throws ValidationException {
        if (value != null && value.length() > max) {
            throw new ValidationException(fieldName + " must not exceed " + max + " characters.");
        }
    }

    public static void notFuture(LocalDate value, String fieldName) throws ValidationException {
        required(value, fieldName);
        if (value.isAfter(LocalDate.now())) {
            throw new ValidationException(fieldName + " cannot be in the future.");
        }
    }

    public static void futureOrToday(LocalDate value, String fieldName) throws ValidationException {
        required(value, fieldName);
        if (value.isBefore(LocalDate.now())) {
            throw new ValidationException(fieldName + " cannot be in the past.");
        }
    }

    public static void afterOrEqual(LocalDate later, LocalDate earlier, String laterField, String earlierField) throws ValidationException {
        required(later, laterField);
        required(earlier, earlierField);
        if (later.isBefore(earlier)) {
            throw new ValidationException(laterField + " cannot be before " + earlierField + ".");
        }
    }

    public static OffsetDateTime nowIfNull(OffsetDateTime value) {
        return value != null ? value : OffsetDateTime.now();
    }
}
