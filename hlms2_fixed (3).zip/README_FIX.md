# Fix: schema/code mismatches on CHECK constraints (code-side only)

Your schema (`hlms_schema_corrected.sql`) has exactly **three** CHECK
constraints. The Java code had its own, independently-invented enum
lists for all three, none of which matched. This fix updates the Java
code only — no schema/constraint changes.

## 1. `app_user.role`

Schema allows: `customer`, `legal`, `bankoffice`, `bidder`, `admin`

Code had: `ADMIN, CUSTOMER, LOAN_OFFICER, LEGAL_OFFICER, ENGINEER, MANAGER`
(uppercase, and 4 of those 6 values don't exist in the schema at all)

**Fixed in:**
- `AppUserServiceImpl.java` — `VALID_ROLES` now matches the schema;
  `register()`/`assignRole()` normalize to lowercase instead of
  uppercase.
- `RolePermissionServiceImpl.java` — same `VALID_ROLES` list was
  wrong here too (this table has no CHECK constraint of its own, but
  the app-level validation was silently rejecting valid roles like
  `bankoffice`/`bidder`/`legal`).

## 2. `insurance_policy.policy_type`

Schema allows: `property`, `life`

Code had: `LIFE, PROPERTY, TERM` (uppercase, plus `TERM` which the
schema doesn't accept at all)

**Fixed in:** `InsurancePolicyServiceImpl.java` — `VALID_TYPES` now
matches the schema exactly.

## 3. `auction_case.stage`

Schema allows: `None`, `Notice Issued`, `Possession`,
`Auction Scheduled`, `Resolved`

Code had: `NOTICE_ISSUED, POSSESSION_TAKEN, AUCTION_SCHEDULED,
AUCTION_COMPLETED, RECOVERY_CLOSED` — completely different
vocabulary (underscored, uppercase, different stage names/count).

**Fixed in:** `AuctionCaseServiceImpl.java` — `VALID_STAGES` and the
default stage on `create()` now use the schema's exact values.

## Also updated for consistency (no CHECK constraint, but wrong casing)

`insurance_policy.status` has no CHECK constraint, but the schema
comments document the app's actual casing as `'Active'` (not
`'ACTIVE'`). `InsurancePolicyServiceImpl`'s default and `VALID_STATUSES`
were updated to match, purely for consistency — this wouldn't have
caused an error, just a naming mismatch.

## Files changed

- `hlms2/serviceimpl/AppUserServiceImpl.java`
- `hlms2/serviceimpl/RolePermissionServiceImpl.java`
- `hlms2/serviceimpl/InsurancePolicyServiceImpl.java`
- `hlms2/serviceimpl/AuctionCaseServiceImpl.java`
- `hlms2/main/HlmsFullDemoMain.java` — every hardcoded role/stage/
  policy-type literal in the demo updated to the schema's real values
  (e.g. `"CUSTOMER"` → `"customer"`, `"LOAN_OFFICER"` → `"bankoffice"`,
  `"NOTICE_ISSUED"` → `"Notice Issued"`, `"AUCTION_SCHEDULED"` →
  `"Auction Scheduled"`, insurance status `"ACTIVE"` → `"Active"`).

## How to run

No database changes needed — your schema/constraints are untouched.
Drop the updated files into your Eclipse project and re-run
`HlmsFullDemoMain`. Both `runEntityLayerDemo()` and
`runServiceLayerDemo()` should now complete end-to-end.

If you hit further constraint errors, the fastest way to track them
down is: find the failing `INSERT`/`UPDATE` in the console output,
note the column named in the constraint (e.g.
`some_table_some_column_check`), then check that column's `CHECK (...)`
clause in `hlms_schema_corrected.sql` against whatever value the
corresponding `ServiceImpl`/demo code is sending.

