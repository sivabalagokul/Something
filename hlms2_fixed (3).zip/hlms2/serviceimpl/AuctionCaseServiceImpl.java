package hlms.serviceimpl;

import hlms.dao.AuctionCaseDAO;
import hlms.daoimpl.AuctionCaseDAOImpl;
import hlms.dto.AuctionCaseDTO;
import hlms.entity.*;
import hlms.service.AuctionCaseService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of AuctionCaseService. Converts AuctionCaseDTO <-> hlms.entity.AuctionCase
 * and delegates persistence to AuctionCaseDAOImpl.
 *
 * Business logic (US-AM-01, US-AM-02): validates auction eligibility - the
 * default/notice/possession/auction dates must fall in a sane chronological
 * order - and enforces the workflow stage vocabulary.
 */
public class AuctionCaseServiceImpl implements AuctionCaseService {

    // Must match the stage CHECK constraint in hlms_schema_corrected.sql
    private static final List<String> VALID_STAGES = List.of(
            "None", "Notice Issued", "Possession", "Auction Scheduled", "Resolved");

    private final AuctionCaseDAO dao;

    public AuctionCaseServiceImpl() {
        this.dao = new AuctionCaseDAOImpl();
    }

    public AuctionCaseServiceImpl(AuctionCaseDAO dao) {
        this.dao = dao;
    }

    @Override
    public AuctionCaseDTO create(AuctionCaseDTO dto) throws DAOException {
        Validators.required(dto.getAppId(), "appId");
        if (dao.findById(dto.getAppId()) != null) {
            throw new ValidationException("An auction case already exists for application " + dto.getAppId() + ".");
        }
        validate(dto);
        AuctionCase entity = toEntity(dto);
        entity.setStage(entity.getStage() == null ? "Notice Issued" : entity.getStage());
        AuctionCase saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public AuctionCaseDTO update(AuctionCaseDTO dto) throws DAOException {
        Validators.required(dto.getAppId(), "appId");
        if (dao.findById(dto.getAppId()) == null) {
            throw new ValidationException("No auction case found for application " + dto.getAppId() + ".");
        }
        validate(dto);
        AuctionCase entity = toEntity(dto);
        AuctionCase saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        Validators.required(appId, "appId");
        return dao.delete(appId);
    }

    @Override
    public AuctionCaseDTO findById(String appId) throws DAOException {
        Validators.required(appId, "appId");
        AuctionCase entity = dao.findById(appId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<AuctionCaseDTO> findAll() throws DAOException {
        List<AuctionCase> entities = dao.findAll();
        List<AuctionCaseDTO> result = new ArrayList<>();
        for (AuctionCase entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(AuctionCaseDTO dto) throws ValidationException {
        if (dto.getStage() != null) {
            Validators.oneOf(dto.getStage(), "stage", VALID_STAGES.toArray(new String[0]));
        }
        Validators.required(dto.getNoticeDate(), "noticeDate");
        Validators.afterOrEqual(dto.getNoticeDueDate(), dto.getNoticeDate(), "noticeDueDate", "noticeDate");
        Validators.positive(dto.getDemandAmount(), "demandAmount");
        Validators.positive(dto.getReservePrice(), "reservePrice");
        if (dto.getPossessionDate() != null) {
            Validators.afterOrEqual(dto.getPossessionDate(), dto.getNoticeDueDate(), "possessionDate", "noticeDueDate");
        }
        if (dto.getAuctionDate() != null && dto.getPossessionDate() != null) {
            Validators.afterOrEqual(dto.getAuctionDate(), dto.getPossessionDate(), "auctionDate", "possessionDate");
        }
    }

    private AuctionCase toEntity(AuctionCaseDTO dto) {
        AuctionCase entity = new AuctionCase();
        entity.setAppId(dto.getAppId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setStage(dto.getStage());
        entity.setNoticeDate(dto.getNoticeDate());
        entity.setNoticeDueDate(dto.getNoticeDueDate());
        entity.setDemandAmount(dto.getDemandAmount());
        entity.setPossessionDate(dto.getPossessionDate());
        entity.setAuctionDate(dto.getAuctionDate());
        entity.setReservePrice(dto.getReservePrice());
        return entity;
    }

    private AuctionCaseDTO toDto(AuctionCase entity) {
        AuctionCaseDTO dto = new AuctionCaseDTO();
        dto.setAppId(entity.getAppId());
        dto.setStage(entity.getStage());
        dto.setNoticeDate(entity.getNoticeDate());
        dto.setNoticeDueDate(entity.getNoticeDueDate());
        dto.setDemandAmount(entity.getDemandAmount());
        dto.setPossessionDate(entity.getPossessionDate());
        dto.setAuctionDate(entity.getAuctionDate());
        dto.setReservePrice(entity.getReservePrice());
        return dto;
    }
}
