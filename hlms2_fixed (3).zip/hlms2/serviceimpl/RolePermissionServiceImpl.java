package hlms.serviceimpl;

import hlms.dao.RolePermissionDAO;
import hlms.daoimpl.RolePermissionDAOImpl;
import hlms.dto.RolePermissionDTO;
import hlms.entity.*;
import hlms.service.RolePermissionService;
import hlms.util.DAOException;
import hlms.util.ValidationException;
import hlms.util.Validators;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of RolePermissionService. Converts RolePermissionDTO <-> hlms.entity.RolePermission
 * and delegates persistence to RolePermissionDAOImpl.
 *
 * Business logic (US-UM-01): validates role/module and enforces that a
 * permission row can never grant add/edit/delete without also granting view.
 */
public class RolePermissionServiceImpl implements RolePermissionService {

    // Must match the role enum used by app_user (app_user_role_check in hlms_schema_corrected.sql)
    private static final List<String> VALID_ROLES =
            List.of("customer", "legal", "bankoffice", "bidder", "admin");

    private final RolePermissionDAO dao;

    public RolePermissionServiceImpl() {
        this.dao = new RolePermissionDAOImpl();
    }

    public RolePermissionServiceImpl(RolePermissionDAO dao) {
        this.dao = dao;
    }

    @Override
    public RolePermissionDTO create(RolePermissionDTO dto) throws DAOException {
        validate(dto);
        if (dao.findById(dto.getRole(), dto.getModule()) != null) {
            throw new ValidationException("Permissions for role " + dto.getRole() + " on module " + dto.getModule() + " already exist. Use update instead.");
        }
        RolePermission entity = toEntity(dto);
        RolePermission saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public RolePermissionDTO update(RolePermissionDTO dto) throws DAOException {
        validate(dto);
        if (dao.findById(dto.getRole(), dto.getModule()) == null) {
            throw new ValidationException("No permission row found for role " + dto.getRole() + " on module " + dto.getModule() + ".");
        }
        RolePermission entity = toEntity(dto);
        RolePermission saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String role, String module) throws DAOException {
        Validators.required(role, "role");
        Validators.required(module, "module");
        return dao.delete(role, module);
    }

    @Override
    public RolePermissionDTO findById(String role, String module) throws DAOException {
        Validators.required(role, "role");
        Validators.required(module, "module");
        RolePermission entity = dao.findById(role, module);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<RolePermissionDTO> findAll() throws DAOException {
        List<RolePermission> entities = dao.findAll();
        List<RolePermissionDTO> result = new ArrayList<>();
        for (RolePermission entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private void validate(RolePermissionDTO dto) throws ValidationException {
        Validators.oneOf(dto.getRole(), "role", VALID_ROLES.toArray(new String[0]));
        Validators.required(dto.getModule(), "module");
        boolean view = Boolean.TRUE.equals(dto.getCanView());
        boolean add = Boolean.TRUE.equals(dto.getCanAdd());
        boolean edit = Boolean.TRUE.equals(dto.getCanEdit());
        boolean del = Boolean.TRUE.equals(dto.getCanDelete());
        // US-UM-01: a role must be able to view a module before it can add/edit/delete in it.
        if ((add || edit || del) && !view) {
            throw new ValidationException("canView must be true whenever canAdd, canEdit or canDelete is granted.");
        }
    }

    private RolePermission toEntity(RolePermissionDTO dto) {
        RolePermission entity = new RolePermission();
        entity.setRole(dto.getRole());
        entity.setModule(dto.getModule());
        entity.setCanView(dto.getCanView() != null ? dto.getCanView() : Boolean.FALSE);
        entity.setCanAdd(dto.getCanAdd() != null ? dto.getCanAdd() : Boolean.FALSE);
        entity.setCanEdit(dto.getCanEdit() != null ? dto.getCanEdit() : Boolean.FALSE);
        entity.setCanDelete(dto.getCanDelete() != null ? dto.getCanDelete() : Boolean.FALSE);
        return entity;
    }

    private RolePermissionDTO toDto(RolePermission entity) {
        RolePermissionDTO dto = new RolePermissionDTO();
        dto.setRole(entity.getRole());
        dto.setModule(entity.getModule());
        dto.setCanView(entity.getCanView());
        dto.setCanAdd(entity.getCanAdd());
        dto.setCanEdit(entity.getCanEdit());
        dto.setCanDelete(entity.getCanDelete());
        return dto;
    }
}
