# Fix: `app_user_role_check` constraint violation

## What the error means

```
ERROR: new row for relation "app_user" violates check constraint "app_user_role_check"
Detail: Failing row contains (demo.customer@hlms.local, Demo Customer, 9000000001, ..., CUSTOMER, ...)
```

Part 1 of the demo (`runEntityLayerDemo`) inserted a user with role
`"customer"` (lowercase) and it worked. Part 2 (`runServiceLayerDemo`)
inserted a user with role `"CUSTOMER"` (uppercase, produced by
`AppUserServiceImpl`, which enforces the fixed role enum from
US-UM-02: `ADMIN, CUSTOMER, LOAN_OFFICER, LEGAL_OFFICER, ENGINEER, MANAGER`)
and it failed.

That's the tell: the **database's check constraint** was written
against the old, lowercase role scheme (`'customer'`, `'bankoffice'`,
...) and was never updated when the Java code moved to the new
uppercase role enum. It's a schema/code mismatch, not a bug in your
Java classes.

## What was changed

1. **`db/fix_app_user_role_check.sql`** (new) — drops the stale
   constraint and recreates it to allow the roles the app actually
   uses: `ADMIN`, `CUSTOMER`, `LOAN_OFFICER`, `LEGAL_OFFICER`,
   `ENGINEER`, `MANAGER`.
2. **`hlms2/main/HlmsFullDemoMain.java`** — updated the two
   entity-layer inserts that were still using the legacy lowercase
   values (`"customer"` → `"CUSTOMER"`, `"bankoffice"` →
   `"LOAN_OFFICER"`) so Part 1 and Part 2 of the demo use the same
   canonical role values and stay consistent going forward.
   (`RolePermission.role` values were left untouched — that column
   has no check constraint, it's a free-form module/permission
   mapping, not the `app_user.role` enum.)

## How to run

1. **Run the SQL fix first**, against the same Postgres database your
   app connects to (check `DBConnection`/your `.properties` file for
   host/db name):
   ```bash
   psql -U <your_user> -d <your_database> -f db/fix_app_user_role_check.sql
   ```
   Or open `db/fix_app_user_role_check.sql` in your SQL client
   (pgAdmin, DBeaver, Eclipse Data Source Explorer, etc.) and execute
   it.

2. **If you already have leftover rows** from previous failed test
   runs with old-style values, uncomment the two `UPDATE` lines near
   the bottom of the script before running it, so those rows also
   satisfy the new constraint.

3. **Re-run `HlmsFullDemoMain`** from Eclipse as before. Both
   `runEntityLayerDemo()` and `runServiceLayerDemo()` should now
   complete and print `=== Done. ===`.

If you hit the same kind of error on a different table later, it's
worth checking the same way: compare what value the Java code is
actually sending against what the table's `CHECK` constraint allows
(`\d app_user` in `psql`, or the constraint's definition in
`information_schema.check_constraints`).
