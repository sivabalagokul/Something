# HLMS Entity / DAO / DAOImpl / Main layer

Generated from `hlms_schema_corrected.sql` (21 tables) to match your existing
`src/entity/*.java` package layout and PostgreSQL schema.

## Structure

```
src/
 ├── entity/     # 21 POJOs, one per table, package hlms.entity
 ├── dao/        # 21 interfaces (insert/update/delete/findById/findAll), package hlms.dao
 ├── daoimpl/    # 21 JDBC implementations, package hlms.daoimpl
 ├── util/
 │    ├── DBConnection.java   # PostgreSQL connection factory
 │    └── DAOException.java   # checked exception all DAOImpls wrap SQLException into
 └── main/
      └── HlmsFullDemoMain.java   # single entry point covering all 21 entities, package hlms.main
```

The original 21 separate `*Main.java` demo classes (one per entity, each with its
own hard-coded `"REPLACE_WITH_EXISTING_..."` placeholders) have been merged into
**one** class, `HlmsFullDemoMain`. It runs all 21 tables in a single program:

1. Inserts one row into every table, in FK-safe order, wiring each foreign key
   to the row it actually just inserted earlier in the same run (no manual
   placeholder editing needed).
2. For each entity: `findById` → update one field → `findAll` (row count).
3. At the end, deletes every row it created, in reverse order, so the run is
   repeatable against your database without leaving demo data behind.

## How foreign keys are modeled

Where a table has a foreign key (e.g. `loan_application.user_email -> app_user.email`),
the entity exposes the **related object** (`AppUser user`) instead of the raw
column, matching the style already used in your uploaded entities. On
`insert`/`update`, the DAOImpl pulls the id off that object
(`entity.getUser().getEmail()`). On `findById`/`findAll`, the DAOImpl fills in a
**lightweight reference** (only the primary key set) rather than eagerly
joining every related table — call the related DAO's `findById(...)`
yourself if you need the full object graph.

Five tables have a foreign key that **is also the primary key** (1:1 tables:
`customer_employment_profile`, `legal_verification`, `bank_office_decision`,
`disbursement`, `auction_case`). In these entities both the plain id field
(e.g. `appId`) and the related object (`application`) are kept for
convenience, but only one of them is bound to SQL to avoid writing the same
column twice.

`role_permission` has a composite primary key (`role`, `module`) — its DAO
methods take both parameters instead of one.

`audit_log.log_id` is a `BIGSERIAL`; `AuditLogDAOImpl.insert(...)` uses
`RETURNING log_id` and sets it back on the entity after insert.

## Before you run anything

1. **Add the PostgreSQL JDBC driver** to your classpath (e.g.
   `postgresql-42.7.x.jar` from https://jdbc.postgresql.org/download/).
2. **Create the database and run the schema**:
   ```
   createdb hlms
   psql -d hlms -f hlms_schema_corrected.sql
   ```
3. **Edit `src/util/DBConnection.java`** and set `DB_URL` / `DB_USER` /
   `DB_PASSWORD` to match your local PostgreSQL instance (defaults to
   `localhost:5432/hlms`, user `postgres`, password `postgres`).

## Compiling / running

```
javac -cp .:postgresql-42.7.x.jar -d out src/entity/*.java src/dao/*.java src/util/*.java src/daoimpl/*.java src/main/HlmsFullDemoMain.java
java  -cp out:postgresql-42.7.x.jar hlms.main.HlmsFullDemoMain
```

No placeholders to edit and no run order to remember — `HlmsFullDemoMain`
inserts everything itself in this order (each step's foreign keys point at
what the previous step just inserted):

```
AppUser (x2) → LoanProduct → RolePermission → CustomerEmploymentProfile
→ LoanDraft → LoanApplication → ApplicationDocument
→ LegalVerification → LegalChecklistItem → BankOfficeDecision
→ Disbursement → InsurancePolicy → EmiInstallment
→ ServiceRequest → PostDisbursementDocument → AuctionCase
→ AuctionNote → LegalNotice → Bid → Notification → AuditLog
```

then deletes everything it inserted, in reverse order.

## Error handling

Every DAOImpl method catches `java.sql.SQLException` and rethrows it wrapped
as `hlms.util.DAOException`, so calling code (the `Main` classes, or your own
service layer) only ever has to catch one exception type and never needs to
import `java.sql.*`.
