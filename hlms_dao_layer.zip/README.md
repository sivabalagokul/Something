# HLMS Entity / DAO / DAOImpl / Main layer

Generated from `hlms_schema_corrected.sql` (21 tables) to match your existing
`src/entity/*.java` package layout and PostgreSQL schema.

## Structure

```
src/
 ├── entity/     # 21 POJOs, one per table, package hlms.entity
 ├── dao/        # 21 interfaces (insert/update/delete/findById/findAll), package hlms.dao
 ├── daoimpl/    # 21 JDBC implementations, package hlms.daoimpl
 ├── util/
 │    ├── DBConnection.java   # PostgreSQL connection factory
 │    └── DAOException.java   # checked exception all DAOImpls wrap SQLException into
 └── main/       # 21 runnable classes, one CRUD demo per entity, package hlms.main
```

## How foreign keys are modeled

Where a table has a foreign key (e.g. `loan_application.user_email -> app_user.email`),
the entity exposes the **related object** (`AppUser user`) instead of the raw
column, matching the style already used in your uploaded entities. On
`insert`/`update`, the DAOImpl pulls the id off that object
(`entity.getUser().getEmail()`). On `findById`/`findAll`, the DAOImpl fills in a
**lightweight reference** (only the primary key set) rather than eagerly
joining every related table — call the related DAO's `findById(...)`
yourself if you need the full object graph.

Five tables have a foreign key that **is also the primary key** (1:1 tables:
`customer_employment_profile`, `legal_verification`, `bank_office_decision`,
`disbursement`, `auction_case`). In these entities both the plain id field
(e.g. `appId`) and the related object (`application`) are kept for
convenience, but only one of them is bound to SQL to avoid writing the same
column twice.

`role_permission` has a composite primary key (`role`, `module`) — its DAO
methods take both parameters instead of one.

`audit_log.log_id` is a `BIGSERIAL`; `AuditLogDAOImpl.insert(...)` uses
`RETURNING log_id` and sets it back on the entity after insert.

## Before you run anything

1. **Add the PostgreSQL JDBC driver** to your classpath (e.g.
   `postgresql-42.7.x.jar` from https://jdbc.postgresql.org/download/).
2. **Create the database and run the schema**:
   ```
   createdb hlms
   psql -d hlms -f hlms_schema_corrected.sql
   ```
3. **Edit `src/util/DBConnection.java`** and set `DB_URL` / `DB_USER` /
   `DB_PASSWORD` to match your local PostgreSQL instance (defaults to
   `localhost:5432/hlms`, user `postgres`, password `postgres`).

## Compiling / running

```
javac -cp .:postgresql-42.7.x.jar -d out src/entity/*.java src/dao/*.java src/util/*.java src/daoimpl/*.java src/main/*.java
java  -cp out:postgresql-42.7.x.jar hlms.main.AppUserMain
```

Every `*Main` class runs a full CRUD cycle (insert → findById → update →
findAll → delete) for its entity, and prints what happened. **Important:**
for entities with foreign keys, open the corresponding `*Main.java` first and
replace the `"REPLACE_WITH_EXISTING_..."` placeholder values with ids that
already exist in your database (e.g. `LoanApplicationMain` needs a real
`app_user.email` and `loan_product.product_id`), otherwise the insert will
fail on the FK constraint. A sensible run order that satisfies dependencies:

```
AppUserMain → LoanProductMain → RolePermissionMain → CustomerEmploymentProfileMain
→ LoanDraftMain → LoanApplicationMain → ApplicationDocumentMain
→ LegalVerificationMain → LegalChecklistItemMain → BankOfficeDecisionMain
→ DisbursementMain → InsurancePolicyMain → EmiInstallmentMain
→ ServiceRequestMain → PostDisbursementDocumentMain → AuctionCaseMain
→ AuctionNoteMain → LegalNoticeMain → BidMain → NotificationMain → AuditLogMain
```

## Error handling

Every DAOImpl method catches `java.sql.SQLException` and rethrows it wrapped
as `hlms.util.DAOException`, so calling code (the `Main` classes, or your own
service layer) only ever has to catch one exception type and never needs to
import `java.sql.*`.
