package hlms.main;

import hlms.dao.AppUserDAO;
import hlms.daoimpl.AppUserDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for AppUserDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class AppUserMain {

    public static void main(String[] args) {
        AppUserDAO dao = new AppUserDAOImpl();

        try {
            // ---- CREATE ----
            AppUser entity = new AppUser();
            entity.setEmail("sample-email");
            entity.setName("sample-name");
            entity.setMobile("sample-mobile");
            entity.setPasswordHash("sample-passwordHash");
            entity.setRole("sample-role");
            entity.setActive(true);
            entity.setIdType("sample-idType");
            entity.setIdNumber("sample-idNumber");
            entity.setPrefSms(true);
            entity.setPrefEmail(true);
            entity.setPrefInapp(true);
            entity.setCreatedAt(OffsetDateTime.now());
            AppUser inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            AppUser found = dao.findById(entity.getEmail());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setName("updated-name");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<AppUser> all = dao.findAll();
            System.out.println("Total AppUser rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getEmail());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running AppUserMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
