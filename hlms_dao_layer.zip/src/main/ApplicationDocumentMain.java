package hlms.main;

import hlms.dao.ApplicationDocumentDAO;
import hlms.daoimpl.ApplicationDocumentDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for ApplicationDocumentDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class ApplicationDocumentMain {

    public static void main(String[] args) {
        ApplicationDocumentDAO dao = new ApplicationDocumentDAOImpl();

        try {
            // ---- CREATE ----
            ApplicationDocument entity = new ApplicationDocument();
            entity.setDocumentId("sample-documentId");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            entity.setDocType("sample-docType");
            entity.setFileName("sample-fileName");
            entity.setFileSize(1);
            entity.setUploadedAt(OffsetDateTime.now());
            entity.setVerificationStatus("sample-verificationStatus");
            AppUser verifiedByRef = new AppUser();
            verifiedByRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setVerifiedBy(verifiedByRef);
            entity.setVerifiedAt(OffsetDateTime.now());
            entity.setRemarks("sample-remarks");
            ApplicationDocument inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            ApplicationDocument found = dao.findById(entity.getDocumentId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setDocType("updated-docType");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<ApplicationDocument> all = dao.findAll();
            System.out.println("Total ApplicationDocument rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getDocumentId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running ApplicationDocumentMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
