package hlms.main;

import hlms.dao.AuctionCaseDAO;
import hlms.daoimpl.AuctionCaseDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Standalone demo / manual test harness for AuctionCaseDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class AuctionCaseMain {

    public static void main(String[] args) {
        AuctionCaseDAO dao = new AuctionCaseDAOImpl();

        try {
            // ---- CREATE ----
            AuctionCase entity = new AuctionCase();
            entity.setAppId("sample-appId");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            entity.setStage("sample-stage");
            entity.setNoticeDate(LocalDate.now());
            entity.setNoticeDueDate(LocalDate.now());
            entity.setDemandAmount(new BigDecimal("1000.00"));
            entity.setPossessionDate(LocalDate.now());
            entity.setAuctionDate(LocalDate.now());
            entity.setReservePrice(new BigDecimal("1000.00"));
            AuctionCase inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            AuctionCase found = dao.findById(entity.getAppId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setStage("updated-stage");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<AuctionCase> all = dao.findAll();
            System.out.println("Total AuctionCase rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getAppId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running AuctionCaseMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
