package hlms.main;

import hlms.dao.AuctionNoteDAO;
import hlms.daoimpl.AuctionNoteDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for AuctionNoteDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class AuctionNoteMain {

    public static void main(String[] args) {
        AuctionNoteDAO dao = new AuctionNoteDAOImpl();

        try {
            // ---- CREATE ----
            AuctionNote entity = new AuctionNote();
            entity.setNoteId("sample-noteId");
            AuctionCase auctionCaseRef = new AuctionCase();
            auctionCaseRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setAuctionCase(auctionCaseRef);
            entity.setNoteDate(OffsetDateTime.now());
            entity.setNoteText("sample-noteText");
            AuctionNote inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            AuctionNote found = dao.findById(entity.getNoteId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setNoteText("updated-noteText");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<AuctionNote> all = dao.findAll();
            System.out.println("Total AuctionNote rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getNoteId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running AuctionNoteMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
