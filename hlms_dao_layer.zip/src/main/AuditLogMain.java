package hlms.main;

import hlms.dao.AuditLogDAO;
import hlms.daoimpl.AuditLogDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for AuditLogDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class AuditLogMain {

    public static void main(String[] args) {
        AuditLogDAO dao = new AuditLogDAOImpl();

        try {
            // ---- CREATE ----
            AuditLog entity = new AuditLog();
            entity.setEntityType("sample-entityType");
            entity.setEntityId("sample-entityId");
            entity.setAction("sample-action");
            AppUser actorRef = new AppUser();
            actorRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setActor(actorRef);
            entity.setBeforeData("sample-beforeData");
            entity.setAfterData("sample-afterData");
            entity.setCreatedAt(OffsetDateTime.now());
            AuditLog inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            AuditLog found = dao.findById(inserted.getLogId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setEntityType("updated-entityType");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<AuditLog> all = dao.findAll();
            System.out.println("Total AuditLog rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(inserted.getLogId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running AuditLogMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
