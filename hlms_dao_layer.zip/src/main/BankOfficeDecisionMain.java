package hlms.main;

import hlms.dao.BankOfficeDecisionDAO;
import hlms.daoimpl.BankOfficeDecisionDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for BankOfficeDecisionDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class BankOfficeDecisionMain {

    public static void main(String[] args) {
        BankOfficeDecisionDAO dao = new BankOfficeDecisionDAOImpl();

        try {
            // ---- CREATE ----
            BankOfficeDecision entity = new BankOfficeDecision();
            entity.setAppId("sample-appId");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            entity.setDecision("sample-decision");
            AppUser officerRef = new AppUser();
            officerRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setOfficer(officerRef);
            entity.setDecisionDate(OffsetDateTime.now());
            entity.setReason("sample-reason");
            entity.setRemarks("sample-remarks");
            BankOfficeDecision inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            BankOfficeDecision found = dao.findById(entity.getAppId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setDecision("updated-decision");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<BankOfficeDecision> all = dao.findAll();
            System.out.println("Total BankOfficeDecision rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getAppId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running BankOfficeDecisionMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
