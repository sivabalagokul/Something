package hlms.main;

import hlms.dao.BidDAO;
import hlms.daoimpl.BidDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for BidDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class BidMain {

    public static void main(String[] args) {
        BidDAO dao = new BidDAOImpl();

        try {
            // ---- CREATE ----
            Bid entity = new Bid();
            entity.setBidId("sample-bidId");
            AuctionCase auctionCaseRef = new AuctionCase();
            auctionCaseRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setAuctionCase(auctionCaseRef);
            AppUser bidderRef = new AppUser();
            bidderRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setBidder(bidderRef);
            entity.setBidAmount(new BigDecimal("1000.00"));
            entity.setCreatedAt(OffsetDateTime.now());
            Bid inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            Bid found = dao.findById(entity.getBidId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<Bid> all = dao.findAll();
            System.out.println("Total Bid rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getBidId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running BidMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
