package hlms.main;

import hlms.dao.CustomerEmploymentProfileDAO;
import hlms.daoimpl.CustomerEmploymentProfileDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.math.BigDecimal;

/**
 * Standalone demo / manual test harness for CustomerEmploymentProfileDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class CustomerEmploymentProfileMain {

    public static void main(String[] args) {
        CustomerEmploymentProfileDAO dao = new CustomerEmploymentProfileDAOImpl();

        try {
            // ---- CREATE ----
            CustomerEmploymentProfile entity = new CustomerEmploymentProfile();
            entity.setUserEmail("sample-userEmail");
            AppUser userRef = new AppUser();
            userRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setUser(userRef);
            entity.setEmploymentType("sample-employmentType");
            entity.setEmployer("sample-employer");
            entity.setMonthlyIncome(new BigDecimal("1000.00"));
            entity.setOtherEmis(new BigDecimal("1000.00"));
            entity.setDesiredAmount(new BigDecimal("1000.00"));
            entity.setPan("sample-pan");
            CustomerEmploymentProfile inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            CustomerEmploymentProfile found = dao.findById(entity.getUserEmail());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setEmploymentType("updated-employmentType");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<CustomerEmploymentProfile> all = dao.findAll();
            System.out.println("Total CustomerEmploymentProfile rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getUserEmail());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running CustomerEmploymentProfileMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
