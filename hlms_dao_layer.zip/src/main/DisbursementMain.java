package hlms.main;

import hlms.dao.DisbursementDAO;
import hlms.daoimpl.DisbursementDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for DisbursementDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class DisbursementMain {

    public static void main(String[] args) {
        DisbursementDAO dao = new DisbursementDAOImpl();

        try {
            // ---- CREATE ----
            Disbursement entity = new Disbursement();
            entity.setAppId("sample-appId");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            entity.setDisbursedDate(OffsetDateTime.now());
            entity.setAmount(new BigDecimal("1000.00"));
            entity.setRefNo("sample-refNo");
            entity.setMode("sample-mode");
            entity.setBankDetails("sample-bankDetails");
            Disbursement inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            Disbursement found = dao.findById(entity.getAppId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setRefNo("updated-refNo");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<Disbursement> all = dao.findAll();
            System.out.println("Total Disbursement rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getAppId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running DisbursementMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
