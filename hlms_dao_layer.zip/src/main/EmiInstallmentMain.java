package hlms.main;

import hlms.dao.EmiInstallmentDAO;
import hlms.daoimpl.EmiInstallmentDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Standalone demo / manual test harness for EmiInstallmentDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class EmiInstallmentMain {

    public static void main(String[] args) {
        EmiInstallmentDAO dao = new EmiInstallmentDAOImpl();

        try {
            // ---- CREATE ----
            EmiInstallment entity = new EmiInstallment();
            entity.setInstallmentId("sample-installmentId");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            entity.setInstallmentNo(1);
            entity.setDueDate(LocalDate.now());
            entity.setEmiAmount(new BigDecimal("1000.00"));
            entity.setPrincipalComponent(new BigDecimal("1000.00"));
            entity.setInterestComponent(new BigDecimal("1000.00"));
            entity.setClosingBalance(new BigDecimal("1000.00"));
            entity.setStatus("sample-status");
            entity.setPaidDate(LocalDate.now());
            EmiInstallment inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            EmiInstallment found = dao.findById(entity.getInstallmentId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setStatus("updated-status");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<EmiInstallment> all = dao.findAll();
            System.out.println("Total EmiInstallment rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getInstallmentId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running EmiInstallmentMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
