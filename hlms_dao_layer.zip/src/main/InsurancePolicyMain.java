package hlms.main;

import hlms.dao.InsurancePolicyDAO;
import hlms.daoimpl.InsurancePolicyDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.LocalDate;

/**
 * Standalone demo / manual test harness for InsurancePolicyDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class InsurancePolicyMain {

    public static void main(String[] args) {
        InsurancePolicyDAO dao = new InsurancePolicyDAOImpl();

        try {
            // ---- CREATE ----
            InsurancePolicy entity = new InsurancePolicy();
            entity.setPolicyId("sample-policyId");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            entity.setPolicyType("sample-policyType");
            entity.setStatus("sample-status");
            entity.setValidTill(LocalDate.now());
            InsurancePolicy inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            InsurancePolicy found = dao.findById(entity.getPolicyId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setPolicyType("updated-policyType");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<InsurancePolicy> all = dao.findAll();
            System.out.println("Total InsurancePolicy rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getPolicyId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running InsurancePolicyMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
