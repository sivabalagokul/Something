package hlms.main;

import hlms.dao.LegalChecklistItemDAO;
import hlms.daoimpl.LegalChecklistItemDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;

/**
 * Standalone demo / manual test harness for LegalChecklistItemDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class LegalChecklistItemMain {

    public static void main(String[] args) {
        LegalChecklistItemDAO dao = new LegalChecklistItemDAOImpl();

        try {
            // ---- CREATE ----
            LegalChecklistItem entity = new LegalChecklistItem();
            entity.setChecklistItemId("sample-checklistItemId");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            entity.setChecklistKey("sample-checklistKey");
            entity.setStatus("sample-status");
            LegalChecklistItem inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            LegalChecklistItem found = dao.findById(entity.getChecklistItemId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setChecklistKey("updated-checklistKey");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<LegalChecklistItem> all = dao.findAll();
            System.out.println("Total LegalChecklistItem rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getChecklistItemId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running LegalChecklistItemMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
