package hlms.main;

import hlms.dao.LegalNoticeDAO;
import hlms.daoimpl.LegalNoticeDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.LocalDate;

/**
 * Standalone demo / manual test harness for LegalNoticeDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class LegalNoticeMain {

    public static void main(String[] args) {
        LegalNoticeDAO dao = new LegalNoticeDAOImpl();

        try {
            // ---- CREATE ----
            LegalNotice entity = new LegalNotice();
            entity.setNoticeId("sample-noticeId");
            entity.setNoticeNo("sample-noticeNo");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            entity.setNoticeType("sample-noticeType");
            entity.setIssueDate(LocalDate.now());
            entity.setDueDate(LocalDate.now());
            entity.setStatus("sample-status");
            AppUser officerRef = new AppUser();
            officerRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setOfficer(officerRef);
            entity.setContent("sample-content");
            LegalNotice inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            LegalNotice found = dao.findById(entity.getNoticeId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setNoticeNo("updated-noticeNo");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<LegalNotice> all = dao.findAll();
            System.out.println("Total LegalNotice rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getNoticeId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running LegalNoticeMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
