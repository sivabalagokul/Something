package hlms.main;

import hlms.dao.LegalVerificationDAO;
import hlms.daoimpl.LegalVerificationDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for LegalVerificationDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class LegalVerificationMain {

    public static void main(String[] args) {
        LegalVerificationDAO dao = new LegalVerificationDAOImpl();

        try {
            // ---- CREATE ----
            LegalVerification entity = new LegalVerification();
            entity.setAppId("sample-appId");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            entity.setDecision("sample-decision");
            entity.setDecisionDate(OffsetDateTime.now());
            AppUser officerRef = new AppUser();
            officerRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setOfficer(officerRef);
            entity.setRemarks("sample-remarks");
            LegalVerification inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            LegalVerification found = dao.findById(entity.getAppId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setDecision("updated-decision");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<LegalVerification> all = dao.findAll();
            System.out.println("Total LegalVerification rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getAppId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running LegalVerificationMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
