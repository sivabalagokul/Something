package hlms.main;

import hlms.dao.LoanApplicationDAO;
import hlms.daoimpl.LoanApplicationDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for LoanApplicationDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class LoanApplicationMain {

    public static void main(String[] args) {
        LoanApplicationDAO dao = new LoanApplicationDAOImpl();

        try {
            // ---- CREATE ----
            LoanApplication entity = new LoanApplication();
            entity.setAppId("sample-appId");
            entity.setTrackingNo("sample-trackingNo");
            AppUser userRef = new AppUser();
            userRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setUser(userRef);
            LoanProduct productRef = new LoanProduct();
            productRef.setProductId("REPLACE_WITH_EXISTING_PRODUCTID");
            entity.setProduct(productRef);
            entity.setLoanAmount(new BigDecimal("1000.00"));
            entity.setTenureYears(1);
            entity.setPurpose("sample-purpose");
            entity.setInterestRate(new BigDecimal("1000.00"));
            entity.setStatus("sample-status");
            entity.setStageIndex(1);
            entity.setCreatedAt(OffsetDateTime.now());
            entity.setApplicantName("sample-applicantName");
            entity.setApplicantMobile("sample-applicantMobile");
            entity.setApplicantPan("sample-applicantPan");
            entity.setAddrDoorNo("sample-addrDoorNo");
            entity.setAddrStreet("sample-addrStreet");
            entity.setAddrCity("sample-addrCity");
            entity.setAddrState("sample-addrState");
            entity.setAddrPincode("sample-addrPincode");
            entity.setEmploymentType("sample-employmentType");
            entity.setEmployer("sample-employer");
            entity.setMonthlyIncome(new BigDecimal("1000.00"));
            entity.setOtherEmis(new BigDecimal("1000.00"));
            entity.setPropertyAddress("sample-propertyAddress");
            entity.setPropertyType("sample-propertyType");
            entity.setPropertyValue(new BigDecimal("1000.00"));
            LoanApplication inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            LoanApplication found = dao.findById(entity.getAppId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setTrackingNo("updated-trackingNo");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<LoanApplication> all = dao.findAll();
            System.out.println("Total LoanApplication rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getAppId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running LoanApplicationMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
