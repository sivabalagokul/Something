package hlms.main;

import hlms.dao.LoanDraftDAO;
import hlms.daoimpl.LoanDraftDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for LoanDraftDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class LoanDraftMain {

    public static void main(String[] args) {
        LoanDraftDAO dao = new LoanDraftDAOImpl();

        try {
            // ---- CREATE ----
            LoanDraft entity = new LoanDraft();
            entity.setDraftId("sample-draftId");
            AppUser userRef = new AppUser();
            userRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setUser(userRef);
            entity.setCurrentStep(1);
            entity.setSavedAt(OffsetDateTime.now());
            entity.setLoanType("sample-loanType");
            entity.setLoanAmount(new BigDecimal("1000.00"));
            entity.setTenureYears(1);
            entity.setFormData("sample-formData");
            LoanDraft inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            LoanDraft found = dao.findById(entity.getDraftId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setLoanType("updated-loanType");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<LoanDraft> all = dao.findAll();
            System.out.println("Total LoanDraft rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getDraftId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running LoanDraftMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
