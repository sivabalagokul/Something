package hlms.main;

import hlms.dao.LoanProductDAO;
import hlms.daoimpl.LoanProductDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.math.BigDecimal;

/**
 * Standalone demo / manual test harness for LoanProductDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class LoanProductMain {

    public static void main(String[] args) {
        LoanProductDAO dao = new LoanProductDAOImpl();

        try {
            // ---- CREATE ----
            LoanProduct entity = new LoanProduct();
            entity.setProductId("sample-productId");
            entity.setName("sample-name");
            entity.setCategory("sample-category");
            entity.setInterestRate(new BigDecimal("1000.00"));
            entity.setMaxTenureYears(1);
            entity.setMaxLtv("sample-maxLtv");
            entity.setDescription("sample-description");
            LoanProduct inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            LoanProduct found = dao.findById(entity.getProductId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setName("updated-name");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<LoanProduct> all = dao.findAll();
            System.out.println("Total LoanProduct rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getProductId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running LoanProductMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
