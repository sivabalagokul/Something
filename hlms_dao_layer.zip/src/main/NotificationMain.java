package hlms.main;

import hlms.dao.NotificationDAO;
import hlms.daoimpl.NotificationDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for NotificationDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class NotificationMain {

    public static void main(String[] args) {
        NotificationDAO dao = new NotificationDAOImpl();

        try {
            // ---- CREATE ----
            Notification entity = new Notification();
            entity.setNotificationId("sample-notificationId");
            AppUser userRef = new AppUser();
            userRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setUser(userRef);
            entity.setTitle("sample-title");
            entity.setBody("sample-body");
            entity.setChannels(new String[]{"inapp"});
            entity.setIsRead(true);
            entity.setCreatedAt(OffsetDateTime.now());
            Notification inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            Notification found = dao.findById(entity.getNotificationId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setTitle("updated-title");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<Notification> all = dao.findAll();
            System.out.println("Total Notification rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getNotificationId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running NotificationMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
