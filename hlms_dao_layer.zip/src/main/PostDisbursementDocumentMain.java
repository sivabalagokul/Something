package hlms.main;

import hlms.dao.PostDisbursementDocumentDAO;
import hlms.daoimpl.PostDisbursementDocumentDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for PostDisbursementDocumentDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class PostDisbursementDocumentMain {

    public static void main(String[] args) {
        PostDisbursementDocumentDAO dao = new PostDisbursementDocumentDAOImpl();

        try {
            // ---- CREATE ----
            PostDisbursementDocument entity = new PostDisbursementDocument();
            entity.setPdDocId("sample-pdDocId");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            entity.setDocType("sample-docType");
            entity.setFileName("sample-fileName");
            entity.setFileSize(1);
            entity.setNote("sample-note");
            entity.setStatus("sample-status");
            entity.setUploadedAt(OffsetDateTime.now());
            AppUser verifiedByRef = new AppUser();
            verifiedByRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setVerifiedBy(verifiedByRef);
            entity.setVerifiedAt(OffsetDateTime.now());
            entity.setRemarks("sample-remarks");
            PostDisbursementDocument inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            PostDisbursementDocument found = dao.findById(entity.getPdDocId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setDocType("updated-docType");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<PostDisbursementDocument> all = dao.findAll();
            System.out.println("Total PostDisbursementDocument rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getPdDocId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running PostDisbursementDocumentMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
