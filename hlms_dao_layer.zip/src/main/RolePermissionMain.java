package hlms.main;

import hlms.dao.RolePermissionDAO;
import hlms.daoimpl.RolePermissionDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;

/**
 * Standalone demo / manual test harness for RolePermissionDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class RolePermissionMain {

    public static void main(String[] args) {
        RolePermissionDAO dao = new RolePermissionDAOImpl();

        try {
            // ---- CREATE ----
            RolePermission entity = new RolePermission();
            entity.setRole("sample-role");
            entity.setModule("sample-module");
            entity.setCanView(true);
            entity.setCanAdd(true);
            entity.setCanEdit(true);
            entity.setCanDelete(true);
            RolePermission inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            RolePermission found = dao.findById(entity.getRole(), entity.getModule());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<RolePermission> all = dao.findAll();
            System.out.println("Total RolePermission rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getRole(), entity.getModule());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running RolePermissionMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
