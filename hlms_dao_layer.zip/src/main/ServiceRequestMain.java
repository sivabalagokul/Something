package hlms.main;

import hlms.dao.ServiceRequestDAO;
import hlms.daoimpl.ServiceRequestDAOImpl;
import hlms.entity.*;
import hlms.util.DAOException;

import java.util.List;
import java.time.OffsetDateTime;

/**
 * Standalone demo / manual test harness for ServiceRequestDAO CRUD operations.
 * NOTE: adjust the sample values below (especially any foreign keys) so
 * that they reference rows that already exist in your PostgreSQL database
 * before running this class.
 */
public class ServiceRequestMain {

    public static void main(String[] args) {
        ServiceRequestDAO dao = new ServiceRequestDAOImpl();

        try {
            // ---- CREATE ----
            ServiceRequest entity = new ServiceRequest();
            entity.setRequestId("sample-requestId");
            entity.setRefNo("sample-refNo");
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId("REPLACE_WITH_EXISTING_APPID");
            entity.setApplication(applicationRef);
            AppUser userRef = new AppUser();
            userRef.setEmail("REPLACE_WITH_EXISTING_EMAIL");
            entity.setUser(userRef);
            entity.setRequestType("sample-requestType");
            entity.setDescription("sample-description");
            entity.setStatus("sample-status");
            entity.setCreatedAt(OffsetDateTime.now());
            ServiceRequest inserted = dao.insert(entity);
            System.out.println("Inserted: " + inserted);

            // ---- READ (single) ----
            ServiceRequest found = dao.findById(entity.getRequestId());
            System.out.println("Found: " + found);

            // ---- UPDATE ----
            if (found != null) {
                found.setRefNo("updated-refNo");
                dao.update(found);
                System.out.println("Updated: " + found);
            }

            // ---- READ (all) ----
            List<ServiceRequest> all = dao.findAll();
            System.out.println("Total ServiceRequest rows: " + all.size());

            // ---- DELETE ----
            boolean deleted = dao.delete(entity.getRequestId());
            System.out.println("Deleted: " + deleted);

        } catch (DAOException e) {
            System.err.println("Error while running ServiceRequestMain: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
