# HLMS Entity / DTO / Service / DAO layer

Generated from `hlms_schema_corrected.sql` (21 tables) to match your existing
`src/entity`, `src/dao`, and `src/daoimpl` package layout, with a new
`src/dto`, `src/service`, and `src/serviceimpl` layer added on top so the
project now follows:

```
Main -> DTO -> Service -> DAO -> Entity
```

## Structure

```
src/
 ├── entity/       # 21 POJOs, one per table                    package hlms.entity
 ├── dao/          # 21 interfaces (insert/update/delete/       package hlms.dao
 │                 #   findById/findAll)
 ├── daoimpl/      # 21 JDBC implementations                    package hlms.daoimpl
 ├── dto/          # NEW: 21 plain data-transfer objects         package hlms.dto
 ├── service/      # NEW: 21 service interfaces                  package hlms.service
 ├── serviceimpl/  # NEW: 21 service implementations             package hlms.serviceimpl
 ├── util/
 │    ├── DBConnection.java   # PostgreSQL connection factory
 │    └── DAOException.java   # checked exception all DAOImpls wrap SQLException into
 └── main/
      ├── HlmsFullDemoMain.java     # original demo: Main -> DAO -> Entity
      └── HlmsServiceDemoMain.java  # NEW demo: Main -> DTO -> Service -> DAO -> Entity
```

Everything under `entity/`, `dao/`, and `daoimpl/` is unchanged from what you
uploaded. `dto/`, `service/`, and `serviceimpl/` are new, and `main/` gained
one new class (`HlmsServiceDemoMain`) alongside the original.

## The new DTO layer (`src/dto`)

Each `*DTO` is a plain POJO — fields, no-arg + all-args constructors,
getters/setters, `toString()` — with the same style as the entities. The
only difference from the entity it mirrors: **foreign keys are flattened to
plain id fields** instead of nested related objects, so code above the
service layer never needs to import `hlms.entity.*`.

For example, `hlms.entity.LoanApplication` has an `AppUser user` field and a
`LoanProduct product` field; `LoanApplicationDTO` has `String userEmail` and
`String productId` instead. The five 1:1 tables that use their foreign key
as their own primary key (`customer_employment_profile`,
`legal_verification`, `bank_office_decision`, `disbursement`,
`auction_case`) already expose that id as a plain field on the entity
(`userEmail`, `appId`, …) — the DTO just keeps that same field and drops the
redundant object reference.

`RolePermissionDTO` mirrors `RolePermission` exactly (composite key `role` +
`module`, no foreign keys).

## The new Service layer (`src/service`, `src/serviceimpl`)

Each `*Service` interface has the same five operations as its DAO, but
speaks DTOs instead of entities:

```java
public interface RolePermissionService {
    RolePermissionDTO create(RolePermissionDTO dto) throws DAOException;
    RolePermissionDTO update(RolePermissionDTO dto) throws DAOException;
    boolean delete(String role, String module) throws DAOException;
    RolePermissionDTO findById(String role, String module) throws DAOException;
    List<RolePermissionDTO> findAll() throws DAOException;
}
```

Each `*ServiceImpl`:
1. Instantiates the matching `*DAOImpl` (a no-arg constructor is used by
   default; there's also a constructor that accepts a DAO instance, useful
   for unit tests with a mock/fake DAO).
2. Converts the incoming DTO to an entity (`toEntity`) — for every
   foreign-key DTO field, it builds a **lightweight related entity** with
   only the id set (e.g. `new AppUser(); .setEmail(dto.getUserEmail())`),
   the same "id-only reference" pattern the DAOImpl classes already use
   when reading rows back.
3. Delegates to the DAO.
4. Converts the returned entity back to a DTO (`toDto`) for the caller.

`DAOException` is reused as-is at this layer too, so callers (Main, or a
future controller/UI layer) still only ever need to catch one exception
type.

## Two demo Main classes

- **`HlmsFullDemoMain`** (unchanged) — `Main -> DAO -> Entity`. Inserts one
  row per table, reads/updates/lists each, then deletes everything, all
  through the DAO layer directly.
- **`HlmsServiceDemoMain`** (new) — the same walkthrough, one layer higher:
  `Main -> DTO -> Service -> DAO -> Entity`. It never imports `hlms.entity`
  or `hlms.dao`; every table is created, updated, listed, and deleted
  through its `*Service` using `*DTO` objects only. Foreign keys are wired
  by reading the id straight off the DTO returned from the previous step
  (e.g. `application.setUserEmail(customer.getEmail())`), the same idea as
  the original class but one layer removed from entities.

Run either one — they don't conflict, and both clean up after themselves.

## Before you run anything

1. **Add the PostgreSQL JDBC driver** to your classpath (e.g.
   `postgresql-42.7.x.jar` from https://jdbc.postgresql.org/download/).
2. **Create the database and run the schema**, if you haven't already:
   ```
   createdb hlms
   psql -d hlms -f hlms_schema_corrected.sql
   ```
3. **Edit `src/util/DBConnection.java`** and set `DB_URL` / `DB_USER` /
   `DB_PASSWORD` to match your existing PostgreSQL instance (defaults to
   `localhost:5432/hlms`, user `postgres`, password `postgres`).

## Compiling / running

To run the original DAO-only demo:
```
javac -cp .:postgresql-42.7.x.jar -d out src/entity/*.java src/dao/*.java src/util/*.java src/daoimpl/*.java src/main/HlmsFullDemoMain.java
java  -cp out:postgresql-42.7.x.jar hlms.main.HlmsFullDemoMain
```

To run the new service-layer demo (compiles everything, including the new
DTO/Service layer):
```
javac -cp .:postgresql-42.7.x.jar -d out src/entity/*.java src/dao/*.java src/util/*.java src/daoimpl/*.java src/dto/*.java src/service/*.java src/serviceimpl/*.java src/main/HlmsServiceDemoMain.java
java  -cp out:postgresql-42.7.x.jar hlms.main.HlmsServiceDemoMain
```

(Simplest option: just compile everything under `src/**/*.java` at once and
run whichever `main` class you want — both demo classes live happily side
by side.)

Both demo classes follow the same FK-safe order:
```
AppUser (x2 or x3) -> LoanProduct -> RolePermission -> CustomerEmploymentProfile
-> LoanDraft -> LoanApplication -> ApplicationDocument
-> LegalVerification -> LegalChecklistItem -> BankOfficeDecision
-> Disbursement -> InsurancePolicy -> EmiInstallment
-> ServiceRequest -> PostDisbursementDocument -> AuctionCase
-> AuctionNote -> LegalNotice -> Bid -> Notification -> AuditLog
```
then delete everything they inserted, in reverse order, so a run is
repeatable against your existing database without leaving demo data behind.

## How foreign keys are modeled

**Entity layer (unchanged):** where a table has a foreign key (e.g.
`loan_application.user_email -> app_user.email`), the entity exposes the
**related object** (`AppUser user`) instead of the raw column. On
`insert`/`update`, the DAOImpl pulls the id off that object
(`entity.getUser().getEmail()`). On `findById`/`findAll`, the DAOImpl fills
in a **lightweight reference** (only the primary key set).

**DTO/Service layer (new):** the DTO exposes that same foreign key as a
plain id field (`String userEmail`) instead of a nested object. The
`*ServiceImpl` is what bridges the two: it builds the lightweight related
entity from the DTO's id field before calling the DAO, and flattens the
DAO's lightweight related entity back to an id field when returning a DTO.

Five tables have a foreign key that **is also the primary key** (1:1
tables: `customer_employment_profile`, `legal_verification`,
`bank_office_decision`, `disbursement`, `auction_case`). Both layers handle
this the same way as before: the entity keeps both the plain id field and
the related object (only one is bound to SQL); the DTO just keeps the
single plain id field.

`role_permission` has a composite primary key (`role`, `module`) — its DAO
*and* Service methods take both parameters instead of one.

`audit_log.log_id` is a `BIGSERIAL`; `AuditLogDAOImpl.insert(...)` uses
`RETURNING log_id` and sets it back on the entity after insert, and
`AuditLogServiceImpl.create(...)` carries that generated id back onto the
returned DTO the same way.

## Error handling

Every DAOImpl method catches `java.sql.SQLException` and rethrows it
wrapped as `hlms.util.DAOException`. Every ServiceImpl method simply lets
that same `DAOException` propagate — it doesn't wrap it again — so calling
code (`Main`, or any future controller/UI layer) only ever has to catch one
exception type, however many layers deep the actual JDBC call is.
