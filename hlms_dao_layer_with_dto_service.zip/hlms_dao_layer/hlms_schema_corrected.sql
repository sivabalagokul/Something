-- ============================================================
-- HLMS - Housing Loan Management System
-- PostgreSQL Database Schema (CORRECTED)
-- Corrections made to match the actual integration-2-1.js app logic
-- are flagged inline with "-- FIX:" comments.
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- 1. USERS & ACCESS CONTROL
-- ============================================================

CREATE TABLE app_user (
    email               VARCHAR(255) PRIMARY KEY,
    name                VARCHAR(150) NOT NULL,
    mobile              VARCHAR(20) NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,
    -- FIX: the app only ever creates/checks these five role strings
    -- (isLegal(), isBankOffice(), isBidder(), ensureAdminSeed()).
    -- 'loan_officer'/'legal_officer'/'bank_officer'/'auction_officer' never
    -- appear in the app, and 'bidder' (a fully built role with its own
    -- dashboard, settings page, and bids) was missing entirely.
    role                VARCHAR(30) NOT NULL CHECK (role IN (
                            'customer', 'legal', 'bankoffice',
                            'bidder', 'admin'
                        )),
    active              BOOLEAN NOT NULL DEFAULT TRUE,
    id_type             VARCHAR(30),
    id_number           VARCHAR(50),
    pref_sms            BOOLEAN NOT NULL DEFAULT TRUE,
    pref_email          BOOLEAN NOT NULL DEFAULT TRUE,
    pref_inapp          BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE role_permission (
    role        VARCHAR(30) NOT NULL,
    module      VARCHAR(50) NOT NULL,
    can_view    BOOLEAN NOT NULL DEFAULT FALSE,
    can_add     BOOLEAN NOT NULL DEFAULT FALSE,
    can_edit    BOOLEAN NOT NULL DEFAULT FALSE,
    can_delete  BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (role, module)
);

CREATE TABLE customer_employment_profile (
    user_email      VARCHAR(255) PRIMARY KEY REFERENCES app_user(email) ON DELETE CASCADE,
    employment_type VARCHAR(30),
    employer        VARCHAR(150),
    monthly_income  NUMERIC(14,2),
    other_emis      NUMERIC(14,2) DEFAULT 0,
    desired_amount  NUMERIC(14,2),
    pan             VARCHAR(20)
);

-- ============================================================
-- 2. PRODUCTS & APPLICATIONS
-- ============================================================

CREATE TABLE loan_product (
    product_id       VARCHAR(50) PRIMARY KEY,
    name             VARCHAR(150) NOT NULL,
    category         VARCHAR(50),
    interest_rate    NUMERIC(5,2) NOT NULL,
    max_tenure_years INT NOT NULL,
    max_ltv          VARCHAR(10),
    description      TEXT
);

CREATE TABLE loan_draft (
    draft_id      VARCHAR(50) PRIMARY KEY,
    user_email    VARCHAR(255) NOT NULL REFERENCES app_user(email) ON DELETE CASCADE,
    current_step  INT NOT NULL DEFAULT 1,
    saved_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    loan_type     VARCHAR(50),
    loan_amount   NUMERIC(14,2),
    tenure_years  INT,
    -- form_data holds personal/employment/property/documents/purpose,
    -- exactly as saveDraftNow() spreads applyData into the draft record.
    form_data     JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX idx_loan_draft_user ON loan_draft(user_email);

CREATE TABLE loan_application (
    app_id           VARCHAR(50) PRIMARY KEY,
    tracking_no      VARCHAR(50) UNIQUE NOT NULL,
    user_email       VARCHAR(255) NOT NULL REFERENCES app_user(email),
    product_id       VARCHAR(50) NOT NULL REFERENCES loan_product(product_id),
    loan_amount      NUMERIC(14,2) NOT NULL,
    tenure_years     INT NOT NULL,
    purpose          VARCHAR(150),
    interest_rate    NUMERIC(5,2),
    -- FIX: default aligned to app's actual casing ('Submitted', not 'submitted').
    -- App status values in use: Submitted, Under Review, Rejected, Disbursed.
    status           VARCHAR(30) NOT NULL DEFAULT 'Submitted',
    stage_index      INT NOT NULL DEFAULT 0,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),

    applicant_name    VARCHAR(150),
    applicant_mobile  VARCHAR(20),
    applicant_pan     VARCHAR(20),

    addr_door_no      VARCHAR(30),
    addr_street       VARCHAR(150),
    addr_city         VARCHAR(100),
    addr_state        VARCHAR(100),
    addr_pincode      VARCHAR(10),

    employment_type   VARCHAR(30),
    employer          VARCHAR(150),
    monthly_income    NUMERIC(14,2),
    other_emis        NUMERIC(14,2),

    property_address  TEXT,
    property_type     VARCHAR(50),
    property_value    NUMERIC(14,2)
);
CREATE INDEX idx_loan_app_user ON loan_application(user_email);
CREATE INDEX idx_loan_app_product ON loan_application(product_id);
CREATE INDEX idx_loan_app_status ON loan_application(status);

-- ============================================================
-- 3. DOCUMENTS & VERIFICATION
-- ============================================================

CREATE TABLE application_document (
    document_id          VARCHAR(50) PRIMARY KEY,
    app_id               VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    -- App doc_type keys in use: idProof, incomeProof, addressProof,
    -- bankStatement, propertyDocs (see DOC_LABELS in the JS).
    doc_type             VARCHAR(50) NOT NULL,
    file_name            VARCHAR(255) NOT NULL,
    file_size            INT,
    uploaded_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    -- FIX: default aligned to app's actual casing ('Pending', not 'pending').
    verification_status  VARCHAR(30) NOT NULL DEFAULT 'Pending',
    verified_by          VARCHAR(255) REFERENCES app_user(email),
    verified_at          TIMESTAMPTZ,
    remarks              TEXT
);
CREATE INDEX idx_app_doc_app ON application_document(app_id);

CREATE TABLE legal_verification (
    app_id         VARCHAR(50) PRIMARY KEY REFERENCES loan_application(app_id) ON DELETE CASCADE,
    -- App decision values in use: Approved, Rejected, Query Raised.
    decision       VARCHAR(30),
    decision_date  TIMESTAMPTZ,
    officer        VARCHAR(255) REFERENCES app_user(email),
    remarks        TEXT
);

CREATE TABLE legal_checklist_item (
    checklist_item_id  VARCHAR(50) PRIMARY KEY,
    app_id             VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    -- App's LEGAL_CHECKLIST keys in use: titleDeed, encumbrance, saleDeed,
    -- noc, valuation, taxReceipt.
    checklist_key      VARCHAR(100) NOT NULL,
    status             VARCHAR(30) NOT NULL DEFAULT 'Pending'
);
CREATE INDEX idx_checklist_app ON legal_checklist_item(app_id);

CREATE TABLE bank_office_decision (
    app_id         VARCHAR(50) PRIMARY KEY REFERENCES loan_application(app_id) ON DELETE CASCADE,
    decision       VARCHAR(30),
    officer        VARCHAR(255) REFERENCES app_user(email),
    decision_date  TIMESTAMPTZ,
    reason         VARCHAR(255),
    remarks        TEXT
);

-- ============================================================
-- 4. DISBURSEMENT, INSURANCE & REPAYMENT
-- ============================================================

CREATE TABLE disbursement (
    app_id          VARCHAR(50) PRIMARY KEY REFERENCES loan_application(app_id) ON DELETE CASCADE,
    disbursed_date  TIMESTAMPTZ,
    amount          NUMERIC(14,2),
    ref_no          VARCHAR(50),
    mode            VARCHAR(30),
    -- FIX: app stores one combined string (e.g. "HDFC Bank - 1234"), not a
    -- separate account number. Renamed to reflect what's actually captured.
    bank_details    VARCHAR(150)
);

CREATE TABLE insurance_policy (
    policy_id    VARCHAR(50) PRIMARY KEY,
    app_id       VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    -- App creates exactly two policies per disbursed loan: 'property', 'life'.
    policy_type  VARCHAR(50) CHECK (policy_type IN ('property', 'life')),
    -- FIX: default aligned to app's actual casing ('Active', not 'active').
    status       VARCHAR(30) NOT NULL DEFAULT 'Active',
    valid_till   DATE
);
CREATE INDEX idx_insurance_app ON insurance_policy(app_id);

CREATE TABLE emi_installment (
    installment_id       VARCHAR(50) PRIMARY KEY,
    app_id               VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    installment_no       INT NOT NULL,
    due_date             DATE NOT NULL,
    emi_amount           NUMERIC(14,2) NOT NULL,
    principal_component  NUMERIC(14,2),
    interest_component   NUMERIC(14,2),
    closing_balance      NUMERIC(14,2),
    -- FIX: default aligned to app's actual casing ('Due', not 'due').
    -- App status values in use: Due, Paid, Overdue.
    status               VARCHAR(30) NOT NULL DEFAULT 'Due',
    paid_date            DATE,
    UNIQUE (app_id, installment_no)
);
CREATE INDEX idx_emi_app ON emi_installment(app_id);
CREATE INDEX idx_emi_status ON emi_installment(status);

-- ============================================================
-- 5. SERVICE REQUESTS & POST-DISBURSEMENT DOCS
-- ============================================================

CREATE TABLE service_request (
    request_id    VARCHAR(50) PRIMARY KEY,
    ref_no        VARCHAR(50) UNIQUE NOT NULL,
    app_id        VARCHAR(50) REFERENCES loan_application(app_id) ON DELETE CASCADE,
    user_email    VARCHAR(255) NOT NULL REFERENCES app_user(email),
    request_type  VARCHAR(50) NOT NULL,
    description   TEXT,
    -- FIX: default aligned to app's actual value ('Requested', not 'open').
    status        VARCHAR(30) NOT NULL DEFAULT 'Requested',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_service_req_user ON service_request(user_email);
CREATE INDEX idx_service_req_app ON service_request(app_id);

CREATE TABLE post_disbursement_document (
    pd_doc_id     VARCHAR(50) PRIMARY KEY,
    app_id        VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    -- App's PD_DOC_TYPES in use: 'Updated KYC / Identity Document',
    -- 'Property Insurance Renewal', 'NOC / Loan Closure Supporting Document',
    -- 'Address Change Proof', 'Property Tax Receipt', 'Other Supporting Document'.
    doc_type      VARCHAR(80) NOT NULL,
    file_name     VARCHAR(255) NOT NULL,
    file_size     INT,
    note          TEXT,
    status        VARCHAR(30) NOT NULL DEFAULT 'Pending',
    uploaded_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    verified_by   VARCHAR(255) REFERENCES app_user(email),
    verified_at   TIMESTAMPTZ,
    remarks       TEXT
);
CREATE INDEX idx_pd_doc_app ON post_disbursement_document(app_id);

-- ============================================================
-- 6. AUCTION & LEGAL NOTICES (SARFAESI)
-- ============================================================

CREATE TABLE auction_case (
    app_id           VARCHAR(50) PRIMARY KEY REFERENCES loan_application(app_id) ON DELETE CASCADE,
    -- FIX: default and value set aligned to advanceStage()/markAppAsNPA()/
    -- recordPossession()/scheduleAuction()/resolveAuction() in the app:
    -- None -> Notice Issued -> Possession -> Auction Scheduled -> Resolved.
    stage            VARCHAR(30) NOT NULL DEFAULT 'None' CHECK (stage IN (
                        'None', 'Notice Issued', 'Possession',
                        'Auction Scheduled', 'Resolved'
                     )),
    notice_date      DATE,
    notice_due_date  DATE,
    demand_amount    NUMERIC(14,2),
    possession_date  DATE,
    auction_date     DATE,
    reserve_price    NUMERIC(14,2)
);

CREATE TABLE auction_note (
    note_id    VARCHAR(50) PRIMARY KEY,
    app_id     VARCHAR(50) NOT NULL REFERENCES auction_case(app_id) ON DELETE CASCADE,
    note_date  TIMESTAMPTZ NOT NULL DEFAULT now(),
    note_text  TEXT NOT NULL
);
CREATE INDEX idx_auction_note_app ON auction_note(app_id);

CREATE TABLE legal_notice (
    notice_id    VARCHAR(50) PRIMARY KEY,
    notice_no    VARCHAR(50) UNIQUE NOT NULL,
    app_id       VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    notice_type  VARCHAR(50) NOT NULL,
    issue_date   DATE NOT NULL,
    due_date     DATE,
    status       VARCHAR(30) NOT NULL DEFAULT 'Active',
    officer      VARCHAR(255) REFERENCES app_user(email),
    content      TEXT
);
CREATE INDEX idx_legal_notice_app ON legal_notice(app_id);

CREATE TABLE bid (
    bid_id        VARCHAR(50) PRIMARY KEY,
    app_id        VARCHAR(50) NOT NULL REFERENCES auction_case(app_id) ON DELETE CASCADE,
    bidder_email  VARCHAR(255) NOT NULL REFERENCES app_user(email),
    bid_amount    NUMERIC(14,2) NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_bid_app ON bid(app_id);
CREATE INDEX idx_bid_bidder ON bid(bidder_email);

-- ============================================================
-- 7. NOTIFICATIONS & AUDIT
-- ============================================================

CREATE TABLE notification (
    notification_id  VARCHAR(50) PRIMARY KEY,
    user_email       VARCHAR(255) NOT NULL REFERENCES app_user(email) ON DELETE CASCADE,
    title            VARCHAR(150) NOT NULL,
    body             TEXT,
    -- FIX: pushNotification() stores an array of channels (e.g.
    -- ['inapp','sms','email']), not a single string — use a real array type.
    channels         TEXT[] NOT NULL DEFAULT ARRAY['inapp'],
    is_read          BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notification_user ON notification(user_email);
CREATE INDEX idx_notification_read ON notification(user_email, is_read);

CREATE TABLE audit_log (
    log_id       BIGSERIAL PRIMARY KEY,
    entity_type  VARCHAR(50) NOT NULL,
    entity_id    VARCHAR(50) NOT NULL,
    action       VARCHAR(30) NOT NULL,
    actor_email  VARCHAR(255) REFERENCES app_user(email),
    before_data  JSONB,
    after_data   JSONB,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_entity ON audit_log(entity_type, entity_id);
CREATE INDEX idx_audit_actor ON audit_log(actor_email);

-- ============================================================
-- SEED DATA: loan products
-- FIX: original seed only had 3 products (matching the homepage marketing
-- cards). The app's actual LOAN_PRODUCTS catalog — used throughout Loan
-- Guidance, Eligibility Check, and the Apply flow — has 6 products.
-- product_id values below match the app's internal short codes
-- (LOAN_PRODUCTS[].id) instead of the old PROD-* naming.
-- ============================================================

INSERT INTO loan_product (product_id, name, category, interest_rate, max_tenure_years, max_ltv, description) VALUES
('HP',  'Home Purchase Loan',          'Home Purchase',    8.50, 30, '90%', 'Finance the purchase of a new or resale residential property.'),
('HC',  'Home Construction Loan',      'Construction',     8.75, 25, '85%', 'Funds disbursed in stages to construct your house on owned land.'),
('HR',  'Home Renovation Loan',        'Renovation',       9.25, 15, '80%', 'Renovate, repair or extend your existing home.'),
('PL',  'Plot Loan',                   'Plot Loan',        9.00, 20, '75%', 'Purchase a residential plot for future construction.'),
('BT',  'Balance Transfer + Top-up',   'Balance Transfer', 8.40, 30, '90%', 'Transfer your existing home loan and get an additional top-up amount.'),
('NRI', 'NRI Home Loan',               'Home Purchase',    8.90, 20, '80%', 'Home loan tailored for Non-Resident Indian customers.');
