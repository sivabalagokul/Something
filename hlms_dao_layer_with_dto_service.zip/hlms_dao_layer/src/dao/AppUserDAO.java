package hlms.dao;

import hlms.entity.AppUser;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for AppUser ('app_user').
 */
public interface AppUserDAO {

    AppUser insert(AppUser entity) throws DAOException;

    AppUser update(AppUser entity) throws DAOException;

    boolean delete(String email) throws DAOException;

    AppUser findById(String email) throws DAOException;

    List<AppUser> findAll() throws DAOException;
}
