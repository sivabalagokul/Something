package hlms.dao;

import hlms.entity.ApplicationDocument;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for ApplicationDocument ('application_document').
 */
public interface ApplicationDocumentDAO {

    ApplicationDocument insert(ApplicationDocument entity) throws DAOException;

    ApplicationDocument update(ApplicationDocument entity) throws DAOException;

    boolean delete(String documentId) throws DAOException;

    ApplicationDocument findById(String documentId) throws DAOException;

    List<ApplicationDocument> findAll() throws DAOException;
}
