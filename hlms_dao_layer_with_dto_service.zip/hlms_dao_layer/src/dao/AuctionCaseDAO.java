package hlms.dao;

import hlms.entity.AuctionCase;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for AuctionCase ('auction_case').
 */
public interface AuctionCaseDAO {

    AuctionCase insert(AuctionCase entity) throws DAOException;

    AuctionCase update(AuctionCase entity) throws DAOException;

    boolean delete(String appId) throws DAOException;

    AuctionCase findById(String appId) throws DAOException;

    List<AuctionCase> findAll() throws DAOException;
}
