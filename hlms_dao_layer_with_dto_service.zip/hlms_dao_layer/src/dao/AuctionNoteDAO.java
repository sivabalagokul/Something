package hlms.dao;

import hlms.entity.AuctionNote;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for AuctionNote ('auction_note').
 */
public interface AuctionNoteDAO {

    AuctionNote insert(AuctionNote entity) throws DAOException;

    AuctionNote update(AuctionNote entity) throws DAOException;

    boolean delete(String noteId) throws DAOException;

    AuctionNote findById(String noteId) throws DAOException;

    List<AuctionNote> findAll() throws DAOException;
}
