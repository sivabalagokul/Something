package hlms.dao;

import hlms.entity.AuditLog;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for AuditLog ('audit_log').
 */
public interface AuditLogDAO {

    AuditLog insert(AuditLog entity) throws DAOException;

    AuditLog update(AuditLog entity) throws DAOException;

    boolean delete(Long logId) throws DAOException;

    AuditLog findById(Long logId) throws DAOException;

    List<AuditLog> findAll() throws DAOException;
}
