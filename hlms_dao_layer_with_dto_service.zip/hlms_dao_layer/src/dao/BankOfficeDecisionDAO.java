package hlms.dao;

import hlms.entity.BankOfficeDecision;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for BankOfficeDecision ('bank_office_decision').
 */
public interface BankOfficeDecisionDAO {

    BankOfficeDecision insert(BankOfficeDecision entity) throws DAOException;

    BankOfficeDecision update(BankOfficeDecision entity) throws DAOException;

    boolean delete(String appId) throws DAOException;

    BankOfficeDecision findById(String appId) throws DAOException;

    List<BankOfficeDecision> findAll() throws DAOException;
}
