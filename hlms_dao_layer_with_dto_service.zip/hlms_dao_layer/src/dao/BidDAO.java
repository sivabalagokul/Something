package hlms.dao;

import hlms.entity.Bid;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for Bid ('bid').
 */
public interface BidDAO {

    Bid insert(Bid entity) throws DAOException;

    Bid update(Bid entity) throws DAOException;

    boolean delete(String bidId) throws DAOException;

    Bid findById(String bidId) throws DAOException;

    List<Bid> findAll() throws DAOException;
}
