package hlms.dao;

import hlms.entity.CustomerEmploymentProfile;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for CustomerEmploymentProfile ('customer_employment_profile').
 */
public interface CustomerEmploymentProfileDAO {

    CustomerEmploymentProfile insert(CustomerEmploymentProfile entity) throws DAOException;

    CustomerEmploymentProfile update(CustomerEmploymentProfile entity) throws DAOException;

    boolean delete(String userEmail) throws DAOException;

    CustomerEmploymentProfile findById(String userEmail) throws DAOException;

    List<CustomerEmploymentProfile> findAll() throws DAOException;
}
