package hlms.dao;

import hlms.entity.Disbursement;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for Disbursement ('disbursement').
 */
public interface DisbursementDAO {

    Disbursement insert(Disbursement entity) throws DAOException;

    Disbursement update(Disbursement entity) throws DAOException;

    boolean delete(String appId) throws DAOException;

    Disbursement findById(String appId) throws DAOException;

    List<Disbursement> findAll() throws DAOException;
}
