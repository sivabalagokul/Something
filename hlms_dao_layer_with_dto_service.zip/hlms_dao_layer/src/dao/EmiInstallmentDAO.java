package hlms.dao;

import hlms.entity.EmiInstallment;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for EmiInstallment ('emi_installment').
 */
public interface EmiInstallmentDAO {

    EmiInstallment insert(EmiInstallment entity) throws DAOException;

    EmiInstallment update(EmiInstallment entity) throws DAOException;

    boolean delete(String installmentId) throws DAOException;

    EmiInstallment findById(String installmentId) throws DAOException;

    List<EmiInstallment> findAll() throws DAOException;
}
