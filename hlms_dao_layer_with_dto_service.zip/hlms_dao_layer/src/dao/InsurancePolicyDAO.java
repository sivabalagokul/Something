package hlms.dao;

import hlms.entity.InsurancePolicy;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for InsurancePolicy ('insurance_policy').
 */
public interface InsurancePolicyDAO {

    InsurancePolicy insert(InsurancePolicy entity) throws DAOException;

    InsurancePolicy update(InsurancePolicy entity) throws DAOException;

    boolean delete(String policyId) throws DAOException;

    InsurancePolicy findById(String policyId) throws DAOException;

    List<InsurancePolicy> findAll() throws DAOException;
}
