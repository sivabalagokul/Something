package hlms.dao;

import hlms.entity.LegalChecklistItem;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for LegalChecklistItem ('legal_checklist_item').
 */
public interface LegalChecklistItemDAO {

    LegalChecklistItem insert(LegalChecklistItem entity) throws DAOException;

    LegalChecklistItem update(LegalChecklistItem entity) throws DAOException;

    boolean delete(String checklistItemId) throws DAOException;

    LegalChecklistItem findById(String checklistItemId) throws DAOException;

    List<LegalChecklistItem> findAll() throws DAOException;
}
