package hlms.dao;

import hlms.entity.LegalNotice;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for LegalNotice ('legal_notice').
 */
public interface LegalNoticeDAO {

    LegalNotice insert(LegalNotice entity) throws DAOException;

    LegalNotice update(LegalNotice entity) throws DAOException;

    boolean delete(String noticeId) throws DAOException;

    LegalNotice findById(String noticeId) throws DAOException;

    List<LegalNotice> findAll() throws DAOException;
}
