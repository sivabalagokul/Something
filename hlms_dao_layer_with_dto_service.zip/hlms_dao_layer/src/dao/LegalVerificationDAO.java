package hlms.dao;

import hlms.entity.LegalVerification;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for LegalVerification ('legal_verification').
 */
public interface LegalVerificationDAO {

    LegalVerification insert(LegalVerification entity) throws DAOException;

    LegalVerification update(LegalVerification entity) throws DAOException;

    boolean delete(String appId) throws DAOException;

    LegalVerification findById(String appId) throws DAOException;

    List<LegalVerification> findAll() throws DAOException;
}
