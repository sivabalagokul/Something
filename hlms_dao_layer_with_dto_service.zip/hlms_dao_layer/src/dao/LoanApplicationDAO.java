package hlms.dao;

import hlms.entity.LoanApplication;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for LoanApplication ('loan_application').
 */
public interface LoanApplicationDAO {

    LoanApplication insert(LoanApplication entity) throws DAOException;

    LoanApplication update(LoanApplication entity) throws DAOException;

    boolean delete(String appId) throws DAOException;

    LoanApplication findById(String appId) throws DAOException;

    List<LoanApplication> findAll() throws DAOException;
}
