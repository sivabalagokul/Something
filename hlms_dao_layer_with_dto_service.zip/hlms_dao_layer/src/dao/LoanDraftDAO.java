package hlms.dao;

import hlms.entity.LoanDraft;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for LoanDraft ('loan_draft').
 */
public interface LoanDraftDAO {

    LoanDraft insert(LoanDraft entity) throws DAOException;

    LoanDraft update(LoanDraft entity) throws DAOException;

    boolean delete(String draftId) throws DAOException;

    LoanDraft findById(String draftId) throws DAOException;

    List<LoanDraft> findAll() throws DAOException;
}
