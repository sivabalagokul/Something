package hlms.dao;

import hlms.entity.LoanProduct;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for LoanProduct ('loan_product').
 */
public interface LoanProductDAO {

    LoanProduct insert(LoanProduct entity) throws DAOException;

    LoanProduct update(LoanProduct entity) throws DAOException;

    boolean delete(String productId) throws DAOException;

    LoanProduct findById(String productId) throws DAOException;

    List<LoanProduct> findAll() throws DAOException;
}
