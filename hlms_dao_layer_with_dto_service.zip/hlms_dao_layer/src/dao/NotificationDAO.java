package hlms.dao;

import hlms.entity.Notification;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for Notification ('notification').
 */
public interface NotificationDAO {

    Notification insert(Notification entity) throws DAOException;

    Notification update(Notification entity) throws DAOException;

    boolean delete(String notificationId) throws DAOException;

    Notification findById(String notificationId) throws DAOException;

    List<Notification> findAll() throws DAOException;
}
