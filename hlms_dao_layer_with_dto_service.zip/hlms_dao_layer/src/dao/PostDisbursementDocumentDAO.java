package hlms.dao;

import hlms.entity.PostDisbursementDocument;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for PostDisbursementDocument ('post_disbursement_document').
 */
public interface PostDisbursementDocumentDAO {

    PostDisbursementDocument insert(PostDisbursementDocument entity) throws DAOException;

    PostDisbursementDocument update(PostDisbursementDocument entity) throws DAOException;

    boolean delete(String pdDocId) throws DAOException;

    PostDisbursementDocument findById(String pdDocId) throws DAOException;

    List<PostDisbursementDocument> findAll() throws DAOException;
}
