package hlms.dao;

import hlms.entity.RolePermission;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for RolePermission ('role_permission').
 */
public interface RolePermissionDAO {

    RolePermission insert(RolePermission entity) throws DAOException;

    RolePermission update(RolePermission entity) throws DAOException;

    boolean delete(String role, String module) throws DAOException;

    RolePermission findById(String role, String module) throws DAOException;

    List<RolePermission> findAll() throws DAOException;
}
