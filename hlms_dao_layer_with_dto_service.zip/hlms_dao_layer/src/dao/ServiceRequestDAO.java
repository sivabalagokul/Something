package hlms.dao;

import hlms.entity.ServiceRequest;
import hlms.util.DAOException;
import java.util.List;

/**
 * DAO contract for ServiceRequest ('service_request').
 */
public interface ServiceRequestDAO {

    ServiceRequest insert(ServiceRequest entity) throws DAOException;

    ServiceRequest update(ServiceRequest entity) throws DAOException;

    boolean delete(String requestId) throws DAOException;

    ServiceRequest findById(String requestId) throws DAOException;

    List<ServiceRequest> findAll() throws DAOException;
}
