package hlms.daoimpl;

import hlms.dao.AppUserDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of AppUserDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class AppUserDAOImpl implements AppUserDAO {

    private static final String INSERT_SQL =
            "INSERT INTO app_user (email, name, mobile, password_hash, role, active, id_type, id_number, pref_sms, pref_email, pref_inapp, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE app_user SET name = ?, mobile = ?, password_hash = ?, role = ?, active = ?, id_type = ?, id_number = ?, pref_sms = ?, pref_email = ?, pref_inapp = ?, created_at = ? WHERE email = ?";

    private static final String DELETE_SQL =
            "DELETE FROM app_user WHERE email = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM app_user WHERE email = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM app_user";

    @Override
    public AppUser insert(AppUser entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getEmail());
            ps.setObject(2, entity.getName());
            ps.setObject(3, entity.getMobile());
            ps.setObject(4, entity.getPasswordHash());
            ps.setObject(5, entity.getRole());
            ps.setObject(6, entity.getActive());
            ps.setObject(7, entity.getIdType());
            ps.setObject(8, entity.getIdNumber());
            ps.setObject(9, entity.getPrefSms());
            ps.setObject(10, entity.getPrefEmail());
            ps.setObject(11, entity.getPrefInapp());
            ps.setObject(12, entity.getCreatedAt());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert AppUser: " + e.getMessage(), e);
        }
    }

    @Override
    public AppUser update(AppUser entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getName());
            ps.setObject(2, entity.getMobile());
            ps.setObject(3, entity.getPasswordHash());
            ps.setObject(4, entity.getRole());
            ps.setObject(5, entity.getActive());
            ps.setObject(6, entity.getIdType());
            ps.setObject(7, entity.getIdNumber());
            ps.setObject(8, entity.getPrefSms());
            ps.setObject(9, entity.getPrefEmail());
            ps.setObject(10, entity.getPrefInapp());
            ps.setObject(11, entity.getCreatedAt());
            ps.setObject(12, entity.getEmail());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No AppUser found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update AppUser: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String email) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, email);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete AppUser: " + e.getMessage(), e);
        }
    }

    @Override
    public AppUser findById(String email) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch AppUser: " + e.getMessage(), e);
        }
    }

    @Override
    public List<AppUser> findAll() throws DAOException {
        List<AppUser> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch AppUser list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a AppUser. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private AppUser mapRow(ResultSet rs) throws SQLException {
        AppUser entity = new AppUser();
        entity.setEmail(rs.getString("email"));
        entity.setName(rs.getString("name"));
        entity.setMobile(rs.getString("mobile"));
        entity.setPasswordHash(rs.getString("password_hash"));
        entity.setRole(rs.getString("role"));
        Object activeVal = rs.getObject("active");
        entity.setActive(activeVal == null ? null : (Boolean) activeVal);
        entity.setIdType(rs.getString("id_type"));
        entity.setIdNumber(rs.getString("id_number"));
        Object prefSmsVal = rs.getObject("pref_sms");
        entity.setPrefSms(prefSmsVal == null ? null : (Boolean) prefSmsVal);
        Object prefEmailVal = rs.getObject("pref_email");
        entity.setPrefEmail(prefEmailVal == null ? null : (Boolean) prefEmailVal);
        Object prefInappVal = rs.getObject("pref_inapp");
        entity.setPrefInapp(prefInappVal == null ? null : (Boolean) prefInappVal);
        entity.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        return entity;
    }
}
