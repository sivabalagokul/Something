package hlms.daoimpl;

import hlms.dao.ApplicationDocumentDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of ApplicationDocumentDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class ApplicationDocumentDAOImpl implements ApplicationDocumentDAO {

    private static final String INSERT_SQL =
            "INSERT INTO application_document (document_id, app_id, doc_type, file_name, file_size, uploaded_at, verification_status, verified_by, verified_at, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE application_document SET app_id = ?, doc_type = ?, file_name = ?, file_size = ?, uploaded_at = ?, verification_status = ?, verified_by = ?, verified_at = ?, remarks = ? WHERE document_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM application_document WHERE document_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM application_document WHERE document_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM application_document";

    @Override
    public ApplicationDocument insert(ApplicationDocument entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getDocumentId());
            ps.setObject(2, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(3, entity.getDocType());
            ps.setObject(4, entity.getFileName());
            ps.setObject(5, entity.getFileSize());
            ps.setObject(6, entity.getUploadedAt());
            ps.setObject(7, entity.getVerificationStatus());
            ps.setObject(8, entity.getVerifiedBy() == null ? null : entity.getVerifiedBy().getEmail());
            ps.setObject(9, entity.getVerifiedAt());
            ps.setObject(10, entity.getRemarks());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert ApplicationDocument: " + e.getMessage(), e);
        }
    }

    @Override
    public ApplicationDocument update(ApplicationDocument entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(2, entity.getDocType());
            ps.setObject(3, entity.getFileName());
            ps.setObject(4, entity.getFileSize());
            ps.setObject(5, entity.getUploadedAt());
            ps.setObject(6, entity.getVerificationStatus());
            ps.setObject(7, entity.getVerifiedBy() == null ? null : entity.getVerifiedBy().getEmail());
            ps.setObject(8, entity.getVerifiedAt());
            ps.setObject(9, entity.getRemarks());
            ps.setObject(10, entity.getDocumentId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No ApplicationDocument found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update ApplicationDocument: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String documentId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, documentId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete ApplicationDocument: " + e.getMessage(), e);
        }
    }

    @Override
    public ApplicationDocument findById(String documentId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, documentId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch ApplicationDocument: " + e.getMessage(), e);
        }
    }

    @Override
    public List<ApplicationDocument> findAll() throws DAOException {
        List<ApplicationDocument> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch ApplicationDocument list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a ApplicationDocument. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private ApplicationDocument mapRow(ResultSet rs) throws SQLException {
        ApplicationDocument entity = new ApplicationDocument();
        entity.setDocumentId(rs.getString("document_id"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        entity.setDocType(rs.getString("doc_type"));
        entity.setFileName(rs.getString("file_name"));
        entity.setFileSize(rs.getObject("file_size") == null ? null : rs.getInt("file_size"));
        entity.setUploadedAt(rs.getObject("uploaded_at", OffsetDateTime.class));
        entity.setVerificationStatus(rs.getString("verification_status"));
        String verifiedByRef = rs.getString("verified_by");
        if (verifiedByRef != null) {
            AppUser verifiedBy = new AppUser();
            verifiedBy.setEmail(verifiedByRef);
            entity.setVerifiedBy(verifiedBy);
        }
        entity.setVerifiedAt(rs.getObject("verified_at", OffsetDateTime.class));
        entity.setRemarks(rs.getString("remarks"));
        return entity;
    }
}
