package hlms.daoimpl;

import hlms.dao.AuctionCaseDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * JDBC implementation of AuctionCaseDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class AuctionCaseDAOImpl implements AuctionCaseDAO {

    private static final String INSERT_SQL =
            "INSERT INTO auction_case (app_id, stage, notice_date, notice_due_date, demand_amount, possession_date, auction_date, reserve_price) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE auction_case SET stage = ?, notice_date = ?, notice_due_date = ?, demand_amount = ?, possession_date = ?, auction_date = ?, reserve_price = ? WHERE app_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM auction_case WHERE app_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM auction_case WHERE app_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM auction_case";

    @Override
    public AuctionCase insert(AuctionCase entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getAppId());
            ps.setObject(2, entity.getStage());
            ps.setObject(3, entity.getNoticeDate());
            ps.setObject(4, entity.getNoticeDueDate());
            ps.setObject(5, entity.getDemandAmount());
            ps.setObject(6, entity.getPossessionDate());
            ps.setObject(7, entity.getAuctionDate());
            ps.setObject(8, entity.getReservePrice());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert AuctionCase: " + e.getMessage(), e);
        }
    }

    @Override
    public AuctionCase update(AuctionCase entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getStage());
            ps.setObject(2, entity.getNoticeDate());
            ps.setObject(3, entity.getNoticeDueDate());
            ps.setObject(4, entity.getDemandAmount());
            ps.setObject(5, entity.getPossessionDate());
            ps.setObject(6, entity.getAuctionDate());
            ps.setObject(7, entity.getReservePrice());
            ps.setObject(8, entity.getAppId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No AuctionCase found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update AuctionCase: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, appId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete AuctionCase: " + e.getMessage(), e);
        }
    }

    @Override
    public AuctionCase findById(String appId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, appId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch AuctionCase: " + e.getMessage(), e);
        }
    }

    @Override
    public List<AuctionCase> findAll() throws DAOException {
        List<AuctionCase> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch AuctionCase list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a AuctionCase. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private AuctionCase mapRow(ResultSet rs) throws SQLException {
        AuctionCase entity = new AuctionCase();
        entity.setAppId(rs.getString("app_id"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        entity.setStage(rs.getString("stage"));
        entity.setNoticeDate(rs.getObject("notice_date", LocalDate.class));
        entity.setNoticeDueDate(rs.getObject("notice_due_date", LocalDate.class));
        entity.setDemandAmount(rs.getBigDecimal("demand_amount"));
        entity.setPossessionDate(rs.getObject("possession_date", LocalDate.class));
        entity.setAuctionDate(rs.getObject("auction_date", LocalDate.class));
        entity.setReservePrice(rs.getBigDecimal("reserve_price"));
        return entity;
    }
}
