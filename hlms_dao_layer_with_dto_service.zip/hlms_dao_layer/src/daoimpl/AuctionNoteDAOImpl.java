package hlms.daoimpl;

import hlms.dao.AuctionNoteDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of AuctionNoteDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class AuctionNoteDAOImpl implements AuctionNoteDAO {

    private static final String INSERT_SQL =
            "INSERT INTO auction_note (note_id, app_id, note_date, note_text) VALUES (?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE auction_note SET app_id = ?, note_date = ?, note_text = ? WHERE note_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM auction_note WHERE note_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM auction_note WHERE note_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM auction_note";

    @Override
    public AuctionNote insert(AuctionNote entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getNoteId());
            ps.setObject(2, entity.getAuctionCase() == null ? null : entity.getAuctionCase().getAppId());
            ps.setObject(3, entity.getNoteDate());
            ps.setObject(4, entity.getNoteText());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert AuctionNote: " + e.getMessage(), e);
        }
    }

    @Override
    public AuctionNote update(AuctionNote entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getAuctionCase() == null ? null : entity.getAuctionCase().getAppId());
            ps.setObject(2, entity.getNoteDate());
            ps.setObject(3, entity.getNoteText());
            ps.setObject(4, entity.getNoteId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No AuctionNote found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update AuctionNote: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String noteId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, noteId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete AuctionNote: " + e.getMessage(), e);
        }
    }

    @Override
    public AuctionNote findById(String noteId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, noteId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch AuctionNote: " + e.getMessage(), e);
        }
    }

    @Override
    public List<AuctionNote> findAll() throws DAOException {
        List<AuctionNote> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch AuctionNote list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a AuctionNote. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private AuctionNote mapRow(ResultSet rs) throws SQLException {
        AuctionNote entity = new AuctionNote();
        entity.setNoteId(rs.getString("note_id"));
        String auctionCaseRef = rs.getString("app_id");
        if (auctionCaseRef != null) {
            AuctionCase auctionCase = new AuctionCase();
            auctionCase.setAppId(auctionCaseRef);
            entity.setAuctionCase(auctionCase);
        }
        entity.setNoteDate(rs.getObject("note_date", OffsetDateTime.class));
        entity.setNoteText(rs.getString("note_text"));
        return entity;
    }
}
