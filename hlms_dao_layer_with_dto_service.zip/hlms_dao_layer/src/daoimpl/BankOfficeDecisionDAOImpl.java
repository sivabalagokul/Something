package hlms.daoimpl;

import hlms.dao.BankOfficeDecisionDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of BankOfficeDecisionDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class BankOfficeDecisionDAOImpl implements BankOfficeDecisionDAO {

    private static final String INSERT_SQL =
            "INSERT INTO bank_office_decision (app_id, decision, officer, decision_date, reason, remarks) VALUES (?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE bank_office_decision SET decision = ?, officer = ?, decision_date = ?, reason = ?, remarks = ? WHERE app_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM bank_office_decision WHERE app_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM bank_office_decision WHERE app_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM bank_office_decision";

    @Override
    public BankOfficeDecision insert(BankOfficeDecision entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getAppId());
            ps.setObject(2, entity.getDecision());
            ps.setObject(3, entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
            ps.setObject(4, entity.getDecisionDate());
            ps.setObject(5, entity.getReason());
            ps.setObject(6, entity.getRemarks());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert BankOfficeDecision: " + e.getMessage(), e);
        }
    }

    @Override
    public BankOfficeDecision update(BankOfficeDecision entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getDecision());
            ps.setObject(2, entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
            ps.setObject(3, entity.getDecisionDate());
            ps.setObject(4, entity.getReason());
            ps.setObject(5, entity.getRemarks());
            ps.setObject(6, entity.getAppId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No BankOfficeDecision found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update BankOfficeDecision: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, appId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete BankOfficeDecision: " + e.getMessage(), e);
        }
    }

    @Override
    public BankOfficeDecision findById(String appId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, appId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch BankOfficeDecision: " + e.getMessage(), e);
        }
    }

    @Override
    public List<BankOfficeDecision> findAll() throws DAOException {
        List<BankOfficeDecision> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch BankOfficeDecision list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a BankOfficeDecision. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private BankOfficeDecision mapRow(ResultSet rs) throws SQLException {
        BankOfficeDecision entity = new BankOfficeDecision();
        entity.setAppId(rs.getString("app_id"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        entity.setDecision(rs.getString("decision"));
        String officerRef = rs.getString("officer");
        if (officerRef != null) {
            AppUser officer = new AppUser();
            officer.setEmail(officerRef);
            entity.setOfficer(officer);
        }
        entity.setDecisionDate(rs.getObject("decision_date", OffsetDateTime.class));
        entity.setReason(rs.getString("reason"));
        entity.setRemarks(rs.getString("remarks"));
        return entity;
    }
}
