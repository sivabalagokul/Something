package hlms.daoimpl;

import hlms.dao.BidDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of BidDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class BidDAOImpl implements BidDAO {

    private static final String INSERT_SQL =
            "INSERT INTO bid (bid_id, app_id, bidder_email, bid_amount, created_at) VALUES (?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE bid SET app_id = ?, bidder_email = ?, bid_amount = ?, created_at = ? WHERE bid_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM bid WHERE bid_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM bid WHERE bid_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM bid";

    @Override
    public Bid insert(Bid entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getBidId());
            ps.setObject(2, entity.getAuctionCase() == null ? null : entity.getAuctionCase().getAppId());
            ps.setObject(3, entity.getBidder() == null ? null : entity.getBidder().getEmail());
            ps.setObject(4, entity.getBidAmount());
            ps.setObject(5, entity.getCreatedAt());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert Bid: " + e.getMessage(), e);
        }
    }

    @Override
    public Bid update(Bid entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getAuctionCase() == null ? null : entity.getAuctionCase().getAppId());
            ps.setObject(2, entity.getBidder() == null ? null : entity.getBidder().getEmail());
            ps.setObject(3, entity.getBidAmount());
            ps.setObject(4, entity.getCreatedAt());
            ps.setObject(5, entity.getBidId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No Bid found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update Bid: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String bidId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, bidId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete Bid: " + e.getMessage(), e);
        }
    }

    @Override
    public Bid findById(String bidId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, bidId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch Bid: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Bid> findAll() throws DAOException {
        List<Bid> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch Bid list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a Bid. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private Bid mapRow(ResultSet rs) throws SQLException {
        Bid entity = new Bid();
        entity.setBidId(rs.getString("bid_id"));
        String auctionCaseRef = rs.getString("app_id");
        if (auctionCaseRef != null) {
            AuctionCase auctionCase = new AuctionCase();
            auctionCase.setAppId(auctionCaseRef);
            entity.setAuctionCase(auctionCase);
        }
        String bidderRef = rs.getString("bidder_email");
        if (bidderRef != null) {
            AppUser bidder = new AppUser();
            bidder.setEmail(bidderRef);
            entity.setBidder(bidder);
        }
        entity.setBidAmount(rs.getBigDecimal("bid_amount"));
        entity.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        return entity;
    }
}
