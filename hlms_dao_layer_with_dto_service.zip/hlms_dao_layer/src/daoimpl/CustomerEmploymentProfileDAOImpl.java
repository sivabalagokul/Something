package hlms.daoimpl;

import hlms.dao.CustomerEmploymentProfileDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;

/**
 * JDBC implementation of CustomerEmploymentProfileDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class CustomerEmploymentProfileDAOImpl implements CustomerEmploymentProfileDAO {

    private static final String INSERT_SQL =
            "INSERT INTO customer_employment_profile (user_email, employment_type, employer, monthly_income, other_emis, desired_amount, pan) VALUES (?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE customer_employment_profile SET employment_type = ?, employer = ?, monthly_income = ?, other_emis = ?, desired_amount = ?, pan = ? WHERE user_email = ?";

    private static final String DELETE_SQL =
            "DELETE FROM customer_employment_profile WHERE user_email = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM customer_employment_profile WHERE user_email = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM customer_employment_profile";

    @Override
    public CustomerEmploymentProfile insert(CustomerEmploymentProfile entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getUserEmail());
            ps.setObject(2, entity.getEmploymentType());
            ps.setObject(3, entity.getEmployer());
            ps.setObject(4, entity.getMonthlyIncome());
            ps.setObject(5, entity.getOtherEmis());
            ps.setObject(6, entity.getDesiredAmount());
            ps.setObject(7, entity.getPan());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert CustomerEmploymentProfile: " + e.getMessage(), e);
        }
    }

    @Override
    public CustomerEmploymentProfile update(CustomerEmploymentProfile entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getEmploymentType());
            ps.setObject(2, entity.getEmployer());
            ps.setObject(3, entity.getMonthlyIncome());
            ps.setObject(4, entity.getOtherEmis());
            ps.setObject(5, entity.getDesiredAmount());
            ps.setObject(6, entity.getPan());
            ps.setObject(7, entity.getUserEmail());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No CustomerEmploymentProfile found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update CustomerEmploymentProfile: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String userEmail) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, userEmail);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete CustomerEmploymentProfile: " + e.getMessage(), e);
        }
    }

    @Override
    public CustomerEmploymentProfile findById(String userEmail) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, userEmail);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch CustomerEmploymentProfile: " + e.getMessage(), e);
        }
    }

    @Override
    public List<CustomerEmploymentProfile> findAll() throws DAOException {
        List<CustomerEmploymentProfile> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch CustomerEmploymentProfile list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a CustomerEmploymentProfile. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private CustomerEmploymentProfile mapRow(ResultSet rs) throws SQLException {
        CustomerEmploymentProfile entity = new CustomerEmploymentProfile();
        entity.setUserEmail(rs.getString("user_email"));
        String userRef = rs.getString("user_email");
        if (userRef != null) {
            AppUser user = new AppUser();
            user.setEmail(userRef);
            entity.setUser(user);
        }
        entity.setEmploymentType(rs.getString("employment_type"));
        entity.setEmployer(rs.getString("employer"));
        entity.setMonthlyIncome(rs.getBigDecimal("monthly_income"));
        entity.setOtherEmis(rs.getBigDecimal("other_emis"));
        entity.setDesiredAmount(rs.getBigDecimal("desired_amount"));
        entity.setPan(rs.getString("pan"));
        return entity;
    }
}
