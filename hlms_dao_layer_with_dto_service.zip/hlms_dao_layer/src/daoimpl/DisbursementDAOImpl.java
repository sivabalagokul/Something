package hlms.daoimpl;

import hlms.dao.DisbursementDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of DisbursementDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class DisbursementDAOImpl implements DisbursementDAO {

    private static final String INSERT_SQL =
            "INSERT INTO disbursement (app_id, disbursed_date, amount, ref_no, mode, bank_details) VALUES (?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE disbursement SET disbursed_date = ?, amount = ?, ref_no = ?, mode = ?, bank_details = ? WHERE app_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM disbursement WHERE app_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM disbursement WHERE app_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM disbursement";

    @Override
    public Disbursement insert(Disbursement entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getAppId());
            ps.setObject(2, entity.getDisbursedDate());
            ps.setObject(3, entity.getAmount());
            ps.setObject(4, entity.getRefNo());
            ps.setObject(5, entity.getMode());
            ps.setObject(6, entity.getBankDetails());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert Disbursement: " + e.getMessage(), e);
        }
    }

    @Override
    public Disbursement update(Disbursement entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getDisbursedDate());
            ps.setObject(2, entity.getAmount());
            ps.setObject(3, entity.getRefNo());
            ps.setObject(4, entity.getMode());
            ps.setObject(5, entity.getBankDetails());
            ps.setObject(6, entity.getAppId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No Disbursement found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update Disbursement: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, appId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete Disbursement: " + e.getMessage(), e);
        }
    }

    @Override
    public Disbursement findById(String appId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, appId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch Disbursement: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Disbursement> findAll() throws DAOException {
        List<Disbursement> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch Disbursement list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a Disbursement. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private Disbursement mapRow(ResultSet rs) throws SQLException {
        Disbursement entity = new Disbursement();
        entity.setAppId(rs.getString("app_id"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        entity.setDisbursedDate(rs.getObject("disbursed_date", OffsetDateTime.class));
        entity.setAmount(rs.getBigDecimal("amount"));
        entity.setRefNo(rs.getString("ref_no"));
        entity.setMode(rs.getString("mode"));
        entity.setBankDetails(rs.getString("bank_details"));
        return entity;
    }
}
