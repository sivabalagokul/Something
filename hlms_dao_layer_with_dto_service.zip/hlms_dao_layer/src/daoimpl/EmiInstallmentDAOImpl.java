package hlms.daoimpl;

import hlms.dao.EmiInstallmentDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * JDBC implementation of EmiInstallmentDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class EmiInstallmentDAOImpl implements EmiInstallmentDAO {

    private static final String INSERT_SQL =
            "INSERT INTO emi_installment (installment_id, app_id, installment_no, due_date, emi_amount, principal_component, interest_component, closing_balance, status, paid_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE emi_installment SET app_id = ?, installment_no = ?, due_date = ?, emi_amount = ?, principal_component = ?, interest_component = ?, closing_balance = ?, status = ?, paid_date = ? WHERE installment_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM emi_installment WHERE installment_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM emi_installment WHERE installment_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM emi_installment";

    @Override
    public EmiInstallment insert(EmiInstallment entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getInstallmentId());
            ps.setObject(2, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(3, entity.getInstallmentNo());
            ps.setObject(4, entity.getDueDate());
            ps.setObject(5, entity.getEmiAmount());
            ps.setObject(6, entity.getPrincipalComponent());
            ps.setObject(7, entity.getInterestComponent());
            ps.setObject(8, entity.getClosingBalance());
            ps.setObject(9, entity.getStatus());
            ps.setObject(10, entity.getPaidDate());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert EmiInstallment: " + e.getMessage(), e);
        }
    }

    @Override
    public EmiInstallment update(EmiInstallment entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(2, entity.getInstallmentNo());
            ps.setObject(3, entity.getDueDate());
            ps.setObject(4, entity.getEmiAmount());
            ps.setObject(5, entity.getPrincipalComponent());
            ps.setObject(6, entity.getInterestComponent());
            ps.setObject(7, entity.getClosingBalance());
            ps.setObject(8, entity.getStatus());
            ps.setObject(9, entity.getPaidDate());
            ps.setObject(10, entity.getInstallmentId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No EmiInstallment found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update EmiInstallment: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String installmentId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, installmentId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete EmiInstallment: " + e.getMessage(), e);
        }
    }

    @Override
    public EmiInstallment findById(String installmentId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, installmentId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch EmiInstallment: " + e.getMessage(), e);
        }
    }

    @Override
    public List<EmiInstallment> findAll() throws DAOException {
        List<EmiInstallment> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch EmiInstallment list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a EmiInstallment. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private EmiInstallment mapRow(ResultSet rs) throws SQLException {
        EmiInstallment entity = new EmiInstallment();
        entity.setInstallmentId(rs.getString("installment_id"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        entity.setInstallmentNo(rs.getObject("installment_no") == null ? null : rs.getInt("installment_no"));
        entity.setDueDate(rs.getObject("due_date", LocalDate.class));
        entity.setEmiAmount(rs.getBigDecimal("emi_amount"));
        entity.setPrincipalComponent(rs.getBigDecimal("principal_component"));
        entity.setInterestComponent(rs.getBigDecimal("interest_component"));
        entity.setClosingBalance(rs.getBigDecimal("closing_balance"));
        entity.setStatus(rs.getString("status"));
        entity.setPaidDate(rs.getObject("paid_date", LocalDate.class));
        return entity;
    }
}
