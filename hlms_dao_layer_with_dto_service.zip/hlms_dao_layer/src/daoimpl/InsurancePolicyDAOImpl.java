package hlms.daoimpl;

import hlms.dao.InsurancePolicyDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

/**
 * JDBC implementation of InsurancePolicyDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class InsurancePolicyDAOImpl implements InsurancePolicyDAO {

    private static final String INSERT_SQL =
            "INSERT INTO insurance_policy (policy_id, app_id, policy_type, status, valid_till) VALUES (?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE insurance_policy SET app_id = ?, policy_type = ?, status = ?, valid_till = ? WHERE policy_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM insurance_policy WHERE policy_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM insurance_policy WHERE policy_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM insurance_policy";

    @Override
    public InsurancePolicy insert(InsurancePolicy entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getPolicyId());
            ps.setObject(2, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(3, entity.getPolicyType());
            ps.setObject(4, entity.getStatus());
            ps.setObject(5, entity.getValidTill());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert InsurancePolicy: " + e.getMessage(), e);
        }
    }

    @Override
    public InsurancePolicy update(InsurancePolicy entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(2, entity.getPolicyType());
            ps.setObject(3, entity.getStatus());
            ps.setObject(4, entity.getValidTill());
            ps.setObject(5, entity.getPolicyId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No InsurancePolicy found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update InsurancePolicy: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String policyId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, policyId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete InsurancePolicy: " + e.getMessage(), e);
        }
    }

    @Override
    public InsurancePolicy findById(String policyId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, policyId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch InsurancePolicy: " + e.getMessage(), e);
        }
    }

    @Override
    public List<InsurancePolicy> findAll() throws DAOException {
        List<InsurancePolicy> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch InsurancePolicy list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a InsurancePolicy. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private InsurancePolicy mapRow(ResultSet rs) throws SQLException {
        InsurancePolicy entity = new InsurancePolicy();
        entity.setPolicyId(rs.getString("policy_id"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        entity.setPolicyType(rs.getString("policy_type"));
        entity.setStatus(rs.getString("status"));
        entity.setValidTill(rs.getObject("valid_till", LocalDate.class));
        return entity;
    }
}
