package hlms.daoimpl;

import hlms.dao.LegalChecklistItemDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation of LegalChecklistItemDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class LegalChecklistItemDAOImpl implements LegalChecklistItemDAO {

    private static final String INSERT_SQL =
            "INSERT INTO legal_checklist_item (checklist_item_id, app_id, checklist_key, status) VALUES (?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE legal_checklist_item SET app_id = ?, checklist_key = ?, status = ? WHERE checklist_item_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM legal_checklist_item WHERE checklist_item_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM legal_checklist_item WHERE checklist_item_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM legal_checklist_item";

    @Override
    public LegalChecklistItem insert(LegalChecklistItem entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getChecklistItemId());
            ps.setObject(2, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(3, entity.getChecklistKey());
            ps.setObject(4, entity.getStatus());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert LegalChecklistItem: " + e.getMessage(), e);
        }
    }

    @Override
    public LegalChecklistItem update(LegalChecklistItem entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(2, entity.getChecklistKey());
            ps.setObject(3, entity.getStatus());
            ps.setObject(4, entity.getChecklistItemId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No LegalChecklistItem found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update LegalChecklistItem: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String checklistItemId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, checklistItemId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete LegalChecklistItem: " + e.getMessage(), e);
        }
    }

    @Override
    public LegalChecklistItem findById(String checklistItemId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, checklistItemId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LegalChecklistItem: " + e.getMessage(), e);
        }
    }

    @Override
    public List<LegalChecklistItem> findAll() throws DAOException {
        List<LegalChecklistItem> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LegalChecklistItem list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a LegalChecklistItem. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private LegalChecklistItem mapRow(ResultSet rs) throws SQLException {
        LegalChecklistItem entity = new LegalChecklistItem();
        entity.setChecklistItemId(rs.getString("checklist_item_id"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        entity.setChecklistKey(rs.getString("checklist_key"));
        entity.setStatus(rs.getString("status"));
        return entity;
    }
}
