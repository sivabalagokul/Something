package hlms.daoimpl;

import hlms.dao.LegalNoticeDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

/**
 * JDBC implementation of LegalNoticeDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class LegalNoticeDAOImpl implements LegalNoticeDAO {

    private static final String INSERT_SQL =
            "INSERT INTO legal_notice (notice_id, notice_no, app_id, notice_type, issue_date, due_date, status, officer, content) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE legal_notice SET notice_no = ?, app_id = ?, notice_type = ?, issue_date = ?, due_date = ?, status = ?, officer = ?, content = ? WHERE notice_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM legal_notice WHERE notice_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM legal_notice WHERE notice_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM legal_notice";

    @Override
    public LegalNotice insert(LegalNotice entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getNoticeId());
            ps.setObject(2, entity.getNoticeNo());
            ps.setObject(3, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(4, entity.getNoticeType());
            ps.setObject(5, entity.getIssueDate());
            ps.setObject(6, entity.getDueDate());
            ps.setObject(7, entity.getStatus());
            ps.setObject(8, entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
            ps.setObject(9, entity.getContent());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert LegalNotice: " + e.getMessage(), e);
        }
    }

    @Override
    public LegalNotice update(LegalNotice entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getNoticeNo());
            ps.setObject(2, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(3, entity.getNoticeType());
            ps.setObject(4, entity.getIssueDate());
            ps.setObject(5, entity.getDueDate());
            ps.setObject(6, entity.getStatus());
            ps.setObject(7, entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
            ps.setObject(8, entity.getContent());
            ps.setObject(9, entity.getNoticeId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No LegalNotice found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update LegalNotice: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String noticeId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, noticeId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete LegalNotice: " + e.getMessage(), e);
        }
    }

    @Override
    public LegalNotice findById(String noticeId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, noticeId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LegalNotice: " + e.getMessage(), e);
        }
    }

    @Override
    public List<LegalNotice> findAll() throws DAOException {
        List<LegalNotice> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LegalNotice list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a LegalNotice. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private LegalNotice mapRow(ResultSet rs) throws SQLException {
        LegalNotice entity = new LegalNotice();
        entity.setNoticeId(rs.getString("notice_id"));
        entity.setNoticeNo(rs.getString("notice_no"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        entity.setNoticeType(rs.getString("notice_type"));
        entity.setIssueDate(rs.getObject("issue_date", LocalDate.class));
        entity.setDueDate(rs.getObject("due_date", LocalDate.class));
        entity.setStatus(rs.getString("status"));
        String officerRef = rs.getString("officer");
        if (officerRef != null) {
            AppUser officer = new AppUser();
            officer.setEmail(officerRef);
            entity.setOfficer(officer);
        }
        entity.setContent(rs.getString("content"));
        return entity;
    }
}
