package hlms.daoimpl;

import hlms.dao.LegalVerificationDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of LegalVerificationDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class LegalVerificationDAOImpl implements LegalVerificationDAO {

    private static final String INSERT_SQL =
            "INSERT INTO legal_verification (app_id, decision, decision_date, officer, remarks) VALUES (?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE legal_verification SET decision = ?, decision_date = ?, officer = ?, remarks = ? WHERE app_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM legal_verification WHERE app_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM legal_verification WHERE app_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM legal_verification";

    @Override
    public LegalVerification insert(LegalVerification entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getAppId());
            ps.setObject(2, entity.getDecision());
            ps.setObject(3, entity.getDecisionDate());
            ps.setObject(4, entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
            ps.setObject(5, entity.getRemarks());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert LegalVerification: " + e.getMessage(), e);
        }
    }

    @Override
    public LegalVerification update(LegalVerification entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getDecision());
            ps.setObject(2, entity.getDecisionDate());
            ps.setObject(3, entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
            ps.setObject(4, entity.getRemarks());
            ps.setObject(5, entity.getAppId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No LegalVerification found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update LegalVerification: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, appId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete LegalVerification: " + e.getMessage(), e);
        }
    }

    @Override
    public LegalVerification findById(String appId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, appId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LegalVerification: " + e.getMessage(), e);
        }
    }

    @Override
    public List<LegalVerification> findAll() throws DAOException {
        List<LegalVerification> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LegalVerification list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a LegalVerification. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private LegalVerification mapRow(ResultSet rs) throws SQLException {
        LegalVerification entity = new LegalVerification();
        entity.setAppId(rs.getString("app_id"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        entity.setDecision(rs.getString("decision"));
        entity.setDecisionDate(rs.getObject("decision_date", OffsetDateTime.class));
        String officerRef = rs.getString("officer");
        if (officerRef != null) {
            AppUser officer = new AppUser();
            officer.setEmail(officerRef);
            entity.setOfficer(officer);
        }
        entity.setRemarks(rs.getString("remarks"));
        return entity;
    }
}
