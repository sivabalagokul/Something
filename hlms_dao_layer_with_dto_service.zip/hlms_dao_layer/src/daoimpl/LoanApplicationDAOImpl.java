package hlms.daoimpl;

import hlms.dao.LoanApplicationDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of LoanApplicationDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class LoanApplicationDAOImpl implements LoanApplicationDAO {

    private static final String INSERT_SQL =
            "INSERT INTO loan_application (app_id, tracking_no, user_email, product_id, loan_amount, tenure_years, purpose, interest_rate, status, stage_index, created_at, applicant_name, applicant_mobile, applicant_pan, addr_door_no, addr_street, addr_city, addr_state, addr_pincode, employment_type, employer, monthly_income, other_emis, property_address, property_type, property_value) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE loan_application SET tracking_no = ?, user_email = ?, product_id = ?, loan_amount = ?, tenure_years = ?, purpose = ?, interest_rate = ?, status = ?, stage_index = ?, created_at = ?, applicant_name = ?, applicant_mobile = ?, applicant_pan = ?, addr_door_no = ?, addr_street = ?, addr_city = ?, addr_state = ?, addr_pincode = ?, employment_type = ?, employer = ?, monthly_income = ?, other_emis = ?, property_address = ?, property_type = ?, property_value = ? WHERE app_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM loan_application WHERE app_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM loan_application WHERE app_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM loan_application";

    @Override
    public LoanApplication insert(LoanApplication entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getAppId());
            ps.setObject(2, entity.getTrackingNo());
            ps.setObject(3, entity.getUser() == null ? null : entity.getUser().getEmail());
            ps.setObject(4, entity.getProduct() == null ? null : entity.getProduct().getProductId());
            ps.setObject(5, entity.getLoanAmount());
            ps.setObject(6, entity.getTenureYears());
            ps.setObject(7, entity.getPurpose());
            ps.setObject(8, entity.getInterestRate());
            ps.setObject(9, entity.getStatus());
            ps.setObject(10, entity.getStageIndex());
            ps.setObject(11, entity.getCreatedAt());
            ps.setObject(12, entity.getApplicantName());
            ps.setObject(13, entity.getApplicantMobile());
            ps.setObject(14, entity.getApplicantPan());
            ps.setObject(15, entity.getAddrDoorNo());
            ps.setObject(16, entity.getAddrStreet());
            ps.setObject(17, entity.getAddrCity());
            ps.setObject(18, entity.getAddrState());
            ps.setObject(19, entity.getAddrPincode());
            ps.setObject(20, entity.getEmploymentType());
            ps.setObject(21, entity.getEmployer());
            ps.setObject(22, entity.getMonthlyIncome());
            ps.setObject(23, entity.getOtherEmis());
            ps.setObject(24, entity.getPropertyAddress());
            ps.setObject(25, entity.getPropertyType());
            ps.setObject(26, entity.getPropertyValue());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert LoanApplication: " + e.getMessage(), e);
        }
    }

    @Override
    public LoanApplication update(LoanApplication entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getTrackingNo());
            ps.setObject(2, entity.getUser() == null ? null : entity.getUser().getEmail());
            ps.setObject(3, entity.getProduct() == null ? null : entity.getProduct().getProductId());
            ps.setObject(4, entity.getLoanAmount());
            ps.setObject(5, entity.getTenureYears());
            ps.setObject(6, entity.getPurpose());
            ps.setObject(7, entity.getInterestRate());
            ps.setObject(8, entity.getStatus());
            ps.setObject(9, entity.getStageIndex());
            ps.setObject(10, entity.getCreatedAt());
            ps.setObject(11, entity.getApplicantName());
            ps.setObject(12, entity.getApplicantMobile());
            ps.setObject(13, entity.getApplicantPan());
            ps.setObject(14, entity.getAddrDoorNo());
            ps.setObject(15, entity.getAddrStreet());
            ps.setObject(16, entity.getAddrCity());
            ps.setObject(17, entity.getAddrState());
            ps.setObject(18, entity.getAddrPincode());
            ps.setObject(19, entity.getEmploymentType());
            ps.setObject(20, entity.getEmployer());
            ps.setObject(21, entity.getMonthlyIncome());
            ps.setObject(22, entity.getOtherEmis());
            ps.setObject(23, entity.getPropertyAddress());
            ps.setObject(24, entity.getPropertyType());
            ps.setObject(25, entity.getPropertyValue());
            ps.setObject(26, entity.getAppId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No LoanApplication found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update LoanApplication: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, appId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete LoanApplication: " + e.getMessage(), e);
        }
    }

    @Override
    public LoanApplication findById(String appId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, appId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LoanApplication: " + e.getMessage(), e);
        }
    }

    @Override
    public List<LoanApplication> findAll() throws DAOException {
        List<LoanApplication> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LoanApplication list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a LoanApplication. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private LoanApplication mapRow(ResultSet rs) throws SQLException {
        LoanApplication entity = new LoanApplication();
        entity.setAppId(rs.getString("app_id"));
        entity.setTrackingNo(rs.getString("tracking_no"));
        String userRef = rs.getString("user_email");
        if (userRef != null) {
            AppUser user = new AppUser();
            user.setEmail(userRef);
            entity.setUser(user);
        }
        String productRef = rs.getString("product_id");
        if (productRef != null) {
            LoanProduct product = new LoanProduct();
            product.setProductId(productRef);
            entity.setProduct(product);
        }
        entity.setLoanAmount(rs.getBigDecimal("loan_amount"));
        entity.setTenureYears(rs.getObject("tenure_years") == null ? null : rs.getInt("tenure_years"));
        entity.setPurpose(rs.getString("purpose"));
        entity.setInterestRate(rs.getBigDecimal("interest_rate"));
        entity.setStatus(rs.getString("status"));
        entity.setStageIndex(rs.getObject("stage_index") == null ? null : rs.getInt("stage_index"));
        entity.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        entity.setApplicantName(rs.getString("applicant_name"));
        entity.setApplicantMobile(rs.getString("applicant_mobile"));
        entity.setApplicantPan(rs.getString("applicant_pan"));
        entity.setAddrDoorNo(rs.getString("addr_door_no"));
        entity.setAddrStreet(rs.getString("addr_street"));
        entity.setAddrCity(rs.getString("addr_city"));
        entity.setAddrState(rs.getString("addr_state"));
        entity.setAddrPincode(rs.getString("addr_pincode"));
        entity.setEmploymentType(rs.getString("employment_type"));
        entity.setEmployer(rs.getString("employer"));
        entity.setMonthlyIncome(rs.getBigDecimal("monthly_income"));
        entity.setOtherEmis(rs.getBigDecimal("other_emis"));
        entity.setPropertyAddress(rs.getString("property_address"));
        entity.setPropertyType(rs.getString("property_type"));
        entity.setPropertyValue(rs.getBigDecimal("property_value"));
        return entity;
    }
}
