package hlms.daoimpl;

import hlms.dao.LoanDraftDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of LoanDraftDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class LoanDraftDAOImpl implements LoanDraftDAO {

    private static final String INSERT_SQL =
            "INSERT INTO loan_draft (draft_id, user_email, current_step, saved_at, loan_type, loan_amount, tenure_years, form_data) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE loan_draft SET user_email = ?, current_step = ?, saved_at = ?, loan_type = ?, loan_amount = ?, tenure_years = ?, form_data = ? WHERE draft_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM loan_draft WHERE draft_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM loan_draft WHERE draft_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM loan_draft";

    @Override
    public LoanDraft insert(LoanDraft entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getDraftId());
            ps.setObject(2, entity.getUser() == null ? null : entity.getUser().getEmail());
            ps.setObject(3, entity.getCurrentStep());
            ps.setObject(4, entity.getSavedAt());
            ps.setObject(5, entity.getLoanType());
            ps.setObject(6, entity.getLoanAmount());
            ps.setObject(7, entity.getTenureYears());
            ps.setObject(8, entity.getFormData());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert LoanDraft: " + e.getMessage(), e);
        }
    }

    @Override
    public LoanDraft update(LoanDraft entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getUser() == null ? null : entity.getUser().getEmail());
            ps.setObject(2, entity.getCurrentStep());
            ps.setObject(3, entity.getSavedAt());
            ps.setObject(4, entity.getLoanType());
            ps.setObject(5, entity.getLoanAmount());
            ps.setObject(6, entity.getTenureYears());
            ps.setObject(7, entity.getFormData());
            ps.setObject(8, entity.getDraftId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No LoanDraft found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update LoanDraft: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String draftId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, draftId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete LoanDraft: " + e.getMessage(), e);
        }
    }

    @Override
    public LoanDraft findById(String draftId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, draftId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LoanDraft: " + e.getMessage(), e);
        }
    }

    @Override
    public List<LoanDraft> findAll() throws DAOException {
        List<LoanDraft> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LoanDraft list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a LoanDraft. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private LoanDraft mapRow(ResultSet rs) throws SQLException {
        LoanDraft entity = new LoanDraft();
        entity.setDraftId(rs.getString("draft_id"));
        String userRef = rs.getString("user_email");
        if (userRef != null) {
            AppUser user = new AppUser();
            user.setEmail(userRef);
            entity.setUser(user);
        }
        entity.setCurrentStep(rs.getObject("current_step") == null ? null : rs.getInt("current_step"));
        entity.setSavedAt(rs.getObject("saved_at", OffsetDateTime.class));
        entity.setLoanType(rs.getString("loan_type"));
        entity.setLoanAmount(rs.getBigDecimal("loan_amount"));
        entity.setTenureYears(rs.getObject("tenure_years") == null ? null : rs.getInt("tenure_years"));
        entity.setFormData(rs.getString("form_data"));
        return entity;
    }
}
