package hlms.daoimpl;

import hlms.dao.LoanProductDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;

/**
 * JDBC implementation of LoanProductDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class LoanProductDAOImpl implements LoanProductDAO {

    private static final String INSERT_SQL =
            "INSERT INTO loan_product (product_id, name, category, interest_rate, max_tenure_years, max_ltv, description) VALUES (?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE loan_product SET name = ?, category = ?, interest_rate = ?, max_tenure_years = ?, max_ltv = ?, description = ? WHERE product_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM loan_product WHERE product_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM loan_product WHERE product_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM loan_product";

    @Override
    public LoanProduct insert(LoanProduct entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getProductId());
            ps.setObject(2, entity.getName());
            ps.setObject(3, entity.getCategory());
            ps.setObject(4, entity.getInterestRate());
            ps.setObject(5, entity.getMaxTenureYears());
            ps.setObject(6, entity.getMaxLtv());
            ps.setObject(7, entity.getDescription());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert LoanProduct: " + e.getMessage(), e);
        }
    }

    @Override
    public LoanProduct update(LoanProduct entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getName());
            ps.setObject(2, entity.getCategory());
            ps.setObject(3, entity.getInterestRate());
            ps.setObject(4, entity.getMaxTenureYears());
            ps.setObject(5, entity.getMaxLtv());
            ps.setObject(6, entity.getDescription());
            ps.setObject(7, entity.getProductId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No LoanProduct found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update LoanProduct: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String productId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, productId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete LoanProduct: " + e.getMessage(), e);
        }
    }

    @Override
    public LoanProduct findById(String productId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, productId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LoanProduct: " + e.getMessage(), e);
        }
    }

    @Override
    public List<LoanProduct> findAll() throws DAOException {
        List<LoanProduct> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch LoanProduct list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a LoanProduct. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private LoanProduct mapRow(ResultSet rs) throws SQLException {
        LoanProduct entity = new LoanProduct();
        entity.setProductId(rs.getString("product_id"));
        entity.setName(rs.getString("name"));
        entity.setCategory(rs.getString("category"));
        entity.setInterestRate(rs.getBigDecimal("interest_rate"));
        entity.setMaxTenureYears(rs.getObject("max_tenure_years") == null ? null : rs.getInt("max_tenure_years"));
        entity.setMaxLtv(rs.getString("max_ltv"));
        entity.setDescription(rs.getString("description"));
        return entity;
    }
}
