package hlms.daoimpl;

import hlms.dao.NotificationDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of NotificationDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class NotificationDAOImpl implements NotificationDAO {

    private static final String INSERT_SQL =
            "INSERT INTO notification (notification_id, user_email, title, body, channels, is_read, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE notification SET user_email = ?, title = ?, body = ?, channels = ?, is_read = ?, created_at = ? WHERE notification_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM notification WHERE notification_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM notification WHERE notification_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM notification";

    @Override
    public Notification insert(Notification entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getNotificationId());
            ps.setObject(2, entity.getUser() == null ? null : entity.getUser().getEmail());
            ps.setObject(3, entity.getTitle());
            ps.setObject(4, entity.getBody());
            ps.setArray(5, entity.getChannels() == null ? null : conn.createArrayOf("text", entity.getChannels()));
            ps.setObject(6, entity.getIsRead());
            ps.setObject(7, entity.getCreatedAt());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert Notification: " + e.getMessage(), e);
        }
    }

    @Override
    public Notification update(Notification entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getUser() == null ? null : entity.getUser().getEmail());
            ps.setObject(2, entity.getTitle());
            ps.setObject(3, entity.getBody());
            ps.setArray(4, entity.getChannels() == null ? null : conn.createArrayOf("text", entity.getChannels()));
            ps.setObject(5, entity.getIsRead());
            ps.setObject(6, entity.getCreatedAt());
            ps.setObject(7, entity.getNotificationId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No Notification found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update Notification: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String notificationId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, notificationId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete Notification: " + e.getMessage(), e);
        }
    }

    @Override
    public Notification findById(String notificationId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, notificationId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch Notification: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Notification> findAll() throws DAOException {
        List<Notification> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch Notification list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a Notification. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private Notification mapRow(ResultSet rs) throws SQLException {
        Notification entity = new Notification();
        entity.setNotificationId(rs.getString("notification_id"));
        String userRef = rs.getString("user_email");
        if (userRef != null) {
            AppUser user = new AppUser();
            user.setEmail(userRef);
            entity.setUser(user);
        }
        entity.setTitle(rs.getString("title"));
        entity.setBody(rs.getString("body"));
        Array channelsArr = rs.getArray("channels");
        if (channelsArr != null) {
            entity.setChannels((String[]) channelsArr.getArray());
        }
        Object isReadVal = rs.getObject("is_read");
        entity.setIsRead(isReadVal == null ? null : (Boolean) isReadVal);
        entity.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        return entity;
    }
}
