package hlms.daoimpl;

import hlms.dao.PostDisbursementDocumentDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of PostDisbursementDocumentDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class PostDisbursementDocumentDAOImpl implements PostDisbursementDocumentDAO {

    private static final String INSERT_SQL =
            "INSERT INTO post_disbursement_document (pd_doc_id, app_id, doc_type, file_name, file_size, note, status, uploaded_at, verified_by, verified_at, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE post_disbursement_document SET app_id = ?, doc_type = ?, file_name = ?, file_size = ?, note = ?, status = ?, uploaded_at = ?, verified_by = ?, verified_at = ?, remarks = ? WHERE pd_doc_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM post_disbursement_document WHERE pd_doc_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM post_disbursement_document WHERE pd_doc_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM post_disbursement_document";

    @Override
    public PostDisbursementDocument insert(PostDisbursementDocument entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getPdDocId());
            ps.setObject(2, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(3, entity.getDocType());
            ps.setObject(4, entity.getFileName());
            ps.setObject(5, entity.getFileSize());
            ps.setObject(6, entity.getNote());
            ps.setObject(7, entity.getStatus());
            ps.setObject(8, entity.getUploadedAt());
            ps.setObject(9, entity.getVerifiedBy() == null ? null : entity.getVerifiedBy().getEmail());
            ps.setObject(10, entity.getVerifiedAt());
            ps.setObject(11, entity.getRemarks());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert PostDisbursementDocument: " + e.getMessage(), e);
        }
    }

    @Override
    public PostDisbursementDocument update(PostDisbursementDocument entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(2, entity.getDocType());
            ps.setObject(3, entity.getFileName());
            ps.setObject(4, entity.getFileSize());
            ps.setObject(5, entity.getNote());
            ps.setObject(6, entity.getStatus());
            ps.setObject(7, entity.getUploadedAt());
            ps.setObject(8, entity.getVerifiedBy() == null ? null : entity.getVerifiedBy().getEmail());
            ps.setObject(9, entity.getVerifiedAt());
            ps.setObject(10, entity.getRemarks());
            ps.setObject(11, entity.getPdDocId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No PostDisbursementDocument found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update PostDisbursementDocument: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String pdDocId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, pdDocId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete PostDisbursementDocument: " + e.getMessage(), e);
        }
    }

    @Override
    public PostDisbursementDocument findById(String pdDocId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, pdDocId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch PostDisbursementDocument: " + e.getMessage(), e);
        }
    }

    @Override
    public List<PostDisbursementDocument> findAll() throws DAOException {
        List<PostDisbursementDocument> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch PostDisbursementDocument list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a PostDisbursementDocument. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private PostDisbursementDocument mapRow(ResultSet rs) throws SQLException {
        PostDisbursementDocument entity = new PostDisbursementDocument();
        entity.setPdDocId(rs.getString("pd_doc_id"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        entity.setDocType(rs.getString("doc_type"));
        entity.setFileName(rs.getString("file_name"));
        entity.setFileSize(rs.getObject("file_size") == null ? null : rs.getInt("file_size"));
        entity.setNote(rs.getString("note"));
        entity.setStatus(rs.getString("status"));
        entity.setUploadedAt(rs.getObject("uploaded_at", OffsetDateTime.class));
        String verifiedByRef = rs.getString("verified_by");
        if (verifiedByRef != null) {
            AppUser verifiedBy = new AppUser();
            verifiedBy.setEmail(verifiedByRef);
            entity.setVerifiedBy(verifiedBy);
        }
        entity.setVerifiedAt(rs.getObject("verified_at", OffsetDateTime.class));
        entity.setRemarks(rs.getString("remarks"));
        return entity;
    }
}
