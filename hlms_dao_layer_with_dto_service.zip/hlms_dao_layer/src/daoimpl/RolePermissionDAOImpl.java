package hlms.daoimpl;

import hlms.dao.RolePermissionDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation of RolePermissionDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class RolePermissionDAOImpl implements RolePermissionDAO {

    private static final String INSERT_SQL =
            "INSERT INTO role_permission (role, module, can_view, can_add, can_edit, can_delete) VALUES (?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE role_permission SET can_view = ?, can_add = ?, can_edit = ?, can_delete = ? WHERE role = ? AND module = ?";

    private static final String DELETE_SQL =
            "DELETE FROM role_permission WHERE role = ? AND module = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM role_permission WHERE role = ? AND module = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM role_permission";

    @Override
    public RolePermission insert(RolePermission entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getRole());
            ps.setObject(2, entity.getModule());
            ps.setObject(3, entity.getCanView());
            ps.setObject(4, entity.getCanAdd());
            ps.setObject(5, entity.getCanEdit());
            ps.setObject(6, entity.getCanDelete());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert RolePermission: " + e.getMessage(), e);
        }
    }

    @Override
    public RolePermission update(RolePermission entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getCanView());
            ps.setObject(2, entity.getCanAdd());
            ps.setObject(3, entity.getCanEdit());
            ps.setObject(4, entity.getCanDelete());
            ps.setObject(5, entity.getRole());
            ps.setObject(6, entity.getModule());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No RolePermission found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update RolePermission: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String role, String module) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, role);
            ps.setObject(2, module);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete RolePermission: " + e.getMessage(), e);
        }
    }

    @Override
    public RolePermission findById(String role, String module) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, role);
            ps.setObject(2, module);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch RolePermission: " + e.getMessage(), e);
        }
    }

    @Override
    public List<RolePermission> findAll() throws DAOException {
        List<RolePermission> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch RolePermission list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a RolePermission. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private RolePermission mapRow(ResultSet rs) throws SQLException {
        RolePermission entity = new RolePermission();
        entity.setRole(rs.getString("role"));
        entity.setModule(rs.getString("module"));
        Object canViewVal = rs.getObject("can_view");
        entity.setCanView(canViewVal == null ? null : (Boolean) canViewVal);
        Object canAddVal = rs.getObject("can_add");
        entity.setCanAdd(canAddVal == null ? null : (Boolean) canAddVal);
        Object canEditVal = rs.getObject("can_edit");
        entity.setCanEdit(canEditVal == null ? null : (Boolean) canEditVal);
        Object canDeleteVal = rs.getObject("can_delete");
        entity.setCanDelete(canDeleteVal == null ? null : (Boolean) canDeleteVal);
        return entity;
    }
}
