package hlms.daoimpl;

import hlms.dao.ServiceRequestDAO;
import hlms.entity.*;
import hlms.util.DAOException;
import hlms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.OffsetDateTime;

/**
 * JDBC implementation of ServiceRequestDAO for PostgreSQL.
 * All SQLExceptions are caught here and re-thrown as {@link DAOException}
 * so calling code never has to deal with java.sql.SQLException directly.
 */
public class ServiceRequestDAOImpl implements ServiceRequestDAO {

    private static final String INSERT_SQL =
            "INSERT INTO service_request (request_id, ref_no, app_id, user_email, request_type, description, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE service_request SET ref_no = ?, app_id = ?, user_email = ?, request_type = ?, description = ?, status = ?, created_at = ? WHERE request_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM service_request WHERE request_id = ?";

    private static final String FIND_BY_ID_SQL =
            "SELECT * FROM service_request WHERE request_id = ?";

    private static final String FIND_ALL_SQL =
            "SELECT * FROM service_request";

    @Override
    public ServiceRequest insert(ServiceRequest entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setObject(1, entity.getRequestId());
            ps.setObject(2, entity.getRefNo());
            ps.setObject(3, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(4, entity.getUser() == null ? null : entity.getUser().getEmail());
            ps.setObject(5, entity.getRequestType());
            ps.setObject(6, entity.getDescription());
            ps.setObject(7, entity.getStatus());
            ps.setObject(8, entity.getCreatedAt());

            ps.executeUpdate();
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to insert ServiceRequest: " + e.getMessage(), e);
        }
    }

    @Override
    public ServiceRequest update(ServiceRequest entity) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setObject(1, entity.getRefNo());
            ps.setObject(2, entity.getApplication() == null ? null : entity.getApplication().getAppId());
            ps.setObject(3, entity.getUser() == null ? null : entity.getUser().getEmail());
            ps.setObject(4, entity.getRequestType());
            ps.setObject(5, entity.getDescription());
            ps.setObject(6, entity.getStatus());
            ps.setObject(7, entity.getCreatedAt());
            ps.setObject(8, entity.getRequestId());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new DAOException("No ServiceRequest found to update for given id");
            }
            return entity;
        } catch (SQLException e) {
            throw new DAOException("Failed to update ServiceRequest: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean delete(String requestId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setObject(1, requestId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Failed to delete ServiceRequest: " + e.getMessage(), e);
        }
    }

    @Override
    public ServiceRequest findById(String requestId) throws DAOException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_BY_ID_SQL)) {

            ps.setObject(1, requestId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch ServiceRequest: " + e.getMessage(), e);
        }
    }

    @Override
    public List<ServiceRequest> findAll() throws DAOException {
        List<ServiceRequest> result = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                result.add(mapRow(rs));
            }
            return result;
        } catch (SQLException e) {
            throw new DAOException("Failed to fetch ServiceRequest list: " + e.getMessage(), e);
        }
    }

    /**
     * Maps one ResultSet row to a ServiceRequest. Foreign-key fields are hydrated
     * as lightweight reference objects (primary key only) to avoid extra
     * joins here -- use the corresponding DAO's findById(...) if the full
     * related object graph is needed.
     */
    private ServiceRequest mapRow(ResultSet rs) throws SQLException {
        ServiceRequest entity = new ServiceRequest();
        entity.setRequestId(rs.getString("request_id"));
        entity.setRefNo(rs.getString("ref_no"));
        String applicationRef = rs.getString("app_id");
        if (applicationRef != null) {
            LoanApplication application = new LoanApplication();
            application.setAppId(applicationRef);
            entity.setApplication(application);
        }
        String userRef = rs.getString("user_email");
        if (userRef != null) {
            AppUser user = new AppUser();
            user.setEmail(userRef);
            entity.setUser(user);
        }
        entity.setRequestType(rs.getString("request_type"));
        entity.setDescription(rs.getString("description"));
        entity.setStatus(rs.getString("status"));
        entity.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        return entity;
    }
}
