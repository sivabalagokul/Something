package hlms.dto;

import java.time.OffsetDateTime;

/**
 * Data Transfer Object for ApplicationDocument ('application_document').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class ApplicationDocumentDTO {

    private String documentId;
    private String appId;
    private String docType;
    private String fileName;
    private Integer fileSize;
    private OffsetDateTime uploadedAt;
    private String verificationStatus;
    private String verifiedByEmail;
    private OffsetDateTime verifiedAt;
    private String remarks;

    public ApplicationDocumentDTO() {
    }

    public ApplicationDocumentDTO(
            String documentId,
            String appId,
            String docType,
            String fileName,
            Integer fileSize,
            OffsetDateTime uploadedAt,
            String verificationStatus,
            String verifiedByEmail,
            OffsetDateTime verifiedAt,
            String remarks) {

        this.documentId = documentId;
        this.appId = appId;
        this.docType = docType;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.uploadedAt = uploadedAt;
        this.verificationStatus = verificationStatus;
        this.verifiedByEmail = verifiedByEmail;
        this.verifiedAt = verifiedAt;
        this.remarks = remarks;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Integer getFileSize() {
        return fileSize;
    }

    public void setFileSize(Integer fileSize) {
        this.fileSize = fileSize;
    }

    public OffsetDateTime getUploadedAt() {
        return uploadedAt;
    }

    public void setUploadedAt(OffsetDateTime uploadedAt) {
        this.uploadedAt = uploadedAt;
    }

    public String getVerificationStatus() {
        return verificationStatus;
    }

    public void setVerificationStatus(String verificationStatus) {
        this.verificationStatus = verificationStatus;
    }

    public String getVerifiedByEmail() {
        return verifiedByEmail;
    }

    public void setVerifiedByEmail(String verifiedByEmail) {
        this.verifiedByEmail = verifiedByEmail;
    }

    public OffsetDateTime getVerifiedAt() {
        return verifiedAt;
    }

    public void setVerifiedAt(OffsetDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "ApplicationDocumentDTO{" + "documentId=" + documentId + ", " + "appId=" + appId + ", " + "docType=" + docType + ", " + "fileName=" + fileName + ", " + "fileSize=" + fileSize + ", " + "uploadedAt=" + uploadedAt + ", " + "verificationStatus=" + verificationStatus + ", " + "verifiedByEmail=" + verifiedByEmail + ", " + "verifiedAt=" + verifiedAt + ", " + "remarks=" + remarks + "}";
    }
}
