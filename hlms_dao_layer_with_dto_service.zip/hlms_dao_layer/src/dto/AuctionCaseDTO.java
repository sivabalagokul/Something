package hlms.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Data Transfer Object for AuctionCase ('auction_case').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class AuctionCaseDTO {

    private String appId;
    private String stage;
    private LocalDate noticeDate;
    private LocalDate noticeDueDate;
    private BigDecimal demandAmount;
    private LocalDate possessionDate;
    private LocalDate auctionDate;
    private BigDecimal reservePrice;

    public AuctionCaseDTO() {
    }

    public AuctionCaseDTO(
            String appId,
            String stage,
            LocalDate noticeDate,
            LocalDate noticeDueDate,
            BigDecimal demandAmount,
            LocalDate possessionDate,
            LocalDate auctionDate,
            BigDecimal reservePrice) {

        this.appId = appId;
        this.stage = stage;
        this.noticeDate = noticeDate;
        this.noticeDueDate = noticeDueDate;
        this.demandAmount = demandAmount;
        this.possessionDate = possessionDate;
        this.auctionDate = auctionDate;
        this.reservePrice = reservePrice;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public LocalDate getNoticeDate() {
        return noticeDate;
    }

    public void setNoticeDate(LocalDate noticeDate) {
        this.noticeDate = noticeDate;
    }

    public LocalDate getNoticeDueDate() {
        return noticeDueDate;
    }

    public void setNoticeDueDate(LocalDate noticeDueDate) {
        this.noticeDueDate = noticeDueDate;
    }

    public BigDecimal getDemandAmount() {
        return demandAmount;
    }

    public void setDemandAmount(BigDecimal demandAmount) {
        this.demandAmount = demandAmount;
    }

    public LocalDate getPossessionDate() {
        return possessionDate;
    }

    public void setPossessionDate(LocalDate possessionDate) {
        this.possessionDate = possessionDate;
    }

    public LocalDate getAuctionDate() {
        return auctionDate;
    }

    public void setAuctionDate(LocalDate auctionDate) {
        this.auctionDate = auctionDate;
    }

    public BigDecimal getReservePrice() {
        return reservePrice;
    }

    public void setReservePrice(BigDecimal reservePrice) {
        this.reservePrice = reservePrice;
    }

    @Override
    public String toString() {
        return "AuctionCaseDTO{" + "appId=" + appId + ", " + "stage=" + stage + ", " + "noticeDate=" + noticeDate + ", " + "noticeDueDate=" + noticeDueDate + ", " + "demandAmount=" + demandAmount + ", " + "possessionDate=" + possessionDate + ", " + "auctionDate=" + auctionDate + ", " + "reservePrice=" + reservePrice + "}";
    }
}
