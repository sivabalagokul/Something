package hlms.dto;

import java.time.OffsetDateTime;

/**
 * Data Transfer Object for AuctionNote ('auction_note').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class AuctionNoteDTO {

    private String noteId;
    private String appId;
    private OffsetDateTime noteDate;
    private String noteText;

    public AuctionNoteDTO() {
    }

    public AuctionNoteDTO(
            String noteId,
            String appId,
            OffsetDateTime noteDate,
            String noteText) {

        this.noteId = noteId;
        this.appId = appId;
        this.noteDate = noteDate;
        this.noteText = noteText;
    }

    public String getNoteId() {
        return noteId;
    }

    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public OffsetDateTime getNoteDate() {
        return noteDate;
    }

    public void setNoteDate(OffsetDateTime noteDate) {
        this.noteDate = noteDate;
    }

    public String getNoteText() {
        return noteText;
    }

    public void setNoteText(String noteText) {
        this.noteText = noteText;
    }

    @Override
    public String toString() {
        return "AuctionNoteDTO{" + "noteId=" + noteId + ", " + "appId=" + appId + ", " + "noteDate=" + noteDate + ", " + "noteText=" + noteText + "}";
    }
}
