package hlms.dto;

import java.time.OffsetDateTime;

/**
 * Data Transfer Object for AuditLog ('audit_log').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class AuditLogDTO {

    private Long logId;
    private String entityType;
    private String entityId;
    private String action;
    private String actorEmail;
    private String beforeData;
    private String afterData;
    private OffsetDateTime createdAt;

    public AuditLogDTO() {
    }

    public AuditLogDTO(
            Long logId,
            String entityType,
            String entityId,
            String action,
            String actorEmail,
            String beforeData,
            String afterData,
            OffsetDateTime createdAt) {

        this.logId = logId;
        this.entityType = entityType;
        this.entityId = entityId;
        this.action = action;
        this.actorEmail = actorEmail;
        this.beforeData = beforeData;
        this.afterData = afterData;
        this.createdAt = createdAt;
    }

    public Long getLogId() {
        return logId;
    }

    public void setLogId(Long logId) {
        this.logId = logId;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getActorEmail() {
        return actorEmail;
    }

    public void setActorEmail(String actorEmail) {
        this.actorEmail = actorEmail;
    }

    public String getBeforeData() {
        return beforeData;
    }

    public void setBeforeData(String beforeData) {
        this.beforeData = beforeData;
    }

    public String getAfterData() {
        return afterData;
    }

    public void setAfterData(String afterData) {
        this.afterData = afterData;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "AuditLogDTO{" + "logId=" + logId + ", " + "entityType=" + entityType + ", " + "entityId=" + entityId + ", " + "action=" + action + ", " + "actorEmail=" + actorEmail + ", " + "beforeData=" + beforeData + ", " + "afterData=" + afterData + ", " + "createdAt=" + createdAt + "}";
    }
}
