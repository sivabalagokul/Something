package hlms.dto;

import java.time.OffsetDateTime;

/**
 * Data Transfer Object for BankOfficeDecision ('bank_office_decision').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class BankOfficeDecisionDTO {

    private String appId;
    private String decision;
    private String officerEmail;
    private OffsetDateTime decisionDate;
    private String reason;
    private String remarks;

    public BankOfficeDecisionDTO() {
    }

    public BankOfficeDecisionDTO(
            String appId,
            String decision,
            String officerEmail,
            OffsetDateTime decisionDate,
            String reason,
            String remarks) {

        this.appId = appId;
        this.decision = decision;
        this.officerEmail = officerEmail;
        this.decisionDate = decisionDate;
        this.reason = reason;
        this.remarks = remarks;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public String getOfficerEmail() {
        return officerEmail;
    }

    public void setOfficerEmail(String officerEmail) {
        this.officerEmail = officerEmail;
    }

    public OffsetDateTime getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(OffsetDateTime decisionDate) {
        this.decisionDate = decisionDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "BankOfficeDecisionDTO{" + "appId=" + appId + ", " + "decision=" + decision + ", " + "officerEmail=" + officerEmail + ", " + "decisionDate=" + decisionDate + ", " + "reason=" + reason + ", " + "remarks=" + remarks + "}";
    }
}
