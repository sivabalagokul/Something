package hlms.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Data Transfer Object for Bid ('bid').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class BidDTO {

    private String bidId;
    private String appId;
    private String bidderEmail;
    private BigDecimal bidAmount;
    private OffsetDateTime createdAt;

    public BidDTO() {
    }

    public BidDTO(
            String bidId,
            String appId,
            String bidderEmail,
            BigDecimal bidAmount,
            OffsetDateTime createdAt) {

        this.bidId = bidId;
        this.appId = appId;
        this.bidderEmail = bidderEmail;
        this.bidAmount = bidAmount;
        this.createdAt = createdAt;
    }

    public String getBidId() {
        return bidId;
    }

    public void setBidId(String bidId) {
        this.bidId = bidId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getBidderEmail() {
        return bidderEmail;
    }

    public void setBidderEmail(String bidderEmail) {
        this.bidderEmail = bidderEmail;
    }

    public BigDecimal getBidAmount() {
        return bidAmount;
    }

    public void setBidAmount(BigDecimal bidAmount) {
        this.bidAmount = bidAmount;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "BidDTO{" + "bidId=" + bidId + ", " + "appId=" + appId + ", " + "bidderEmail=" + bidderEmail + ", " + "bidAmount=" + bidAmount + ", " + "createdAt=" + createdAt + "}";
    }
}
