package hlms.dto;

import java.math.BigDecimal;

/**
 * Data Transfer Object for CustomerEmploymentProfile ('customer_employment_profile').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class CustomerEmploymentProfileDTO {

    private String userEmail;
    private String employmentType;
    private String employer;
    private BigDecimal monthlyIncome;
    private BigDecimal otherEmis;
    private BigDecimal desiredAmount;
    private String pan;

    public CustomerEmploymentProfileDTO() {
    }

    public CustomerEmploymentProfileDTO(
            String userEmail,
            String employmentType,
            String employer,
            BigDecimal monthlyIncome,
            BigDecimal otherEmis,
            BigDecimal desiredAmount,
            String pan) {

        this.userEmail = userEmail;
        this.employmentType = employmentType;
        this.employer = employer;
        this.monthlyIncome = monthlyIncome;
        this.otherEmis = otherEmis;
        this.desiredAmount = desiredAmount;
        this.pan = pan;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    public String getEmployer() {
        return employer;
    }

    public void setEmployer(String employer) {
        this.employer = employer;
    }

    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public BigDecimal getOtherEmis() {
        return otherEmis;
    }

    public void setOtherEmis(BigDecimal otherEmis) {
        this.otherEmis = otherEmis;
    }

    public BigDecimal getDesiredAmount() {
        return desiredAmount;
    }

    public void setDesiredAmount(BigDecimal desiredAmount) {
        this.desiredAmount = desiredAmount;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    @Override
    public String toString() {
        return "CustomerEmploymentProfileDTO{" + "userEmail=" + userEmail + ", " + "employmentType=" + employmentType + ", " + "employer=" + employer + ", " + "monthlyIncome=" + monthlyIncome + ", " + "otherEmis=" + otherEmis + ", " + "desiredAmount=" + desiredAmount + ", " + "pan=" + pan + "}";
    }
}
