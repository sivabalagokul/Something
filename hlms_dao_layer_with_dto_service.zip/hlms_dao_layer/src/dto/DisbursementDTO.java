package hlms.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Data Transfer Object for Disbursement ('disbursement').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class DisbursementDTO {

    private String appId;
    private OffsetDateTime disbursedDate;
    private BigDecimal amount;
    private String refNo;
    private String mode;
    private String bankDetails;

    public DisbursementDTO() {
    }

    public DisbursementDTO(
            String appId,
            OffsetDateTime disbursedDate,
            BigDecimal amount,
            String refNo,
            String mode,
            String bankDetails) {

        this.appId = appId;
        this.disbursedDate = disbursedDate;
        this.amount = amount;
        this.refNo = refNo;
        this.mode = mode;
        this.bankDetails = bankDetails;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public OffsetDateTime getDisbursedDate() {
        return disbursedDate;
    }

    public void setDisbursedDate(OffsetDateTime disbursedDate) {
        this.disbursedDate = disbursedDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getRefNo() {
        return refNo;
    }

    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getBankDetails() {
        return bankDetails;
    }

    public void setBankDetails(String bankDetails) {
        this.bankDetails = bankDetails;
    }

    @Override
    public String toString() {
        return "DisbursementDTO{" + "appId=" + appId + ", " + "disbursedDate=" + disbursedDate + ", " + "amount=" + amount + ", " + "refNo=" + refNo + ", " + "mode=" + mode + ", " + "bankDetails=" + bankDetails + "}";
    }
}
