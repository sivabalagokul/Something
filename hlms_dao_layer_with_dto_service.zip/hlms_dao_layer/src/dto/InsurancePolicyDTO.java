package hlms.dto;

import java.time.LocalDate;

/**
 * Data Transfer Object for InsurancePolicy ('insurance_policy').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class InsurancePolicyDTO {

    private String policyId;
    private String appId;
    private String policyType;
    private String status;
    private LocalDate validTill;

    public InsurancePolicyDTO() {
    }

    public InsurancePolicyDTO(
            String policyId,
            String appId,
            String policyType,
            String status,
            LocalDate validTill) {

        this.policyId = policyId;
        this.appId = appId;
        this.policyType = policyType;
        this.status = status;
        this.validTill = validTill;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getPolicyType() {
        return policyType;
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getValidTill() {
        return validTill;
    }

    public void setValidTill(LocalDate validTill) {
        this.validTill = validTill;
    }

    @Override
    public String toString() {
        return "InsurancePolicyDTO{" + "policyId=" + policyId + ", " + "appId=" + appId + ", " + "policyType=" + policyType + ", " + "status=" + status + ", " + "validTill=" + validTill + "}";
    }
}
