package hlms.dto;

/**
 * Data Transfer Object for LegalChecklistItem ('legal_checklist_item').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class LegalChecklistItemDTO {

    private String checklistItemId;
    private String appId;
    private String checklistKey;
    private String status;

    public LegalChecklistItemDTO() {
    }

    public LegalChecklistItemDTO(
            String checklistItemId,
            String appId,
            String checklistKey,
            String status) {

        this.checklistItemId = checklistItemId;
        this.appId = appId;
        this.checklistKey = checklistKey;
        this.status = status;
    }

    public String getChecklistItemId() {
        return checklistItemId;
    }

    public void setChecklistItemId(String checklistItemId) {
        this.checklistItemId = checklistItemId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getChecklistKey() {
        return checklistKey;
    }

    public void setChecklistKey(String checklistKey) {
        this.checklistKey = checklistKey;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "LegalChecklistItemDTO{" + "checklistItemId=" + checklistItemId + ", " + "appId=" + appId + ", " + "checklistKey=" + checklistKey + ", " + "status=" + status + "}";
    }
}
