package hlms.dto;

import java.time.LocalDate;

/**
 * Data Transfer Object for LegalNotice ('legal_notice').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class LegalNoticeDTO {

    private String noticeId;
    private String noticeNo;
    private String appId;
    private String noticeType;
    private LocalDate issueDate;
    private LocalDate dueDate;
    private String status;
    private String officerEmail;
    private String content;

    public LegalNoticeDTO() {
    }

    public LegalNoticeDTO(
            String noticeId,
            String noticeNo,
            String appId,
            String noticeType,
            LocalDate issueDate,
            LocalDate dueDate,
            String status,
            String officerEmail,
            String content) {

        this.noticeId = noticeId;
        this.noticeNo = noticeNo;
        this.appId = appId;
        this.noticeType = noticeType;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.status = status;
        this.officerEmail = officerEmail;
        this.content = content;
    }

    public String getNoticeId() {
        return noticeId;
    }

    public void setNoticeId(String noticeId) {
        this.noticeId = noticeId;
    }

    public String getNoticeNo() {
        return noticeNo;
    }

    public void setNoticeNo(String noticeNo) {
        this.noticeNo = noticeNo;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getNoticeType() {
        return noticeType;
    }

    public void setNoticeType(String noticeType) {
        this.noticeType = noticeType;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOfficerEmail() {
        return officerEmail;
    }

    public void setOfficerEmail(String officerEmail) {
        this.officerEmail = officerEmail;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "LegalNoticeDTO{" + "noticeId=" + noticeId + ", " + "noticeNo=" + noticeNo + ", " + "appId=" + appId + ", " + "noticeType=" + noticeType + ", " + "issueDate=" + issueDate + ", " + "dueDate=" + dueDate + ", " + "status=" + status + ", " + "officerEmail=" + officerEmail + ", " + "content=" + content + "}";
    }
}
