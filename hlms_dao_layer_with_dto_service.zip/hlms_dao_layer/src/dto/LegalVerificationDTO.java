package hlms.dto;

import java.time.OffsetDateTime;

/**
 * Data Transfer Object for LegalVerification ('legal_verification').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class LegalVerificationDTO {

    private String appId;
    private String decision;
    private OffsetDateTime decisionDate;
    private String officerEmail;
    private String remarks;

    public LegalVerificationDTO() {
    }

    public LegalVerificationDTO(
            String appId,
            String decision,
            OffsetDateTime decisionDate,
            String officerEmail,
            String remarks) {

        this.appId = appId;
        this.decision = decision;
        this.decisionDate = decisionDate;
        this.officerEmail = officerEmail;
        this.remarks = remarks;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public OffsetDateTime getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(OffsetDateTime decisionDate) {
        this.decisionDate = decisionDate;
    }

    public String getOfficerEmail() {
        return officerEmail;
    }

    public void setOfficerEmail(String officerEmail) {
        this.officerEmail = officerEmail;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "LegalVerificationDTO{" + "appId=" + appId + ", " + "decision=" + decision + ", " + "decisionDate=" + decisionDate + ", " + "officerEmail=" + officerEmail + ", " + "remarks=" + remarks + "}";
    }
}
