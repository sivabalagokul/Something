package hlms.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Data Transfer Object for LoanDraft ('loan_draft').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class LoanDraftDTO {

    private String draftId;
    private String userEmail;
    private Integer currentStep;
    private OffsetDateTime savedAt;
    private String loanType;
    private BigDecimal loanAmount;
    private Integer tenureYears;
    private String formData;

    public LoanDraftDTO() {
    }

    public LoanDraftDTO(
            String draftId,
            String userEmail,
            Integer currentStep,
            OffsetDateTime savedAt,
            String loanType,
            BigDecimal loanAmount,
            Integer tenureYears,
            String formData) {

        this.draftId = draftId;
        this.userEmail = userEmail;
        this.currentStep = currentStep;
        this.savedAt = savedAt;
        this.loanType = loanType;
        this.loanAmount = loanAmount;
        this.tenureYears = tenureYears;
        this.formData = formData;
    }

    public String getDraftId() {
        return draftId;
    }

    public void setDraftId(String draftId) {
        this.draftId = draftId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Integer getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(Integer currentStep) {
        this.currentStep = currentStep;
    }

    public OffsetDateTime getSavedAt() {
        return savedAt;
    }

    public void setSavedAt(OffsetDateTime savedAt) {
        this.savedAt = savedAt;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    public Integer getTenureYears() {
        return tenureYears;
    }

    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }

    public String getFormData() {
        return formData;
    }

    public void setFormData(String formData) {
        this.formData = formData;
    }

    @Override
    public String toString() {
        return "LoanDraftDTO{" + "draftId=" + draftId + ", " + "userEmail=" + userEmail + ", " + "currentStep=" + currentStep + ", " + "savedAt=" + savedAt + ", " + "loanType=" + loanType + ", " + "loanAmount=" + loanAmount + ", " + "tenureYears=" + tenureYears + ", " + "formData=" + formData + "}";
    }
}
