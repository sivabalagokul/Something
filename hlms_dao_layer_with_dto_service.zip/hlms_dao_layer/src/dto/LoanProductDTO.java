package hlms.dto;

import java.math.BigDecimal;

/**
 * Data Transfer Object for LoanProduct ('loan_product').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class LoanProductDTO {

    private String productId;
    private String name;
    private String category;
    private BigDecimal interestRate;
    private Integer maxTenureYears;
    private String maxLtv;
    private String description;

    public LoanProductDTO() {
    }

    public LoanProductDTO(
            String productId,
            String name,
            String category,
            BigDecimal interestRate,
            Integer maxTenureYears,
            String maxLtv,
            String description) {

        this.productId = productId;
        this.name = name;
        this.category = category;
        this.interestRate = interestRate;
        this.maxTenureYears = maxTenureYears;
        this.maxLtv = maxLtv;
        this.description = description;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public Integer getMaxTenureYears() {
        return maxTenureYears;
    }

    public void setMaxTenureYears(Integer maxTenureYears) {
        this.maxTenureYears = maxTenureYears;
    }

    public String getMaxLtv() {
        return maxLtv;
    }

    public void setMaxLtv(String maxLtv) {
        this.maxLtv = maxLtv;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "LoanProductDTO{" + "productId=" + productId + ", " + "name=" + name + ", " + "category=" + category + ", " + "interestRate=" + interestRate + ", " + "maxTenureYears=" + maxTenureYears + ", " + "maxLtv=" + maxLtv + ", " + "description=" + description + "}";
    }
}
