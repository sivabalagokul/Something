package hlms.dto;

import java.time.OffsetDateTime;

/**
 * Data Transfer Object for Notification ('notification').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class NotificationDTO {

    private String notificationId;
    private String userEmail;
    private String title;
    private String body;
    private String[] channels;
    private Boolean isRead;
    private OffsetDateTime createdAt;

    public NotificationDTO() {
    }

    public NotificationDTO(
            String notificationId,
            String userEmail,
            String title,
            String body,
            String[] channels,
            Boolean isRead,
            OffsetDateTime createdAt) {

        this.notificationId = notificationId;
        this.userEmail = userEmail;
        this.title = title;
        this.body = body;
        this.channels = channels;
        this.isRead = isRead;
        this.createdAt = createdAt;
    }

    public String getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String[] getChannels() {
        return channels;
    }

    public void setChannels(String[] channels) {
        this.channels = channels;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "NotificationDTO{" + "notificationId=" + notificationId + ", " + "userEmail=" + userEmail + ", " + "title=" + title + ", " + "body=" + body + ", " + "channels=" + channels + ", " + "isRead=" + isRead + ", " + "createdAt=" + createdAt + "}";
    }
}
