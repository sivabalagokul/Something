package hlms.dto;

import java.time.OffsetDateTime;

/**
 * Data Transfer Object for PostDisbursementDocument ('post_disbursement_document').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class PostDisbursementDocumentDTO {

    private String pdDocId;
    private String appId;
    private String docType;
    private String fileName;
    private Integer fileSize;
    private String note;
    private String status;
    private OffsetDateTime uploadedAt;
    private String verifiedByEmail;
    private OffsetDateTime verifiedAt;
    private String remarks;

    public PostDisbursementDocumentDTO() {
    }

    public PostDisbursementDocumentDTO(
            String pdDocId,
            String appId,
            String docType,
            String fileName,
            Integer fileSize,
            String note,
            String status,
            OffsetDateTime uploadedAt,
            String verifiedByEmail,
            OffsetDateTime verifiedAt,
            String remarks) {

        this.pdDocId = pdDocId;
        this.appId = appId;
        this.docType = docType;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.note = note;
        this.status = status;
        this.uploadedAt = uploadedAt;
        this.verifiedByEmail = verifiedByEmail;
        this.verifiedAt = verifiedAt;
        this.remarks = remarks;
    }

    public String getPdDocId() {
        return pdDocId;
    }

    public void setPdDocId(String pdDocId) {
        this.pdDocId = pdDocId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Integer getFileSize() {
        return fileSize;
    }

    public void setFileSize(Integer fileSize) {
        this.fileSize = fileSize;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public OffsetDateTime getUploadedAt() {
        return uploadedAt;
    }

    public void setUploadedAt(OffsetDateTime uploadedAt) {
        this.uploadedAt = uploadedAt;
    }

    public String getVerifiedByEmail() {
        return verifiedByEmail;
    }

    public void setVerifiedByEmail(String verifiedByEmail) {
        this.verifiedByEmail = verifiedByEmail;
    }

    public OffsetDateTime getVerifiedAt() {
        return verifiedAt;
    }

    public void setVerifiedAt(OffsetDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "PostDisbursementDocumentDTO{" + "pdDocId=" + pdDocId + ", " + "appId=" + appId + ", " + "docType=" + docType + ", " + "fileName=" + fileName + ", " + "fileSize=" + fileSize + ", " + "note=" + note + ", " + "status=" + status + ", " + "uploadedAt=" + uploadedAt + ", " + "verifiedByEmail=" + verifiedByEmail + ", " + "verifiedAt=" + verifiedAt + ", " + "remarks=" + remarks + "}";
    }
}
