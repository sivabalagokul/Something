package hlms.dto;

/**
 * Data Transfer Object for RolePermission ('role_permission').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class RolePermissionDTO {

    private String role;
    private String module;
    private Boolean canView;
    private Boolean canAdd;
    private Boolean canEdit;
    private Boolean canDelete;

    public RolePermissionDTO() {
    }

    public RolePermissionDTO(
            String role,
            String module,
            Boolean canView,
            Boolean canAdd,
            Boolean canEdit,
            Boolean canDelete) {

        this.role = role;
        this.module = module;
        this.canView = canView;
        this.canAdd = canAdd;
        this.canEdit = canEdit;
        this.canDelete = canDelete;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public Boolean getCanView() {
        return canView;
    }

    public void setCanView(Boolean canView) {
        this.canView = canView;
    }

    public Boolean getCanAdd() {
        return canAdd;
    }

    public void setCanAdd(Boolean canAdd) {
        this.canAdd = canAdd;
    }

    public Boolean getCanEdit() {
        return canEdit;
    }

    public void setCanEdit(Boolean canEdit) {
        this.canEdit = canEdit;
    }

    public Boolean getCanDelete() {
        return canDelete;
    }

    public void setCanDelete(Boolean canDelete) {
        this.canDelete = canDelete;
    }

    @Override
    public String toString() {
        return "RolePermissionDTO{" + "role=" + role + ", " + "module=" + module + ", " + "canView=" + canView + ", " + "canAdd=" + canAdd + ", " + "canEdit=" + canEdit + ", " + "canDelete=" + canDelete + "}";
    }
}
