package hlms.dto;

import java.time.OffsetDateTime;

/**
 * Data Transfer Object for ServiceRequest ('service_request').
 * Foreign-key relations are flattened to the related row's id so callers
 * above the service layer (e.g. Main) never need to touch hlms.entity
 * classes directly.
 */
public class ServiceRequestDTO {

    private String requestId;
    private String refNo;
    private String appId;
    private String userEmail;
    private String requestType;
    private String description;
    private String status;
    private OffsetDateTime createdAt;

    public ServiceRequestDTO() {
    }

    public ServiceRequestDTO(
            String requestId,
            String refNo,
            String appId,
            String userEmail,
            String requestType,
            String description,
            String status,
            OffsetDateTime createdAt) {

        this.requestId = requestId;
        this.refNo = refNo;
        this.appId = appId;
        this.userEmail = userEmail;
        this.requestType = requestType;
        this.description = description;
        this.status = status;
        this.createdAt = createdAt;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRefNo() {
        return refNo;
    }

    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "ServiceRequestDTO{" + "requestId=" + requestId + ", " + "refNo=" + refNo + ", " + "appId=" + appId + ", " + "userEmail=" + userEmail + ", " + "requestType=" + requestType + ", " + "description=" + description + ", " + "status=" + status + ", " + "createdAt=" + createdAt + "}";
    }
}
