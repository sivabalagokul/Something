package hlms.entity;

import java.time.OffsetDateTime;

/**
 * Entity representing the 'app_user' table.
 */
public class AppUser {

    private String email;
    private String name;
    private String mobile;
    private String passwordHash;
    private String role;
    private Boolean active;
    private String idType;
    private String idNumber;
    private Boolean prefSms;
    private Boolean prefEmail;
    private Boolean prefInapp;
    private OffsetDateTime createdAt;

    public AppUser() {
    }

    public AppUser(
            String email,
            String name,
            String mobile,
            String passwordHash,
            String role,
            Boolean active,
            String idType,
            String idNumber,
            Boolean prefSms,
            Boolean prefEmail,
            Boolean prefInapp,
            OffsetDateTime createdAt) {

        this.email = email;
        this.name = name;
        this.mobile = mobile;
        this.passwordHash = passwordHash;
        this.role = role;
        this.active = active;
        this.idType = idType;
        this.idNumber = idNumber;
        this.prefSms = prefSms;
        this.prefEmail = prefEmail;
        this.prefInapp = prefInapp;
        this.createdAt = createdAt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public Boolean getPrefSms() {
        return prefSms;
    }

    public void setPrefSms(Boolean prefSms) {
        this.prefSms = prefSms;
    }

    public Boolean getPrefEmail() {
        return prefEmail;
    }

    public void setPrefEmail(Boolean prefEmail) {
        this.prefEmail = prefEmail;
    }

    public Boolean getPrefInapp() {
        return prefInapp;
    }

    public void setPrefInapp(Boolean prefInapp) {
        this.prefInapp = prefInapp;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "AppUser{" + "email=" + email + ", " + "name=" + name + ", " + "mobile=" + mobile + ", " + "passwordHash=" + passwordHash + ", " + "role=" + role + ", " + "active=" + active + ", " + "idType=" + idType + ", " + "idNumber=" + idNumber + ", " + "prefSms=" + prefSms + ", " + "prefEmail=" + prefEmail + ", " + "prefInapp=" + prefInapp + ", " + "createdAt=" + createdAt + "}";
    }
}
