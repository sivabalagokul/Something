package hlms.entity;

import java.time.OffsetDateTime;

/**
 * Entity representing the 'application_document' table.
 */
public class ApplicationDocument {

    private String documentId;
    private LoanApplication application;
    private String docType;
    private String fileName;
    private Integer fileSize;
    private OffsetDateTime uploadedAt;
    private String verificationStatus;
    private AppUser verifiedBy;
    private OffsetDateTime verifiedAt;
    private String remarks;

    public ApplicationDocument() {
    }

    public ApplicationDocument(
            String documentId,
            LoanApplication application,
            String docType,
            String fileName,
            Integer fileSize,
            OffsetDateTime uploadedAt,
            String verificationStatus,
            AppUser verifiedBy,
            OffsetDateTime verifiedAt,
            String remarks) {

        this.documentId = documentId;
        this.application = application;
        this.docType = docType;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.uploadedAt = uploadedAt;
        this.verificationStatus = verificationStatus;
        this.verifiedBy = verifiedBy;
        this.verifiedAt = verifiedAt;
        this.remarks = remarks;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Integer getFileSize() {
        return fileSize;
    }

    public void setFileSize(Integer fileSize) {
        this.fileSize = fileSize;
    }

    public OffsetDateTime getUploadedAt() {
        return uploadedAt;
    }

    public void setUploadedAt(OffsetDateTime uploadedAt) {
        this.uploadedAt = uploadedAt;
    }

    public String getVerificationStatus() {
        return verificationStatus;
    }

    public void setVerificationStatus(String verificationStatus) {
        this.verificationStatus = verificationStatus;
    }

    public AppUser getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(AppUser verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public OffsetDateTime getVerifiedAt() {
        return verifiedAt;
    }

    public void setVerifiedAt(OffsetDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "ApplicationDocument{" + "documentId=" + documentId + ", " + "application=" + application + ", " + "docType=" + docType + ", " + "fileName=" + fileName + ", " + "fileSize=" + fileSize + ", " + "uploadedAt=" + uploadedAt + ", " + "verificationStatus=" + verificationStatus + ", " + "verifiedBy=" + verifiedBy + ", " + "verifiedAt=" + verifiedAt + ", " + "remarks=" + remarks + "}";
    }
}
