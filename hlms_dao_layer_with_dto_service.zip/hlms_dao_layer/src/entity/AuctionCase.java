package hlms.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Entity representing the 'auction_case' table.
 */
public class AuctionCase {

    private String appId;
    private LoanApplication application;
    private String stage;
    private LocalDate noticeDate;
    private LocalDate noticeDueDate;
    private BigDecimal demandAmount;
    private LocalDate possessionDate;
    private LocalDate auctionDate;
    private BigDecimal reservePrice;

    public AuctionCase() {
    }

    public AuctionCase(
            String appId,
            LoanApplication application,
            String stage,
            LocalDate noticeDate,
            LocalDate noticeDueDate,
            BigDecimal demandAmount,
            LocalDate possessionDate,
            LocalDate auctionDate,
            BigDecimal reservePrice) {

        this.appId = appId;
        this.application = application;
        this.stage = stage;
        this.noticeDate = noticeDate;
        this.noticeDueDate = noticeDueDate;
        this.demandAmount = demandAmount;
        this.possessionDate = possessionDate;
        this.auctionDate = auctionDate;
        this.reservePrice = reservePrice;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public LocalDate getNoticeDate() {
        return noticeDate;
    }

    public void setNoticeDate(LocalDate noticeDate) {
        this.noticeDate = noticeDate;
    }

    public LocalDate getNoticeDueDate() {
        return noticeDueDate;
    }

    public void setNoticeDueDate(LocalDate noticeDueDate) {
        this.noticeDueDate = noticeDueDate;
    }

    public BigDecimal getDemandAmount() {
        return demandAmount;
    }

    public void setDemandAmount(BigDecimal demandAmount) {
        this.demandAmount = demandAmount;
    }

    public LocalDate getPossessionDate() {
        return possessionDate;
    }

    public void setPossessionDate(LocalDate possessionDate) {
        this.possessionDate = possessionDate;
    }

    public LocalDate getAuctionDate() {
        return auctionDate;
    }

    public void setAuctionDate(LocalDate auctionDate) {
        this.auctionDate = auctionDate;
    }

    public BigDecimal getReservePrice() {
        return reservePrice;
    }

    public void setReservePrice(BigDecimal reservePrice) {
        this.reservePrice = reservePrice;
    }

    @Override
    public String toString() {
        return "AuctionCase{" + "appId=" + appId + ", " + "application=" + application + ", " + "stage=" + stage + ", " + "noticeDate=" + noticeDate + ", " + "noticeDueDate=" + noticeDueDate + ", " + "demandAmount=" + demandAmount + ", " + "possessionDate=" + possessionDate + ", " + "auctionDate=" + auctionDate + ", " + "reservePrice=" + reservePrice + "}";
    }
}
