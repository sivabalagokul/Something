package hlms.entity;

import java.time.OffsetDateTime;

/**
 * Entity representing the 'auction_note' table.
 */
public class AuctionNote {

    private String noteId;
    private AuctionCase auctionCase;
    private OffsetDateTime noteDate;
    private String noteText;

    public AuctionNote() {
    }

    public AuctionNote(
            String noteId,
            AuctionCase auctionCase,
            OffsetDateTime noteDate,
            String noteText) {

        this.noteId = noteId;
        this.auctionCase = auctionCase;
        this.noteDate = noteDate;
        this.noteText = noteText;
    }

    public String getNoteId() {
        return noteId;
    }

    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }

    public AuctionCase getAuctionCase() {
        return auctionCase;
    }

    public void setAuctionCase(AuctionCase auctionCase) {
        this.auctionCase = auctionCase;
    }

    public OffsetDateTime getNoteDate() {
        return noteDate;
    }

    public void setNoteDate(OffsetDateTime noteDate) {
        this.noteDate = noteDate;
    }

    public String getNoteText() {
        return noteText;
    }

    public void setNoteText(String noteText) {
        this.noteText = noteText;
    }

    @Override
    public String toString() {
        return "AuctionNote{" + "noteId=" + noteId + ", " + "auctionCase=" + auctionCase + ", " + "noteDate=" + noteDate + ", " + "noteText=" + noteText + "}";
    }
}
