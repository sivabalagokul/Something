package hlms.entity;

import java.time.OffsetDateTime;

/**
 * Entity representing the 'audit_log' table.
 */
public class AuditLog {

    private Long logId;
    private String entityType;
    private String entityId;
    private String action;
    private AppUser actor;
    private String beforeData;
    private String afterData;
    private OffsetDateTime createdAt;

    public AuditLog() {
    }

    public AuditLog(
            Long logId,
            String entityType,
            String entityId,
            String action,
            AppUser actor,
            String beforeData,
            String afterData,
            OffsetDateTime createdAt) {

        this.logId = logId;
        this.entityType = entityType;
        this.entityId = entityId;
        this.action = action;
        this.actor = actor;
        this.beforeData = beforeData;
        this.afterData = afterData;
        this.createdAt = createdAt;
    }

    public Long getLogId() {
        return logId;
    }

    public void setLogId(Long logId) {
        this.logId = logId;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public AppUser getActor() {
        return actor;
    }

    public void setActor(AppUser actor) {
        this.actor = actor;
    }

    public String getBeforeData() {
        return beforeData;
    }

    public void setBeforeData(String beforeData) {
        this.beforeData = beforeData;
    }

    public String getAfterData() {
        return afterData;
    }

    public void setAfterData(String afterData) {
        this.afterData = afterData;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "AuditLog{" + "logId=" + logId + ", " + "entityType=" + entityType + ", " + "entityId=" + entityId + ", " + "action=" + action + ", " + "actor=" + actor + ", " + "beforeData=" + beforeData + ", " + "afterData=" + afterData + ", " + "createdAt=" + createdAt + "}";
    }
}
