package hlms.entity;

import java.time.OffsetDateTime;

/**
 * Entity representing the 'bank_office_decision' table.
 */
public class BankOfficeDecision {

    private String appId;
    private LoanApplication application;
    private String decision;
    private AppUser officer;
    private OffsetDateTime decisionDate;
    private String reason;
    private String remarks;

    public BankOfficeDecision() {
    }

    public BankOfficeDecision(
            String appId,
            LoanApplication application,
            String decision,
            AppUser officer,
            OffsetDateTime decisionDate,
            String reason,
            String remarks) {

        this.appId = appId;
        this.application = application;
        this.decision = decision;
        this.officer = officer;
        this.decisionDate = decisionDate;
        this.reason = reason;
        this.remarks = remarks;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public AppUser getOfficer() {
        return officer;
    }

    public void setOfficer(AppUser officer) {
        this.officer = officer;
    }

    public OffsetDateTime getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(OffsetDateTime decisionDate) {
        this.decisionDate = decisionDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "BankOfficeDecision{" + "appId=" + appId + ", " + "application=" + application + ", " + "decision=" + decision + ", " + "officer=" + officer + ", " + "decisionDate=" + decisionDate + ", " + "reason=" + reason + ", " + "remarks=" + remarks + "}";
    }
}
