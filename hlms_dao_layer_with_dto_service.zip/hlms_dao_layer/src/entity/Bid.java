package hlms.entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Entity representing the 'bid' table.
 */
public class Bid {

    private String bidId;
    private AuctionCase auctionCase;
    private AppUser bidder;
    private BigDecimal bidAmount;
    private OffsetDateTime createdAt;

    public Bid() {
    }

    public Bid(
            String bidId,
            AuctionCase auctionCase,
            AppUser bidder,
            BigDecimal bidAmount,
            OffsetDateTime createdAt) {

        this.bidId = bidId;
        this.auctionCase = auctionCase;
        this.bidder = bidder;
        this.bidAmount = bidAmount;
        this.createdAt = createdAt;
    }

    public String getBidId() {
        return bidId;
    }

    public void setBidId(String bidId) {
        this.bidId = bidId;
    }

    public AuctionCase getAuctionCase() {
        return auctionCase;
    }

    public void setAuctionCase(AuctionCase auctionCase) {
        this.auctionCase = auctionCase;
    }

    public AppUser getBidder() {
        return bidder;
    }

    public void setBidder(AppUser bidder) {
        this.bidder = bidder;
    }

    public BigDecimal getBidAmount() {
        return bidAmount;
    }

    public void setBidAmount(BigDecimal bidAmount) {
        this.bidAmount = bidAmount;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "Bid{" + "bidId=" + bidId + ", " + "auctionCase=" + auctionCase + ", " + "bidder=" + bidder + ", " + "bidAmount=" + bidAmount + ", " + "createdAt=" + createdAt + "}";
    }
}
