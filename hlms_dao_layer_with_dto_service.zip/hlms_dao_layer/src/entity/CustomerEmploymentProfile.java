package hlms.entity;

import java.math.BigDecimal;

/**
 * Entity representing the 'customer_employment_profile' table.
 */
public class CustomerEmploymentProfile {

    private String userEmail;
    private AppUser user;
    private String employmentType;
    private String employer;
    private BigDecimal monthlyIncome;
    private BigDecimal otherEmis;
    private BigDecimal desiredAmount;
    private String pan;

    public CustomerEmploymentProfile() {
    }

    public CustomerEmploymentProfile(
            String userEmail,
            AppUser user,
            String employmentType,
            String employer,
            BigDecimal monthlyIncome,
            BigDecimal otherEmis,
            BigDecimal desiredAmount,
            String pan) {

        this.userEmail = userEmail;
        this.user = user;
        this.employmentType = employmentType;
        this.employer = employer;
        this.monthlyIncome = monthlyIncome;
        this.otherEmis = otherEmis;
        this.desiredAmount = desiredAmount;
        this.pan = pan;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public AppUser getUser() {
        return user;
    }

    public void setUser(AppUser user) {
        this.user = user;
    }

    public String getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    public String getEmployer() {
        return employer;
    }

    public void setEmployer(String employer) {
        this.employer = employer;
    }

    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public BigDecimal getOtherEmis() {
        return otherEmis;
    }

    public void setOtherEmis(BigDecimal otherEmis) {
        this.otherEmis = otherEmis;
    }

    public BigDecimal getDesiredAmount() {
        return desiredAmount;
    }

    public void setDesiredAmount(BigDecimal desiredAmount) {
        this.desiredAmount = desiredAmount;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    @Override
    public String toString() {
        return "CustomerEmploymentProfile{" + "userEmail=" + userEmail + ", " + "user=" + user + ", " + "employmentType=" + employmentType + ", " + "employer=" + employer + ", " + "monthlyIncome=" + monthlyIncome + ", " + "otherEmis=" + otherEmis + ", " + "desiredAmount=" + desiredAmount + ", " + "pan=" + pan + "}";
    }
}
