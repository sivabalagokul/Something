package hlms.entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Entity representing the 'disbursement' table.
 */
public class Disbursement {

    private String appId;
    private LoanApplication application;
    private OffsetDateTime disbursedDate;
    private BigDecimal amount;
    private String refNo;
    private String mode;
    private String bankDetails;

    public Disbursement() {
    }

    public Disbursement(
            String appId,
            LoanApplication application,
            OffsetDateTime disbursedDate,
            BigDecimal amount,
            String refNo,
            String mode,
            String bankDetails) {

        this.appId = appId;
        this.application = application;
        this.disbursedDate = disbursedDate;
        this.amount = amount;
        this.refNo = refNo;
        this.mode = mode;
        this.bankDetails = bankDetails;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public OffsetDateTime getDisbursedDate() {
        return disbursedDate;
    }

    public void setDisbursedDate(OffsetDateTime disbursedDate) {
        this.disbursedDate = disbursedDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getRefNo() {
        return refNo;
    }

    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getBankDetails() {
        return bankDetails;
    }

    public void setBankDetails(String bankDetails) {
        this.bankDetails = bankDetails;
    }

    @Override
    public String toString() {
        return "Disbursement{" + "appId=" + appId + ", " + "application=" + application + ", " + "disbursedDate=" + disbursedDate + ", " + "amount=" + amount + ", " + "refNo=" + refNo + ", " + "mode=" + mode + ", " + "bankDetails=" + bankDetails + "}";
    }
}
