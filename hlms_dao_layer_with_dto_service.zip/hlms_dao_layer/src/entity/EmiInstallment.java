package hlms.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Entity representing the 'emi_installment' table.
 */
public class EmiInstallment {

    private String installmentId;
    private LoanApplication application;
    private Integer installmentNo;
    private LocalDate dueDate;
    private BigDecimal emiAmount;
    private BigDecimal principalComponent;
    private BigDecimal interestComponent;
    private BigDecimal closingBalance;
    private String status;
    private LocalDate paidDate;

    public EmiInstallment() {
    }

    public EmiInstallment(
            String installmentId,
            LoanApplication application,
            Integer installmentNo,
            LocalDate dueDate,
            BigDecimal emiAmount,
            BigDecimal principalComponent,
            BigDecimal interestComponent,
            BigDecimal closingBalance,
            String status,
            LocalDate paidDate) {

        this.installmentId = installmentId;
        this.application = application;
        this.installmentNo = installmentNo;
        this.dueDate = dueDate;
        this.emiAmount = emiAmount;
        this.principalComponent = principalComponent;
        this.interestComponent = interestComponent;
        this.closingBalance = closingBalance;
        this.status = status;
        this.paidDate = paidDate;
    }

    public String getInstallmentId() {
        return installmentId;
    }

    public void setInstallmentId(String installmentId) {
        this.installmentId = installmentId;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public Integer getInstallmentNo() {
        return installmentNo;
    }

    public void setInstallmentNo(Integer installmentNo) {
        this.installmentNo = installmentNo;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public BigDecimal getEmiAmount() {
        return emiAmount;
    }

    public void setEmiAmount(BigDecimal emiAmount) {
        this.emiAmount = emiAmount;
    }

    public BigDecimal getPrincipalComponent() {
        return principalComponent;
    }

    public void setPrincipalComponent(BigDecimal principalComponent) {
        this.principalComponent = principalComponent;
    }

    public BigDecimal getInterestComponent() {
        return interestComponent;
    }

    public void setInterestComponent(BigDecimal interestComponent) {
        this.interestComponent = interestComponent;
    }

    public BigDecimal getClosingBalance() {
        return closingBalance;
    }

    public void setClosingBalance(BigDecimal closingBalance) {
        this.closingBalance = closingBalance;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getPaidDate() {
        return paidDate;
    }

    public void setPaidDate(LocalDate paidDate) {
        this.paidDate = paidDate;
    }

    @Override
    public String toString() {
        return "EmiInstallment{" + "installmentId=" + installmentId + ", " + "application=" + application + ", " + "installmentNo=" + installmentNo + ", " + "dueDate=" + dueDate + ", " + "emiAmount=" + emiAmount + ", " + "principalComponent=" + principalComponent + ", " + "interestComponent=" + interestComponent + ", " + "closingBalance=" + closingBalance + ", " + "status=" + status + ", " + "paidDate=" + paidDate + "}";
    }
}
