package hlms.entity;

import java.time.LocalDate;

/**
 * Entity representing the 'insurance_policy' table.
 */
public class InsurancePolicy {

    private String policyId;
    private LoanApplication application;
    private String policyType;
    private String status;
    private LocalDate validTill;

    public InsurancePolicy() {
    }

    public InsurancePolicy(
            String policyId,
            LoanApplication application,
            String policyType,
            String status,
            LocalDate validTill) {

        this.policyId = policyId;
        this.application = application;
        this.policyType = policyType;
        this.status = status;
        this.validTill = validTill;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public String getPolicyType() {
        return policyType;
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getValidTill() {
        return validTill;
    }

    public void setValidTill(LocalDate validTill) {
        this.validTill = validTill;
    }

    @Override
    public String toString() {
        return "InsurancePolicy{" + "policyId=" + policyId + ", " + "application=" + application + ", " + "policyType=" + policyType + ", " + "status=" + status + ", " + "validTill=" + validTill + "}";
    }
}
