package hlms.entity;

/**
 * Entity representing the 'legal_checklist_item' table.
 */
public class LegalChecklistItem {

    private String checklistItemId;
    private LoanApplication application;
    private String checklistKey;
    private String status;

    public LegalChecklistItem() {
    }

    public LegalChecklistItem(
            String checklistItemId,
            LoanApplication application,
            String checklistKey,
            String status) {

        this.checklistItemId = checklistItemId;
        this.application = application;
        this.checklistKey = checklistKey;
        this.status = status;
    }

    public String getChecklistItemId() {
        return checklistItemId;
    }

    public void setChecklistItemId(String checklistItemId) {
        this.checklistItemId = checklistItemId;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public String getChecklistKey() {
        return checklistKey;
    }

    public void setChecklistKey(String checklistKey) {
        this.checklistKey = checklistKey;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "LegalChecklistItem{" + "checklistItemId=" + checklistItemId + ", " + "application=" + application + ", " + "checklistKey=" + checklistKey + ", " + "status=" + status + "}";
    }
}
