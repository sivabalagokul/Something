package hlms.entity;

import java.time.LocalDate;

/**
 * Entity representing the 'legal_notice' table.
 */
public class LegalNotice {

    private String noticeId;
    private String noticeNo;
    private LoanApplication application;
    private String noticeType;
    private LocalDate issueDate;
    private LocalDate dueDate;
    private String status;
    private AppUser officer;
    private String content;

    public LegalNotice() {
    }

    public LegalNotice(
            String noticeId,
            String noticeNo,
            LoanApplication application,
            String noticeType,
            LocalDate issueDate,
            LocalDate dueDate,
            String status,
            AppUser officer,
            String content) {

        this.noticeId = noticeId;
        this.noticeNo = noticeNo;
        this.application = application;
        this.noticeType = noticeType;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.status = status;
        this.officer = officer;
        this.content = content;
    }

    public String getNoticeId() {
        return noticeId;
    }

    public void setNoticeId(String noticeId) {
        this.noticeId = noticeId;
    }

    public String getNoticeNo() {
        return noticeNo;
    }

    public void setNoticeNo(String noticeNo) {
        this.noticeNo = noticeNo;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public String getNoticeType() {
        return noticeType;
    }

    public void setNoticeType(String noticeType) {
        this.noticeType = noticeType;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public AppUser getOfficer() {
        return officer;
    }

    public void setOfficer(AppUser officer) {
        this.officer = officer;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "LegalNotice{" + "noticeId=" + noticeId + ", " + "noticeNo=" + noticeNo + ", " + "application=" + application + ", " + "noticeType=" + noticeType + ", " + "issueDate=" + issueDate + ", " + "dueDate=" + dueDate + ", " + "status=" + status + ", " + "officer=" + officer + ", " + "content=" + content + "}";
    }
}
