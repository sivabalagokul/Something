package hlms.entity;

import java.time.OffsetDateTime;

/**
 * Entity representing the 'legal_verification' table.
 */
public class LegalVerification {

    private String appId;
    private LoanApplication application;
    private String decision;
    private OffsetDateTime decisionDate;
    private AppUser officer;
    private String remarks;

    public LegalVerification() {
    }

    public LegalVerification(
            String appId,
            LoanApplication application,
            String decision,
            OffsetDateTime decisionDate,
            AppUser officer,
            String remarks) {

        this.appId = appId;
        this.application = application;
        this.decision = decision;
        this.decisionDate = decisionDate;
        this.officer = officer;
        this.remarks = remarks;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public OffsetDateTime getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(OffsetDateTime decisionDate) {
        this.decisionDate = decisionDate;
    }

    public AppUser getOfficer() {
        return officer;
    }

    public void setOfficer(AppUser officer) {
        this.officer = officer;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "LegalVerification{" + "appId=" + appId + ", " + "application=" + application + ", " + "decision=" + decision + ", " + "decisionDate=" + decisionDate + ", " + "officer=" + officer + ", " + "remarks=" + remarks + "}";
    }
}
