package hlms.entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Entity representing the 'loan_application' table.
 */
public class LoanApplication {

    private String appId;
    private String trackingNo;
    private AppUser user;
    private LoanProduct product;
    private BigDecimal loanAmount;
    private Integer tenureYears;
    private String purpose;
    private BigDecimal interestRate;
    private String status;
    private Integer stageIndex;
    private OffsetDateTime createdAt;
    private String applicantName;
    private String applicantMobile;
    private String applicantPan;
    private String addrDoorNo;
    private String addrStreet;
    private String addrCity;
    private String addrState;
    private String addrPincode;
    private String employmentType;
    private String employer;
    private BigDecimal monthlyIncome;
    private BigDecimal otherEmis;
    private String propertyAddress;
    private String propertyType;
    private BigDecimal propertyValue;

    public LoanApplication() {
    }

    public LoanApplication(
            String appId,
            String trackingNo,
            AppUser user,
            LoanProduct product,
            BigDecimal loanAmount,
            Integer tenureYears,
            String purpose,
            BigDecimal interestRate,
            String status,
            Integer stageIndex,
            OffsetDateTime createdAt,
            String applicantName,
            String applicantMobile,
            String applicantPan,
            String addrDoorNo,
            String addrStreet,
            String addrCity,
            String addrState,
            String addrPincode,
            String employmentType,
            String employer,
            BigDecimal monthlyIncome,
            BigDecimal otherEmis,
            String propertyAddress,
            String propertyType,
            BigDecimal propertyValue) {

        this.appId = appId;
        this.trackingNo = trackingNo;
        this.user = user;
        this.product = product;
        this.loanAmount = loanAmount;
        this.tenureYears = tenureYears;
        this.purpose = purpose;
        this.interestRate = interestRate;
        this.status = status;
        this.stageIndex = stageIndex;
        this.createdAt = createdAt;
        this.applicantName = applicantName;
        this.applicantMobile = applicantMobile;
        this.applicantPan = applicantPan;
        this.addrDoorNo = addrDoorNo;
        this.addrStreet = addrStreet;
        this.addrCity = addrCity;
        this.addrState = addrState;
        this.addrPincode = addrPincode;
        this.employmentType = employmentType;
        this.employer = employer;
        this.monthlyIncome = monthlyIncome;
        this.otherEmis = otherEmis;
        this.propertyAddress = propertyAddress;
        this.propertyType = propertyType;
        this.propertyValue = propertyValue;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public AppUser getUser() {
        return user;
    }

    public void setUser(AppUser user) {
        this.user = user;
    }

    public LoanProduct getProduct() {
        return product;
    }

    public void setProduct(LoanProduct product) {
        this.product = product;
    }

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    public Integer getTenureYears() {
        return tenureYears;
    }

    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getStageIndex() {
        return stageIndex;
    }

    public void setStageIndex(Integer stageIndex) {
        this.stageIndex = stageIndex;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public String getApplicantMobile() {
        return applicantMobile;
    }

    public void setApplicantMobile(String applicantMobile) {
        this.applicantMobile = applicantMobile;
    }

    public String getApplicantPan() {
        return applicantPan;
    }

    public void setApplicantPan(String applicantPan) {
        this.applicantPan = applicantPan;
    }

    public String getAddrDoorNo() {
        return addrDoorNo;
    }

    public void setAddrDoorNo(String addrDoorNo) {
        this.addrDoorNo = addrDoorNo;
    }

    public String getAddrStreet() {
        return addrStreet;
    }

    public void setAddrStreet(String addrStreet) {
        this.addrStreet = addrStreet;
    }

    public String getAddrCity() {
        return addrCity;
    }

    public void setAddrCity(String addrCity) {
        this.addrCity = addrCity;
    }

    public String getAddrState() {
        return addrState;
    }

    public void setAddrState(String addrState) {
        this.addrState = addrState;
    }

    public String getAddrPincode() {
        return addrPincode;
    }

    public void setAddrPincode(String addrPincode) {
        this.addrPincode = addrPincode;
    }

    public String getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    public String getEmployer() {
        return employer;
    }

    public void setEmployer(String employer) {
        this.employer = employer;
    }

    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public BigDecimal getOtherEmis() {
        return otherEmis;
    }

    public void setOtherEmis(BigDecimal otherEmis) {
        this.otherEmis = otherEmis;
    }

    public String getPropertyAddress() {
        return propertyAddress;
    }

    public void setPropertyAddress(String propertyAddress) {
        this.propertyAddress = propertyAddress;
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    public BigDecimal getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(BigDecimal propertyValue) {
        this.propertyValue = propertyValue;
    }

    @Override
    public String toString() {
        return "LoanApplication{" + "appId=" + appId + ", " + "trackingNo=" + trackingNo + ", " + "user=" + user + ", " + "product=" + product + ", " + "loanAmount=" + loanAmount + ", " + "tenureYears=" + tenureYears + ", " + "purpose=" + purpose + ", " + "interestRate=" + interestRate + ", " + "status=" + status + ", " + "stageIndex=" + stageIndex + ", " + "createdAt=" + createdAt + ", " + "applicantName=" + applicantName + ", " + "applicantMobile=" + applicantMobile + ", " + "applicantPan=" + applicantPan + ", " + "addrDoorNo=" + addrDoorNo + ", " + "addrStreet=" + addrStreet + ", " + "addrCity=" + addrCity + ", " + "addrState=" + addrState + ", " + "addrPincode=" + addrPincode + ", " + "employmentType=" + employmentType + ", " + "employer=" + employer + ", " + "monthlyIncome=" + monthlyIncome + ", " + "otherEmis=" + otherEmis + ", " + "propertyAddress=" + propertyAddress + ", " + "propertyType=" + propertyType + ", " + "propertyValue=" + propertyValue + "}";
    }
}
