package hlms.entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Entity representing the 'loan_draft' table.
 */
public class LoanDraft {

    private String draftId;
    private AppUser user;
    private Integer currentStep;
    private OffsetDateTime savedAt;
    private String loanType;
    private BigDecimal loanAmount;
    private Integer tenureYears;
    private String formData;

    public LoanDraft() {
    }

    public LoanDraft(
            String draftId,
            AppUser user,
            Integer currentStep,
            OffsetDateTime savedAt,
            String loanType,
            BigDecimal loanAmount,
            Integer tenureYears,
            String formData) {

        this.draftId = draftId;
        this.user = user;
        this.currentStep = currentStep;
        this.savedAt = savedAt;
        this.loanType = loanType;
        this.loanAmount = loanAmount;
        this.tenureYears = tenureYears;
        this.formData = formData;
    }

    public String getDraftId() {
        return draftId;
    }

    public void setDraftId(String draftId) {
        this.draftId = draftId;
    }

    public AppUser getUser() {
        return user;
    }

    public void setUser(AppUser user) {
        this.user = user;
    }

    public Integer getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(Integer currentStep) {
        this.currentStep = currentStep;
    }

    public OffsetDateTime getSavedAt() {
        return savedAt;
    }

    public void setSavedAt(OffsetDateTime savedAt) {
        this.savedAt = savedAt;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    public Integer getTenureYears() {
        return tenureYears;
    }

    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }

    public String getFormData() {
        return formData;
    }

    public void setFormData(String formData) {
        this.formData = formData;
    }

    @Override
    public String toString() {
        return "LoanDraft{" + "draftId=" + draftId + ", " + "user=" + user + ", " + "currentStep=" + currentStep + ", " + "savedAt=" + savedAt + ", " + "loanType=" + loanType + ", " + "loanAmount=" + loanAmount + ", " + "tenureYears=" + tenureYears + ", " + "formData=" + formData + "}";
    }
}
