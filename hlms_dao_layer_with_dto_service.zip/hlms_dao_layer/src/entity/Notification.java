package hlms.entity;

import java.time.OffsetDateTime;

/**
 * Entity representing the 'notification' table.
 */
public class Notification {

    private String notificationId;
    private AppUser user;
    private String title;
    private String body;
    private String[] channels;
    private Boolean isRead;
    private OffsetDateTime createdAt;

    public Notification() {
    }

    public Notification(
            String notificationId,
            AppUser user,
            String title,
            String body,
            String[] channels,
            Boolean isRead,
            OffsetDateTime createdAt) {

        this.notificationId = notificationId;
        this.user = user;
        this.title = title;
        this.body = body;
        this.channels = channels;
        this.isRead = isRead;
        this.createdAt = createdAt;
    }

    public String getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    public AppUser getUser() {
        return user;
    }

    public void setUser(AppUser user) {
        this.user = user;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String[] getChannels() {
        return channels;
    }

    public void setChannels(String[] channels) {
        this.channels = channels;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "Notification{" + "notificationId=" + notificationId + ", " + "user=" + user + ", " + "title=" + title + ", " + "body=" + body + ", " + "channels=" + channels + ", " + "isRead=" + isRead + ", " + "createdAt=" + createdAt + "}";
    }
}
