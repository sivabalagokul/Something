package hlms.entity;

import java.time.OffsetDateTime;

/**
 * Entity representing the 'post_disbursement_document' table.
 */
public class PostDisbursementDocument {

    private String pdDocId;
    private LoanApplication application;
    private String docType;
    private String fileName;
    private Integer fileSize;
    private String note;
    private String status;
    private OffsetDateTime uploadedAt;
    private AppUser verifiedBy;
    private OffsetDateTime verifiedAt;
    private String remarks;

    public PostDisbursementDocument() {
    }

    public PostDisbursementDocument(
            String pdDocId,
            LoanApplication application,
            String docType,
            String fileName,
            Integer fileSize,
            String note,
            String status,
            OffsetDateTime uploadedAt,
            AppUser verifiedBy,
            OffsetDateTime verifiedAt,
            String remarks) {

        this.pdDocId = pdDocId;
        this.application = application;
        this.docType = docType;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.note = note;
        this.status = status;
        this.uploadedAt = uploadedAt;
        this.verifiedBy = verifiedBy;
        this.verifiedAt = verifiedAt;
        this.remarks = remarks;
    }

    public String getPdDocId() {
        return pdDocId;
    }

    public void setPdDocId(String pdDocId) {
        this.pdDocId = pdDocId;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Integer getFileSize() {
        return fileSize;
    }

    public void setFileSize(Integer fileSize) {
        this.fileSize = fileSize;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public OffsetDateTime getUploadedAt() {
        return uploadedAt;
    }

    public void setUploadedAt(OffsetDateTime uploadedAt) {
        this.uploadedAt = uploadedAt;
    }

    public AppUser getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(AppUser verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public OffsetDateTime getVerifiedAt() {
        return verifiedAt;
    }

    public void setVerifiedAt(OffsetDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "PostDisbursementDocument{" + "pdDocId=" + pdDocId + ", " + "application=" + application + ", " + "docType=" + docType + ", " + "fileName=" + fileName + ", " + "fileSize=" + fileSize + ", " + "note=" + note + ", " + "status=" + status + ", " + "uploadedAt=" + uploadedAt + ", " + "verifiedBy=" + verifiedBy + ", " + "verifiedAt=" + verifiedAt + ", " + "remarks=" + remarks + "}";
    }
}
