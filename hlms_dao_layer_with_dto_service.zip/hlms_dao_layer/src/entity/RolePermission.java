package hlms.entity;

/**
 * Entity representing the 'role_permission' table.
 */
public class RolePermission {

    private String role;
    private String module;
    private Boolean canView;
    private Boolean canAdd;
    private Boolean canEdit;
    private Boolean canDelete;

    public RolePermission() {
    }

    public RolePermission(
            String role,
            String module,
            Boolean canView,
            Boolean canAdd,
            Boolean canEdit,
            Boolean canDelete) {

        this.role = role;
        this.module = module;
        this.canView = canView;
        this.canAdd = canAdd;
        this.canEdit = canEdit;
        this.canDelete = canDelete;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public Boolean getCanView() {
        return canView;
    }

    public void setCanView(Boolean canView) {
        this.canView = canView;
    }

    public Boolean getCanAdd() {
        return canAdd;
    }

    public void setCanAdd(Boolean canAdd) {
        this.canAdd = canAdd;
    }

    public Boolean getCanEdit() {
        return canEdit;
    }

    public void setCanEdit(Boolean canEdit) {
        this.canEdit = canEdit;
    }

    public Boolean getCanDelete() {
        return canDelete;
    }

    public void setCanDelete(Boolean canDelete) {
        this.canDelete = canDelete;
    }

    @Override
    public String toString() {
        return "RolePermission{" + "role=" + role + ", " + "module=" + module + ", " + "canView=" + canView + ", " + "canAdd=" + canAdd + ", " + "canEdit=" + canEdit + ", " + "canDelete=" + canDelete + "}";
    }
}
