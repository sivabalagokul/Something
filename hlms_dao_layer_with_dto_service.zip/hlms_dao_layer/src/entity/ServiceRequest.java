package hlms.entity;

import java.time.OffsetDateTime;

/**
 * Entity representing the 'service_request' table.
 */
public class ServiceRequest {

    private String requestId;
    private String refNo;
    private LoanApplication application;
    private AppUser user;
    private String requestType;
    private String description;
    private String status;
    private OffsetDateTime createdAt;

    public ServiceRequest() {
    }

    public ServiceRequest(
            String requestId,
            String refNo,
            LoanApplication application,
            AppUser user,
            String requestType,
            String description,
            String status,
            OffsetDateTime createdAt) {

        this.requestId = requestId;
        this.refNo = refNo;
        this.application = application;
        this.user = user;
        this.requestType = requestType;
        this.description = description;
        this.status = status;
        this.createdAt = createdAt;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRefNo() {
        return refNo;
    }

    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }

    public LoanApplication getApplication() {
        return application;
    }

    public void setApplication(LoanApplication application) {
        this.application = application;
    }

    public AppUser getUser() {
        return user;
    }

    public void setUser(AppUser user) {
        this.user = user;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "ServiceRequest{" + "requestId=" + requestId + ", " + "refNo=" + refNo + ", " + "application=" + application + ", " + "user=" + user + ", " + "requestType=" + requestType + ", " + "description=" + description + ", " + "status=" + status + ", " + "createdAt=" + createdAt + "}";
    }
}
