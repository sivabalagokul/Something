package hlms.main;

import hlms.dao.*;
import hlms.daoimpl.*;
import hlms.entity.*;
import hlms.util.DAOException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * Single consolidated entry point that replaces the 21 separate *Main.java
 * demo classes.
 *
 * What this does, in one run:
 *   1. INSERTs one row into every one of the 21 tables, in an order that
 *      satisfies every foreign-key constraint (same order recommended in
 *      the original README), wiring each foreign key to the row actually
 *      inserted a moment earlier in this same run instead of a
 *      "REPLACE_WITH_EXISTING_..." placeholder.
 *   2. For each entity: findById (read-back check), one field update,
 *      findAll (row count).
 *   3. At the very end, DELETEs every row it created, in the reverse
 *      order, so the run is repeatable against your existing database
 *      without leaving demo data behind or violating FK constraints.
 *
 * Before running:
 *   - Point src/util/DBConnection.java at your existing PostgreSQL
 *     database (DB_URL / DB_USER / DB_PASSWORD).
 *   - Make sure the 21 tables already exist in that database (this class
 *     does not create schema, only rows).
 *
 * Compile / run:
 *   javac -cp .:postgresql-42.7.x.jar -d out src/entity/*.java src/dao/*.java src/util/*.java src/daoimpl/*.java src/main/HlmsFullDemoMain.java
 *   java  -cp out:postgresql-42.7.x.jar hlms.main.HlmsFullDemoMain
 */
public class HlmsFullDemoMain {

    public static void main(String[] args) {
        try {
            runAll();
        } catch (DAOException e) {
            System.err.println("Run aborted: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void runAll() throws DAOException {

        // ---------- 1. AppUser (customer + officer) ----------
        AppUserDAO appUserDao = new AppUserDAOImpl();

        AppUser customer = new AppUser();
        customer.setEmail("demo.customer@hlms.local");
        customer.setName("Demo Customer");
        customer.setMobile("9000000001");
        customer.setPasswordHash("hash-customer");
        customer.setRole("CUSTOMER");
        customer.setActive(true);
        customer.setIdType("PAN");
        customer.setIdNumber("ABCDE1234F");
        customer.setPrefSms(true);
        customer.setPrefEmail(true);
        customer.setPrefInapp(true);
        customer.setCreatedAt(OffsetDateTime.now());
        customer = appUserDao.insert(customer);
        report("AppUser (customer)", customer);

        AppUser officer = new AppUser();
        officer.setEmail("demo.officer@hlms.local");
        officer.setName("Demo Officer");
        officer.setMobile("9000000002");
        officer.setPasswordHash("hash-officer");
        officer.setRole("BANK_OFFICER");
        officer.setActive(true);
        officer.setIdType("EMP_ID");
        officer.setIdNumber("EMP-001");
        officer.setPrefSms(false);
        officer.setPrefEmail(true);
        officer.setPrefInapp(true);
        officer.setCreatedAt(OffsetDateTime.now());
        officer = appUserDao.insert(officer);
        report("AppUser (officer)", officer);

        readUpdateCount(customer.getEmail(), "name", "Demo Customer Updated",
                (u, v) -> u.setName(v), appUserDao::findById, appUserDao::update, appUserDao::findAll);

        // ---------- 2. LoanProduct ----------
        LoanProductDAO productDao = new LoanProductDAOImpl();
        LoanProduct product = new LoanProduct();
        product.setProductId("PRD-HOME-001");
        product.setName("Standard Home Loan");
        product.setCategory("HOME");
        product.setInterestRate(new BigDecimal("8.50"));
        product.setMaxTenureYears(20);
        product.setMaxLtv("80");
        product.setDescription("Demo product created by HlmsFullDemoMain");
        product = productDao.insert(product);
        report("LoanProduct", product);
        readUpdateCount(product.getProductId(), null, null, null,
                productDao::findById, productDao::update, productDao::findAll);

        // ---------- 3. RolePermission (no FK) ----------
        RolePermissionDAO rolePermDao = new RolePermissionDAOImpl();
        RolePermission rolePerm = new RolePermission();
        rolePerm.setRole("BANK_OFFICER");
        rolePerm.setModule("LOAN_APPLICATION");
        rolePerm.setCanView(true);
        rolePerm.setCanAdd(true);
        rolePerm.setCanEdit(true);
        rolePerm.setCanDelete(false);
        rolePerm = rolePermDao.insert(rolePerm);
        report("RolePermission", rolePerm);
        RolePermission foundRolePerm = rolePermDao.findById(rolePerm.getRole(), rolePerm.getModule());
        System.out.println("Found: " + foundRolePerm);
        rolePermDao.update(foundRolePerm);
        System.out.println("Total RolePermission rows: " + rolePermDao.findAll().size());

        // ---------- 4. CustomerEmploymentProfile (1:1 on user_email) ----------
        CustomerEmploymentProfileDAO empDao = new CustomerEmploymentProfileDAOImpl();
        CustomerEmploymentProfile empProfile = new CustomerEmploymentProfile();
        empProfile.setUserEmail(customer.getEmail());
        empProfile.setUser(customer);
        empProfile.setEmploymentType("SALARIED");
        empProfile.setEmployer("Demo Employer Pvt Ltd");
        empProfile.setMonthlyIncome(new BigDecimal("75000.00"));
        empProfile.setOtherEmis(new BigDecimal("5000.00"));
        empProfile.setDesiredAmount(new BigDecimal("2500000.00"));
        empProfile.setPan("ABCDE1234F");
        empProfile = empDao.insert(empProfile);
        report("CustomerEmploymentProfile", empProfile);
        readUpdateCount(empProfile.getUserEmail(), null, null, null,
                empDao::findById, empDao::update, empDao::findAll);

        // ---------- 5. LoanDraft ----------
        LoanDraftDAO draftDao = new LoanDraftDAOImpl();
        LoanDraft draft = new LoanDraft();
        draft.setDraftId("DRAFT-0001");
        draft.setUser(customer);
        draft.setCurrentStep(1);
        draft.setSavedAt(OffsetDateTime.now());
        draft.setLoanType("HOME");
        draft.setLoanAmount(new BigDecimal("2500000.00"));
        draft.setTenureYears(20);
        draft.setFormData("{}");
        draft = draftDao.insert(draft);
        report("LoanDraft", draft);
        readUpdateCount(draft.getDraftId(), null, null, null,
                draftDao::findById, draftDao::update, draftDao::findAll);

        // ---------- 6. LoanApplication ----------
        LoanApplicationDAO appDao = new LoanApplicationDAOImpl();
        LoanApplication loanApp = new LoanApplication();
        loanApp.setAppId("APP-0001");
        loanApp.setTrackingNo("TRK-0001");
        loanApp.setUser(customer);
        loanApp.setProduct(product);
        loanApp.setLoanAmount(new BigDecimal("2500000.00"));
        loanApp.setTenureYears(20);
        loanApp.setPurpose("Purchase of flat");
        loanApp.setInterestRate(new BigDecimal("8.50"));
        loanApp.setStatus("SUBMITTED");
        loanApp.setStageIndex(1);
        loanApp.setCreatedAt(OffsetDateTime.now());
        loanApp.setApplicantName("Demo Customer");
        loanApp.setApplicantMobile("9000000001");
        loanApp.setApplicantPan("ABCDE1234F");
        loanApp.setAddrDoorNo("12A");
        loanApp.setAddrStreet("MG Road");
        loanApp.setAddrCity("Chennai");
        loanApp.setAddrState("Tamil Nadu");
        loanApp.setAddrPincode("600001");
        loanApp.setEmploymentType("SALARIED");
        loanApp.setEmployer("Demo Employer Pvt Ltd");
        loanApp.setMonthlyIncome(new BigDecimal("75000.00"));
        loanApp.setOtherEmis(new BigDecimal("5000.00"));
        loanApp.setPropertyAddress("Flat 4B, Green Towers, Chennai");
        loanApp.setPropertyType("APARTMENT");
        loanApp.setPropertyValue(new BigDecimal("3000000.00"));
        loanApp = appDao.insert(loanApp);
        report("LoanApplication", loanApp);
        readUpdateCount(loanApp.getAppId(), null, null, null,
                appDao::findById, appDao::update, appDao::findAll);

        // ---------- 7. ApplicationDocument ----------
        ApplicationDocumentDAO appDocDao = new ApplicationDocumentDAOImpl();
        ApplicationDocument appDoc = new ApplicationDocument();
        appDoc.setDocumentId("DOC-0001");
        appDoc.setApplication(loanApp);
        appDoc.setDocType("ID_PROOF");
        appDoc.setFileName("id-proof.pdf");
        appDoc.setFileSize(102400);
        appDoc.setUploadedAt(OffsetDateTime.now());
        appDoc.setVerificationStatus("PENDING");
        appDoc.setVerifiedBy(officer);
        appDoc.setVerifiedAt(OffsetDateTime.now());
        appDoc.setRemarks("Awaiting review");
        appDoc = appDocDao.insert(appDoc);
        report("ApplicationDocument", appDoc);
        readUpdateCount(appDoc.getDocumentId(), null, null, null,
                appDocDao::findById, appDocDao::update, appDocDao::findAll);

        // ---------- 8. LegalVerification (1:1 on app_id) ----------
        LegalVerificationDAO legalVerDao = new LegalVerificationDAOImpl();
        LegalVerification legalVer = new LegalVerification();
        legalVer.setAppId(loanApp.getAppId());
        legalVer.setApplication(loanApp);
        legalVer.setDecision("PENDING");
        legalVer.setDecisionDate(OffsetDateTime.now());
        legalVer.setOfficer(officer);
        legalVer.setRemarks("Initial legal review");
        legalVer = legalVerDao.insert(legalVer);
        report("LegalVerification", legalVer);
        readUpdateCount(legalVer.getAppId(), null, null, null,
                legalVerDao::findById, legalVerDao::update, legalVerDao::findAll);

        // ---------- 9. LegalChecklistItem ----------
        LegalChecklistItemDAO checklistDao = new LegalChecklistItemDAOImpl();
        LegalChecklistItem checklistItem = new LegalChecklistItem();
        checklistItem.setChecklistItemId("CHK-0001");
        checklistItem.setApplication(loanApp);
        checklistItem.setChecklistKey("TITLE_DEED");
        checklistItem.setStatus("PENDING");
        checklistItem = checklistDao.insert(checklistItem);
        report("LegalChecklistItem", checklistItem);
        readUpdateCount(checklistItem.getChecklistItemId(), null, null, null,
                checklistDao::findById, checklistDao::update, checklistDao::findAll);

        // ---------- 10. BankOfficeDecision (1:1 on app_id) ----------
        BankOfficeDecisionDAO decisionDao = new BankOfficeDecisionDAOImpl();
        BankOfficeDecision decision = new BankOfficeDecision();
        decision.setAppId(loanApp.getAppId());
        decision.setApplication(loanApp);
        decision.setDecision("APPROVED");
        decision.setOfficer(officer);
        decision.setDecisionDate(OffsetDateTime.now());
        decision.setReason("Meets eligibility criteria");
        decision.setRemarks("Approved with standard terms");
        decision = decisionDao.insert(decision);
        report("BankOfficeDecision", decision);
        readUpdateCount(decision.getAppId(), null, null, null,
                decisionDao::findById, decisionDao::update, decisionDao::findAll);

        // ---------- 11. Disbursement (1:1 on app_id) ----------
        DisbursementDAO disbDao = new DisbursementDAOImpl();
        Disbursement disbursement = new Disbursement();
        disbursement.setAppId(loanApp.getAppId());
        disbursement.setApplication(loanApp);
        disbursement.setDisbursedDate(OffsetDateTime.now());
        disbursement.setAmount(new BigDecimal("2500000.00"));
        disbursement.setRefNo("DISB-REF-0001");
        disbursement.setMode("NEFT");
        disbursement.setBankDetails("HDFC Bank, A/C ****1234");
        disbursement = disbDao.insert(disbursement);
        report("Disbursement", disbursement);
        readUpdateCount(disbursement.getAppId(), null, null, null,
                disbDao::findById, disbDao::update, disbDao::findAll);

        // ---------- 12. InsurancePolicy ----------
        InsurancePolicyDAO insDao = new InsurancePolicyDAOImpl();
        InsurancePolicy policy = new InsurancePolicy();
        policy.setPolicyId("POL-0001");
        policy.setApplication(loanApp);
        policy.setPolicyType("PROPERTY");
        policy.setStatus("ACTIVE");
        policy.setValidTill(LocalDate.now().plusYears(20));
        policy = insDao.insert(policy);
        report("InsurancePolicy", policy);
        readUpdateCount(policy.getPolicyId(), null, null, null,
                insDao::findById, insDao::update, insDao::findAll);

        // ---------- 13. EmiInstallment ----------
        EmiInstallmentDAO emiDao = new EmiInstallmentDAOImpl();
        EmiInstallment emi = new EmiInstallment();
        emi.setInstallmentId("EMI-0001");
        emi.setApplication(loanApp);
        emi.setInstallmentNo(1);
        emi.setDueDate(LocalDate.now().plusMonths(1));
        emi.setEmiAmount(new BigDecimal("21700.00"));
        emi.setPrincipalComponent(new BigDecimal("4033.00"));
        emi.setInterestComponent(new BigDecimal("17667.00"));
        emi.setClosingBalance(new BigDecimal("2495967.00"));
        emi.setStatus("DUE");
        emi.setPaidDate(null);
        emi = emiDao.insert(emi);
        report("EmiInstallment", emi);
        readUpdateCount(emi.getInstallmentId(), null, null, null,
                emiDao::findById, emiDao::update, emiDao::findAll);

        // ---------- 14. ServiceRequest ----------
        ServiceRequestDAO srDao = new ServiceRequestDAOImpl();
        ServiceRequest sr = new ServiceRequest();
        sr.setRequestId("SR-0001");
        sr.setRefNo("SR-REF-0001");
        sr.setApplication(loanApp);
        sr.setUser(customer);
        sr.setRequestType("STATEMENT_REQUEST");
        sr.setDescription("Requesting loan statement");
        sr.setStatus("OPEN");
        sr.setCreatedAt(OffsetDateTime.now());
        sr = srDao.insert(sr);
        report("ServiceRequest", sr);
        readUpdateCount(sr.getRequestId(), null, null, null,
                srDao::findById, srDao::update, srDao::findAll);

        // ---------- 15. PostDisbursementDocument ----------
        PostDisbursementDocumentDAO pdDocDao = new PostDisbursementDocumentDAOImpl();
        PostDisbursementDocument pdDoc = new PostDisbursementDocument();
        pdDoc.setPdDocId("PDDOC-0001");
        pdDoc.setApplication(loanApp);
        pdDoc.setDocType("INSURANCE_CERTIFICATE");
        pdDoc.setFileName("insurance-cert.pdf");
        pdDoc.setFileSize(51200);
        pdDoc.setNote("Uploaded after disbursement");
        pdDoc.setStatus("PENDING");
        pdDoc.setUploadedAt(OffsetDateTime.now());
        pdDoc.setVerifiedBy(officer);
        pdDoc.setVerifiedAt(OffsetDateTime.now());
        pdDoc.setRemarks("Awaiting review");
        pdDoc = pdDocDao.insert(pdDoc);
        report("PostDisbursementDocument", pdDoc);
        readUpdateCount(pdDoc.getPdDocId(), null, null, null,
                pdDocDao::findById, pdDocDao::update, pdDocDao::findAll);

        // ---------- 16. AuctionCase (1:1 on app_id) ----------
        AuctionCaseDAO auctionCaseDao = new AuctionCaseDAOImpl();
        AuctionCase auctionCase = new AuctionCase();
        auctionCase.setAppId(loanApp.getAppId());
        auctionCase.setApplication(loanApp);
        auctionCase.setStage("NOTICE_ISSUED");
        auctionCase.setNoticeDate(LocalDate.now());
        auctionCase.setNoticeDueDate(LocalDate.now().plusDays(60));
        auctionCase.setDemandAmount(new BigDecimal("2495967.00"));
        auctionCase.setPossessionDate(null);
        auctionCase.setAuctionDate(null);
        auctionCase.setReservePrice(new BigDecimal("2800000.00"));
        auctionCase = auctionCaseDao.insert(auctionCase);
        report("AuctionCase", auctionCase);
        readUpdateCount(auctionCase.getAppId(), null, null, null,
                auctionCaseDao::findById, auctionCaseDao::update, auctionCaseDao::findAll);

        // ---------- 17. AuctionNote ----------
        AuctionNoteDAO auctionNoteDao = new AuctionNoteDAOImpl();
        AuctionNote auctionNote = new AuctionNote();
        auctionNote.setNoteId("ANOTE-0001");
        auctionNote.setAuctionCase(auctionCase);
        auctionNote.setNoteDate(OffsetDateTime.now());
        auctionNote.setNoteText("Notice served to borrower");
        auctionNote = auctionNoteDao.insert(auctionNote);
        report("AuctionNote", auctionNote);
        readUpdateCount(auctionNote.getNoteId(), null, null, null,
                auctionNoteDao::findById, auctionNoteDao::update, auctionNoteDao::findAll);

        // ---------- 18. LegalNotice ----------
        LegalNoticeDAO noticeDao = new LegalNoticeDAOImpl();
        LegalNotice notice = new LegalNotice();
        notice.setNoticeId("NOTICE-0001");
        notice.setNoticeNo("NOTICE-NO-0001");
        notice.setApplication(loanApp);
        notice.setNoticeType("DEMAND_NOTICE");
        notice.setIssueDate(LocalDate.now());
        notice.setDueDate(LocalDate.now().plusDays(30));
        notice.setStatus("SENT");
        notice.setOfficer(officer);
        notice.setContent("Demand notice content");
        notice = noticeDao.insert(notice);
        report("LegalNotice", notice);
        readUpdateCount(notice.getNoticeId(), null, null, null,
                noticeDao::findById, noticeDao::update, noticeDao::findAll);

        // ---------- 19. Bid ----------
        BidDAO bidDao = new BidDAOImpl();
        Bid bid = new Bid();
        bid.setBidId("BID-0001");
        bid.setAuctionCase(auctionCase);
        bid.setBidder(customer);
        bid.setBidAmount(new BigDecimal("2850000.00"));
        bid.setCreatedAt(OffsetDateTime.now());
        bid = bidDao.insert(bid);
        report("Bid", bid);
        Bid foundBid = bidDao.findById(bid.getBidId());
        System.out.println("Found: " + foundBid);
        bidDao.update(foundBid);
        System.out.println("Total Bid rows: " + bidDao.findAll().size());

        // ---------- 20. Notification ----------
        NotificationDAO notifDao = new NotificationDAOImpl();
        Notification notification = new Notification();
        notification.setNotificationId("NOTIF-0001");
        notification.setUser(customer);
        notification.setTitle("Application submitted");
        notification.setBody("Your loan application has been submitted successfully.");
        notification.setChannels(new String[]{"EMAIL", "INAPP"});
        notification.setIsRead(false);
        notification.setCreatedAt(OffsetDateTime.now());
        notification = notifDao.insert(notification);
        report("Notification", notification);
        readUpdateCount(notification.getNotificationId(), null, null, null,
                notifDao::findById, notifDao::update, notifDao::findAll);

        // ---------- 21. AuditLog (BIGSERIAL id) ----------
        AuditLogDAO auditDao = new AuditLogDAOImpl();
        AuditLog audit = new AuditLog();
        audit.setEntityType("LOAN_APPLICATION");
        audit.setEntityId(loanApp.getAppId());
        audit.setAction("CREATE");
        audit.setActor(officer);
        audit.setBeforeData("{}");
        audit.setAfterData("{\"status\":\"SUBMITTED\"}");
        audit.setCreatedAt(OffsetDateTime.now());
        audit = auditDao.insert(audit);
        report("AuditLog", audit);
        AuditLog foundAudit = auditDao.findById(audit.getLogId());
        System.out.println("Found: " + foundAudit);
        auditDao.update(foundAudit);
        System.out.println("Total AuditLog rows: " + auditDao.findAll().size());

        System.out.println("\n=== All 21 inserts complete. Cleaning up in reverse order... ===\n");

        // ---------- Cleanup: delete everything in reverse dependency order ----------
        deleteQuietly("AuditLog", () -> auditDao.delete(audit.getLogId()));
        deleteQuietly("Notification", () -> notifDao.delete(notification.getNotificationId()));
        deleteQuietly("Bid", () -> bidDao.delete(bid.getBidId()));
        deleteQuietly("LegalNotice", () -> noticeDao.delete(notice.getNoticeId()));
        deleteQuietly("AuctionNote", () -> auctionNoteDao.delete(auctionNote.getNoteId()));
        deleteQuietly("AuctionCase", () -> auctionCaseDao.delete(auctionCase.getAppId()));
        deleteQuietly("PostDisbursementDocument", () -> pdDocDao.delete(pdDoc.getPdDocId()));
        deleteQuietly("ServiceRequest", () -> srDao.delete(sr.getRequestId()));
        deleteQuietly("EmiInstallment", () -> emiDao.delete(emi.getInstallmentId()));
        deleteQuietly("InsurancePolicy", () -> insDao.delete(policy.getPolicyId()));
        deleteQuietly("Disbursement", () -> disbDao.delete(disbursement.getAppId()));
        deleteQuietly("BankOfficeDecision", () -> decisionDao.delete(decision.getAppId()));
        deleteQuietly("LegalChecklistItem", () -> checklistDao.delete(checklistItem.getChecklistItemId()));
        deleteQuietly("LegalVerification", () -> legalVerDao.delete(legalVer.getAppId()));
        deleteQuietly("ApplicationDocument", () -> appDocDao.delete(appDoc.getDocumentId()));
        deleteQuietly("LoanApplication", () -> appDao.delete(loanApp.getAppId()));
        deleteQuietly("LoanDraft", () -> draftDao.delete(draft.getDraftId()));
        deleteQuietly("CustomerEmploymentProfile", () -> empDao.delete(empProfile.getUserEmail()));
        deleteQuietly("RolePermission", () -> rolePermDao.delete(rolePerm.getRole(), rolePerm.getModule()));
        deleteQuietly("LoanProduct", () -> productDao.delete(product.getProductId()));
        deleteQuietly("AppUser (officer)", () -> appUserDao.delete(officer.getEmail()));
        deleteQuietly("AppUser (customer)", () -> appUserDao.delete(customer.getEmail()));

        System.out.println("\n=== Done. ===");
    }

    // ---------- small helpers to keep the method above readable ----------

    private static void report(String label, Object entity) {
        System.out.println("Inserted " + label + ": " + entity);
    }

    @FunctionalInterface
    private interface Deleter {
        boolean delete() throws DAOException;
    }

    private static void deleteQuietly(String label, Deleter deleter) {
        try {
            boolean deleted = deleter.delete();
            System.out.println("Deleted " + label + ": " + deleted);
        } catch (DAOException e) {
            System.err.println("Could not delete " + label + ": " + e.getMessage());
        }
    }

    @FunctionalInterface
    private interface FieldSetter<T> {
        void set(T entity, String value);
    }

    @FunctionalInterface
    private interface FindById<T> {
        T find(String id) throws DAOException;
    }

    @FunctionalInterface
    private interface Update<T> {
        T update(T entity) throws DAOException;
    }

    @FunctionalInterface
    private interface FindAll<T> {
        List<T> find() throws DAOException;
    }

    /**
     * Generic findById -> (optional field tweak) -> update -> findAll/count,
     * mirroring the READ / UPDATE / READ-ALL steps every original *Main
     * class performed. Pass null for fieldName/newValue/setter to skip the
     * field tweak (e.g. for entities where updating is a no-op demo).
     */
    private static <T> void readUpdateCount(
            String id,
            String fieldName,
            String newValue,
            FieldSetter<T> setter,
            FindById<T> findById,
            Update<T> update,
            FindAll<T> findAll) throws DAOException {

        T found = findById.find(id);
        System.out.println("Found: " + found);
        if (found != null) {
            if (setter != null && newValue != null) {
                setter.set(found, newValue);
            }
            update.update(found);
            System.out.println("Updated: " + found);
        }
        System.out.println("Total rows: " + findAll.find().size());
    }
}
