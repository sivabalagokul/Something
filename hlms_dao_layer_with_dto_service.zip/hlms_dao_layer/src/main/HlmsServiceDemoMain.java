package hlms.main;

import hlms.dto.*;
import hlms.service.*;
import hlms.serviceimpl.*;
import hlms.util.DAOException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * Service-layer counterpart of {@link HlmsFullDemoMain}.
 *
 * Same idea, one layer higher: Main only ever touches hlms.dto.*DTO objects
 * and hlms.service.*Service interfaces. Nothing in this class imports
 * hlms.entity or hlms.dao -- all of that is hidden behind the *ServiceImpl
 * classes, which do the DTO &lt;-&gt; Entity conversion and delegate to the
 * existing *DAOImpl classes underneath.
 *
 * Run order and behaviour are identical to HlmsFullDemoMain:
 *   1. INSERT one row per table (21 tables), in FK-safe order, each new
 *      DTO's foreign-key id fields pointing at the id of the DTO the
 *      previous step just created.
 *   2. For each entity: findById -> update one field -> findAll (row count).
 *   3. DELETE everything just inserted, in reverse order, so the run can be
 *      repeated against your existing database without leaving demo rows
 *      behind.
 *
 * Before running:
 *   - Point src/util/DBConnection.java at your existing PostgreSQL database.
 *   - Make sure the 21 tables already exist (this class does not create
 *     schema, only rows).
 *
 * Compile / run:
 *   javac -cp .:postgresql-42.7.x.jar -d out src/entity/*.java src/dao/*.java src/util/*.java src/daoimpl/*.java src/dto/*.java src/service/*.java src/serviceimpl/*.java src/main/HlmsServiceDemoMain.java
 *   java  -cp out:postgresql-42.7.x.jar hlms.main.HlmsServiceDemoMain
 */
public class HlmsServiceDemoMain {

    public static void main(String[] args) {
        try {
            runAll();
        } catch (DAOException e) {
            System.err.println("Run aborted: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void runAll() throws DAOException {

        section("1. AppUser");
        AppUserService appUserService = new AppUserServiceImpl();

        AppUserDTO customer = new AppUserDTO();
        customer.setEmail("demo.customer@hlms.local");
        customer.setName("Demo Customer");
        customer.setMobile("9000000001");
        customer.setPasswordHash("hash-customer");
        customer.setRole("customer");
        customer.setActive(true);
        customer.setIdType("PAN");
        customer.setIdNumber("ABCDE1234F");
        customer.setPrefSms(true);
        customer.setPrefEmail(true);
        customer.setPrefInapp(true);
        customer.setCreatedAt(OffsetDateTime.now());
        customer = appUserService.create(customer);
        report("AppUser (customer)", customer);

        AppUserDTO officer = new AppUserDTO();
        officer.setEmail("demo.officer@hlms.local");
        officer.setName("Demo Officer");
        officer.setMobile("9000000002");
        officer.setPasswordHash("hash-officer");
        officer.setRole("bankoffice");
        officer.setActive(true);
        officer.setIdType("EMP_ID");
        officer.setIdNumber("EMP-001");
        officer.setPrefSms(false);
        officer.setPrefEmail(true);
        officer.setPrefInapp(true);
        officer.setCreatedAt(OffsetDateTime.now());
        officer = appUserService.create(officer);
        report("AppUser (officer)", officer);

        AppUserDTO bidder = new AppUserDTO();
        bidder.setEmail("demo.bidder@hlms.local");
        bidder.setName("Demo Bidder");
        bidder.setMobile("9000000003");
        bidder.setPasswordHash("hash-bidder");
        bidder.setRole("bidder");
        bidder.setActive(true);
        bidder.setIdType("PAN");
        bidder.setIdNumber("BIDDR5678K");
        bidder.setPrefSms(true);
        bidder.setPrefEmail(true);
        bidder.setPrefInapp(true);
        bidder.setCreatedAt(OffsetDateTime.now());
        bidder = appUserService.create(bidder);
        report("AppUser (bidder)", bidder);

        customer.setName("Demo Customer Updated");
        customer = appUserService.update(customer);
        report("AppUser (customer) after update", appUserService.findById(customer.getEmail()));
        System.out.println("AppUser count: " + appUserService.findAll().size());

        section("2. LoanProduct");
        LoanProductService loanProductService = new LoanProductServiceImpl();
        LoanProductDTO product = new LoanProductDTO();
        product.setProductId("DEMO-HP");
        product.setName("Demo Home Purchase Loan");
        product.setCategory("Home Purchase");
        product.setInterestRate(new BigDecimal("8.50"));
        product.setMaxTenureYears(30);
        product.setMaxLtv("90%");
        product.setDescription("Demo product created by the service-layer walkthrough.");
        product = loanProductService.create(product);
        report("LoanProduct", product);
        product.setDescription("Demo product (updated).");
        product = loanProductService.update(product);
        report("LoanProduct after update", loanProductService.findById(product.getProductId()));
        System.out.println("LoanProduct count: " + loanProductService.findAll().size());

        section("3. RolePermission");
        RolePermissionService rolePermissionService = new RolePermissionServiceImpl();
        RolePermissionDTO rolePermission = new RolePermissionDTO();
        rolePermission.setRole("customer");
        rolePermission.setModule("loan_application");
        rolePermission.setCanView(true);
        rolePermission.setCanAdd(true);
        rolePermission.setCanEdit(false);
        rolePermission.setCanDelete(false);
        rolePermission = rolePermissionService.create(rolePermission);
        report("RolePermission", rolePermission);
        rolePermission.setCanEdit(true);
        rolePermission = rolePermissionService.update(rolePermission);
        report("RolePermission after update", rolePermissionService.findById(rolePermission.getRole(), rolePermission.getModule()));
        System.out.println("RolePermission count: " + rolePermissionService.findAll().size());

        section("4. CustomerEmploymentProfile");
        CustomerEmploymentProfileService employmentProfileService = new CustomerEmploymentProfileServiceImpl();
        CustomerEmploymentProfileDTO employmentProfile = new CustomerEmploymentProfileDTO();
        employmentProfile.setUserEmail(customer.getEmail());
        employmentProfile.setEmploymentType("Salaried");
        employmentProfile.setEmployer("Demo Corp");
        employmentProfile.setMonthlyIncome(new BigDecimal("75000.00"));
        employmentProfile.setOtherEmis(new BigDecimal("5000.00"));
        employmentProfile.setDesiredAmount(new BigDecimal("2500000.00"));
        employmentProfile.setPan("ABCDE1234F");
        employmentProfile = employmentProfileService.create(employmentProfile);
        report("CustomerEmploymentProfile", employmentProfile);
        employmentProfile.setEmployer("Demo Corp (updated)");
        employmentProfile = employmentProfileService.update(employmentProfile);
        report("CustomerEmploymentProfile after update", employmentProfileService.findById(employmentProfile.getUserEmail()));
        System.out.println("CustomerEmploymentProfile count: " + employmentProfileService.findAll().size());

        section("5. LoanDraft");
        LoanDraftService loanDraftService = new LoanDraftServiceImpl();
        LoanDraftDTO loanDraft = new LoanDraftDTO();
        loanDraft.setDraftId("DEMO-DRAFT-001");
        loanDraft.setUserEmail(customer.getEmail());
        loanDraft.setCurrentStep(1);
        loanDraft.setSavedAt(OffsetDateTime.now());
        loanDraft.setLoanType("HP");
        loanDraft.setLoanAmount(new BigDecimal("2500000.00"));
        loanDraft.setTenureYears(20);
        loanDraft.setFormData("{}");
        loanDraft = loanDraftService.create(loanDraft);
        report("LoanDraft", loanDraft);
        loanDraft.setCurrentStep(2);
        loanDraft = loanDraftService.update(loanDraft);
        report("LoanDraft after update", loanDraftService.findById(loanDraft.getDraftId()));
        System.out.println("LoanDraft count: " + loanDraftService.findAll().size());

        section("6. LoanApplication");
        LoanApplicationService loanApplicationService = new LoanApplicationServiceImpl();
        LoanApplicationDTO application = new LoanApplicationDTO();
        application.setAppId("DEMO-APP-001");
        application.setTrackingNo("TRK-DEMO-001");
        application.setUserEmail(customer.getEmail());
        application.setProductId(product.getProductId());
        application.setLoanAmount(new BigDecimal("2500000.00"));
        application.setTenureYears(20);
        application.setPurpose("Home purchase");
        application.setInterestRate(new BigDecimal("8.50"));
        application.setStatus("Submitted");
        application.setStageIndex(0);
        application.setCreatedAt(OffsetDateTime.now());
        application.setApplicantName("Demo Customer");
        application.setApplicantMobile("9000000001");
        application.setApplicantPan("ABCDE1234F");
        application.setAddrDoorNo("12");
        application.setAddrStreet("Demo Street");
        application.setAddrCity("Chennai");
        application.setAddrState("Tamil Nadu");
        application.setAddrPincode("600001");
        application.setEmploymentType("Salaried");
        application.setEmployer("Demo Corp");
        application.setMonthlyIncome(new BigDecimal("75000.00"));
        application.setOtherEmis(new BigDecimal("5000.00"));
        application.setPropertyAddress("Demo Property Address");
        application.setPropertyType("Apartment");
        application.setPropertyValue(new BigDecimal("3000000.00"));
        application = loanApplicationService.create(application);
        report("LoanApplication", application);
        application.setStatus("Under Review");
        application = loanApplicationService.update(application);
        report("LoanApplication after update", loanApplicationService.findById(application.getAppId()));
        System.out.println("LoanApplication count: " + loanApplicationService.findAll().size());

        section("7. ApplicationDocument");
        ApplicationDocumentService applicationDocumentService = new ApplicationDocumentServiceImpl();
        ApplicationDocumentDTO document = new ApplicationDocumentDTO();
        document.setDocumentId("DEMO-DOC-001");
        document.setAppId(application.getAppId());
        document.setDocType("idProof");
        document.setFileName("id-proof.pdf");
        document.setFileSize(102400);
        document.setUploadedAt(OffsetDateTime.now());
        document.setVerificationStatus("Pending");
        document.setVerifiedByEmail(null);
        document.setVerifiedAt(null);
        document.setRemarks("Awaiting review");
        document = applicationDocumentService.create(document);
        report("ApplicationDocument", document);
        document.setVerificationStatus("Verified");
        document.setVerifiedByEmail(officer.getEmail());
        document.setVerifiedAt(OffsetDateTime.now());
        document = applicationDocumentService.update(document);
        report("ApplicationDocument after update", applicationDocumentService.findById(document.getDocumentId()));
        System.out.println("ApplicationDocument count: " + applicationDocumentService.findAll().size());

        section("8. LegalVerification");
        LegalVerificationService legalVerificationService = new LegalVerificationServiceImpl();
        LegalVerificationDTO legalVerification = new LegalVerificationDTO();
        legalVerification.setAppId(application.getAppId());
        legalVerification.setDecision("Query Raised");
        legalVerification.setDecisionDate(OffsetDateTime.now());
        legalVerification.setOfficerEmail(officer.getEmail());
        legalVerification.setRemarks("Needs sale deed copy");
        legalVerification = legalVerificationService.create(legalVerification);
        report("LegalVerification", legalVerification);
        legalVerification.setDecision("Approved");
        legalVerification = legalVerificationService.update(legalVerification);
        report("LegalVerification after update", legalVerificationService.findById(legalVerification.getAppId()));
        System.out.println("LegalVerification count: " + legalVerificationService.findAll().size());

        section("9. LegalChecklistItem");
        LegalChecklistItemService checklistItemService = new LegalChecklistItemServiceImpl();
        LegalChecklistItemDTO checklistItem = new LegalChecklistItemDTO();
        checklistItem.setChecklistItemId("DEMO-CHK-001");
        checklistItem.setAppId(application.getAppId());
        checklistItem.setChecklistKey("titleDeed");
        checklistItem.setStatus("Pending");
        checklistItem = checklistItemService.create(checklistItem);
        report("LegalChecklistItem", checklistItem);
        checklistItem.setStatus("Verified");
        checklistItem = checklistItemService.update(checklistItem);
        report("LegalChecklistItem after update", checklistItemService.findById(checklistItem.getChecklistItemId()));
        System.out.println("LegalChecklistItem count: " + checklistItemService.findAll().size());

        section("10. BankOfficeDecision");
        BankOfficeDecisionService bankOfficeDecisionService = new BankOfficeDecisionServiceImpl();
        BankOfficeDecisionDTO bankDecision = new BankOfficeDecisionDTO();
        bankDecision.setAppId(application.getAppId());
        bankDecision.setDecision("Approved");
        bankDecision.setOfficerEmail(officer.getEmail());
        bankDecision.setDecisionDate(OffsetDateTime.now());
        bankDecision.setReason("Meets eligibility criteria");
        bankDecision.setRemarks("Proceed to disbursement");
        bankDecision = bankOfficeDecisionService.create(bankDecision);
        report("BankOfficeDecision", bankDecision);
        bankDecision.setRemarks("Proceed to disbursement (confirmed)");
        bankDecision = bankOfficeDecisionService.update(bankDecision);
        report("BankOfficeDecision after update", bankOfficeDecisionService.findById(bankDecision.getAppId()));
        System.out.println("BankOfficeDecision count: " + bankOfficeDecisionService.findAll().size());

        section("11. Disbursement");
        DisbursementService disbursementService = new DisbursementServiceImpl();
        DisbursementDTO disbursement = new DisbursementDTO();
        disbursement.setAppId(application.getAppId());
        disbursement.setDisbursedDate(OffsetDateTime.now());
        disbursement.setAmount(new BigDecimal("2500000.00"));
        disbursement.setRefNo("REF-DEMO-001");
        disbursement.setMode("NEFT");
        disbursement.setBankDetails("HDFC Bank - 1234");
        disbursement = disbursementService.create(disbursement);
        report("Disbursement", disbursement);
        disbursement.setMode("RTGS");
        disbursement = disbursementService.update(disbursement);
        report("Disbursement after update", disbursementService.findById(disbursement.getAppId()));
        System.out.println("Disbursement count: " + disbursementService.findAll().size());

        section("12. InsurancePolicy");
        InsurancePolicyService insurancePolicyService = new InsurancePolicyServiceImpl();
        InsurancePolicyDTO policy = new InsurancePolicyDTO();
        policy.setPolicyId("DEMO-POL-001");
        policy.setAppId(application.getAppId());
        policy.setPolicyType("property");
        policy.setStatus("Active");
        policy.setValidTill(LocalDate.now().plusYears(1));
        policy = insurancePolicyService.create(policy);
        report("InsurancePolicy", policy);
        policy.setStatus("Renewed");
        policy = insurancePolicyService.update(policy);
        report("InsurancePolicy after update", insurancePolicyService.findById(policy.getPolicyId()));
        System.out.println("InsurancePolicy count: " + insurancePolicyService.findAll().size());

        section("13. EmiInstallment");
        EmiInstallmentService emiInstallmentService = new EmiInstallmentServiceImpl();
        EmiInstallmentDTO installment = new EmiInstallmentDTO();
        installment.setInstallmentId("DEMO-EMI-001");
        installment.setAppId(application.getAppId());
        installment.setInstallmentNo(1);
        installment.setDueDate(LocalDate.now().plusMonths(1));
        installment.setEmiAmount(new BigDecimal("21500.00"));
        installment.setPrincipalComponent(new BigDecimal("15000.00"));
        installment.setInterestComponent(new BigDecimal("6500.00"));
        installment.setClosingBalance(new BigDecimal("2485000.00"));
        installment.setStatus("Due");
        installment.setPaidDate(null);
        installment = emiInstallmentService.create(installment);
        report("EmiInstallment", installment);
        installment.setStatus("Paid");
        installment.setPaidDate(LocalDate.now());
        installment = emiInstallmentService.update(installment);
        report("EmiInstallment after update", emiInstallmentService.findById(installment.getInstallmentId()));
        System.out.println("EmiInstallment count: " + emiInstallmentService.findAll().size());

        section("14. ServiceRequest");
        ServiceRequestService serviceRequestService = new ServiceRequestServiceImpl();
        ServiceRequestDTO serviceRequest = new ServiceRequestDTO();
        serviceRequest.setRequestId("DEMO-SR-001");
        serviceRequest.setRefNo("SR-REF-001");
        serviceRequest.setAppId(application.getAppId());
        serviceRequest.setUserEmail(customer.getEmail());
        serviceRequest.setRequestType("Address Change");
        serviceRequest.setDescription("Update mailing address");
        serviceRequest.setStatus("Requested");
        serviceRequest.setCreatedAt(OffsetDateTime.now());
        serviceRequest = serviceRequestService.create(serviceRequest);
        report("ServiceRequest", serviceRequest);
        serviceRequest.setStatus("Resolved");
        serviceRequest = serviceRequestService.update(serviceRequest);
        report("ServiceRequest after update", serviceRequestService.findById(serviceRequest.getRequestId()));
        System.out.println("ServiceRequest count: " + serviceRequestService.findAll().size());

        section("15. PostDisbursementDocument");
        PostDisbursementDocumentService pdDocService = new PostDisbursementDocumentServiceImpl();
        PostDisbursementDocumentDTO pdDoc = new PostDisbursementDocumentDTO();
        pdDoc.setPdDocId("DEMO-PDD-001");
        pdDoc.setAppId(application.getAppId());
        pdDoc.setDocType("Property Tax Receipt");
        pdDoc.setFileName("tax-receipt.pdf");
        pdDoc.setFileSize(51200);
        pdDoc.setNote("FY 2025-26 receipt");
        pdDoc.setStatus("Pending");
        pdDoc.setUploadedAt(OffsetDateTime.now());
        pdDoc.setVerifiedByEmail(null);
        pdDoc.setVerifiedAt(null);
        pdDoc.setRemarks("Awaiting review");
        pdDoc = pdDocService.create(pdDoc);
        report("PostDisbursementDocument", pdDoc);
        pdDoc.setStatus("Verified");
        pdDoc.setVerifiedByEmail(officer.getEmail());
        pdDoc.setVerifiedAt(OffsetDateTime.now());
        pdDoc = pdDocService.update(pdDoc);
        report("PostDisbursementDocument after update", pdDocService.findById(pdDoc.getPdDocId()));
        System.out.println("PostDisbursementDocument count: " + pdDocService.findAll().size());

        section("16. AuctionCase");
        AuctionCaseService auctionCaseService = new AuctionCaseServiceImpl();
        AuctionCaseDTO auctionCase = new AuctionCaseDTO();
        auctionCase.setAppId(application.getAppId());
        auctionCase.setStage("Notice Issued");
        auctionCase.setNoticeDate(LocalDate.now());
        auctionCase.setNoticeDueDate(LocalDate.now().plusDays(60));
        auctionCase.setDemandAmount(new BigDecimal("2450000.00"));
        auctionCase.setPossessionDate(null);
        auctionCase.setAuctionDate(null);
        auctionCase.setReservePrice(new BigDecimal("2800000.00"));
        auctionCase = auctionCaseService.create(auctionCase);
        report("AuctionCase", auctionCase);
        auctionCase.setStage("Auction Scheduled");
        auctionCase.setAuctionDate(LocalDate.now().plusDays(90));
        auctionCase = auctionCaseService.update(auctionCase);
        report("AuctionCase after update", auctionCaseService.findById(auctionCase.getAppId()));
        System.out.println("AuctionCase count: " + auctionCaseService.findAll().size());

        section("17. AuctionNote");
        AuctionNoteService auctionNoteService = new AuctionNoteServiceImpl();
        AuctionNoteDTO auctionNote = new AuctionNoteDTO();
        auctionNote.setNoteId("DEMO-NOTE-001");
        auctionNote.setAppId(auctionCase.getAppId());
        auctionNote.setNoteDate(OffsetDateTime.now());
        auctionNote.setNoteText("Possession notice served to occupants.");
        auctionNote = auctionNoteService.create(auctionNote);
        report("AuctionNote", auctionNote);
        auctionNote.setNoteText("Possession notice served to occupants (follow-up added).");
        auctionNote = auctionNoteService.update(auctionNote);
        report("AuctionNote after update", auctionNoteService.findById(auctionNote.getNoteId()));
        System.out.println("AuctionNote count: " + auctionNoteService.findAll().size());

        section("18. LegalNotice");
        LegalNoticeService legalNoticeService = new LegalNoticeServiceImpl();
        LegalNoticeDTO legalNotice = new LegalNoticeDTO();
        legalNotice.setNoticeId("DEMO-LN-001");
        legalNotice.setNoticeNo("NOTICE-DEMO-001");
        legalNotice.setAppId(application.getAppId());
        legalNotice.setNoticeType("SARFAESI 13(2)");
        legalNotice.setIssueDate(LocalDate.now());
        legalNotice.setDueDate(LocalDate.now().plusDays(60));
        legalNotice.setStatus("Active");
        legalNotice.setOfficerEmail(officer.getEmail());
        legalNotice.setContent("Demand notice under Section 13(2) of the SARFAESI Act.");
        legalNotice = legalNoticeService.create(legalNotice);
        report("LegalNotice", legalNotice);
        legalNotice.setStatus("Closed");
        legalNotice = legalNoticeService.update(legalNotice);
        report("LegalNotice after update", legalNoticeService.findById(legalNotice.getNoticeId()));
        System.out.println("LegalNotice count: " + legalNoticeService.findAll().size());

        section("19. Bid");
        BidService bidService = new BidServiceImpl();
        BidDTO bid = new BidDTO();
        bid.setBidId("DEMO-BID-001");
        bid.setAppId(auctionCase.getAppId());
        bid.setBidderEmail(bidder.getEmail());
        bid.setBidAmount(new BigDecimal("2850000.00"));
        bid.setCreatedAt(OffsetDateTime.now());
        bid = bidService.create(bid);
        report("Bid", bid);
        bid.setBidAmount(new BigDecimal("2900000.00"));
        bid = bidService.update(bid);
        report("Bid after update", bidService.findById(bid.getBidId()));
        System.out.println("Bid count: " + bidService.findAll().size());

        section("20. Notification");
        NotificationService notificationService = new NotificationServiceImpl();
        NotificationDTO notification = new NotificationDTO();
        notification.setNotificationId("DEMO-NOTIF-001");
        notification.setUserEmail(customer.getEmail());
        notification.setTitle("Application submitted");
        notification.setBody("Your loan application DEMO-APP-001 has been submitted.");
        notification.setChannels(new String[]{"inapp", "email"});
        notification.setIsRead(false);
        notification.setCreatedAt(OffsetDateTime.now());
        notification = notificationService.create(notification);
        report("Notification", notification);
        notification.setIsRead(true);
        notification = notificationService.update(notification);
        report("Notification after update", notificationService.findById(notification.getNotificationId()));
        System.out.println("Notification count: " + notificationService.findAll().size());

        section("21. AuditLog");
        AuditLogService auditLogService = new AuditLogServiceImpl();
        AuditLogDTO auditLog = new AuditLogDTO();
        auditLog.setEntityType("LoanApplication");
        auditLog.setEntityId(application.getAppId());
        auditLog.setAction("CREATE");
        auditLog.setActorEmail(customer.getEmail());
        auditLog.setBeforeData(null);
        auditLog.setAfterData("{\"status\":\"Submitted\"}");
        auditLog.setCreatedAt(OffsetDateTime.now());
        auditLog = auditLogService.create(auditLog);
        report("AuditLog", auditLog);
        auditLog.setAction("UPDATE");
        auditLog = auditLogService.update(auditLog);
        report("AuditLog after update", auditLogService.findById(auditLog.getLogId()));
        System.out.println("AuditLog count: " + auditLogService.findAll().size());

        section("Cleanup (reverse order delete)");
        auditLogService.delete(auditLog.getLogId());
        notificationService.delete(notification.getNotificationId());
        bidService.delete(bid.getBidId());
        legalNoticeService.delete(legalNotice.getNoticeId());
        auctionNoteService.delete(auctionNote.getNoteId());
        auctionCaseService.delete(auctionCase.getAppId());
        pdDocService.delete(pdDoc.getPdDocId());
        serviceRequestService.delete(serviceRequest.getRequestId());
        emiInstallmentService.delete(installment.getInstallmentId());
        insurancePolicyService.delete(policy.getPolicyId());
        disbursementService.delete(disbursement.getAppId());
        bankOfficeDecisionService.delete(bankDecision.getAppId());
        checklistItemService.delete(checklistItem.getChecklistItemId());
        legalVerificationService.delete(legalVerification.getAppId());
        applicationDocumentService.delete(document.getDocumentId());
        loanApplicationService.delete(application.getAppId());
        loanDraftService.delete(loanDraft.getDraftId());
        employmentProfileService.delete(employmentProfile.getUserEmail());
        rolePermissionService.delete(rolePermission.getRole(), rolePermission.getModule());
        loanProductService.delete(product.getProductId());
        appUserService.delete(bidder.getEmail());
        appUserService.delete(officer.getEmail());
        appUserService.delete(customer.getEmail());
        System.out.println("All demo rows deleted.");
        System.out.println("\nService-layer demo run completed successfully.");
    }

    private static void report(String label, Object dto) {
        System.out.println("[" + label + "] " + dto);
    }

    private static void section(String title) {
        System.out.println("\n---------- " + title + " ----------");
    }
}
