package hlms.service;

import hlms.dto.AppUserDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for AppUser. Sits between Main (or any other caller) and
 * AppUserDAO: everything in and out of this layer is a AppUserDTO, never a
 * hlms.entity.AppUser.
 */
public interface AppUserService {

    AppUserDTO create(AppUserDTO dto) throws DAOException;

    AppUserDTO update(AppUserDTO dto) throws DAOException;

    boolean delete(String email) throws DAOException;

    AppUserDTO findById(String email) throws DAOException;

    List<AppUserDTO> findAll() throws DAOException;
}
