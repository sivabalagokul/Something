package hlms.service;

import hlms.dto.ApplicationDocumentDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for ApplicationDocument. Sits between Main (or any other caller) and
 * ApplicationDocumentDAO: everything in and out of this layer is a ApplicationDocumentDTO, never a
 * hlms.entity.ApplicationDocument.
 */
public interface ApplicationDocumentService {

    ApplicationDocumentDTO create(ApplicationDocumentDTO dto) throws DAOException;

    ApplicationDocumentDTO update(ApplicationDocumentDTO dto) throws DAOException;

    boolean delete(String documentId) throws DAOException;

    ApplicationDocumentDTO findById(String documentId) throws DAOException;

    List<ApplicationDocumentDTO> findAll() throws DAOException;
}
