package hlms.service;

import hlms.dto.AuctionCaseDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for AuctionCase. Sits between Main (or any other caller) and
 * AuctionCaseDAO: everything in and out of this layer is a AuctionCaseDTO, never a
 * hlms.entity.AuctionCase.
 */
public interface AuctionCaseService {

    AuctionCaseDTO create(AuctionCaseDTO dto) throws DAOException;

    AuctionCaseDTO update(AuctionCaseDTO dto) throws DAOException;

    boolean delete(String appId) throws DAOException;

    AuctionCaseDTO findById(String appId) throws DAOException;

    List<AuctionCaseDTO> findAll() throws DAOException;
}
