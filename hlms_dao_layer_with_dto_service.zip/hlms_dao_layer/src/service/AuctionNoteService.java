package hlms.service;

import hlms.dto.AuctionNoteDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for AuctionNote. Sits between Main (or any other caller) and
 * AuctionNoteDAO: everything in and out of this layer is a AuctionNoteDTO, never a
 * hlms.entity.AuctionNote.
 */
public interface AuctionNoteService {

    AuctionNoteDTO create(AuctionNoteDTO dto) throws DAOException;

    AuctionNoteDTO update(AuctionNoteDTO dto) throws DAOException;

    boolean delete(String noteId) throws DAOException;

    AuctionNoteDTO findById(String noteId) throws DAOException;

    List<AuctionNoteDTO> findAll() throws DAOException;
}
