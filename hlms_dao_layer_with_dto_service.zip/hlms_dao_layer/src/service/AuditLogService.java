package hlms.service;

import hlms.dto.AuditLogDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for AuditLog. Sits between Main (or any other caller) and
 * AuditLogDAO: everything in and out of this layer is a AuditLogDTO, never a
 * hlms.entity.AuditLog.
 */
public interface AuditLogService {

    AuditLogDTO create(AuditLogDTO dto) throws DAOException;

    AuditLogDTO update(AuditLogDTO dto) throws DAOException;

    boolean delete(Long logId) throws DAOException;

    AuditLogDTO findById(Long logId) throws DAOException;

    List<AuditLogDTO> findAll() throws DAOException;
}
