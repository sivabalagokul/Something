package hlms.service;

import hlms.dto.BankOfficeDecisionDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for BankOfficeDecision. Sits between Main (or any other caller) and
 * BankOfficeDecisionDAO: everything in and out of this layer is a BankOfficeDecisionDTO, never a
 * hlms.entity.BankOfficeDecision.
 */
public interface BankOfficeDecisionService {

    BankOfficeDecisionDTO create(BankOfficeDecisionDTO dto) throws DAOException;

    BankOfficeDecisionDTO update(BankOfficeDecisionDTO dto) throws DAOException;

    boolean delete(String appId) throws DAOException;

    BankOfficeDecisionDTO findById(String appId) throws DAOException;

    List<BankOfficeDecisionDTO> findAll() throws DAOException;
}
