package hlms.service;

import hlms.dto.BidDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for Bid. Sits between Main (or any other caller) and
 * BidDAO: everything in and out of this layer is a BidDTO, never a
 * hlms.entity.Bid.
 */
public interface BidService {

    BidDTO create(BidDTO dto) throws DAOException;

    BidDTO update(BidDTO dto) throws DAOException;

    boolean delete(String bidId) throws DAOException;

    BidDTO findById(String bidId) throws DAOException;

    List<BidDTO> findAll() throws DAOException;
}
