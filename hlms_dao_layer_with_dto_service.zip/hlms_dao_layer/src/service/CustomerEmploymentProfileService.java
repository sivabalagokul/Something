package hlms.service;

import hlms.dto.CustomerEmploymentProfileDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for CustomerEmploymentProfile. Sits between Main (or any other caller) and
 * CustomerEmploymentProfileDAO: everything in and out of this layer is a CustomerEmploymentProfileDTO, never a
 * hlms.entity.CustomerEmploymentProfile.
 */
public interface CustomerEmploymentProfileService {

    CustomerEmploymentProfileDTO create(CustomerEmploymentProfileDTO dto) throws DAOException;

    CustomerEmploymentProfileDTO update(CustomerEmploymentProfileDTO dto) throws DAOException;

    boolean delete(String userEmail) throws DAOException;

    CustomerEmploymentProfileDTO findById(String userEmail) throws DAOException;

    List<CustomerEmploymentProfileDTO> findAll() throws DAOException;
}
