package hlms.service;

import hlms.dto.DisbursementDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for Disbursement. Sits between Main (or any other caller) and
 * DisbursementDAO: everything in and out of this layer is a DisbursementDTO, never a
 * hlms.entity.Disbursement.
 */
public interface DisbursementService {

    DisbursementDTO create(DisbursementDTO dto) throws DAOException;

    DisbursementDTO update(DisbursementDTO dto) throws DAOException;

    boolean delete(String appId) throws DAOException;

    DisbursementDTO findById(String appId) throws DAOException;

    List<DisbursementDTO> findAll() throws DAOException;
}
