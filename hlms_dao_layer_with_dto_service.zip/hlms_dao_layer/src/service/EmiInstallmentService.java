package hlms.service;

import hlms.dto.EmiInstallmentDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for EmiInstallment. Sits between Main (or any other caller) and
 * EmiInstallmentDAO: everything in and out of this layer is a EmiInstallmentDTO, never a
 * hlms.entity.EmiInstallment.
 */
public interface EmiInstallmentService {

    EmiInstallmentDTO create(EmiInstallmentDTO dto) throws DAOException;

    EmiInstallmentDTO update(EmiInstallmentDTO dto) throws DAOException;

    boolean delete(String installmentId) throws DAOException;

    EmiInstallmentDTO findById(String installmentId) throws DAOException;

    List<EmiInstallmentDTO> findAll() throws DAOException;
}
