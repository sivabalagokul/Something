package hlms.service;

import hlms.dto.InsurancePolicyDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for InsurancePolicy. Sits between Main (or any other caller) and
 * InsurancePolicyDAO: everything in and out of this layer is a InsurancePolicyDTO, never a
 * hlms.entity.InsurancePolicy.
 */
public interface InsurancePolicyService {

    InsurancePolicyDTO create(InsurancePolicyDTO dto) throws DAOException;

    InsurancePolicyDTO update(InsurancePolicyDTO dto) throws DAOException;

    boolean delete(String policyId) throws DAOException;

    InsurancePolicyDTO findById(String policyId) throws DAOException;

    List<InsurancePolicyDTO> findAll() throws DAOException;
}
