package hlms.service;

import hlms.dto.LegalChecklistItemDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for LegalChecklistItem. Sits between Main (or any other caller) and
 * LegalChecklistItemDAO: everything in and out of this layer is a LegalChecklistItemDTO, never a
 * hlms.entity.LegalChecklistItem.
 */
public interface LegalChecklistItemService {

    LegalChecklistItemDTO create(LegalChecklistItemDTO dto) throws DAOException;

    LegalChecklistItemDTO update(LegalChecklistItemDTO dto) throws DAOException;

    boolean delete(String checklistItemId) throws DAOException;

    LegalChecklistItemDTO findById(String checklistItemId) throws DAOException;

    List<LegalChecklistItemDTO> findAll() throws DAOException;
}
