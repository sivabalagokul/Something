package hlms.service;

import hlms.dto.LegalNoticeDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for LegalNotice. Sits between Main (or any other caller) and
 * LegalNoticeDAO: everything in and out of this layer is a LegalNoticeDTO, never a
 * hlms.entity.LegalNotice.
 */
public interface LegalNoticeService {

    LegalNoticeDTO create(LegalNoticeDTO dto) throws DAOException;

    LegalNoticeDTO update(LegalNoticeDTO dto) throws DAOException;

    boolean delete(String noticeId) throws DAOException;

    LegalNoticeDTO findById(String noticeId) throws DAOException;

    List<LegalNoticeDTO> findAll() throws DAOException;
}
