package hlms.service;

import hlms.dto.LegalVerificationDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for LegalVerification. Sits between Main (or any other caller) and
 * LegalVerificationDAO: everything in and out of this layer is a LegalVerificationDTO, never a
 * hlms.entity.LegalVerification.
 */
public interface LegalVerificationService {

    LegalVerificationDTO create(LegalVerificationDTO dto) throws DAOException;

    LegalVerificationDTO update(LegalVerificationDTO dto) throws DAOException;

    boolean delete(String appId) throws DAOException;

    LegalVerificationDTO findById(String appId) throws DAOException;

    List<LegalVerificationDTO> findAll() throws DAOException;
}
