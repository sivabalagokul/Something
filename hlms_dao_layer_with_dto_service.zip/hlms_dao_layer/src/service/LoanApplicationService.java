package hlms.service;

import hlms.dto.LoanApplicationDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for LoanApplication. Sits between Main (or any other caller) and
 * LoanApplicationDAO: everything in and out of this layer is a LoanApplicationDTO, never a
 * hlms.entity.LoanApplication.
 */
public interface LoanApplicationService {

    LoanApplicationDTO create(LoanApplicationDTO dto) throws DAOException;

    LoanApplicationDTO update(LoanApplicationDTO dto) throws DAOException;

    boolean delete(String appId) throws DAOException;

    LoanApplicationDTO findById(String appId) throws DAOException;

    List<LoanApplicationDTO> findAll() throws DAOException;
}
