package hlms.service;

import hlms.dto.LoanDraftDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for LoanDraft. Sits between Main (or any other caller) and
 * LoanDraftDAO: everything in and out of this layer is a LoanDraftDTO, never a
 * hlms.entity.LoanDraft.
 */
public interface LoanDraftService {

    LoanDraftDTO create(LoanDraftDTO dto) throws DAOException;

    LoanDraftDTO update(LoanDraftDTO dto) throws DAOException;

    boolean delete(String draftId) throws DAOException;

    LoanDraftDTO findById(String draftId) throws DAOException;

    List<LoanDraftDTO> findAll() throws DAOException;
}
