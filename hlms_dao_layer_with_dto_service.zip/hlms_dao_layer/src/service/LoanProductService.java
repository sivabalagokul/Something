package hlms.service;

import hlms.dto.LoanProductDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for LoanProduct. Sits between Main (or any other caller) and
 * LoanProductDAO: everything in and out of this layer is a LoanProductDTO, never a
 * hlms.entity.LoanProduct.
 */
public interface LoanProductService {

    LoanProductDTO create(LoanProductDTO dto) throws DAOException;

    LoanProductDTO update(LoanProductDTO dto) throws DAOException;

    boolean delete(String productId) throws DAOException;

    LoanProductDTO findById(String productId) throws DAOException;

    List<LoanProductDTO> findAll() throws DAOException;
}
