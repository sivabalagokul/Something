package hlms.service;

import hlms.dto.NotificationDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for Notification. Sits between Main (or any other caller) and
 * NotificationDAO: everything in and out of this layer is a NotificationDTO, never a
 * hlms.entity.Notification.
 */
public interface NotificationService {

    NotificationDTO create(NotificationDTO dto) throws DAOException;

    NotificationDTO update(NotificationDTO dto) throws DAOException;

    boolean delete(String notificationId) throws DAOException;

    NotificationDTO findById(String notificationId) throws DAOException;

    List<NotificationDTO> findAll() throws DAOException;
}
