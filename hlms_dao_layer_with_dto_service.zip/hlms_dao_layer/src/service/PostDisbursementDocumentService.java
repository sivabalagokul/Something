package hlms.service;

import hlms.dto.PostDisbursementDocumentDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for PostDisbursementDocument. Sits between Main (or any other caller) and
 * PostDisbursementDocumentDAO: everything in and out of this layer is a PostDisbursementDocumentDTO, never a
 * hlms.entity.PostDisbursementDocument.
 */
public interface PostDisbursementDocumentService {

    PostDisbursementDocumentDTO create(PostDisbursementDocumentDTO dto) throws DAOException;

    PostDisbursementDocumentDTO update(PostDisbursementDocumentDTO dto) throws DAOException;

    boolean delete(String pdDocId) throws DAOException;

    PostDisbursementDocumentDTO findById(String pdDocId) throws DAOException;

    List<PostDisbursementDocumentDTO> findAll() throws DAOException;
}
