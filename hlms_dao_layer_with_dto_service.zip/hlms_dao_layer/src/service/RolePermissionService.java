package hlms.service;

import hlms.dto.RolePermissionDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for RolePermission. Sits between Main (or any other caller) and
 * RolePermissionDAO: everything in and out of this layer is a RolePermissionDTO, never a
 * hlms.entity.RolePermission.
 */
public interface RolePermissionService {

    RolePermissionDTO create(RolePermissionDTO dto) throws DAOException;

    RolePermissionDTO update(RolePermissionDTO dto) throws DAOException;

    boolean delete(String role, String module) throws DAOException;

    RolePermissionDTO findById(String role, String module) throws DAOException;

    List<RolePermissionDTO> findAll() throws DAOException;
}
