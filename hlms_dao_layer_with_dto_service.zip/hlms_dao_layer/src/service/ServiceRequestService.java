package hlms.service;

import hlms.dto.ServiceRequestDTO;
import hlms.util.DAOException;
import java.util.List;

/**
 * Service contract for ServiceRequest. Sits between Main (or any other caller) and
 * ServiceRequestDAO: everything in and out of this layer is a ServiceRequestDTO, never a
 * hlms.entity.ServiceRequest.
 */
public interface ServiceRequestService {

    ServiceRequestDTO create(ServiceRequestDTO dto) throws DAOException;

    ServiceRequestDTO update(ServiceRequestDTO dto) throws DAOException;

    boolean delete(String requestId) throws DAOException;

    ServiceRequestDTO findById(String requestId) throws DAOException;

    List<ServiceRequestDTO> findAll() throws DAOException;
}
