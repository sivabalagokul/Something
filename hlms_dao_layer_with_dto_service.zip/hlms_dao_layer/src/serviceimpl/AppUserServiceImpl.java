package hlms.serviceimpl;

import hlms.dao.AppUserDAO;
import hlms.daoimpl.AppUserDAOImpl;
import hlms.dto.AppUserDTO;
import hlms.entity.*;
import hlms.service.AppUserService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of AppUserService. Converts AppUserDTO <-> hlms.entity.AppUser
 * and delegates persistence to AppUserDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how AppUserDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class AppUserServiceImpl implements AppUserService {

    private final AppUserDAO dao;

    public AppUserServiceImpl() {
        this.dao = new AppUserDAOImpl();
    }

    public AppUserServiceImpl(AppUserDAO dao) {
        this.dao = dao;
    }

    @Override
    public AppUserDTO create(AppUserDTO dto) throws DAOException {
        AppUser entity = toEntity(dto);
        AppUser saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public AppUserDTO update(AppUserDTO dto) throws DAOException {
        AppUser entity = toEntity(dto);
        AppUser saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String email) throws DAOException {
        return dao.delete(email);
    }

    @Override
    public AppUserDTO findById(String email) throws DAOException {
        AppUser entity = dao.findById(email);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<AppUserDTO> findAll() throws DAOException {
        List<AppUser> entities = dao.findAll();
        List<AppUserDTO> result = new ArrayList<>();
        for (AppUser entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private AppUser toEntity(AppUserDTO dto) {
        AppUser entity = new AppUser();
        entity.setEmail(dto.getEmail());
        entity.setName(dto.getName());
        entity.setMobile(dto.getMobile());
        entity.setPasswordHash(dto.getPasswordHash());
        entity.setRole(dto.getRole());
        entity.setActive(dto.getActive());
        entity.setIdType(dto.getIdType());
        entity.setIdNumber(dto.getIdNumber());
        entity.setPrefSms(dto.getPrefSms());
        entity.setPrefEmail(dto.getPrefEmail());
        entity.setPrefInapp(dto.getPrefInapp());
        entity.setCreatedAt(dto.getCreatedAt());
        return entity;
    }

    private AppUserDTO toDto(AppUser entity) {
        AppUserDTO dto = new AppUserDTO();
        dto.setEmail(entity.getEmail());
        dto.setName(entity.getName());
        dto.setMobile(entity.getMobile());
        dto.setPasswordHash(entity.getPasswordHash());
        dto.setRole(entity.getRole());
        dto.setActive(entity.getActive());
        dto.setIdType(entity.getIdType());
        dto.setIdNumber(entity.getIdNumber());
        dto.setPrefSms(entity.getPrefSms());
        dto.setPrefEmail(entity.getPrefEmail());
        dto.setPrefInapp(entity.getPrefInapp());
        dto.setCreatedAt(entity.getCreatedAt());
        return dto;
    }
}
