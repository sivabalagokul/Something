package hlms.serviceimpl;

import hlms.dao.ApplicationDocumentDAO;
import hlms.daoimpl.ApplicationDocumentDAOImpl;
import hlms.dto.ApplicationDocumentDTO;
import hlms.entity.*;
import hlms.service.ApplicationDocumentService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of ApplicationDocumentService. Converts ApplicationDocumentDTO <-> hlms.entity.ApplicationDocument
 * and delegates persistence to ApplicationDocumentDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how ApplicationDocumentDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class ApplicationDocumentServiceImpl implements ApplicationDocumentService {

    private final ApplicationDocumentDAO dao;

    public ApplicationDocumentServiceImpl() {
        this.dao = new ApplicationDocumentDAOImpl();
    }

    public ApplicationDocumentServiceImpl(ApplicationDocumentDAO dao) {
        this.dao = dao;
    }

    @Override
    public ApplicationDocumentDTO create(ApplicationDocumentDTO dto) throws DAOException {
        ApplicationDocument entity = toEntity(dto);
        ApplicationDocument saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public ApplicationDocumentDTO update(ApplicationDocumentDTO dto) throws DAOException {
        ApplicationDocument entity = toEntity(dto);
        ApplicationDocument saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String documentId) throws DAOException {
        return dao.delete(documentId);
    }

    @Override
    public ApplicationDocumentDTO findById(String documentId) throws DAOException {
        ApplicationDocument entity = dao.findById(documentId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<ApplicationDocumentDTO> findAll() throws DAOException {
        List<ApplicationDocument> entities = dao.findAll();
        List<ApplicationDocumentDTO> result = new ArrayList<>();
        for (ApplicationDocument entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private ApplicationDocument toEntity(ApplicationDocumentDTO dto) {
        ApplicationDocument entity = new ApplicationDocument();
        entity.setDocumentId(dto.getDocumentId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setDocType(dto.getDocType());
        entity.setFileName(dto.getFileName());
        entity.setFileSize(dto.getFileSize());
        entity.setUploadedAt(dto.getUploadedAt());
        entity.setVerificationStatus(dto.getVerificationStatus());
        if (dto.getVerifiedByEmail() != null) {
            AppUser verifiedByRef = new AppUser();
            verifiedByRef.setEmail(dto.getVerifiedByEmail());
            entity.setVerifiedBy(verifiedByRef);
        }
        entity.setVerifiedAt(dto.getVerifiedAt());
        entity.setRemarks(dto.getRemarks());
        return entity;
    }

    private ApplicationDocumentDTO toDto(ApplicationDocument entity) {
        ApplicationDocumentDTO dto = new ApplicationDocumentDTO();
        dto.setDocumentId(entity.getDocumentId());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setDocType(entity.getDocType());
        dto.setFileName(entity.getFileName());
        dto.setFileSize(entity.getFileSize());
        dto.setUploadedAt(entity.getUploadedAt());
        dto.setVerificationStatus(entity.getVerificationStatus());
        dto.setVerifiedByEmail(entity.getVerifiedBy() == null ? null : entity.getVerifiedBy().getEmail());
        dto.setVerifiedAt(entity.getVerifiedAt());
        dto.setRemarks(entity.getRemarks());
        return dto;
    }
}
