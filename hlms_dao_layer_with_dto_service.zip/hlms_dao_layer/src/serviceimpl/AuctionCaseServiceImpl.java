package hlms.serviceimpl;

import hlms.dao.AuctionCaseDAO;
import hlms.daoimpl.AuctionCaseDAOImpl;
import hlms.dto.AuctionCaseDTO;
import hlms.entity.*;
import hlms.service.AuctionCaseService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of AuctionCaseService. Converts AuctionCaseDTO <-> hlms.entity.AuctionCase
 * and delegates persistence to AuctionCaseDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how AuctionCaseDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class AuctionCaseServiceImpl implements AuctionCaseService {

    private final AuctionCaseDAO dao;

    public AuctionCaseServiceImpl() {
        this.dao = new AuctionCaseDAOImpl();
    }

    public AuctionCaseServiceImpl(AuctionCaseDAO dao) {
        this.dao = dao;
    }

    @Override
    public AuctionCaseDTO create(AuctionCaseDTO dto) throws DAOException {
        AuctionCase entity = toEntity(dto);
        AuctionCase saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public AuctionCaseDTO update(AuctionCaseDTO dto) throws DAOException {
        AuctionCase entity = toEntity(dto);
        AuctionCase saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        return dao.delete(appId);
    }

    @Override
    public AuctionCaseDTO findById(String appId) throws DAOException {
        AuctionCase entity = dao.findById(appId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<AuctionCaseDTO> findAll() throws DAOException {
        List<AuctionCase> entities = dao.findAll();
        List<AuctionCaseDTO> result = new ArrayList<>();
        for (AuctionCase entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private AuctionCase toEntity(AuctionCaseDTO dto) {
        AuctionCase entity = new AuctionCase();
        entity.setAppId(dto.getAppId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setStage(dto.getStage());
        entity.setNoticeDate(dto.getNoticeDate());
        entity.setNoticeDueDate(dto.getNoticeDueDate());
        entity.setDemandAmount(dto.getDemandAmount());
        entity.setPossessionDate(dto.getPossessionDate());
        entity.setAuctionDate(dto.getAuctionDate());
        entity.setReservePrice(dto.getReservePrice());
        return entity;
    }

    private AuctionCaseDTO toDto(AuctionCase entity) {
        AuctionCaseDTO dto = new AuctionCaseDTO();
        dto.setAppId(entity.getAppId());
        dto.setStage(entity.getStage());
        dto.setNoticeDate(entity.getNoticeDate());
        dto.setNoticeDueDate(entity.getNoticeDueDate());
        dto.setDemandAmount(entity.getDemandAmount());
        dto.setPossessionDate(entity.getPossessionDate());
        dto.setAuctionDate(entity.getAuctionDate());
        dto.setReservePrice(entity.getReservePrice());
        return dto;
    }
}
