package hlms.serviceimpl;

import hlms.dao.AuctionNoteDAO;
import hlms.daoimpl.AuctionNoteDAOImpl;
import hlms.dto.AuctionNoteDTO;
import hlms.entity.*;
import hlms.service.AuctionNoteService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of AuctionNoteService. Converts AuctionNoteDTO <-> hlms.entity.AuctionNote
 * and delegates persistence to AuctionNoteDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how AuctionNoteDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class AuctionNoteServiceImpl implements AuctionNoteService {

    private final AuctionNoteDAO dao;

    public AuctionNoteServiceImpl() {
        this.dao = new AuctionNoteDAOImpl();
    }

    public AuctionNoteServiceImpl(AuctionNoteDAO dao) {
        this.dao = dao;
    }

    @Override
    public AuctionNoteDTO create(AuctionNoteDTO dto) throws DAOException {
        AuctionNote entity = toEntity(dto);
        AuctionNote saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public AuctionNoteDTO update(AuctionNoteDTO dto) throws DAOException {
        AuctionNote entity = toEntity(dto);
        AuctionNote saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String noteId) throws DAOException {
        return dao.delete(noteId);
    }

    @Override
    public AuctionNoteDTO findById(String noteId) throws DAOException {
        AuctionNote entity = dao.findById(noteId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<AuctionNoteDTO> findAll() throws DAOException {
        List<AuctionNote> entities = dao.findAll();
        List<AuctionNoteDTO> result = new ArrayList<>();
        for (AuctionNote entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private AuctionNote toEntity(AuctionNoteDTO dto) {
        AuctionNote entity = new AuctionNote();
        entity.setNoteId(dto.getNoteId());
        if (dto.getAppId() != null) {
            AuctionCase auctionCaseRef = new AuctionCase();
            auctionCaseRef.setAppId(dto.getAppId());
            entity.setAuctionCase(auctionCaseRef);
        }
        entity.setNoteDate(dto.getNoteDate());
        entity.setNoteText(dto.getNoteText());
        return entity;
    }

    private AuctionNoteDTO toDto(AuctionNote entity) {
        AuctionNoteDTO dto = new AuctionNoteDTO();
        dto.setNoteId(entity.getNoteId());
        dto.setAppId(entity.getAuctionCase() == null ? null : entity.getAuctionCase().getAppId());
        dto.setNoteDate(entity.getNoteDate());
        dto.setNoteText(entity.getNoteText());
        return dto;
    }
}
