package hlms.serviceimpl;

import hlms.dao.AuditLogDAO;
import hlms.daoimpl.AuditLogDAOImpl;
import hlms.dto.AuditLogDTO;
import hlms.entity.*;
import hlms.service.AuditLogService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of AuditLogService. Converts AuditLogDTO <-> hlms.entity.AuditLog
 * and delegates persistence to AuditLogDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how AuditLogDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogDAO dao;

    public AuditLogServiceImpl() {
        this.dao = new AuditLogDAOImpl();
    }

    public AuditLogServiceImpl(AuditLogDAO dao) {
        this.dao = dao;
    }

    @Override
    public AuditLogDTO create(AuditLogDTO dto) throws DAOException {
        AuditLog entity = toEntity(dto);
        AuditLog saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public AuditLogDTO update(AuditLogDTO dto) throws DAOException {
        AuditLog entity = toEntity(dto);
        AuditLog saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(Long logId) throws DAOException {
        return dao.delete(logId);
    }

    @Override
    public AuditLogDTO findById(Long logId) throws DAOException {
        AuditLog entity = dao.findById(logId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<AuditLogDTO> findAll() throws DAOException {
        List<AuditLog> entities = dao.findAll();
        List<AuditLogDTO> result = new ArrayList<>();
        for (AuditLog entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private AuditLog toEntity(AuditLogDTO dto) {
        AuditLog entity = new AuditLog();
        entity.setLogId(dto.getLogId());
        entity.setEntityType(dto.getEntityType());
        entity.setEntityId(dto.getEntityId());
        entity.setAction(dto.getAction());
        if (dto.getActorEmail() != null) {
            AppUser actorRef = new AppUser();
            actorRef.setEmail(dto.getActorEmail());
            entity.setActor(actorRef);
        }
        entity.setBeforeData(dto.getBeforeData());
        entity.setAfterData(dto.getAfterData());
        entity.setCreatedAt(dto.getCreatedAt());
        return entity;
    }

    private AuditLogDTO toDto(AuditLog entity) {
        AuditLogDTO dto = new AuditLogDTO();
        dto.setLogId(entity.getLogId());
        dto.setEntityType(entity.getEntityType());
        dto.setEntityId(entity.getEntityId());
        dto.setAction(entity.getAction());
        dto.setActorEmail(entity.getActor() == null ? null : entity.getActor().getEmail());
        dto.setBeforeData(entity.getBeforeData());
        dto.setAfterData(entity.getAfterData());
        dto.setCreatedAt(entity.getCreatedAt());
        return dto;
    }
}
