package hlms.serviceimpl;

import hlms.dao.BankOfficeDecisionDAO;
import hlms.daoimpl.BankOfficeDecisionDAOImpl;
import hlms.dto.BankOfficeDecisionDTO;
import hlms.entity.*;
import hlms.service.BankOfficeDecisionService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of BankOfficeDecisionService. Converts BankOfficeDecisionDTO <-> hlms.entity.BankOfficeDecision
 * and delegates persistence to BankOfficeDecisionDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how BankOfficeDecisionDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class BankOfficeDecisionServiceImpl implements BankOfficeDecisionService {

    private final BankOfficeDecisionDAO dao;

    public BankOfficeDecisionServiceImpl() {
        this.dao = new BankOfficeDecisionDAOImpl();
    }

    public BankOfficeDecisionServiceImpl(BankOfficeDecisionDAO dao) {
        this.dao = dao;
    }

    @Override
    public BankOfficeDecisionDTO create(BankOfficeDecisionDTO dto) throws DAOException {
        BankOfficeDecision entity = toEntity(dto);
        BankOfficeDecision saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public BankOfficeDecisionDTO update(BankOfficeDecisionDTO dto) throws DAOException {
        BankOfficeDecision entity = toEntity(dto);
        BankOfficeDecision saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        return dao.delete(appId);
    }

    @Override
    public BankOfficeDecisionDTO findById(String appId) throws DAOException {
        BankOfficeDecision entity = dao.findById(appId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<BankOfficeDecisionDTO> findAll() throws DAOException {
        List<BankOfficeDecision> entities = dao.findAll();
        List<BankOfficeDecisionDTO> result = new ArrayList<>();
        for (BankOfficeDecision entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private BankOfficeDecision toEntity(BankOfficeDecisionDTO dto) {
        BankOfficeDecision entity = new BankOfficeDecision();
        entity.setAppId(dto.getAppId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setDecision(dto.getDecision());
        if (dto.getOfficerEmail() != null) {
            AppUser officerRef = new AppUser();
            officerRef.setEmail(dto.getOfficerEmail());
            entity.setOfficer(officerRef);
        }
        entity.setDecisionDate(dto.getDecisionDate());
        entity.setReason(dto.getReason());
        entity.setRemarks(dto.getRemarks());
        return entity;
    }

    private BankOfficeDecisionDTO toDto(BankOfficeDecision entity) {
        BankOfficeDecisionDTO dto = new BankOfficeDecisionDTO();
        dto.setAppId(entity.getAppId());
        dto.setDecision(entity.getDecision());
        dto.setOfficerEmail(entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
        dto.setDecisionDate(entity.getDecisionDate());
        dto.setReason(entity.getReason());
        dto.setRemarks(entity.getRemarks());
        return dto;
    }
}
