package hlms.serviceimpl;

import hlms.dao.BidDAO;
import hlms.daoimpl.BidDAOImpl;
import hlms.dto.BidDTO;
import hlms.entity.*;
import hlms.service.BidService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of BidService. Converts BidDTO <-> hlms.entity.Bid
 * and delegates persistence to BidDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how BidDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class BidServiceImpl implements BidService {

    private final BidDAO dao;

    public BidServiceImpl() {
        this.dao = new BidDAOImpl();
    }

    public BidServiceImpl(BidDAO dao) {
        this.dao = dao;
    }

    @Override
    public BidDTO create(BidDTO dto) throws DAOException {
        Bid entity = toEntity(dto);
        Bid saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public BidDTO update(BidDTO dto) throws DAOException {
        Bid entity = toEntity(dto);
        Bid saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String bidId) throws DAOException {
        return dao.delete(bidId);
    }

    @Override
    public BidDTO findById(String bidId) throws DAOException {
        Bid entity = dao.findById(bidId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<BidDTO> findAll() throws DAOException {
        List<Bid> entities = dao.findAll();
        List<BidDTO> result = new ArrayList<>();
        for (Bid entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private Bid toEntity(BidDTO dto) {
        Bid entity = new Bid();
        entity.setBidId(dto.getBidId());
        if (dto.getAppId() != null) {
            AuctionCase auctionCaseRef = new AuctionCase();
            auctionCaseRef.setAppId(dto.getAppId());
            entity.setAuctionCase(auctionCaseRef);
        }
        if (dto.getBidderEmail() != null) {
            AppUser bidderRef = new AppUser();
            bidderRef.setEmail(dto.getBidderEmail());
            entity.setBidder(bidderRef);
        }
        entity.setBidAmount(dto.getBidAmount());
        entity.setCreatedAt(dto.getCreatedAt());
        return entity;
    }

    private BidDTO toDto(Bid entity) {
        BidDTO dto = new BidDTO();
        dto.setBidId(entity.getBidId());
        dto.setAppId(entity.getAuctionCase() == null ? null : entity.getAuctionCase().getAppId());
        dto.setBidderEmail(entity.getBidder() == null ? null : entity.getBidder().getEmail());
        dto.setBidAmount(entity.getBidAmount());
        dto.setCreatedAt(entity.getCreatedAt());
        return dto;
    }
}
