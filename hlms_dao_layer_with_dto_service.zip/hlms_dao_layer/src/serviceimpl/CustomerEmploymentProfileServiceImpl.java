package hlms.serviceimpl;

import hlms.dao.CustomerEmploymentProfileDAO;
import hlms.daoimpl.CustomerEmploymentProfileDAOImpl;
import hlms.dto.CustomerEmploymentProfileDTO;
import hlms.entity.*;
import hlms.service.CustomerEmploymentProfileService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of CustomerEmploymentProfileService. Converts CustomerEmploymentProfileDTO <-> hlms.entity.CustomerEmploymentProfile
 * and delegates persistence to CustomerEmploymentProfileDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how CustomerEmploymentProfileDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class CustomerEmploymentProfileServiceImpl implements CustomerEmploymentProfileService {

    private final CustomerEmploymentProfileDAO dao;

    public CustomerEmploymentProfileServiceImpl() {
        this.dao = new CustomerEmploymentProfileDAOImpl();
    }

    public CustomerEmploymentProfileServiceImpl(CustomerEmploymentProfileDAO dao) {
        this.dao = dao;
    }

    @Override
    public CustomerEmploymentProfileDTO create(CustomerEmploymentProfileDTO dto) throws DAOException {
        CustomerEmploymentProfile entity = toEntity(dto);
        CustomerEmploymentProfile saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public CustomerEmploymentProfileDTO update(CustomerEmploymentProfileDTO dto) throws DAOException {
        CustomerEmploymentProfile entity = toEntity(dto);
        CustomerEmploymentProfile saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String userEmail) throws DAOException {
        return dao.delete(userEmail);
    }

    @Override
    public CustomerEmploymentProfileDTO findById(String userEmail) throws DAOException {
        CustomerEmploymentProfile entity = dao.findById(userEmail);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<CustomerEmploymentProfileDTO> findAll() throws DAOException {
        List<CustomerEmploymentProfile> entities = dao.findAll();
        List<CustomerEmploymentProfileDTO> result = new ArrayList<>();
        for (CustomerEmploymentProfile entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private CustomerEmploymentProfile toEntity(CustomerEmploymentProfileDTO dto) {
        CustomerEmploymentProfile entity = new CustomerEmploymentProfile();
        entity.setUserEmail(dto.getUserEmail());
        if (dto.getUserEmail() != null) {
            AppUser userRef = new AppUser();
            userRef.setEmail(dto.getUserEmail());
            entity.setUser(userRef);
        }
        entity.setEmploymentType(dto.getEmploymentType());
        entity.setEmployer(dto.getEmployer());
        entity.setMonthlyIncome(dto.getMonthlyIncome());
        entity.setOtherEmis(dto.getOtherEmis());
        entity.setDesiredAmount(dto.getDesiredAmount());
        entity.setPan(dto.getPan());
        return entity;
    }

    private CustomerEmploymentProfileDTO toDto(CustomerEmploymentProfile entity) {
        CustomerEmploymentProfileDTO dto = new CustomerEmploymentProfileDTO();
        dto.setUserEmail(entity.getUserEmail());
        dto.setEmploymentType(entity.getEmploymentType());
        dto.setEmployer(entity.getEmployer());
        dto.setMonthlyIncome(entity.getMonthlyIncome());
        dto.setOtherEmis(entity.getOtherEmis());
        dto.setDesiredAmount(entity.getDesiredAmount());
        dto.setPan(entity.getPan());
        return dto;
    }
}
