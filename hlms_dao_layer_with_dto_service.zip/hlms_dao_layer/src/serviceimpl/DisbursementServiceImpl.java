package hlms.serviceimpl;

import hlms.dao.DisbursementDAO;
import hlms.daoimpl.DisbursementDAOImpl;
import hlms.dto.DisbursementDTO;
import hlms.entity.*;
import hlms.service.DisbursementService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of DisbursementService. Converts DisbursementDTO <-> hlms.entity.Disbursement
 * and delegates persistence to DisbursementDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how DisbursementDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class DisbursementServiceImpl implements DisbursementService {

    private final DisbursementDAO dao;

    public DisbursementServiceImpl() {
        this.dao = new DisbursementDAOImpl();
    }

    public DisbursementServiceImpl(DisbursementDAO dao) {
        this.dao = dao;
    }

    @Override
    public DisbursementDTO create(DisbursementDTO dto) throws DAOException {
        Disbursement entity = toEntity(dto);
        Disbursement saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public DisbursementDTO update(DisbursementDTO dto) throws DAOException {
        Disbursement entity = toEntity(dto);
        Disbursement saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        return dao.delete(appId);
    }

    @Override
    public DisbursementDTO findById(String appId) throws DAOException {
        Disbursement entity = dao.findById(appId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<DisbursementDTO> findAll() throws DAOException {
        List<Disbursement> entities = dao.findAll();
        List<DisbursementDTO> result = new ArrayList<>();
        for (Disbursement entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private Disbursement toEntity(DisbursementDTO dto) {
        Disbursement entity = new Disbursement();
        entity.setAppId(dto.getAppId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setDisbursedDate(dto.getDisbursedDate());
        entity.setAmount(dto.getAmount());
        entity.setRefNo(dto.getRefNo());
        entity.setMode(dto.getMode());
        entity.setBankDetails(dto.getBankDetails());
        return entity;
    }

    private DisbursementDTO toDto(Disbursement entity) {
        DisbursementDTO dto = new DisbursementDTO();
        dto.setAppId(entity.getAppId());
        dto.setDisbursedDate(entity.getDisbursedDate());
        dto.setAmount(entity.getAmount());
        dto.setRefNo(entity.getRefNo());
        dto.setMode(entity.getMode());
        dto.setBankDetails(entity.getBankDetails());
        return dto;
    }
}
