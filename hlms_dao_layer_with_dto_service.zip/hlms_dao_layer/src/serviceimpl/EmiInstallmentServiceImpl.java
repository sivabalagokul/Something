package hlms.serviceimpl;

import hlms.dao.EmiInstallmentDAO;
import hlms.daoimpl.EmiInstallmentDAOImpl;
import hlms.dto.EmiInstallmentDTO;
import hlms.entity.*;
import hlms.service.EmiInstallmentService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of EmiInstallmentService. Converts EmiInstallmentDTO <-> hlms.entity.EmiInstallment
 * and delegates persistence to EmiInstallmentDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how EmiInstallmentDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class EmiInstallmentServiceImpl implements EmiInstallmentService {

    private final EmiInstallmentDAO dao;

    public EmiInstallmentServiceImpl() {
        this.dao = new EmiInstallmentDAOImpl();
    }

    public EmiInstallmentServiceImpl(EmiInstallmentDAO dao) {
        this.dao = dao;
    }

    @Override
    public EmiInstallmentDTO create(EmiInstallmentDTO dto) throws DAOException {
        EmiInstallment entity = toEntity(dto);
        EmiInstallment saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public EmiInstallmentDTO update(EmiInstallmentDTO dto) throws DAOException {
        EmiInstallment entity = toEntity(dto);
        EmiInstallment saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String installmentId) throws DAOException {
        return dao.delete(installmentId);
    }

    @Override
    public EmiInstallmentDTO findById(String installmentId) throws DAOException {
        EmiInstallment entity = dao.findById(installmentId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<EmiInstallmentDTO> findAll() throws DAOException {
        List<EmiInstallment> entities = dao.findAll();
        List<EmiInstallmentDTO> result = new ArrayList<>();
        for (EmiInstallment entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private EmiInstallment toEntity(EmiInstallmentDTO dto) {
        EmiInstallment entity = new EmiInstallment();
        entity.setInstallmentId(dto.getInstallmentId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setInstallmentNo(dto.getInstallmentNo());
        entity.setDueDate(dto.getDueDate());
        entity.setEmiAmount(dto.getEmiAmount());
        entity.setPrincipalComponent(dto.getPrincipalComponent());
        entity.setInterestComponent(dto.getInterestComponent());
        entity.setClosingBalance(dto.getClosingBalance());
        entity.setStatus(dto.getStatus());
        entity.setPaidDate(dto.getPaidDate());
        return entity;
    }

    private EmiInstallmentDTO toDto(EmiInstallment entity) {
        EmiInstallmentDTO dto = new EmiInstallmentDTO();
        dto.setInstallmentId(entity.getInstallmentId());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setInstallmentNo(entity.getInstallmentNo());
        dto.setDueDate(entity.getDueDate());
        dto.setEmiAmount(entity.getEmiAmount());
        dto.setPrincipalComponent(entity.getPrincipalComponent());
        dto.setInterestComponent(entity.getInterestComponent());
        dto.setClosingBalance(entity.getClosingBalance());
        dto.setStatus(entity.getStatus());
        dto.setPaidDate(entity.getPaidDate());
        return dto;
    }
}
