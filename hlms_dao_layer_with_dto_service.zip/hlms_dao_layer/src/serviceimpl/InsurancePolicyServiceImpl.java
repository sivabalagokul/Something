package hlms.serviceimpl;

import hlms.dao.InsurancePolicyDAO;
import hlms.daoimpl.InsurancePolicyDAOImpl;
import hlms.dto.InsurancePolicyDTO;
import hlms.entity.*;
import hlms.service.InsurancePolicyService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of InsurancePolicyService. Converts InsurancePolicyDTO <-> hlms.entity.InsurancePolicy
 * and delegates persistence to InsurancePolicyDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how InsurancePolicyDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class InsurancePolicyServiceImpl implements InsurancePolicyService {

    private final InsurancePolicyDAO dao;

    public InsurancePolicyServiceImpl() {
        this.dao = new InsurancePolicyDAOImpl();
    }

    public InsurancePolicyServiceImpl(InsurancePolicyDAO dao) {
        this.dao = dao;
    }

    @Override
    public InsurancePolicyDTO create(InsurancePolicyDTO dto) throws DAOException {
        InsurancePolicy entity = toEntity(dto);
        InsurancePolicy saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public InsurancePolicyDTO update(InsurancePolicyDTO dto) throws DAOException {
        InsurancePolicy entity = toEntity(dto);
        InsurancePolicy saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String policyId) throws DAOException {
        return dao.delete(policyId);
    }

    @Override
    public InsurancePolicyDTO findById(String policyId) throws DAOException {
        InsurancePolicy entity = dao.findById(policyId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<InsurancePolicyDTO> findAll() throws DAOException {
        List<InsurancePolicy> entities = dao.findAll();
        List<InsurancePolicyDTO> result = new ArrayList<>();
        for (InsurancePolicy entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private InsurancePolicy toEntity(InsurancePolicyDTO dto) {
        InsurancePolicy entity = new InsurancePolicy();
        entity.setPolicyId(dto.getPolicyId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setPolicyType(dto.getPolicyType());
        entity.setStatus(dto.getStatus());
        entity.setValidTill(dto.getValidTill());
        return entity;
    }

    private InsurancePolicyDTO toDto(InsurancePolicy entity) {
        InsurancePolicyDTO dto = new InsurancePolicyDTO();
        dto.setPolicyId(entity.getPolicyId());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setPolicyType(entity.getPolicyType());
        dto.setStatus(entity.getStatus());
        dto.setValidTill(entity.getValidTill());
        return dto;
    }
}
