package hlms.serviceimpl;

import hlms.dao.LegalChecklistItemDAO;
import hlms.daoimpl.LegalChecklistItemDAOImpl;
import hlms.dto.LegalChecklistItemDTO;
import hlms.entity.*;
import hlms.service.LegalChecklistItemService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of LegalChecklistItemService. Converts LegalChecklistItemDTO <-> hlms.entity.LegalChecklistItem
 * and delegates persistence to LegalChecklistItemDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how LegalChecklistItemDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class LegalChecklistItemServiceImpl implements LegalChecklistItemService {

    private final LegalChecklistItemDAO dao;

    public LegalChecklistItemServiceImpl() {
        this.dao = new LegalChecklistItemDAOImpl();
    }

    public LegalChecklistItemServiceImpl(LegalChecklistItemDAO dao) {
        this.dao = dao;
    }

    @Override
    public LegalChecklistItemDTO create(LegalChecklistItemDTO dto) throws DAOException {
        LegalChecklistItem entity = toEntity(dto);
        LegalChecklistItem saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LegalChecklistItemDTO update(LegalChecklistItemDTO dto) throws DAOException {
        LegalChecklistItem entity = toEntity(dto);
        LegalChecklistItem saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String checklistItemId) throws DAOException {
        return dao.delete(checklistItemId);
    }

    @Override
    public LegalChecklistItemDTO findById(String checklistItemId) throws DAOException {
        LegalChecklistItem entity = dao.findById(checklistItemId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LegalChecklistItemDTO> findAll() throws DAOException {
        List<LegalChecklistItem> entities = dao.findAll();
        List<LegalChecklistItemDTO> result = new ArrayList<>();
        for (LegalChecklistItem entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private LegalChecklistItem toEntity(LegalChecklistItemDTO dto) {
        LegalChecklistItem entity = new LegalChecklistItem();
        entity.setChecklistItemId(dto.getChecklistItemId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setChecklistKey(dto.getChecklistKey());
        entity.setStatus(dto.getStatus());
        return entity;
    }

    private LegalChecklistItemDTO toDto(LegalChecklistItem entity) {
        LegalChecklistItemDTO dto = new LegalChecklistItemDTO();
        dto.setChecklistItemId(entity.getChecklistItemId());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setChecklistKey(entity.getChecklistKey());
        dto.setStatus(entity.getStatus());
        return dto;
    }
}
