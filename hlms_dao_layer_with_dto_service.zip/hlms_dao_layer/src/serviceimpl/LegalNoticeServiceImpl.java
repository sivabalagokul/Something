package hlms.serviceimpl;

import hlms.dao.LegalNoticeDAO;
import hlms.daoimpl.LegalNoticeDAOImpl;
import hlms.dto.LegalNoticeDTO;
import hlms.entity.*;
import hlms.service.LegalNoticeService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of LegalNoticeService. Converts LegalNoticeDTO <-> hlms.entity.LegalNotice
 * and delegates persistence to LegalNoticeDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how LegalNoticeDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class LegalNoticeServiceImpl implements LegalNoticeService {

    private final LegalNoticeDAO dao;

    public LegalNoticeServiceImpl() {
        this.dao = new LegalNoticeDAOImpl();
    }

    public LegalNoticeServiceImpl(LegalNoticeDAO dao) {
        this.dao = dao;
    }

    @Override
    public LegalNoticeDTO create(LegalNoticeDTO dto) throws DAOException {
        LegalNotice entity = toEntity(dto);
        LegalNotice saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LegalNoticeDTO update(LegalNoticeDTO dto) throws DAOException {
        LegalNotice entity = toEntity(dto);
        LegalNotice saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String noticeId) throws DAOException {
        return dao.delete(noticeId);
    }

    @Override
    public LegalNoticeDTO findById(String noticeId) throws DAOException {
        LegalNotice entity = dao.findById(noticeId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LegalNoticeDTO> findAll() throws DAOException {
        List<LegalNotice> entities = dao.findAll();
        List<LegalNoticeDTO> result = new ArrayList<>();
        for (LegalNotice entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private LegalNotice toEntity(LegalNoticeDTO dto) {
        LegalNotice entity = new LegalNotice();
        entity.setNoticeId(dto.getNoticeId());
        entity.setNoticeNo(dto.getNoticeNo());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setNoticeType(dto.getNoticeType());
        entity.setIssueDate(dto.getIssueDate());
        entity.setDueDate(dto.getDueDate());
        entity.setStatus(dto.getStatus());
        if (dto.getOfficerEmail() != null) {
            AppUser officerRef = new AppUser();
            officerRef.setEmail(dto.getOfficerEmail());
            entity.setOfficer(officerRef);
        }
        entity.setContent(dto.getContent());
        return entity;
    }

    private LegalNoticeDTO toDto(LegalNotice entity) {
        LegalNoticeDTO dto = new LegalNoticeDTO();
        dto.setNoticeId(entity.getNoticeId());
        dto.setNoticeNo(entity.getNoticeNo());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setNoticeType(entity.getNoticeType());
        dto.setIssueDate(entity.getIssueDate());
        dto.setDueDate(entity.getDueDate());
        dto.setStatus(entity.getStatus());
        dto.setOfficerEmail(entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
        dto.setContent(entity.getContent());
        return dto;
    }
}
