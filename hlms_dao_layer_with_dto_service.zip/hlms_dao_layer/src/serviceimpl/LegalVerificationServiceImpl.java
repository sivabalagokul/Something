package hlms.serviceimpl;

import hlms.dao.LegalVerificationDAO;
import hlms.daoimpl.LegalVerificationDAOImpl;
import hlms.dto.LegalVerificationDTO;
import hlms.entity.*;
import hlms.service.LegalVerificationService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of LegalVerificationService. Converts LegalVerificationDTO <-> hlms.entity.LegalVerification
 * and delegates persistence to LegalVerificationDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how LegalVerificationDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class LegalVerificationServiceImpl implements LegalVerificationService {

    private final LegalVerificationDAO dao;

    public LegalVerificationServiceImpl() {
        this.dao = new LegalVerificationDAOImpl();
    }

    public LegalVerificationServiceImpl(LegalVerificationDAO dao) {
        this.dao = dao;
    }

    @Override
    public LegalVerificationDTO create(LegalVerificationDTO dto) throws DAOException {
        LegalVerification entity = toEntity(dto);
        LegalVerification saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LegalVerificationDTO update(LegalVerificationDTO dto) throws DAOException {
        LegalVerification entity = toEntity(dto);
        LegalVerification saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        return dao.delete(appId);
    }

    @Override
    public LegalVerificationDTO findById(String appId) throws DAOException {
        LegalVerification entity = dao.findById(appId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LegalVerificationDTO> findAll() throws DAOException {
        List<LegalVerification> entities = dao.findAll();
        List<LegalVerificationDTO> result = new ArrayList<>();
        for (LegalVerification entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private LegalVerification toEntity(LegalVerificationDTO dto) {
        LegalVerification entity = new LegalVerification();
        entity.setAppId(dto.getAppId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setDecision(dto.getDecision());
        entity.setDecisionDate(dto.getDecisionDate());
        if (dto.getOfficerEmail() != null) {
            AppUser officerRef = new AppUser();
            officerRef.setEmail(dto.getOfficerEmail());
            entity.setOfficer(officerRef);
        }
        entity.setRemarks(dto.getRemarks());
        return entity;
    }

    private LegalVerificationDTO toDto(LegalVerification entity) {
        LegalVerificationDTO dto = new LegalVerificationDTO();
        dto.setAppId(entity.getAppId());
        dto.setDecision(entity.getDecision());
        dto.setDecisionDate(entity.getDecisionDate());
        dto.setOfficerEmail(entity.getOfficer() == null ? null : entity.getOfficer().getEmail());
        dto.setRemarks(entity.getRemarks());
        return dto;
    }
}
