package hlms.serviceimpl;

import hlms.dao.LoanApplicationDAO;
import hlms.daoimpl.LoanApplicationDAOImpl;
import hlms.dto.LoanApplicationDTO;
import hlms.entity.*;
import hlms.service.LoanApplicationService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of LoanApplicationService. Converts LoanApplicationDTO <-> hlms.entity.LoanApplication
 * and delegates persistence to LoanApplicationDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how LoanApplicationDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class LoanApplicationServiceImpl implements LoanApplicationService {

    private final LoanApplicationDAO dao;

    public LoanApplicationServiceImpl() {
        this.dao = new LoanApplicationDAOImpl();
    }

    public LoanApplicationServiceImpl(LoanApplicationDAO dao) {
        this.dao = dao;
    }

    @Override
    public LoanApplicationDTO create(LoanApplicationDTO dto) throws DAOException {
        LoanApplication entity = toEntity(dto);
        LoanApplication saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LoanApplicationDTO update(LoanApplicationDTO dto) throws DAOException {
        LoanApplication entity = toEntity(dto);
        LoanApplication saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String appId) throws DAOException {
        return dao.delete(appId);
    }

    @Override
    public LoanApplicationDTO findById(String appId) throws DAOException {
        LoanApplication entity = dao.findById(appId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LoanApplicationDTO> findAll() throws DAOException {
        List<LoanApplication> entities = dao.findAll();
        List<LoanApplicationDTO> result = new ArrayList<>();
        for (LoanApplication entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private LoanApplication toEntity(LoanApplicationDTO dto) {
        LoanApplication entity = new LoanApplication();
        entity.setAppId(dto.getAppId());
        entity.setTrackingNo(dto.getTrackingNo());
        if (dto.getUserEmail() != null) {
            AppUser userRef = new AppUser();
            userRef.setEmail(dto.getUserEmail());
            entity.setUser(userRef);
        }
        if (dto.getProductId() != null) {
            LoanProduct productRef = new LoanProduct();
            productRef.setProductId(dto.getProductId());
            entity.setProduct(productRef);
        }
        entity.setLoanAmount(dto.getLoanAmount());
        entity.setTenureYears(dto.getTenureYears());
        entity.setPurpose(dto.getPurpose());
        entity.setInterestRate(dto.getInterestRate());
        entity.setStatus(dto.getStatus());
        entity.setStageIndex(dto.getStageIndex());
        entity.setCreatedAt(dto.getCreatedAt());
        entity.setApplicantName(dto.getApplicantName());
        entity.setApplicantMobile(dto.getApplicantMobile());
        entity.setApplicantPan(dto.getApplicantPan());
        entity.setAddrDoorNo(dto.getAddrDoorNo());
        entity.setAddrStreet(dto.getAddrStreet());
        entity.setAddrCity(dto.getAddrCity());
        entity.setAddrState(dto.getAddrState());
        entity.setAddrPincode(dto.getAddrPincode());
        entity.setEmploymentType(dto.getEmploymentType());
        entity.setEmployer(dto.getEmployer());
        entity.setMonthlyIncome(dto.getMonthlyIncome());
        entity.setOtherEmis(dto.getOtherEmis());
        entity.setPropertyAddress(dto.getPropertyAddress());
        entity.setPropertyType(dto.getPropertyType());
        entity.setPropertyValue(dto.getPropertyValue());
        return entity;
    }

    private LoanApplicationDTO toDto(LoanApplication entity) {
        LoanApplicationDTO dto = new LoanApplicationDTO();
        dto.setAppId(entity.getAppId());
        dto.setTrackingNo(entity.getTrackingNo());
        dto.setUserEmail(entity.getUser() == null ? null : entity.getUser().getEmail());
        dto.setProductId(entity.getProduct() == null ? null : entity.getProduct().getProductId());
        dto.setLoanAmount(entity.getLoanAmount());
        dto.setTenureYears(entity.getTenureYears());
        dto.setPurpose(entity.getPurpose());
        dto.setInterestRate(entity.getInterestRate());
        dto.setStatus(entity.getStatus());
        dto.setStageIndex(entity.getStageIndex());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setApplicantName(entity.getApplicantName());
        dto.setApplicantMobile(entity.getApplicantMobile());
        dto.setApplicantPan(entity.getApplicantPan());
        dto.setAddrDoorNo(entity.getAddrDoorNo());
        dto.setAddrStreet(entity.getAddrStreet());
        dto.setAddrCity(entity.getAddrCity());
        dto.setAddrState(entity.getAddrState());
        dto.setAddrPincode(entity.getAddrPincode());
        dto.setEmploymentType(entity.getEmploymentType());
        dto.setEmployer(entity.getEmployer());
        dto.setMonthlyIncome(entity.getMonthlyIncome());
        dto.setOtherEmis(entity.getOtherEmis());
        dto.setPropertyAddress(entity.getPropertyAddress());
        dto.setPropertyType(entity.getPropertyType());
        dto.setPropertyValue(entity.getPropertyValue());
        return dto;
    }
}
