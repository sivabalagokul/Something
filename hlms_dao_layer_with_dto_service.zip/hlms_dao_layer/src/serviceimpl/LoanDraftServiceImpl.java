package hlms.serviceimpl;

import hlms.dao.LoanDraftDAO;
import hlms.daoimpl.LoanDraftDAOImpl;
import hlms.dto.LoanDraftDTO;
import hlms.entity.*;
import hlms.service.LoanDraftService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of LoanDraftService. Converts LoanDraftDTO <-> hlms.entity.LoanDraft
 * and delegates persistence to LoanDraftDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how LoanDraftDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class LoanDraftServiceImpl implements LoanDraftService {

    private final LoanDraftDAO dao;

    public LoanDraftServiceImpl() {
        this.dao = new LoanDraftDAOImpl();
    }

    public LoanDraftServiceImpl(LoanDraftDAO dao) {
        this.dao = dao;
    }

    @Override
    public LoanDraftDTO create(LoanDraftDTO dto) throws DAOException {
        LoanDraft entity = toEntity(dto);
        LoanDraft saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LoanDraftDTO update(LoanDraftDTO dto) throws DAOException {
        LoanDraft entity = toEntity(dto);
        LoanDraft saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String draftId) throws DAOException {
        return dao.delete(draftId);
    }

    @Override
    public LoanDraftDTO findById(String draftId) throws DAOException {
        LoanDraft entity = dao.findById(draftId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LoanDraftDTO> findAll() throws DAOException {
        List<LoanDraft> entities = dao.findAll();
        List<LoanDraftDTO> result = new ArrayList<>();
        for (LoanDraft entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private LoanDraft toEntity(LoanDraftDTO dto) {
        LoanDraft entity = new LoanDraft();
        entity.setDraftId(dto.getDraftId());
        if (dto.getUserEmail() != null) {
            AppUser userRef = new AppUser();
            userRef.setEmail(dto.getUserEmail());
            entity.setUser(userRef);
        }
        entity.setCurrentStep(dto.getCurrentStep());
        entity.setSavedAt(dto.getSavedAt());
        entity.setLoanType(dto.getLoanType());
        entity.setLoanAmount(dto.getLoanAmount());
        entity.setTenureYears(dto.getTenureYears());
        entity.setFormData(dto.getFormData());
        return entity;
    }

    private LoanDraftDTO toDto(LoanDraft entity) {
        LoanDraftDTO dto = new LoanDraftDTO();
        dto.setDraftId(entity.getDraftId());
        dto.setUserEmail(entity.getUser() == null ? null : entity.getUser().getEmail());
        dto.setCurrentStep(entity.getCurrentStep());
        dto.setSavedAt(entity.getSavedAt());
        dto.setLoanType(entity.getLoanType());
        dto.setLoanAmount(entity.getLoanAmount());
        dto.setTenureYears(entity.getTenureYears());
        dto.setFormData(entity.getFormData());
        return dto;
    }
}
