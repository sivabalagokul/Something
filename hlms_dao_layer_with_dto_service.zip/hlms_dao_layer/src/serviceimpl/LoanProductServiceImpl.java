package hlms.serviceimpl;

import hlms.dao.LoanProductDAO;
import hlms.daoimpl.LoanProductDAOImpl;
import hlms.dto.LoanProductDTO;
import hlms.entity.*;
import hlms.service.LoanProductService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of LoanProductService. Converts LoanProductDTO <-> hlms.entity.LoanProduct
 * and delegates persistence to LoanProductDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how LoanProductDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class LoanProductServiceImpl implements LoanProductService {

    private final LoanProductDAO dao;

    public LoanProductServiceImpl() {
        this.dao = new LoanProductDAOImpl();
    }

    public LoanProductServiceImpl(LoanProductDAO dao) {
        this.dao = dao;
    }

    @Override
    public LoanProductDTO create(LoanProductDTO dto) throws DAOException {
        LoanProduct entity = toEntity(dto);
        LoanProduct saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public LoanProductDTO update(LoanProductDTO dto) throws DAOException {
        LoanProduct entity = toEntity(dto);
        LoanProduct saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String productId) throws DAOException {
        return dao.delete(productId);
    }

    @Override
    public LoanProductDTO findById(String productId) throws DAOException {
        LoanProduct entity = dao.findById(productId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<LoanProductDTO> findAll() throws DAOException {
        List<LoanProduct> entities = dao.findAll();
        List<LoanProductDTO> result = new ArrayList<>();
        for (LoanProduct entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private LoanProduct toEntity(LoanProductDTO dto) {
        LoanProduct entity = new LoanProduct();
        entity.setProductId(dto.getProductId());
        entity.setName(dto.getName());
        entity.setCategory(dto.getCategory());
        entity.setInterestRate(dto.getInterestRate());
        entity.setMaxTenureYears(dto.getMaxTenureYears());
        entity.setMaxLtv(dto.getMaxLtv());
        entity.setDescription(dto.getDescription());
        return entity;
    }

    private LoanProductDTO toDto(LoanProduct entity) {
        LoanProductDTO dto = new LoanProductDTO();
        dto.setProductId(entity.getProductId());
        dto.setName(entity.getName());
        dto.setCategory(entity.getCategory());
        dto.setInterestRate(entity.getInterestRate());
        dto.setMaxTenureYears(entity.getMaxTenureYears());
        dto.setMaxLtv(entity.getMaxLtv());
        dto.setDescription(entity.getDescription());
        return dto;
    }
}
