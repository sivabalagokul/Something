package hlms.serviceimpl;

import hlms.dao.NotificationDAO;
import hlms.daoimpl.NotificationDAOImpl;
import hlms.dto.NotificationDTO;
import hlms.entity.*;
import hlms.service.NotificationService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of NotificationService. Converts NotificationDTO <-> hlms.entity.Notification
 * and delegates persistence to NotificationDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how NotificationDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class NotificationServiceImpl implements NotificationService {

    private final NotificationDAO dao;

    public NotificationServiceImpl() {
        this.dao = new NotificationDAOImpl();
    }

    public NotificationServiceImpl(NotificationDAO dao) {
        this.dao = dao;
    }

    @Override
    public NotificationDTO create(NotificationDTO dto) throws DAOException {
        Notification entity = toEntity(dto);
        Notification saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public NotificationDTO update(NotificationDTO dto) throws DAOException {
        Notification entity = toEntity(dto);
        Notification saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String notificationId) throws DAOException {
        return dao.delete(notificationId);
    }

    @Override
    public NotificationDTO findById(String notificationId) throws DAOException {
        Notification entity = dao.findById(notificationId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<NotificationDTO> findAll() throws DAOException {
        List<Notification> entities = dao.findAll();
        List<NotificationDTO> result = new ArrayList<>();
        for (Notification entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private Notification toEntity(NotificationDTO dto) {
        Notification entity = new Notification();
        entity.setNotificationId(dto.getNotificationId());
        if (dto.getUserEmail() != null) {
            AppUser userRef = new AppUser();
            userRef.setEmail(dto.getUserEmail());
            entity.setUser(userRef);
        }
        entity.setTitle(dto.getTitle());
        entity.setBody(dto.getBody());
        entity.setChannels(dto.getChannels());
        entity.setIsRead(dto.getIsRead());
        entity.setCreatedAt(dto.getCreatedAt());
        return entity;
    }

    private NotificationDTO toDto(Notification entity) {
        NotificationDTO dto = new NotificationDTO();
        dto.setNotificationId(entity.getNotificationId());
        dto.setUserEmail(entity.getUser() == null ? null : entity.getUser().getEmail());
        dto.setTitle(entity.getTitle());
        dto.setBody(entity.getBody());
        dto.setChannels(entity.getChannels());
        dto.setIsRead(entity.getIsRead());
        dto.setCreatedAt(entity.getCreatedAt());
        return dto;
    }
}
