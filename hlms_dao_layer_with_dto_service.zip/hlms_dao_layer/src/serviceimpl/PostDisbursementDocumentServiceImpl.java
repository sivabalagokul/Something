package hlms.serviceimpl;

import hlms.dao.PostDisbursementDocumentDAO;
import hlms.daoimpl.PostDisbursementDocumentDAOImpl;
import hlms.dto.PostDisbursementDocumentDTO;
import hlms.entity.*;
import hlms.service.PostDisbursementDocumentService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of PostDisbursementDocumentService. Converts PostDisbursementDocumentDTO <-> hlms.entity.PostDisbursementDocument
 * and delegates persistence to PostDisbursementDocumentDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how PostDisbursementDocumentDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class PostDisbursementDocumentServiceImpl implements PostDisbursementDocumentService {

    private final PostDisbursementDocumentDAO dao;

    public PostDisbursementDocumentServiceImpl() {
        this.dao = new PostDisbursementDocumentDAOImpl();
    }

    public PostDisbursementDocumentServiceImpl(PostDisbursementDocumentDAO dao) {
        this.dao = dao;
    }

    @Override
    public PostDisbursementDocumentDTO create(PostDisbursementDocumentDTO dto) throws DAOException {
        PostDisbursementDocument entity = toEntity(dto);
        PostDisbursementDocument saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public PostDisbursementDocumentDTO update(PostDisbursementDocumentDTO dto) throws DAOException {
        PostDisbursementDocument entity = toEntity(dto);
        PostDisbursementDocument saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String pdDocId) throws DAOException {
        return dao.delete(pdDocId);
    }

    @Override
    public PostDisbursementDocumentDTO findById(String pdDocId) throws DAOException {
        PostDisbursementDocument entity = dao.findById(pdDocId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<PostDisbursementDocumentDTO> findAll() throws DAOException {
        List<PostDisbursementDocument> entities = dao.findAll();
        List<PostDisbursementDocumentDTO> result = new ArrayList<>();
        for (PostDisbursementDocument entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private PostDisbursementDocument toEntity(PostDisbursementDocumentDTO dto) {
        PostDisbursementDocument entity = new PostDisbursementDocument();
        entity.setPdDocId(dto.getPdDocId());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        entity.setDocType(dto.getDocType());
        entity.setFileName(dto.getFileName());
        entity.setFileSize(dto.getFileSize());
        entity.setNote(dto.getNote());
        entity.setStatus(dto.getStatus());
        entity.setUploadedAt(dto.getUploadedAt());
        if (dto.getVerifiedByEmail() != null) {
            AppUser verifiedByRef = new AppUser();
            verifiedByRef.setEmail(dto.getVerifiedByEmail());
            entity.setVerifiedBy(verifiedByRef);
        }
        entity.setVerifiedAt(dto.getVerifiedAt());
        entity.setRemarks(dto.getRemarks());
        return entity;
    }

    private PostDisbursementDocumentDTO toDto(PostDisbursementDocument entity) {
        PostDisbursementDocumentDTO dto = new PostDisbursementDocumentDTO();
        dto.setPdDocId(entity.getPdDocId());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setDocType(entity.getDocType());
        dto.setFileName(entity.getFileName());
        dto.setFileSize(entity.getFileSize());
        dto.setNote(entity.getNote());
        dto.setStatus(entity.getStatus());
        dto.setUploadedAt(entity.getUploadedAt());
        dto.setVerifiedByEmail(entity.getVerifiedBy() == null ? null : entity.getVerifiedBy().getEmail());
        dto.setVerifiedAt(entity.getVerifiedAt());
        dto.setRemarks(entity.getRemarks());
        return dto;
    }
}
