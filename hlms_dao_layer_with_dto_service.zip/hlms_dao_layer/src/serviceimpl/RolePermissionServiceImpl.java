package hlms.serviceimpl;

import hlms.dao.RolePermissionDAO;
import hlms.daoimpl.RolePermissionDAOImpl;
import hlms.dto.RolePermissionDTO;
import hlms.entity.*;
import hlms.service.RolePermissionService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of RolePermissionService. Converts RolePermissionDTO <-> hlms.entity.RolePermission
 * and delegates persistence to RolePermissionDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how RolePermissionDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class RolePermissionServiceImpl implements RolePermissionService {

    private final RolePermissionDAO dao;

    public RolePermissionServiceImpl() {
        this.dao = new RolePermissionDAOImpl();
    }

    public RolePermissionServiceImpl(RolePermissionDAO dao) {
        this.dao = dao;
    }

    @Override
    public RolePermissionDTO create(RolePermissionDTO dto) throws DAOException {
        RolePermission entity = toEntity(dto);
        RolePermission saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public RolePermissionDTO update(RolePermissionDTO dto) throws DAOException {
        RolePermission entity = toEntity(dto);
        RolePermission saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String role, String module) throws DAOException {
        return dao.delete(role, module);
    }

    @Override
    public RolePermissionDTO findById(String role, String module) throws DAOException {
        RolePermission entity = dao.findById(role, module);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<RolePermissionDTO> findAll() throws DAOException {
        List<RolePermission> entities = dao.findAll();
        List<RolePermissionDTO> result = new ArrayList<>();
        for (RolePermission entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private RolePermission toEntity(RolePermissionDTO dto) {
        RolePermission entity = new RolePermission();
        entity.setRole(dto.getRole());
        entity.setModule(dto.getModule());
        entity.setCanView(dto.getCanView());
        entity.setCanAdd(dto.getCanAdd());
        entity.setCanEdit(dto.getCanEdit());
        entity.setCanDelete(dto.getCanDelete());
        return entity;
    }

    private RolePermissionDTO toDto(RolePermission entity) {
        RolePermissionDTO dto = new RolePermissionDTO();
        dto.setRole(entity.getRole());
        dto.setModule(entity.getModule());
        dto.setCanView(entity.getCanView());
        dto.setCanAdd(entity.getCanAdd());
        dto.setCanEdit(entity.getCanEdit());
        dto.setCanDelete(entity.getCanDelete());
        return dto;
    }
}
