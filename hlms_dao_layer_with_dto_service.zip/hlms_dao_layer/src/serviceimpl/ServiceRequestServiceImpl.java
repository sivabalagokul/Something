package hlms.serviceimpl;

import hlms.dao.ServiceRequestDAO;
import hlms.daoimpl.ServiceRequestDAOImpl;
import hlms.dto.ServiceRequestDTO;
import hlms.entity.*;
import hlms.service.ServiceRequestService;
import hlms.util.DAOException;

import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of ServiceRequestService. Converts ServiceRequestDTO <-> hlms.entity.ServiceRequest
 * and delegates persistence to ServiceRequestDAOImpl. Foreign-key DTO fields are
 * turned into lightweight related-entity references (id only) before being
 * handed to the DAO layer, mirroring how ServiceRequestDAOImpl itself hydrates
 * related objects when reading rows back.
 */
public class ServiceRequestServiceImpl implements ServiceRequestService {

    private final ServiceRequestDAO dao;

    public ServiceRequestServiceImpl() {
        this.dao = new ServiceRequestDAOImpl();
    }

    public ServiceRequestServiceImpl(ServiceRequestDAO dao) {
        this.dao = dao;
    }

    @Override
    public ServiceRequestDTO create(ServiceRequestDTO dto) throws DAOException {
        ServiceRequest entity = toEntity(dto);
        ServiceRequest saved = dao.insert(entity);
        return toDto(saved);
    }

    @Override
    public ServiceRequestDTO update(ServiceRequestDTO dto) throws DAOException {
        ServiceRequest entity = toEntity(dto);
        ServiceRequest saved = dao.update(entity);
        return toDto(saved);
    }

    @Override
    public boolean delete(String requestId) throws DAOException {
        return dao.delete(requestId);
    }

    @Override
    public ServiceRequestDTO findById(String requestId) throws DAOException {
        ServiceRequest entity = dao.findById(requestId);
        return entity == null ? null : toDto(entity);
    }

    @Override
    public List<ServiceRequestDTO> findAll() throws DAOException {
        List<ServiceRequest> entities = dao.findAll();
        List<ServiceRequestDTO> result = new ArrayList<>();
        for (ServiceRequest entity : entities) {
            result.add(toDto(entity));
        }
        return result;
    }

    private ServiceRequest toEntity(ServiceRequestDTO dto) {
        ServiceRequest entity = new ServiceRequest();
        entity.setRequestId(dto.getRequestId());
        entity.setRefNo(dto.getRefNo());
        if (dto.getAppId() != null) {
            LoanApplication applicationRef = new LoanApplication();
            applicationRef.setAppId(dto.getAppId());
            entity.setApplication(applicationRef);
        }
        if (dto.getUserEmail() != null) {
            AppUser userRef = new AppUser();
            userRef.setEmail(dto.getUserEmail());
            entity.setUser(userRef);
        }
        entity.setRequestType(dto.getRequestType());
        entity.setDescription(dto.getDescription());
        entity.setStatus(dto.getStatus());
        entity.setCreatedAt(dto.getCreatedAt());
        return entity;
    }

    private ServiceRequestDTO toDto(ServiceRequest entity) {
        ServiceRequestDTO dto = new ServiceRequestDTO();
        dto.setRequestId(entity.getRequestId());
        dto.setRefNo(entity.getRefNo());
        dto.setAppId(entity.getApplication() == null ? null : entity.getApplication().getAppId());
        dto.setUserEmail(entity.getUser() == null ? null : entity.getUser().getEmail());
        dto.setRequestType(entity.getRequestType());
        dto.setDescription(entity.getDescription());
        dto.setStatus(entity.getStatus());
        dto.setCreatedAt(entity.getCreatedAt());
        return dto;
    }
}
