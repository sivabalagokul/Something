package hlms.util;

/**
 * Wraps java.sql.SQLException (and any other persistence-layer failure) so
 * that callers of the DAO layer never need to import java.sql.* just to
 * handle errors. Every DAOImpl catches SQLException internally, logs/handles
 * it, and re-throws it wrapped as a DAOException.
 */
public class DAOException extends Exception {

    public DAOException(String message) {
        super(message);
    }

    public DAOException(String message, Throwable cause) {
        super(message, cause);
    }
}
