package com.hlms2.legal.dto;

import lombok.*;

import java.time.OffsetDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BankOfficeDecisionDTO {
    private Long decisionId;
    private String appId;
    private String status;
    private String officerEmail;
    private OffsetDateTime decisionDate;
    private String reason;
    private String remarks;
}
