package com.hlms2.legal.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'bank_office_decision'.
 *
 * CHG(v2): switched from app_id-as-PK to a surrogate decision_id
 * (BIGSERIAL); app_id is now a unique FK column. The "decision" column
 * was also renamed to "status" in the updated schema. Adds the
 * deleted_at soft delete marker.
 */
@Entity
@Table(name = "bank_office_decision")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BankOfficeDecision {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "decision_id")
    private Long decisionId;

    @Column(name = "app_id", length = 50, nullable = false, unique = true)
    private String appId;

    // CHG(v2): column renamed from "decision" to "status" in the schema.
    @Column(name = "status", length = 30)
    private String status;

    @Column(name = "officer")
    private String officerEmail;

    @Column(name = "decision_date")
    private OffsetDateTime decisionDate;

    @Column(name = "reason", length = 255)
    private String reason;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    // CHG(v2): soft delete marker. NULL = active, timestamp = deleted.
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
