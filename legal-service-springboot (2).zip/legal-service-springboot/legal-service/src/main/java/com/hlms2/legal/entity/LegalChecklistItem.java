package com.hlms2.legal.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'legal_checklist_item'.
 * Ported from hlms2.entity.LegalChecklistItem (plain JDBC version).
 * CHG(v2): adds the deleted_at soft delete marker.
 */
@Entity
@Table(name = "legal_checklist_item")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LegalChecklistItem {

    @Id
    @Column(name = "checklist_item_id", length = 50)
    private String checklistItemId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "checklist_key", length = 100, nullable = false)
    private String checklistKey;

    @Column(name = "status", length = 30, nullable = false)
    private String status;

    // CHG(v2): soft delete marker. NULL = active, timestamp = deleted.
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
