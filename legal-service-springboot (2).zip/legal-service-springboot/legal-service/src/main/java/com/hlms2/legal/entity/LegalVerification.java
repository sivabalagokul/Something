package com.hlms2.legal.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'legal_verification'.
 *
 * CHG(v2): switched from app_id-as-PK to a surrogate verification_id
 * (BIGSERIAL). app_id is now a unique FK column instead of the primary
 * key, since the schema update makes this an "IDENTITY" style table.
 * Also adds the info-request workflow columns and the deleted_at soft
 * delete marker introduced in hlms_schema_updated_v2.sql.
 */
@Entity
@Table(name = "legal_verification")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LegalVerification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "verification_id")
    private Long verificationId;

    @Column(name = "app_id", length = 50, nullable = false, unique = true)
    private String appId;

    @Column(name = "decision", length = 30)
    private String decision;

    @Column(name = "decision_date")
    private OffsetDateTime decisionDate;

    @Column(name = "officer")
    private String officerEmail;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    // CHG(v2): info-request workflow - legal team can ask the customer
    // for more documents/clarification without rejecting the application.
    @Column(name = "info_requested", nullable = false)
    private Boolean infoRequested;

    @Column(name = "info_request_details", columnDefinition = "TEXT")
    private String infoRequestDetails;

    @Column(name = "info_requested_at")
    private OffsetDateTime infoRequestedAt;

    // CHG(v2): soft delete marker. NULL = active, timestamp = deleted.
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
