# legal-service — Spring Boot port of hlms2's legal domain

This is a standalone Spring Boot module built from the plain-Java/JDBC legal
files you got in the previous zip (`legal-service-hlms2.zip`). It's a
straight architectural port — same tables, same validation rules, same
generated-ID/notice-number logic — just running on Spring Boot + Spring
Data JPA instead of hand-written JDBC.

## What changed vs. the plain-Java version

| Plain Java (hlms2) | Spring Boot (this) |
|---|---|
| `hlms.entity.*` (POJOs) | `com.hlms2.legal.entity.*` — JPA `@Entity` classes |
| `hlms.dao.*` / `hlms.daoimpl.*` (hand-written JDBC) | `com.hlms2.legal.repository.*` — Spring Data `JpaRepository` |
| `hlms.service.*` / `hlms.serviceimpl.*` | Same interfaces/impls, now `@Service` beans, injected via constructor |
| `hlms.util.ValidationException` (checked) | `com.hlms2.legal.exception.ValidationException` (unchecked, mapped to HTTP 400 by a `@RestControllerAdvice`) |
| `hlms.util.DAOException` (checked) | Removed — JPA/Spring throw unchecked exceptions already; the global exception handler catches everything |
| `Main` class calling services directly | REST controllers (`/api/legal/verifications`, `/api/legal-notices`, `/api/legal/checklist-items`, `/api/bank-office/decisions`) |
| Foreign keys as lightweight `LoanApplication`/`AppUser` stub objects | `appId` stays a plain string column (that table isn't part of this module); `officerEmail` is verified via a REST call to `user-service` instead of a local JPA entity — see "Microservice integration" below |

**Business logic is untouched** — every validation rule, default value, and
ID-generation scheme is copied over exactly:

- `LegalVerification`: decision must be `PENDING/APPROVED/REJECTED`, officer
  required, remarks required if `REJECTED`.
- `LegalNotice`: auto-generates `noticeId`/`noticeNo`, `dueDate` must be
  on/after `issueDate`, status restricted to `DRAFT/SENT/DELIVERED/FAILED`,
  officer + content required.
- `LegalChecklistItem`: status restricted to
  `PENDING/COMPLETED/NOT_APPLICABLE`, defaults to `PENDING`.
- `BankOfficeDecision`: decision must be
  `APPROVED/CONDITIONALLY_APPROVED/REJECTED`, reason required unless
  `APPROVED`.

## Updated for hlms_schema_updated_v2.sql

Your v2 schema made three real changes to the legal domain, and the code
has been updated to match:

1. **Surrogate PKs.** `legal_verification` and `bank_office_decision` now
   have a real `BIGSERIAL` primary key (`verification_id`, `decision_id`)
   instead of using `app_id` as the PK. `app_id` is still there as a unique
   column, so `findByAppId(...)` (and a `GET .../by-application/{appId}`
   endpoint) is how you look things up the old way. `update()` now takes
   the surrogate id, not the appId.
2. **Column rename.** `bank_office_decision.decision` → `.status`. The
   entity, DTO, service, and controller all use `status` now.
3. **Soft delete everywhere.** Every entity owned by this module now has
   `deletedAt`. `delete()` was renamed to `softDelete()`
   — it sets `deleted_at = now()` instead of removing the row — and every
   `findById`/`findAll` filters `deletedAt IS NULL`. A matching `restore()`
   method + `POST .../{id}/restore` endpoint undoes it, mirroring your
   SQL-side `soft_delete()`/`restore_record()` functions.
4. `legal_verification` also picked up the `info_requested` /
   `info_request_details` / `info_requested_at` columns — carried straight
   through on create/update, no extra validation added since your schema
   doesn't require them either.

**Not implemented here:** the DB-level cascading soft-delete triggers (on
`loan_application` and `auction_case`) live entirely in the schema/database
— there's nothing for this service's code to do, since Postgres handles the
cascade itself when a row's `deleted_at` is set directly via SQL. But if
your `loan-service` calls this service's `softDelete()` endpoints instead
of writing `deleted_at` directly, the trigger won't fire — worth deciding
which path (direct DB trigger vs. cross-service call) you want to be the
source of truth for cascading deletes.

**Worth flagging:** the seed data in your v2 schema uses values like
`'Query Raised'` for `legal_verification.decision` and `'Pending'` for
`bank_office_decision.status`, but the original `hlms2` validation only
allowed `PENDING/APPROVED/REJECTED` and `APPROVED/REJECTED` respectively.
I added `PENDING` to the bank-office list and left the legal-verification
list as-is (matching what the original code enforced) — you may want to
widen `VALID_DECISIONS` in `LegalVerificationServiceImpl` to include
`QUERY_RAISED`/`VERIFIED` etc. if the seed values reflect your actual
intended states.

The DDL itself (`hlms_schema_updated_v2.sql`) is included in `schema/` for
reference.

## Microservice integration

This is 1 of 6 HLMS microservices. It owns `legal_verification`,
`legal_notice`, `legal_checklist_item`, and `bank_office_decision` only —
`app_user` belongs to `user-service`, so this module talks to it over REST
instead of reading its table directly.

**Current setup: static URLs, no discovery yet.**
There's no Eureka/Consul in the picture yet, so downstream services are
addressed by a plain base-URL property:

```properties
services.user-service.base-url=http://localhost:8081
```

**How the user-service call is wired:**

- `client/dto/UserDTO.java` — plain (non-JPA) DTO mirroring what
  `app_user` used to look like locally: `email`, `name`, `mobile`, `role`,
  `active`, `idType`, `idNumber`, `createdAt`, `deletedAt`.
- `client/feign/UserFeignClient.java` — the raw OpenFeign contract:
  `GET /api/users/{email}` → `UserDTO` or 404. **This is an assumed
  contract** — update the path/method here once user-service's actual API
  is confirmed; nothing else in the codebase depends on this class
  directly.
- `client/UserServiceClient.java` — the interface the service layer
  actually depends on (`Optional<UserDTO> findActiveUser(String email)`).
  Keeping this separate from the Feign interface means
  `BankOfficeDecisionServiceImpl`, `LegalVerificationServiceImpl`, and
  `LegalNoticeServiceImpl` can be unit-tested by mocking one plain
  interface, exactly as they previously mocked `AppUserRepository` — no
  Feign/HTTP concerns leak into the service layer or its tests.
- `client/UserServiceClientImpl.java` — the real implementation. Treats a
  clean 404 as "not found" (`Optional.empty()`), and anything else that
  goes wrong (timeout, connection refused, 5xx) as an `ExternalServiceException`,
  which `GlobalExceptionHandler` maps to `502 Bad Gateway` — so a legal
  decision failing because user-service is down looks different from one
  failing because the officer email is genuinely unknown.
- `config/FeignClientConfig.java` + `feign.client.config.default.*` in
  `application.properties` — shared timeouts (3s connect / 5s read) and
  logging level for every Feign client in this service.

`LegalChecklistItemServiceImpl` has no officer field, so it doesn't call
user-service at all.

**Adding the other 4 services.** The other 4 services in the system aren't
wired up yet since their contracts aren't confirmed — follow the exact same
three-file pattern (`client/dto/*`, `client/feign/*FeignClient`,
`client/*Client` + `*ClientImpl`) once you're ready, and add its
`services.<name>.base-url` property next to `user-service`'s in
`application.properties`.

**Migrating to service discovery later** (Eureka/Consul instead of static
URLs) needs exactly one change per client: delete the `url` attribute from
its `@FeignClient(name = "...", url = "...")` annotation so `name` resolves
through discovery instead. No service, controller, or test code changes.

**Config Server.** `spring-cloud-starter-config` is on the classpath and
`spring.config.import=optional:configserver:http://localhost:8888` is set,
but it's `optional:` — this service boots fine today with nothing listening
on 8888. Point it at a real Config Server whenever one exists and this
service starts pulling centralized config automatically.

**API Gateway.** No gateway-specific code is needed here — `Spring Cloud
Gateway` (or any reverse proxy) can route to this service by
`spring.application.name=legal-service` plus its port, and
`/actuator/health` (now exposed via `spring-boot-starter-actuator`) is what
it — or Eureka, later — would poll to check this instance is alive.

## One thing worth flagging

Your existing `hlms-microservices/legal-service` Spring Boot module (from
your first upload) is a **different, more advanced implementation** of the
same domain — it already has soft-delete (`deletedAt`), an
`infoRequested`/`infoRequestedAt` workflow on `LegalVerification`, JWT
security, Eureka registration, and identity-generated PKs instead of
`appId` as the primary key. This new module does **not** replace that one —
it's a fresh, standalone port of the plain-Java `hlms2` version only, kept
separate so nothing in your working microservices project gets overwritten.

## How to run in Eclipse

1. **File → Import → Maven → Existing Maven Projects**, point at this
   `legal-service/` folder (the one with `pom.xml`).
2. Update `src/main/resources/application.properties` with your actual
   Postgres credentials, and `services.user-service.base-url` with wherever
   `user-service` actually runs.
3. Make sure `legal_verification`, `legal_notice`, `legal_checklist_item`,
   and `bank_office_decision` tables already exist (`ddl-auto=validate`
   won't create them). `loan_application` and `app_user` just need to exist
   in the same database for the foreign keys to resolve — this service no
   longer reads `app_user` directly.
4. Have `user-service` running and reachable at the configured base URL
   before creating/updating a verification, notice, or bank-office decision
   — those calls now go out over REST to confirm the officer email. (Reads
   — `findById`/`findAll`/`findByAppId` — don't need it.)
5. Right-click `Hlms2LegalServiceApplication.java` → **Run As → Java
   Application**.
6. Test via `http://localhost:8084/api/legal/verifications`,
   `/api/legal-notices`, `/api/legal/checklist-items`,
   `/api/bank-office/decisions`, and `http://localhost:8084/actuator/health`.

No Eureka/Consul/Config Server is required to run this — it works standalone
on port 8084 with static config, and picks up centralized config or service
discovery automatically once you introduce either (see "Microservice
integration" above).
