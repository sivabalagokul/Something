package com.hlms2.legal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients(basePackages = "com.hlms2.legal.client.feign")
public class Hlms2LegalServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(Hlms2LegalServiceApplication.class, args);
    }
}
