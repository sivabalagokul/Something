package com.hlms2.legal.client;

import com.hlms2.legal.client.dto.UserDTO;

import java.util.Optional;

/**
 * What the service layer depends on to confirm an officer email is a real,
 * active user - deliberately independent of Feign so
 * BankOfficeDecisionServiceImpl / LegalVerificationServiceImpl /
 * LegalNoticeServiceImpl can be unit-tested by mocking this interface
 * directly, exactly as they previously mocked AppUserRepository.
 */
public interface UserServiceClient {

    /**
     * @return the user if user-service has an active, non-deleted user
     * with this email; Optional.empty() if the email is null, not found,
     * inactive, or soft-deleted.
     */
    Optional<UserDTO> findActiveUser(String email);
}
