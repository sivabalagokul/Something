package com.hlms2.legal.client;

import com.hlms2.legal.client.dto.UserDTO;
import com.hlms2.legal.client.feign.UserFeignClient;
import com.hlms2.legal.exception.ExternalServiceException;
import feign.FeignException;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class UserServiceClientImpl implements UserServiceClient {

    private final UserFeignClient userFeignClient;

    public UserServiceClientImpl(UserFeignClient userFeignClient) {
        this.userFeignClient = userFeignClient;
    }

    @Override
    public Optional<UserDTO> findActiveUser(String email) {
        if (email == null || email.isBlank()) {
            return Optional.empty();
        }
        try {
            UserDTO user = userFeignClient.getByEmail(email);
            if (user == null) {
                return Optional.empty();
            }
            boolean active = Boolean.TRUE.equals(user.getActive());
            boolean notDeleted = user.getDeletedAt() == null;
            return (active && notDeleted) ? Optional.of(user) : Optional.empty();
        } catch (FeignException.NotFound notFound) {
            return Optional.empty();
        } catch (FeignException feignException) {
            // Anything other than a clean 404 (timeout, 5xx, connection
            // refused because user-service isn't up, etc.) is a dependency
            // failure, not "this email doesn't exist" - surface it as such
            // instead of silently treating it like a validation failure.
            throw new ExternalServiceException("user-service", feignException);
        }
    }
}
