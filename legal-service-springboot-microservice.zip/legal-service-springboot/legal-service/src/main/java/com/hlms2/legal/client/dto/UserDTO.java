package com.hlms2.legal.client.dto;

import java.time.OffsetDateTime;

/**
 * Plain (non-JPA) representation of what user-service returns for a single
 * user. legal-service does not own the app_user table - in a proper
 * database-per-service microservice layout that table belongs to
 * user-service, so this is a wire-format DTO, not an entity.
 *
 * Field names mirror the previous local `AppUser` entity so existing
 * validation logic in the service layer needed no renaming, only a change
 * in where the data comes from (REST call instead of a local repository).
 *
 * Adjust the field set/names here to match user-service's actual response
 * shape once its contract is confirmed; this is a reasonable placeholder
 * based on the app_user table this service used to read directly.
 */
public class UserDTO {

    private String email;
    private String name;
    private String mobile;
    private String role;
    private Boolean active;
    private String idType;
    private String idNumber;
    private OffsetDateTime createdAt;
    private OffsetDateTime deletedAt;

    public UserDTO() {
    }

    public UserDTO(String email, String name, String mobile, String role, Boolean active, String idType,
                   String idNumber, OffsetDateTime createdAt, OffsetDateTime deletedAt) {
        this.email = email;
        this.name = name;
        this.mobile = mobile;
        this.role = role;
        this.active = active;
        this.idType = idType;
        this.idNumber = idNumber;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String email;
        private String name;
        private String mobile;
        private String role;
        private Boolean active;
        private String idType;
        private String idNumber;
        private OffsetDateTime createdAt;
        private OffsetDateTime deletedAt;

        public Builder email(String email) {
            this.email = email;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder mobile(String mobile) {
            this.mobile = mobile;
            return this;
        }

        public Builder role(String role) {
            this.role = role;
            return this;
        }

        public Builder active(Boolean active) {
            this.active = active;
            return this;
        }

        public Builder idType(String idType) {
            this.idType = idType;
            return this;
        }

        public Builder idNumber(String idNumber) {
            this.idNumber = idNumber;
            return this;
        }

        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public UserDTO build() {
            return new UserDTO(email, name, mobile, role, active, idType, idNumber, createdAt, deletedAt);
        }
    }
}
