package com.hlms2.legal.client.feign;

import com.hlms2.legal.client.dto.UserDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Raw Feign contract for user-service.
 *
 * "name" is the logical service id (what it will resolve through Eureka/
 * Consul once discovery is introduced); "url" pins it to a static address
 * for now via the services.user-service.base-url property. To switch to
 * discovery later, delete the url attribute here (and only here) - nothing
 * else in this codebase needs to change.
 *
 * Assumed contract: GET /api/users/{email} -> 200 with a UserDTO body, or
 * 404 if no such user exists. Update the path/method here once
 * user-service's actual API is confirmed; everything downstream
 * (UserServiceClientImpl, and the three services that consume it) only
 * depends on the UserServiceClient interface, not on this class directly.
 */
@FeignClient(name = "user-service", url = "${services.user-service.base-url}")
public interface UserFeignClient {

    @GetMapping("/api/users/{email}")
    UserDTO getByEmail(@PathVariable("email") String email);
}
