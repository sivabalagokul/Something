package com.hlms2.legal.config;

import feign.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Shared configuration applied to every Feign client in this service (see
 * feign.client.config.default.* in application.properties for the matching
 * timeout settings). Add per-client overrides here as more downstream
 * services are wired in.
 */
@Configuration
public class FeignClientConfig {

    @Bean
    public Logger.Level feignLoggerLevel() {
        // BASIC logs method, URL, status and execution time - enough to
        // debug integration issues without dumping full request/response
        // bodies. Requires logging.level.com.hlms2.legal.client=DEBUG to
        // actually show up.
        return Logger.Level.BASIC;
    }
}
