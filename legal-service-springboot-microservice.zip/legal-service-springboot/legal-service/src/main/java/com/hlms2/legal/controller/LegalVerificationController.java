package com.hlms2.legal.controller;

import com.hlms2.legal.dto.LegalVerificationDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.LegalVerificationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/legal/verifications")
public class LegalVerificationController {

    private final LegalVerificationService service;

    public LegalVerificationController(LegalVerificationService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<LegalVerificationDTO> create(@RequestBody LegalVerificationDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{verificationId}")
    public LegalVerificationDTO update(@PathVariable Long verificationId, @RequestBody LegalVerificationDTO dto) {
        return service.update(verificationId, dto);
    }

    @DeleteMapping("/{verificationId}")
    public ResponseEntity<Void> softDelete(@PathVariable Long verificationId) {
        return service.softDelete(verificationId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/{verificationId}/restore")
    public ResponseEntity<Void> restore(@PathVariable Long verificationId) {
        return service.restore(verificationId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{verificationId}")
    public LegalVerificationDTO findById(@PathVariable Long verificationId) {
        LegalVerificationDTO dto = service.findById(verificationId);
        if (dto == null) {
            throw new ResourceNotFoundException("No legal verification found with id " + verificationId + ".");
        }
        return dto;
    }

    @GetMapping("/by-application/{appId}")
    public LegalVerificationDTO findByAppId(@PathVariable String appId) {
        LegalVerificationDTO dto = service.findByAppId(appId);
        if (dto == null) {
            throw new ResourceNotFoundException("No legal verification found for application " + appId + ".");
        }
        return dto;
    }

    @GetMapping
    public List<LegalVerificationDTO> findAll() {
        return service.findAll();
    }
}
