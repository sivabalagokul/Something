package com.hlms2.legal.exception;

/**
 * Raised when a call to a downstream microservice (user-service, and
 * anything added later) fails for a reason other than "not found" - e.g.
 * it's unreachable, times out, or returns an unexpected error status.
 * Deliberately distinct from ValidationException/ResourceNotFoundException:
 * this is a dependency failure, not a problem with the caller's input, so
 * GlobalExceptionHandler maps it to 502 Bad Gateway rather than 400/404.
 */
public class ExternalServiceException extends RuntimeException {

    public ExternalServiceException(String serviceName, Throwable cause) {
        super("Call to downstream service '" + serviceName + "' failed: " + cause.getMessage(), cause);
    }

    public ExternalServiceException(String message) {
        super(message);
    }
}
