package com.hlms2.legal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hlms2LegalServiceApplicationTests {

    @Test
    void contextLoads() {
        // Verifies the Spring application context starts up successfully.
    }
}
