package com.hlms2.legal.client;

import com.hlms2.legal.client.dto.UserDTO;
import com.hlms2.legal.client.feign.UserFeignClient;
import com.hlms2.legal.exception.ExternalServiceException;
import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import feign.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceClientImplTest {

    @Mock
    private UserFeignClient userFeignClient;

    @InjectMocks
    private UserServiceClientImpl client;

    private Request dummyRequest() {
        return Request.create(Request.HttpMethod.GET, "/api/users/x",
                java.util.Map.of(), null, new RequestTemplate());
    }

    private FeignException feignExceptionWithStatus(int status) {
        Response response = Response.builder()
                .status(status)
                .request(dummyRequest())
                .headers(java.util.Map.of())
                .build();
        return FeignException.errorStatus("UserFeignClient#getByEmail(String)", response);
    }

    // ---------- happy path ----------

    @Test
    void findActiveUser_activeNonDeletedUser_returnsUser() {
        UserDTO user = UserDTO.builder().email("a@b.com").active(true).build();
        when(userFeignClient.getByEmail("a@b.com")).thenReturn(user);

        Optional<UserDTO> result = client.findActiveUser("a@b.com");

        assertTrue(result.isPresent());
        assertEquals("a@b.com", result.get().getEmail());
    }

    // ---------- negative / edge cases ----------

    @Test
    void findActiveUser_nullEmail_returnsEmpty_withoutCallingFeign() {
        assertTrue(client.findActiveUser(null).isEmpty());
    }

    @Test
    void findActiveUser_blankEmail_returnsEmpty_withoutCallingFeign() {
        assertTrue(client.findActiveUser("   ").isEmpty());
    }

    @Test
    void findActiveUser_feignReturnsNull_returnsEmpty() {
        when(userFeignClient.getByEmail("missing@b.com")).thenReturn(null);

        assertTrue(client.findActiveUser("missing@b.com").isEmpty());
    }

    @Test
    void findActiveUser_userInactive_returnsEmpty() {
        UserDTO user = UserDTO.builder().email("a@b.com").active(false).build();
        when(userFeignClient.getByEmail("a@b.com")).thenReturn(user);

        assertTrue(client.findActiveUser("a@b.com").isEmpty());
    }

    @Test
    void findActiveUser_userSoftDeleted_returnsEmpty() {
        UserDTO user = UserDTO.builder().email("a@b.com").active(true).deletedAt(OffsetDateTime.now()).build();
        when(userFeignClient.getByEmail("a@b.com")).thenReturn(user);

        assertTrue(client.findActiveUser("a@b.com").isEmpty());
    }

    @Test
    void findActiveUser_feignNotFound_returnsEmpty() {
        when(userFeignClient.getByEmail("missing@b.com")).thenThrow(feignExceptionWithStatus(404));

        assertTrue(client.findActiveUser("missing@b.com").isEmpty());
    }

    @Test
    void findActiveUser_feignServerError_throwsExternalServiceException() {
        when(userFeignClient.getByEmail("a@b.com")).thenThrow(feignExceptionWithStatus(500));

        ExternalServiceException ex = assertThrows(ExternalServiceException.class,
                () -> client.findActiveUser("a@b.com"));
        assertTrue(ex.getMessage().contains("user-service"));
    }
}
