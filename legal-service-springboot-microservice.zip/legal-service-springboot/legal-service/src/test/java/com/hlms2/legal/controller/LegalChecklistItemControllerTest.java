package com.hlms2.legal.controller;

import com.hlms2.legal.dto.LegalChecklistItemDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.LegalChecklistItemService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LegalChecklistItemControllerTest {

    @Mock
    private LegalChecklistItemService service;

    @InjectMocks
    private LegalChecklistItemController controller;

    @Test
    void create_delegatesToServiceAndReturns201() {
        LegalChecklistItemDTO dto = LegalChecklistItemDTO.builder().appId("APP-1").build();
        when(service.create(dto)).thenReturn(dto);

        ResponseEntity<LegalChecklistItemDTO> response = controller.create(dto);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(dto, response.getBody());
    }

    @Test
    void update_setsPathChecklistItemIdOnDtoBeforeDelegating() {
        LegalChecklistItemDTO dto = LegalChecklistItemDTO.builder().appId("APP-1").build();
        ArgumentCaptor<LegalChecklistItemDTO> captor = ArgumentCaptor.forClass(LegalChecklistItemDTO.class);
        when(service.update(captor.capture())).thenReturn(dto);

        controller.update("CHK-1", dto);

        assertEquals("CHK-1", captor.getValue().getChecklistItemId());
    }

    @Test
    void softDelete_found_returnsNoContent() {
        when(service.softDelete("CHK-1")).thenReturn(true);

        assertEquals(HttpStatus.NO_CONTENT, controller.softDelete("CHK-1").getStatusCode());
    }

    @Test
    void softDelete_notFound_returnsNotFound() {
        when(service.softDelete("CHK-404")).thenReturn(false);

        assertEquals(HttpStatus.NOT_FOUND, controller.softDelete("CHK-404").getStatusCode());
    }

    @Test
    void restore_found_returnsOk() {
        when(service.restore("CHK-1")).thenReturn(true);

        assertEquals(HttpStatus.OK, controller.restore("CHK-1").getStatusCode());
    }

    @Test
    void restore_notFound_returnsNotFound() {
        when(service.restore("CHK-404")).thenReturn(false);

        assertEquals(HttpStatus.NOT_FOUND, controller.restore("CHK-404").getStatusCode());
    }

    @Test
    void findById_found_returnsDto() {
        LegalChecklistItemDTO dto = LegalChecklistItemDTO.builder().appId("APP-1").build();
        when(service.findById("CHK-1")).thenReturn(dto);

        assertEquals(dto, controller.findById("CHK-1"));
    }

    @Test
    void findById_notFound_throwsResourceNotFoundException() {
        when(service.findById("CHK-404")).thenReturn(null);

        assertThrows(ResourceNotFoundException.class, () -> controller.findById("CHK-404"));
    }

    @Test
    void findAll_delegatesToService() {
        LegalChecklistItemDTO dto = LegalChecklistItemDTO.builder().appId("APP-1").build();
        when(service.findAll()).thenReturn(List.of(dto));

        assertEquals(1, controller.findAll().size());
    }

    @Test
    void findAll_empty_returnsEmptyList() {
        when(service.findAll()).thenReturn(List.of());

        assertTrue(controller.findAll().isEmpty());
    }
}
