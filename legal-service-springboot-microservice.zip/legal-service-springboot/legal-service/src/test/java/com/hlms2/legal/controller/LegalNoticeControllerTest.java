package com.hlms2.legal.controller;

import com.hlms2.legal.dto.LegalNoticeDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.LegalNoticeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LegalNoticeControllerTest {

    @Mock
    private LegalNoticeService service;

    @InjectMocks
    private LegalNoticeController controller;

    @Test
    void create_delegatesToServiceAndReturns201() {
        LegalNoticeDTO dto = LegalNoticeDTO.builder().appId("APP-1").build();
        when(service.create(dto)).thenReturn(dto);

        ResponseEntity<LegalNoticeDTO> response = controller.create(dto);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(dto, response.getBody());
    }

    @Test
    void update_setsPathNoticeIdOnDtoBeforeDelegating() {
        LegalNoticeDTO dto = LegalNoticeDTO.builder().appId("APP-1").build();
        ArgumentCaptor<LegalNoticeDTO> captor = ArgumentCaptor.forClass(LegalNoticeDTO.class);
        when(service.update(captor.capture())).thenReturn(dto);

        controller.update("NOT-1", dto);

        assertEquals("NOT-1", captor.getValue().getNoticeId());
    }

    @Test
    void softDelete_found_returnsNoContent() {
        when(service.softDelete("NOT-1")).thenReturn(true);

        assertEquals(HttpStatus.NO_CONTENT, controller.softDelete("NOT-1").getStatusCode());
    }

    @Test
    void softDelete_notFound_returnsNotFound() {
        when(service.softDelete("NOT-404")).thenReturn(false);

        assertEquals(HttpStatus.NOT_FOUND, controller.softDelete("NOT-404").getStatusCode());
    }

    @Test
    void restore_found_returnsOk() {
        when(service.restore("NOT-1")).thenReturn(true);

        assertEquals(HttpStatus.OK, controller.restore("NOT-1").getStatusCode());
    }

    @Test
    void restore_notFound_returnsNotFound() {
        when(service.restore("NOT-404")).thenReturn(false);

        assertEquals(HttpStatus.NOT_FOUND, controller.restore("NOT-404").getStatusCode());
    }

    @Test
    void findById_found_returnsDto() {
        LegalNoticeDTO dto = LegalNoticeDTO.builder().appId("APP-1").build();
        when(service.findById("NOT-1")).thenReturn(dto);

        assertEquals(dto, controller.findById("NOT-1"));
    }

    @Test
    void findById_notFound_throwsResourceNotFoundException() {
        when(service.findById("NOT-404")).thenReturn(null);

        assertThrows(ResourceNotFoundException.class, () -> controller.findById("NOT-404"));
    }

    @Test
    void findAll_delegatesToService() {
        LegalNoticeDTO dto = LegalNoticeDTO.builder().appId("APP-1").build();
        when(service.findAll()).thenReturn(List.of(dto));

        assertEquals(1, controller.findAll().size());
    }

    @Test
    void findAll_empty_returnsEmptyList() {
        when(service.findAll()).thenReturn(List.of());

        assertTrue(controller.findAll().isEmpty());
    }
}
