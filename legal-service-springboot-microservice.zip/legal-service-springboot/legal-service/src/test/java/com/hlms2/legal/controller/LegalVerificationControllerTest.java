package com.hlms2.legal.controller;

import com.hlms2.legal.dto.LegalVerificationDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.LegalVerificationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LegalVerificationControllerTest {

    @Mock
    private LegalVerificationService service;

    @InjectMocks
    private LegalVerificationController controller;

    @Test
    void create_delegatesToServiceAndReturns201() {
        LegalVerificationDTO dto = LegalVerificationDTO.builder().appId("APP-1").build();
        when(service.create(dto)).thenReturn(dto);

        ResponseEntity<LegalVerificationDTO> response = controller.create(dto);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(dto, response.getBody());
    }

    @Test
    void update_delegatesToService() {
        LegalVerificationDTO dto = LegalVerificationDTO.builder().appId("APP-1").build();
        when(service.update(7L, dto)).thenReturn(dto);

        assertEquals(dto, controller.update(7L, dto));
    }

    @Test
    void softDelete_found_returnsNoContent() {
        when(service.softDelete(7L)).thenReturn(true);

        assertEquals(HttpStatus.NO_CONTENT, controller.softDelete(7L).getStatusCode());
    }

    @Test
    void softDelete_notFound_returnsNotFound() {
        when(service.softDelete(999L)).thenReturn(false);

        assertEquals(HttpStatus.NOT_FOUND, controller.softDelete(999L).getStatusCode());
    }

    @Test
    void restore_found_returnsOk() {
        when(service.restore(7L)).thenReturn(true);

        assertEquals(HttpStatus.OK, controller.restore(7L).getStatusCode());
    }

    @Test
    void restore_notFound_returnsNotFound() {
        when(service.restore(999L)).thenReturn(false);

        assertEquals(HttpStatus.NOT_FOUND, controller.restore(999L).getStatusCode());
    }

    @Test
    void findById_found_returnsDto() {
        LegalVerificationDTO dto = LegalVerificationDTO.builder().appId("APP-1").build();
        when(service.findById(7L)).thenReturn(dto);

        assertEquals(dto, controller.findById(7L));
    }

    @Test
    void findById_notFound_throwsResourceNotFoundException() {
        when(service.findById(999L)).thenReturn(null);

        assertThrows(ResourceNotFoundException.class, () -> controller.findById(999L));
    }

    @Test
    void findByAppId_found_returnsDto() {
        LegalVerificationDTO dto = LegalVerificationDTO.builder().appId("APP-1").build();
        when(service.findByAppId("APP-1")).thenReturn(dto);

        assertEquals(dto, controller.findByAppId("APP-1"));
    }

    @Test
    void findByAppId_notFound_throwsResourceNotFoundException() {
        when(service.findByAppId("APP-404")).thenReturn(null);

        assertThrows(ResourceNotFoundException.class, () -> controller.findByAppId("APP-404"));
    }

    @Test
    void findAll_delegatesToService() {
        LegalVerificationDTO dto = LegalVerificationDTO.builder().appId("APP-1").build();
        when(service.findAll()).thenReturn(List.of(dto));

        assertEquals(1, controller.findAll().size());
    }

    @Test
    void findAll_empty_returnsEmptyList() {
        when(service.findAll()).thenReturn(List.of());

        assertTrue(controller.findAll().isEmpty());
    }
}
