package com.hlms2.legal.exception;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class ValidatorsTest {

    // ---------- required() ----------

    @Test
    void required_nullValue_throws() {
        ValidationException ex = assertThrows(ValidationException.class, () -> Validators.required(null, "field"));
        assertEquals("field is required.", ex.getMessage());
    }

    @Test
    void required_blankString_throws() {
        assertThrows(ValidationException.class, () -> Validators.required("   ", "field"));
    }

    @Test
    void required_emptyString_throws() {
        assertThrows(ValidationException.class, () -> Validators.required("", "field"));
    }

    @Test
    void required_nonBlankString_doesNotThrow() {
        assertDoesNotThrow(() -> Validators.required("value", "field"));
    }

    @Test
    void required_nonStringObject_doesNotThrow() {
        assertDoesNotThrow(() -> Validators.required(42L, "field"));
    }

    // ---------- oneOf() ----------

    @Test
    void oneOf_nullValue_throws() {
        assertThrows(ValidationException.class, () -> Validators.oneOf(null, "status", "A", "B"));
    }

    @Test
    void oneOf_valueNotInAllowedList_throws() {
        ValidationException ex = assertThrows(ValidationException.class,
                () -> Validators.oneOf("C", "status", "A", "B"));
        assertTrue(ex.getMessage().contains("status"));
    }

    @Test
    void oneOf_exactMatch_doesNotThrow() {
        assertDoesNotThrow(() -> Validators.oneOf("A", "status", "A", "B"));
    }

    @Test
    void oneOf_caseInsensitiveMatch_doesNotThrow() {
        assertDoesNotThrow(() -> Validators.oneOf("a", "status", "A", "B"));
    }

    // ---------- afterOrEqual() ----------

    @Test
    void afterOrEqual_laterIsNull_doesNotThrow() {
        assertDoesNotThrow(() -> Validators.afterOrEqual(null, LocalDate.now(), "due", "issue"));
    }

    @Test
    void afterOrEqual_earlierIsNull_doesNotThrow() {
        assertDoesNotThrow(() -> Validators.afterOrEqual(LocalDate.now(), null, "due", "issue"));
    }

    @Test
    void afterOrEqual_laterBeforeEarlier_throws() {
        LocalDate earlier = LocalDate.of(2026, 1, 10);
        LocalDate later = LocalDate.of(2026, 1, 1);

        ValidationException ex = assertThrows(ValidationException.class,
                () -> Validators.afterOrEqual(later, earlier, "due", "issue"));
        assertTrue(ex.getMessage().contains("due"));
    }

    @Test
    void afterOrEqual_datesEqual_doesNotThrow() {
        LocalDate date = LocalDate.of(2026, 1, 10);

        assertDoesNotThrow(() -> Validators.afterOrEqual(date, date, "due", "issue"));
    }

    @Test
    void afterOrEqual_laterAfterEarlier_doesNotThrow() {
        LocalDate earlier = LocalDate.of(2026, 1, 1);
        LocalDate later = LocalDate.of(2026, 1, 10);

        assertDoesNotThrow(() -> Validators.afterOrEqual(later, earlier, "due", "issue"));
    }
}
