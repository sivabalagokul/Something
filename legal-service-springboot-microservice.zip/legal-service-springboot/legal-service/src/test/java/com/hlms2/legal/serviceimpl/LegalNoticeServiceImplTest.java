package com.hlms2.legal.serviceimpl;

import com.hlms2.legal.dto.LegalNoticeDTO;
import com.hlms2.legal.client.dto.UserDTO;
import com.hlms2.legal.entity.LegalNotice;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.client.UserServiceClient;
import com.hlms2.legal.repository.LegalNoticeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LegalNoticeServiceImplTest {

    @Mock
    private LegalNoticeRepository repository;

    @Mock
    private UserServiceClient userServiceClient;

    @InjectMocks
    private LegalNoticeServiceImpl service;

    private LegalNoticeDTO validDto;

    @BeforeEach
    void setUp() {
        validDto = LegalNoticeDTO.builder()
                .appId("APP-1")
                .noticeType("DEMAND_NOTICE")
                .issueDate(LocalDate.of(2026, 1, 1))
                .dueDate(LocalDate.of(2026, 1, 15))
                .officerEmail("legal@bank.com")
                .content("Please settle your dues.")
                .build();
    }

    private void stubActiveOfficer() {
        when(userServiceClient.findActiveUser("legal@bank.com"))
                .thenReturn(Optional.of(UserDTO.builder().email("legal@bank.com").active(true).build()));
    }

    private void stubSaveReturnsArgument() {
        when(repository.save(any(LegalNotice.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    // ---------- create() ----------

    @Test
    void create_success_generatesNoticeIdAndNoticeNo_whenNotProvided() {
        stubActiveOfficer();
        stubSaveReturnsArgument();

        LegalNoticeDTO result = service.create(validDto);

        assertNotNull(result.getNoticeId());
        assertTrue(result.getNoticeId().startsWith("NOT-"));
        assertNotNull(result.getNoticeNo());
        assertTrue(result.getNoticeNo().startsWith("NOTICE-2026-01-01-"));
        assertTrue(result.getNoticeNo().endsWith(result.getNoticeId().substring(result.getNoticeId().length() - 4)));
    }

    @Test
    void create_defaultsStatusToDraft_whenNotProvided() {
        stubActiveOfficer();
        stubSaveReturnsArgument();

        LegalNoticeDTO result = service.create(validDto);

        assertEquals("DRAFT", result.getStatus());
    }

    @Test
    void create_usesProvidedStatus() {
        validDto.setStatus("SENT");
        stubActiveOfficer();
        stubSaveReturnsArgument();

        LegalNoticeDTO result = service.create(validDto);

        assertEquals("SENT", result.getStatus());
    }

    @Test
    void create_dueDateEqualToIssueDate_isAllowed() {
        validDto.setDueDate(validDto.getIssueDate());
        stubActiveOfficer();
        stubSaveReturnsArgument();

        assertDoesNotThrow(() -> service.create(validDto));
    }

    @Test
    void create_dueDateBeforeIssueDate_throwsValidationException() {
        validDto.setDueDate(LocalDate.of(2025, 12, 31));

        ValidationException ex = assertThrows(ValidationException.class, () -> service.create(validDto));
        assertTrue(ex.getMessage().contains("dueDate"));
        verify(repository, never()).save(any());
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        validDto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(validDto));
        verifyNoInteractions(repository);
    }

    @Test
    void create_invalidNoticeType_throwsValidationException() {
        validDto.setNoticeType("NOT_A_TYPE");

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_missingIssueDate_throwsValidationException() {
        validDto.setIssueDate(null);

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_invalidStatus_throwsValidationException_whenProvided() {
        validDto.setStatus("BOGUS");

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_missingOfficerEmail_throwsValidationException() {
        validDto.setOfficerEmail(null);

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_officerNotActive_throwsValidationException() {
        when(userServiceClient.findActiveUser("legal@bank.com"))
                .thenReturn(Optional.empty());

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_missingContent_throwsValidationException() {
        validDto.setContent(null);
        stubActiveOfficer();

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    // ---------- update() ----------

    @Test
    void update_success_preservesExistingNoticeNo_whenDtoNoticeNoNull() {
        validDto.setNoticeId("NOT-ABCD1234");
        LegalNotice existing = LegalNotice.builder()
                .noticeId("NOT-ABCD1234").noticeNo("NOTICE-2025-01-01-1234")
                .appId("APP-1").noticeType("DEMAND_NOTICE")
                .issueDate(LocalDate.of(2026, 1, 1)).dueDate(LocalDate.of(2026, 1, 15))
                .officerEmail("legal@bank.com").content("old").build();
        when(repository.findByNoticeIdAndDeletedAtIsNull("NOT-ABCD1234")).thenReturn(Optional.of(existing));
        stubActiveOfficer();
        stubSaveReturnsArgument();

        LegalNoticeDTO result = service.update(validDto);

        assertEquals("NOTICE-2025-01-01-1234", result.getNoticeNo());
    }

    @Test
    void update_usesProvidedNoticeNo_whenGiven() {
        validDto.setNoticeId("NOT-ABCD1234");
        validDto.setNoticeNo("CUSTOM-NOTICE-NO");
        LegalNotice existing = LegalNotice.builder()
                .noticeId("NOT-ABCD1234").noticeNo("NOTICE-2025-01-01-1234")
                .appId("APP-1").noticeType("DEMAND_NOTICE")
                .issueDate(LocalDate.of(2026, 1, 1)).dueDate(LocalDate.of(2026, 1, 15))
                .officerEmail("legal@bank.com").content("old").build();
        when(repository.findByNoticeIdAndDeletedAtIsNull("NOT-ABCD1234")).thenReturn(Optional.of(existing));
        stubActiveOfficer();
        stubSaveReturnsArgument();

        LegalNoticeDTO result = service.update(validDto);

        assertEquals("CUSTOM-NOTICE-NO", result.getNoticeNo());
    }

    @Test
    void update_missingNoticeId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.update(validDto));
        verifyNoInteractions(repository);
    }

    @Test
    void update_notFound_throwsResourceNotFoundException() {
        validDto.setNoticeId("NOT-MISSING");
        when(repository.findByNoticeIdAndDeletedAtIsNull("NOT-MISSING")).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.update(validDto));
    }

    // ---------- softDelete() ----------

    @Test
    void softDelete_found_returnsTrue() {
        LegalNotice existing = LegalNotice.builder().noticeId("NOT-1").build();
        when(repository.findByNoticeIdAndDeletedAtIsNull("NOT-1")).thenReturn(Optional.of(existing));
        ArgumentCaptor<LegalNotice> captor = ArgumentCaptor.forClass(LegalNotice.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        assertTrue(service.softDelete("NOT-1"));
        assertNotNull(captor.getValue().getDeletedAt());
    }

    @Test
    void softDelete_notFound_returnsFalse() {
        when(repository.findByNoticeIdAndDeletedAtIsNull("NOT-404")).thenReturn(Optional.empty());

        assertFalse(service.softDelete("NOT-404"));
    }

    // ---------- restore() ----------

    @Test
    void restore_foundAndDeleted_returnsTrue() {
        LegalNotice existing = LegalNotice.builder().noticeId("NOT-1").deletedAt(OffsetDateTime.now()).build();
        when(repository.findById("NOT-1")).thenReturn(Optional.of(existing));
        ArgumentCaptor<LegalNotice> captor = ArgumentCaptor.forClass(LegalNotice.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        assertTrue(service.restore("NOT-1"));
        assertNull(captor.getValue().getDeletedAt());
    }

    @Test
    void restore_foundButNotDeleted_returnsFalse() {
        LegalNotice existing = LegalNotice.builder().noticeId("NOT-1").deletedAt(null).build();
        when(repository.findById("NOT-1")).thenReturn(Optional.of(existing));

        assertFalse(service.restore("NOT-1"));
    }

    @Test
    void restore_notFound_returnsFalse() {
        when(repository.findById("NOT-404")).thenReturn(Optional.empty());

        assertFalse(service.restore("NOT-404"));
    }

    // ---------- findById() ----------

    @Test
    void findById_missingNoticeId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.findById(null));
    }

    @Test
    void findById_found_returnsDto() {
        when(repository.findByNoticeIdAndDeletedAtIsNull("NOT-1"))
                .thenReturn(Optional.of(LegalNotice.builder().noticeId("NOT-1").appId("APP-1").build()));

        LegalNoticeDTO result = service.findById("NOT-1");

        assertNotNull(result);
        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void findById_notFound_returnsNull() {
        when(repository.findByNoticeIdAndDeletedAtIsNull("NOT-404")).thenReturn(Optional.empty());

        assertNull(service.findById("NOT-404"));
    }

    // ---------- findAll() ----------

    @Test
    void findAll_returnsMappedList() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of(
                LegalNotice.builder().noticeId("NOT-1").build(),
                LegalNotice.builder().noticeId("NOT-2").build()));

        assertEquals(2, service.findAll().size());
    }

    @Test
    void findAll_empty_returnsEmptyList() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of());

        assertTrue(service.findAll().isEmpty());
    }
}
