package com.hlms2.legal.exception;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    void handleValidation_returnsBadRequestWithMessage() {
        ResponseEntity<ApiError> response = handler.handleValidation(new ValidationException("bad input"));

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("bad input", response.getBody().getMessage());
        assertEquals(400, response.getBody().getStatus());
    }

    @Test
    void handleNotFound_returnsNotFoundWithMessage() {
        ResponseEntity<ApiError> response = handler.handleNotFound(new ResourceNotFoundException("missing"));

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("missing", response.getBody().getMessage());
    }

    @Test
    void handleGeneric_returnsInternalServerErrorWithMessage() {
        ResponseEntity<ApiError> response = handler.handleGeneric(new RuntimeException("boom"));

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("boom", response.getBody().getMessage());
    }

    @Test
    void apiError_timestampDefaultsToNow_whenNotSupplied() {
        ApiError error = new ApiError(500, "oops");

        assertEquals(500, error.getStatus());
        assertEquals("oops", error.getMessage());
        assertNotNull(error.getTimestamp());
    }

    @Test
    void apiError_usesSuppliedTimestamp() {
        var fixed = java.time.OffsetDateTime.parse("2026-01-01T00:00:00Z");
        ApiError error = new ApiError(404, "not found", fixed);

        assertEquals(fixed, error.getTimestamp());
    }

    @Test
    void validationException_carriesMessage() {
        assertEquals("bad", new ValidationException("bad").getMessage());
    }

    @Test
    void resourceNotFoundException_carriesMessage() {
        assertEquals("gone", new ResourceNotFoundException("gone").getMessage());
    }
}
