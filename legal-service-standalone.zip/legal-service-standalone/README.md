# legal-service — Spring Boot port of hlms2's legal domain

This is a standalone Spring Boot module built from the plain-Java/JDBC legal
files you got in the previous zip (`legal-service-hlms2.zip`). It's a
straight architectural port — same tables, same validation rules, same
generated-ID/notice-number logic — just running on Spring Boot + Spring
Data JPA instead of hand-written JDBC.

## What changed vs. the plain-Java version

| Plain Java (hlms2) | Spring Boot (this) |
|---|---|
| `hlms.entity.*` (POJOs) | `com.hlms2.legal.entity.*` — JPA `@Entity` classes |
| `hlms.dao.*` / `hlms.daoimpl.*` (hand-written JDBC) | `com.hlms2.legal.repository.*` — Spring Data `JpaRepository` |
| `hlms.service.*` / `hlms.serviceimpl.*` | Same interfaces/impls, now `@Service` beans, injected via constructor |
| `hlms.util.ValidationException` (checked) | `com.hlms2.legal.exception.ValidationException` (unchecked, mapped to HTTP 400 by a `@RestControllerAdvice`) |
| `hlms.util.DAOException` (checked) | Removed — JPA/Spring throw unchecked exceptions already; the global exception handler catches everything |
| `Main` class calling services directly | REST controllers (`/api/legal/verifications`, `/api/legal-notices`, `/api/legal/checklist-items`, `/api/bank-office/decisions`) |
| Foreign keys as lightweight `LoanApplication`/`AppUser` stub objects | Flattened to plain `appId` / `officerEmail` string columns (no `@ManyToOne`, since those tables aren't part of this module) |

**Business logic is untouched** — every validation rule, default value, and
ID-generation scheme is copied over exactly:

- `LegalVerification`: decision must be `PENDING/APPROVED/REJECTED`, officer
  required, remarks required if `REJECTED`.
- `LegalNotice`: auto-generates `noticeId`/`noticeNo`, `dueDate` must be
  on/after `issueDate`, status restricted to `DRAFT/SENT/DELIVERED/FAILED`,
  officer + content required.
- `LegalChecklistItem`: status restricted to
  `PENDING/COMPLETED/NOT_APPLICABLE`, defaults to `PENDING`.
- `BankOfficeDecision`: decision must be
  `APPROVED/CONDITIONALLY_APPROVED/REJECTED`, reason required unless
  `APPROVED`.

## AppUser

`app_user` isn't owned by this service (that's the `user-service` domain),
but every officer field on these 4 tables is a foreign key into it
(`officer VARCHAR(255) REFERENCES app_user(email)`), so it's included the
same way your existing Spring `legal-service` module includes it: as a
read-mostly reference entity + repository, used only to confirm an officer
email is a real, active user before a decision/notice/verification is saved
against it.

- `entity/AppUser.java` — maps the full `app_user` table (matching the
  `hlms2` schema fields)
- `repository/AppUserRepository.java` — `findByEmailAndActiveTrue(email)`
- Wired into `LegalVerificationServiceImpl`, `LegalNoticeServiceImpl`, and
  `BankOfficeDecisionServiceImpl` — each now throws a `ValidationException`
  if `officerEmail` doesn't match a real, active `app_user` row.
  (`LegalChecklistItemServiceImpl` has no officer field, so it's untouched.)

This service still doesn't **own** `app_user` — no create/update/delete
endpoints for it here, same as your existing `legal-service` module, which
only ever reads from it (for JWT auth via `CustomUserDetailsService`).

## One thing worth flagging

Your existing `hlms-microservices/legal-service` Spring Boot module (from
your first upload) is a **different, more advanced implementation** of the
same domain — it already has soft-delete (`deletedAt`), an
`infoRequested`/`infoRequestedAt` workflow on `LegalVerification`, JWT
security, Eureka registration, and identity-generated PKs instead of
`appId` as the primary key. This new module does **not** replace that one —
it's a fresh, standalone port of the plain-Java `hlms2` version only, kept
separate so nothing in your working microservices project gets overwritten.

## How to run in Eclipse

1. **File → Import → Maven → Existing Maven Projects**, point at this
   `legal-service/` folder (the one with `pom.xml`).
2. Update `src/main/resources/application.properties` with your actual
   Postgres credentials.
3. Make sure `loan_application`, `app_user`, `legal_verification`,
   `legal_notice`, `legal_checklist_item`, and `bank_office_decision` tables
   already exist (`ddl-auto=validate` won't create them).
4. Right-click `Hlms2LegalServiceApplication.java` → **Run As → Java
   Application**.
5. Test via `http://localhost:8084/api/legal/verifications`,
   `/api/legal-notices`, `/api/legal/checklist-items`,
   `/api/bank-office/decisions`.

This module is standalone (no Eureka/Config Server dependency) — it runs on
its own on port 8084.
