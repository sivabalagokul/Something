package com.hlms2.legal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hlms2LegalServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(Hlms2LegalServiceApplication.class, args);
    }
}
