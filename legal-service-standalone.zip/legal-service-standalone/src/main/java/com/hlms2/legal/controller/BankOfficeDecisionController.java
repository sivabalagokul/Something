package com.hlms2.legal.controller;

import com.hlms2.legal.dto.BankOfficeDecisionDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.BankOfficeDecisionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bank-office/decisions")
@RequiredArgsConstructor
public class BankOfficeDecisionController {

    private final BankOfficeDecisionService service;

    @PostMapping
    public ResponseEntity<BankOfficeDecisionDTO> create(@RequestBody BankOfficeDecisionDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{appId}")
    public BankOfficeDecisionDTO update(@PathVariable String appId, @RequestBody BankOfficeDecisionDTO dto) {
        dto.setAppId(appId);
        return service.update(dto);
    }

    @DeleteMapping("/{appId}")
    public ResponseEntity<Void> delete(@PathVariable String appId) {
        return service.delete(appId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{appId}")
    public BankOfficeDecisionDTO findById(@PathVariable String appId) {
        BankOfficeDecisionDTO dto = service.findById(appId);
        if (dto == null) {
            throw new ResourceNotFoundException("No bank office decision found for application " + appId + ".");
        }
        return dto;
    }

    @GetMapping
    public List<BankOfficeDecisionDTO> findAll() {
        return service.findAll();
    }
}
