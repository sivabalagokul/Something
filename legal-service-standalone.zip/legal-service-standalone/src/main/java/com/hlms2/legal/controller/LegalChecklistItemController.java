package com.hlms2.legal.controller;

import com.hlms2.legal.dto.LegalChecklistItemDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.LegalChecklistItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/legal/checklist-items")
@RequiredArgsConstructor
public class LegalChecklistItemController {

    private final LegalChecklistItemService service;

    @PostMapping
    public ResponseEntity<LegalChecklistItemDTO> create(@RequestBody LegalChecklistItemDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{checklistItemId}")
    public LegalChecklistItemDTO update(@PathVariable String checklistItemId, @RequestBody LegalChecklistItemDTO dto) {
        dto.setChecklistItemId(checklistItemId);
        return service.update(dto);
    }

    @DeleteMapping("/{checklistItemId}")
    public ResponseEntity<Void> delete(@PathVariable String checklistItemId) {
        return service.delete(checklistItemId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{checklistItemId}")
    public LegalChecklistItemDTO findById(@PathVariable String checklistItemId) {
        LegalChecklistItemDTO dto = service.findById(checklistItemId);
        if (dto == null) {
            throw new ResourceNotFoundException("Checklist item " + checklistItemId + " does not exist.");
        }
        return dto;
    }

    @GetMapping
    public List<LegalChecklistItemDTO> findAll() {
        return service.findAll();
    }
}
