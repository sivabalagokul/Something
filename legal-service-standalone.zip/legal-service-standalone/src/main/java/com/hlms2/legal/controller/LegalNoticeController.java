package com.hlms2.legal.controller;

import com.hlms2.legal.dto.LegalNoticeDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.LegalNoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/legal-notices")
@RequiredArgsConstructor
public class LegalNoticeController {

    private final LegalNoticeService service;

    @PostMapping
    public ResponseEntity<LegalNoticeDTO> create(@RequestBody LegalNoticeDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{noticeId}")
    public LegalNoticeDTO update(@PathVariable String noticeId, @RequestBody LegalNoticeDTO dto) {
        dto.setNoticeId(noticeId);
        return service.update(dto);
    }

    @DeleteMapping("/{noticeId}")
    public ResponseEntity<Void> delete(@PathVariable String noticeId) {
        return service.delete(noticeId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{noticeId}")
    public LegalNoticeDTO findById(@PathVariable String noticeId) {
        LegalNoticeDTO dto = service.findById(noticeId);
        if (dto == null) {
            throw new ResourceNotFoundException("Notice " + noticeId + " does not exist.");
        }
        return dto;
    }

    @GetMapping
    public List<LegalNoticeDTO> findAll() {
        return service.findAll();
    }
}
