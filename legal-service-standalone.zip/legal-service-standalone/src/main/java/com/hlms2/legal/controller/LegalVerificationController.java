package com.hlms2.legal.controller;

import com.hlms2.legal.dto.LegalVerificationDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.LegalVerificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/legal/verifications")
@RequiredArgsConstructor
public class LegalVerificationController {

    private final LegalVerificationService service;

    @PostMapping
    public ResponseEntity<LegalVerificationDTO> create(@RequestBody LegalVerificationDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{appId}")
    public LegalVerificationDTO update(@PathVariable String appId, @RequestBody LegalVerificationDTO dto) {
        dto.setAppId(appId);
        return service.update(dto);
    }

    @DeleteMapping("/{appId}")
    public ResponseEntity<Void> delete(@PathVariable String appId) {
        return service.delete(appId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{appId}")
    public LegalVerificationDTO findById(@PathVariable String appId) {
        LegalVerificationDTO dto = service.findById(appId);
        if (dto == null) {
            throw new ResourceNotFoundException("No legal verification found for application " + appId + ".");
        }
        return dto;
    }

    @GetMapping
    public List<LegalVerificationDTO> findAll() {
        return service.findAll();
    }
}
