package com.hlms2.legal.dto;

import lombok.*;

import java.time.OffsetDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BankOfficeDecisionDTO {
    private String appId;
    private String decision;
    private String officerEmail;
    private OffsetDateTime decisionDate;
    private String reason;
    private String remarks;
}
