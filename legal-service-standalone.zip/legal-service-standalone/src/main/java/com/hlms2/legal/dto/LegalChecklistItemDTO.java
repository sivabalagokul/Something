package com.hlms2.legal.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LegalChecklistItemDTO {
    private String checklistItemId;
    private String appId;
    private String checklistKey;
    private String status;
}
