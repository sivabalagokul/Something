package com.hlms2.legal.dto;

import lombok.*;

import java.time.LocalDate;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LegalNoticeDTO {
    private String noticeId;
    private String noticeNo;
    private String appId;
    private String noticeType;
    private LocalDate issueDate;
    private LocalDate dueDate;
    private String status;
    private String officerEmail;
    private String content;
}
