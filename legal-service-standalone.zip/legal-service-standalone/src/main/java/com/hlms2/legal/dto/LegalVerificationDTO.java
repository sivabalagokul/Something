package com.hlms2.legal.dto;

import lombok.*;

import java.time.OffsetDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LegalVerificationDTO {
    private String appId;
    private String decision;
    private OffsetDateTime decisionDate;
    private String officerEmail;
    private String remarks;
}
