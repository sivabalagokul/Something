package com.hlms2.legal.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'app_user'. Ported from hlms2.entity.AppUser.
 *
 * This service doesn't own the app_user table (that belongs to the
 * user-service domain) - it's mapped here read-mostly, the same way the
 * app_id/officer foreign keys on legal_verification, legal_notice,
 * legal_checklist_item and bank_office_decision all reference it. Used to
 * confirm an officer email is a real, active user before a legal decision
 * is recorded against it.
 */
@Entity
@Table(name = "app_user")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AppUser {

    @Id
    @Column(name = "email", length = 255)
    private String email;

    @Column(name = "name", length = 150, nullable = false)
    private String name;

    @Column(name = "mobile", length = 20, nullable = false)
    private String mobile;

    @JsonIgnore
    @Column(name = "password_hash", length = 255, nullable = false)
    private String passwordHash;

    @Column(name = "role", length = 30, nullable = false)
    private String role; // customer, legal, bankoffice, bidder, admin

    @Column(name = "active", nullable = false)
    private Boolean active;

    @Column(name = "id_type", length = 30)
    private String idType;

    @Column(name = "id_number", length = 50)
    private String idNumber;

    @Column(name = "pref_sms", nullable = false)
    private Boolean prefSms;

    @Column(name = "pref_email", nullable = false)
    private Boolean prefEmail;

    @Column(name = "pref_inapp", nullable = false)
    private Boolean prefInapp;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;
}
