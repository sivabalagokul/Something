package com.hlms2.legal.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'bank_office_decision'.
 * Ported from hlms2.entity.BankOfficeDecision (plain JDBC version) -
 * appId is the primary key, matching the hlms2 schema
 * (app_id VARCHAR(50) PRIMARY KEY REFERENCES loan_application(app_id)).
 */
@Entity
@Table(name = "bank_office_decision")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BankOfficeDecision {

    @Id
    @Column(name = "app_id", length = 50)
    private String appId;

    @Column(name = "decision", length = 30)
    private String decision;

    @Column(name = "officer")
    private String officerEmail;

    @Column(name = "decision_date")
    private OffsetDateTime decisionDate;

    @Column(name = "reason", length = 255)
    private String reason;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;
}
