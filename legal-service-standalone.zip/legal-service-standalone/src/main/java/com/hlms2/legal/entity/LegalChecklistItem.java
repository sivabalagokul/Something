package com.hlms2.legal.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * JPA entity for 'legal_checklist_item'.
 * Ported from hlms2.entity.LegalChecklistItem (plain JDBC version).
 */
@Entity
@Table(name = "legal_checklist_item")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LegalChecklistItem {

    @Id
    @Column(name = "checklist_item_id", length = 50)
    private String checklistItemId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "checklist_key", length = 100, nullable = false)
    private String checklistKey;

    @Column(name = "status", length = 30, nullable = false)
    private String status;
}
