package com.hlms2.legal.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'legal_verification'.
 * Ported from hlms2.entity.LegalVerification (plain JDBC version) -
 * appId is the primary key, matching the hlms2 schema
 * (app_id VARCHAR(50) PRIMARY KEY REFERENCES loan_application(app_id)).
 */
@Entity
@Table(name = "legal_verification")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LegalVerification {

    @Id
    @Column(name = "app_id", length = 50)
    private String appId;

    @Column(name = "decision", length = 30)
    private String decision;

    @Column(name = "decision_date")
    private OffsetDateTime decisionDate;

    @Column(name = "officer")
    private String officerEmail;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;
}
