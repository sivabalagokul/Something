package com.hlms2.legal.repository;

import com.hlms2.legal.entity.BankOfficeDecision;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BankOfficeDecisionRepository extends JpaRepository<BankOfficeDecision, String> {
}
