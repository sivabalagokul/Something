package com.hlms2.legal.repository;

import com.hlms2.legal.entity.LegalChecklistItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LegalChecklistItemRepository extends JpaRepository<LegalChecklistItem, String> {
}
