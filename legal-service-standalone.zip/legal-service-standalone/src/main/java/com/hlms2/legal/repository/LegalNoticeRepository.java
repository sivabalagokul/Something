package com.hlms2.legal.repository;

import com.hlms2.legal.entity.LegalNotice;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LegalNoticeRepository extends JpaRepository<LegalNotice, String> {
}
