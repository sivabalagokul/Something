package com.hlms2.legal.repository;

import com.hlms2.legal.entity.LegalVerification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LegalVerificationRepository extends JpaRepository<LegalVerification, String> {
}
