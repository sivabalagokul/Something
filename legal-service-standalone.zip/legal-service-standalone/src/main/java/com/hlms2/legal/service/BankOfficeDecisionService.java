package com.hlms2.legal.service;

import com.hlms2.legal.dto.BankOfficeDecisionDTO;

import java.util.List;

public interface BankOfficeDecisionService {
    BankOfficeDecisionDTO create(BankOfficeDecisionDTO dto);
    BankOfficeDecisionDTO update(BankOfficeDecisionDTO dto);
    boolean delete(String appId);
    BankOfficeDecisionDTO findById(String appId);
    List<BankOfficeDecisionDTO> findAll();
}
