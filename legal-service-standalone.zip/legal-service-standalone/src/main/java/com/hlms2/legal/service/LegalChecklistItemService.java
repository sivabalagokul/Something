package com.hlms2.legal.service;

import com.hlms2.legal.dto.LegalChecklistItemDTO;

import java.util.List;

public interface LegalChecklistItemService {
    LegalChecklistItemDTO create(LegalChecklistItemDTO dto);
    LegalChecklistItemDTO update(LegalChecklistItemDTO dto);
    boolean delete(String checklistItemId);
    LegalChecklistItemDTO findById(String checklistItemId);
    List<LegalChecklistItemDTO> findAll();
}
