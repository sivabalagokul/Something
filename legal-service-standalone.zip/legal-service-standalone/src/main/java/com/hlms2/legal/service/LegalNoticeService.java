package com.hlms2.legal.service;

import com.hlms2.legal.dto.LegalNoticeDTO;

import java.util.List;

public interface LegalNoticeService {
    LegalNoticeDTO create(LegalNoticeDTO dto);
    LegalNoticeDTO update(LegalNoticeDTO dto);
    boolean delete(String noticeId);
    LegalNoticeDTO findById(String noticeId);
    List<LegalNoticeDTO> findAll();
}
