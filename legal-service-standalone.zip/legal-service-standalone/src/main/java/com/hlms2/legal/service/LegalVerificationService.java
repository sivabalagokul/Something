package com.hlms2.legal.service;

import com.hlms2.legal.dto.LegalVerificationDTO;

import java.util.List;

public interface LegalVerificationService {
    LegalVerificationDTO create(LegalVerificationDTO dto);
    LegalVerificationDTO update(LegalVerificationDTO dto);
    boolean delete(String appId);
    LegalVerificationDTO findById(String appId);
    List<LegalVerificationDTO> findAll();
}
