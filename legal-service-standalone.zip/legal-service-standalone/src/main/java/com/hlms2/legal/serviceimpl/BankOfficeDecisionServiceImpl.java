package com.hlms2.legal.serviceimpl;

import com.hlms2.legal.dto.BankOfficeDecisionDTO;
import com.hlms2.legal.entity.BankOfficeDecision;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.exception.Validators;
import com.hlms2.legal.repository.AppUserRepository;
import com.hlms2.legal.repository.BankOfficeDecisionRepository;
import com.hlms2.legal.service.BankOfficeDecisionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Ported from hlms2.serviceimpl.BankOfficeDecisionServiceImpl (plain JDBC
 * version). Persistence now goes through Spring Data JPA
 * (BankOfficeDecisionRepository) instead of a hand-written DAO, but the
 * business rules are unchanged:
 *
 * (US-EL-05): rejected or conditionally-approved decisions must always
 * carry a reason, per the "Eligibility Explanation Engine" story.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class BankOfficeDecisionServiceImpl implements BankOfficeDecisionService {

    private static final List<String> VALID_DECISIONS = List.of("APPROVED", "CONDITIONALLY_APPROVED", "REJECTED");

    private final BankOfficeDecisionRepository repository;
    private final AppUserRepository appUserRepository;

    @Override
    public BankOfficeDecisionDTO create(BankOfficeDecisionDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        if (repository.existsById(dto.getAppId())) {
            throw new ValidationException("A bank office decision already exists for application " + dto.getAppId() + ".");
        }
        validate(dto);
        BankOfficeDecision entity = toEntity(dto);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        return toDto(repository.save(entity));
    }

    @Override
    public BankOfficeDecisionDTO update(BankOfficeDecisionDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        if (!repository.existsById(dto.getAppId())) {
            throw new ResourceNotFoundException("No bank office decision found for application " + dto.getAppId() + ".");
        }
        validate(dto);
        BankOfficeDecision entity = toEntity(dto);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        return toDto(repository.save(entity));
    }

    @Override
    public boolean delete(String appId) {
        Validators.required(appId, "appId");
        if (!repository.existsById(appId)) {
            return false;
        }
        repository.deleteById(appId);
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public BankOfficeDecisionDTO findById(String appId) {
        Validators.required(appId, "appId");
        return repository.findById(appId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BankOfficeDecisionDTO> findAll() {
        return repository.findAll().stream().map(this::toDto).toList();
    }

    private void validate(BankOfficeDecisionDTO dto) {
        Validators.oneOf(dto.getDecision(), "decision", VALID_DECISIONS.toArray(new String[0]));
        Validators.required(dto.getOfficerEmail(), "officerEmail");
        if (appUserRepository.findByEmailAndActiveTrue(dto.getOfficerEmail()).isEmpty()) {
            throw new ValidationException("officerEmail " + dto.getOfficerEmail() + " is not a known active app_user.");
        }
        // US-EL-05: rejection or conditional approval must always be explained to the customer.
        if (!"APPROVED".equalsIgnoreCase(dto.getDecision())) {
            Validators.required(dto.getReason(), "reason");
        }
    }

    private BankOfficeDecision toEntity(BankOfficeDecisionDTO dto) {
        return BankOfficeDecision.builder()
                .appId(dto.getAppId())
                .decision(dto.getDecision())
                .officerEmail(dto.getOfficerEmail())
                .decisionDate(dto.getDecisionDate())
                .reason(dto.getReason())
                .remarks(dto.getRemarks())
                .build();
    }

    private BankOfficeDecisionDTO toDto(BankOfficeDecision entity) {
        return BankOfficeDecisionDTO.builder()
                .appId(entity.getAppId())
                .decision(entity.getDecision())
                .officerEmail(entity.getOfficerEmail())
                .decisionDate(entity.getDecisionDate())
                .reason(entity.getReason())
                .remarks(entity.getRemarks())
                .build();
    }
}
