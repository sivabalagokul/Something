package com.hlms2.legal.serviceimpl;

import com.hlms2.legal.dto.LegalChecklistItemDTO;
import com.hlms2.legal.entity.LegalChecklistItem;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.Validators;
import com.hlms2.legal.repository.LegalChecklistItemRepository;
import com.hlms2.legal.service.LegalChecklistItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/**
 * Ported from hlms2.serviceimpl.LegalChecklistItemServiceImpl (plain JDBC
 * version). Persistence now goes through Spring Data JPA
 * (LegalChecklistItemRepository) instead of a hand-written DAO, but the
 * business rules are unchanged:
 *
 * (US-MRC-05): validates checklist key/status and defaults a newly created
 * item to PENDING.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class LegalChecklistItemServiceImpl implements LegalChecklistItemService {

    private static final List<String> VALID_STATUSES = List.of("PENDING", "COMPLETED", "NOT_APPLICABLE");

    private final LegalChecklistItemRepository repository;

    @Override
    public LegalChecklistItemDTO create(LegalChecklistItemDTO dto) {
        validate(dto);
        LegalChecklistItem entity = toEntity(dto);
        if (entity.getChecklistItemId() == null || entity.getChecklistItemId().isBlank()) {
            entity.setChecklistItemId("CHK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setStatus(entity.getStatus() == null ? "PENDING" : entity.getStatus());
        return toDto(repository.save(entity));
    }

    @Override
    public LegalChecklistItemDTO update(LegalChecklistItemDTO dto) {
        Validators.required(dto.getChecklistItemId(), "checklistItemId");
        if (!repository.existsById(dto.getChecklistItemId())) {
            throw new ResourceNotFoundException("Checklist item " + dto.getChecklistItemId() + " does not exist.");
        }
        validate(dto);
        LegalChecklistItem entity = toEntity(dto);
        return toDto(repository.save(entity));
    }

    @Override
    public boolean delete(String checklistItemId) {
        Validators.required(checklistItemId, "checklistItemId");
        if (!repository.existsById(checklistItemId)) {
            return false;
        }
        repository.deleteById(checklistItemId);
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public LegalChecklistItemDTO findById(String checklistItemId) {
        Validators.required(checklistItemId, "checklistItemId");
        return repository.findById(checklistItemId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<LegalChecklistItemDTO> findAll() {
        return repository.findAll().stream().map(this::toDto).toList();
    }

    private void validate(LegalChecklistItemDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        Validators.required(dto.getChecklistKey(), "checklistKey");
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
    }

    private LegalChecklistItem toEntity(LegalChecklistItemDTO dto) {
        return LegalChecklistItem.builder()
                .checklistItemId(dto.getChecklistItemId())
                .appId(dto.getAppId())
                .checklistKey(dto.getChecklistKey())
                .status(dto.getStatus())
                .build();
    }

    private LegalChecklistItemDTO toDto(LegalChecklistItem entity) {
        return LegalChecklistItemDTO.builder()
                .checklistItemId(entity.getChecklistItemId())
                .appId(entity.getAppId())
                .checklistKey(entity.getChecklistKey())
                .status(entity.getStatus())
                .build();
    }
}
