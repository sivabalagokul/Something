package com.hlms2.legal.serviceimpl;

import com.hlms2.legal.dto.LegalNoticeDTO;
import com.hlms2.legal.entity.LegalNotice;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.exception.Validators;
import com.hlms2.legal.repository.AppUserRepository;
import com.hlms2.legal.repository.LegalNoticeRepository;
import com.hlms2.legal.service.LegalNoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/**
 * Ported from hlms2.serviceimpl.LegalNoticeServiceImpl (plain JDBC version).
 * Persistence now goes through Spring Data JPA (LegalNoticeRepository)
 * instead of a hand-written DAO, but the business rules are unchanged:
 *
 * (US-DMNG-02, US-DMNG-03): auto-generates a unique notice number, validates
 * the notice window (dueDate must be on/after issueDate) and restricts
 * status to the Draft/Sent/Delivered/Failed lifecycle the backlog calls for.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class LegalNoticeServiceImpl implements LegalNoticeService {

    private static final List<String> VALID_TYPES = List.of("DEFAULT_NOTICE", "DEMAND_NOTICE", "AUCTION_NOTICE", "LEGAL_NOTICE");
    private static final List<String> VALID_STATUSES = List.of("DRAFT", "SENT", "DELIVERED", "FAILED");

    private final LegalNoticeRepository repository;
    private final AppUserRepository appUserRepository;

    @Override
    public LegalNoticeDTO create(LegalNoticeDTO dto) {
        validate(dto);
        LegalNotice entity = toEntity(dto);
        if (entity.getNoticeId() == null || entity.getNoticeId().isBlank()) {
            entity.setNoticeId("NOT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        // US-DMNG-02: unique, trackable notice number generated automatically.
        entity.setNoticeNo("NOTICE-" + entity.getIssueDate() + "-" + entity.getNoticeId().substring(entity.getNoticeId().length() - 4));
        entity.setStatus(entity.getStatus() == null ? "DRAFT" : entity.getStatus());
        return toDto(repository.save(entity));
    }

    @Override
    public LegalNoticeDTO update(LegalNoticeDTO dto) {
        Validators.required(dto.getNoticeId(), "noticeId");
        LegalNotice existing = repository.findById(dto.getNoticeId())
                .orElseThrow(() -> new ResourceNotFoundException("Notice " + dto.getNoticeId() + " does not exist."));
        validate(dto);
        LegalNotice entity = toEntity(dto);
        entity.setNoticeNo(dto.getNoticeNo() != null ? dto.getNoticeNo() : existing.getNoticeNo());
        return toDto(repository.save(entity));
    }

    @Override
    public boolean delete(String noticeId) {
        Validators.required(noticeId, "noticeId");
        if (!repository.existsById(noticeId)) {
            return false;
        }
        repository.deleteById(noticeId);
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public LegalNoticeDTO findById(String noticeId) {
        Validators.required(noticeId, "noticeId");
        return repository.findById(noticeId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<LegalNoticeDTO> findAll() {
        return repository.findAll().stream().map(this::toDto).toList();
    }

    private void validate(LegalNoticeDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        Validators.oneOf(dto.getNoticeType(), "noticeType", VALID_TYPES.toArray(new String[0]));
        Validators.required(dto.getIssueDate(), "issueDate");
        Validators.afterOrEqual(dto.getDueDate(), dto.getIssueDate(), "dueDate", "issueDate");
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
        Validators.required(dto.getOfficerEmail(), "officerEmail");
        if (appUserRepository.findByEmailAndActiveTrue(dto.getOfficerEmail()).isEmpty()) {
            throw new ValidationException("officerEmail " + dto.getOfficerEmail() + " is not a known active app_user.");
        }
        Validators.required(dto.getContent(), "content");
    }

    private LegalNotice toEntity(LegalNoticeDTO dto) {
        return LegalNotice.builder()
                .noticeId(dto.getNoticeId())
                .noticeNo(dto.getNoticeNo())
                .appId(dto.getAppId())
                .noticeType(dto.getNoticeType())
                .issueDate(dto.getIssueDate())
                .dueDate(dto.getDueDate())
                .status(dto.getStatus())
                .officerEmail(dto.getOfficerEmail())
                .content(dto.getContent())
                .build();
    }

    private LegalNoticeDTO toDto(LegalNotice entity) {
        return LegalNoticeDTO.builder()
                .noticeId(entity.getNoticeId())
                .noticeNo(entity.getNoticeNo())
                .appId(entity.getAppId())
                .noticeType(entity.getNoticeType())
                .issueDate(entity.getIssueDate())
                .dueDate(entity.getDueDate())
                .status(entity.getStatus())
                .officerEmail(entity.getOfficerEmail())
                .content(entity.getContent())
                .build();
    }
}
