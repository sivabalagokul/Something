package com.hlms2.legal.serviceimpl;

import com.hlms2.legal.dto.LegalVerificationDTO;
import com.hlms2.legal.entity.LegalVerification;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.exception.Validators;
import com.hlms2.legal.repository.AppUserRepository;
import com.hlms2.legal.repository.LegalVerificationRepository;
import com.hlms2.legal.service.LegalVerificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Ported from hlms2.serviceimpl.LegalVerificationServiceImpl (plain JDBC
 * version). Persistence now goes through Spring Data JPA
 * (LegalVerificationRepository) instead of a hand-written DAO, but the
 * business rules are unchanged:
 *
 * (US-MRC-02, US-LT-03): a rejection must carry a reason so the customer
 * knows why, and the officer who made the call is mandatory for audit
 * purposes.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class LegalVerificationServiceImpl implements LegalVerificationService {

    private static final List<String> VALID_DECISIONS = List.of("PENDING", "APPROVED", "REJECTED");

    private final LegalVerificationRepository repository;
    private final AppUserRepository appUserRepository;

    @Override
    public LegalVerificationDTO create(LegalVerificationDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        if (repository.existsById(dto.getAppId())) {
            throw new ValidationException("A legal verification record already exists for application " + dto.getAppId() + ".");
        }
        validate(dto);
        LegalVerification entity = toEntity(dto);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        return toDto(repository.save(entity));
    }

    @Override
    public LegalVerificationDTO update(LegalVerificationDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        if (!repository.existsById(dto.getAppId())) {
            throw new ResourceNotFoundException("No legal verification found for application " + dto.getAppId() + ".");
        }
        validate(dto);
        LegalVerification entity = toEntity(dto);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        return toDto(repository.save(entity));
    }

    @Override
    public boolean delete(String appId) {
        Validators.required(appId, "appId");
        if (!repository.existsById(appId)) {
            return false;
        }
        repository.deleteById(appId);
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public LegalVerificationDTO findById(String appId) {
        Validators.required(appId, "appId");
        return repository.findById(appId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<LegalVerificationDTO> findAll() {
        return repository.findAll().stream().map(this::toDto).toList();
    }

    private void validate(LegalVerificationDTO dto) {
        Validators.oneOf(dto.getDecision(), "decision", VALID_DECISIONS.toArray(new String[0]));
        Validators.required(dto.getOfficerEmail(), "officerEmail");
        if (appUserRepository.findByEmailAndActiveTrue(dto.getOfficerEmail()).isEmpty()) {
            throw new ValidationException("officerEmail " + dto.getOfficerEmail() + " is not a known active app_user.");
        }
        if ("REJECTED".equalsIgnoreCase(dto.getDecision())) {
            Validators.required(dto.getRemarks(), "remarks");
        }
    }

    private LegalVerification toEntity(LegalVerificationDTO dto) {
        return LegalVerification.builder()
                .appId(dto.getAppId())
                .decision(dto.getDecision())
                .decisionDate(dto.getDecisionDate())
                .officerEmail(dto.getOfficerEmail())
                .remarks(dto.getRemarks())
                .build();
    }

    private LegalVerificationDTO toDto(LegalVerification entity) {
        return LegalVerificationDTO.builder()
                .appId(entity.getAppId())
                .decision(entity.getDecision())
                .decisionDate(entity.getDecisionDate())
                .officerEmail(entity.getOfficerEmail())
                .remarks(entity.getRemarks())
                .build();
    }
}
