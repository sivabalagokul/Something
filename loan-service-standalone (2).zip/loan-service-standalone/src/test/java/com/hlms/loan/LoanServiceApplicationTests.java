package com.hlms.loan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanServiceApplicationTests {

    @Test
    void contextLoads() {
        // Verifies the Spring application context starts successfully.
    }
}
