# repayment-service — Spring Boot port of hlms2's repayment domain

Same treatment as `legal-service-springboot`: a standalone Spring Boot
module built from the plain-Java/JDBC `hlms2` codebase, covering the 7
tables your existing `hlms-microservices/repayment-service` module owns:

- `emi_installment`
- `auction_case`
- `auction_note`
- `bid`
- `disbursement`
- `insurance_policy`
- `audit_log`

Runs on **port 8085**, matching the gateway routes
(`/api/emi/**`, `/api/default-management/**`, `/api/auctions/**`).

## What changed vs. the plain-Java version

Same pattern as legal-service: `hlms.entity.*` → JPA `@Entity`,
`hlms.dao(impl).*` → Spring Data `JpaRepository`,
`hlms.service(impl).*` → `@Service` beans, `hlms.util.ValidationException`
→ unchecked + `@RestControllerAdvice`. **Business logic is untouched** —
every validation rule, escalation-tier calculation, and ID-generation
scheme is copied over exactly. Full detail on each rule is in the Javadoc
on each `*ServiceImpl` class.

## Updated for hlms_schema_updated_v2.sql / combined v3 schema

Same three changes as legal-service, applied here from the start:

1. **Surrogate PKs.** `auction_case` and `disbursement` now have a real
   `BIGSERIAL` PK (`auction_id`, `disbursement_id`) instead of using
   `app_id` as the PK. `app_id` is a unique column on both, so
   `findByAppId(...)` / `GET .../by-application/{appId}` is how you look
   things up the old way; `update()` takes the surrogate id.
   `emi_installment`, `auction_note`, `bid`, `insurance_policy` keep
   their original natural-key PKs (`installment_id`, `note_id`, `bid_id`,
   `policy_id`) unchanged.
2. **Soft delete everywhere except `audit_log`.** Every other entity has
   `deletedAt`; `delete()` was renamed to `softDelete()` (sets
   `deleted_at = now()`), reads filter it out, and a matching `restore()`
   + `POST .../{id}/restore` endpoint undoes it. `audit_log` has **no**
   `deleted_at` column in the schema on purpose (append-only audit trail)
   - `AuditLogServiceImpl.delete()` is a genuine hard delete, same as the
     plain-Java version.
3. **Cascading soft delete on auctions.** The schema's
   `trg_cascade_soft_delete_auction_case` trigger automatically
   soft-deletes an auction case's `auction_note` and `bid` rows the
   moment `auction_case.deleted_at` is set - including when this
   service's `softDelete()` does it via JPA, since it's a normal SQL
   `UPDATE` under the hood. No extra code was needed for that cascade to
   work correctly.

## AppUser / LoanApplication (read-only references)

Neither table is owned by this service, but both are foreign-keyed from
tables this service does own:

- **AppUser** — `bid.bidder_email` and `audit_log.actor_email` both
  reference `app_user(email)`. `BidServiceImpl` and `AuditLogServiceImpl`
  now check the email against a real, active `app_user` row before
  accepting a bid or log entry - the original `hlms2` code only checked
  the field was non-blank. Same reasoning as legal-service's officer
  validation.
- **LoanApplication** — every one of this service's 7 tables has an
  `app_id` FK into it. Mapped read-mostly (trimmed to the columns this
  service actually needs), matching how your existing
  `hlms-microservices/repayment-service` module already includes it (used
  by its `DefaultManagementService`/`ReminderSchedulerService`). No
  create/update/delete for it here - `user-service`/`loan-service` own
  that table.

## Worth flagging (business-rule / seed-data mismatches, not silently fixed)

- `emi_installment.status` defaults to `'Due'` in the schema, but the
  original `hlms2` validation only allows `PENDING/PAID/OVERDUE`. Kept
  as-is (matching the original code) rather than guessing your intended
  full vocabulary - widen `VALID_STATUSES` in `EmiInstallmentServiceImpl`
  if `'Due'` (and any other seed values) should be valid.
- `emi_installment` has a `UNIQUE (app_id, installment_no)` constraint
  that the original code never checked before inserting. Rather than add
  new duplicate-checking logic that wasn't in the source, a
  `DataIntegrityViolationException` handler in `GlobalExceptionHandler`
  turns a duplicate insert into a clean 409 instead of a raw DB stack
  trace.

## How to run in Eclipse

1. **File → Import → Maven → Existing Maven Projects**, point at this
   `repayment-service/` folder.
2. Update `src/main/resources/application.properties` with your actual
   Postgres credentials.
3. Make sure the combined schema (`schema/hlms_schema_combined_v3.sql`)
   has already been run against your database - `ddl-auto=validate` won't
   create tables for you.
4. Right-click `Hlms2RepaymentServiceApplication.java` → **Run As → Java
   Application**.
5. Test via `http://localhost:8085/api/emi/installments`,
   `/api/auctions`, `/api/default-management/overdue`,
   `/api/disbursements`, `/api/insurance-policies`, `/api/audit-log`,
   `/api/auction-notes`, `/api/bids`.

Standalone module (no Eureka/Config Server dependency) - runs on its own
on port 8085, same as `legal-service-springboot`.
