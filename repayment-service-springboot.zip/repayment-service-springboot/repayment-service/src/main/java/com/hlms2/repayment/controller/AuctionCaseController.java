package com.hlms2.repayment.controller;

import com.hlms2.repayment.dto.AuctionCaseDTO;
import com.hlms2.repayment.dto.AuctionNoteDTO;
import com.hlms2.repayment.dto.BidDTO;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.service.AuctionCaseService;
import com.hlms2.repayment.service.AuctionNoteService;
import com.hlms2.repayment.service.BidService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auctions")
@RequiredArgsConstructor
public class AuctionCaseController {

    private final AuctionCaseService service;
    private final AuctionNoteService noteService;
    private final BidService bidService;

    @PostMapping
    public ResponseEntity<AuctionCaseDTO> create(@RequestBody AuctionCaseDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{auctionId}")
    public AuctionCaseDTO update(@PathVariable Long auctionId, @RequestBody AuctionCaseDTO dto) {
        return service.update(auctionId, dto);
    }

    @DeleteMapping("/{auctionId}")
    public ResponseEntity<Void> softDelete(@PathVariable Long auctionId) {
        return service.softDelete(auctionId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/{auctionId}/restore")
    public ResponseEntity<Void> restore(@PathVariable Long auctionId) {
        return service.restore(auctionId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{auctionId}")
    public AuctionCaseDTO findById(@PathVariable Long auctionId) {
        AuctionCaseDTO dto = service.findById(auctionId);
        if (dto == null) {
            throw new ResourceNotFoundException("No auction case found with id " + auctionId + ".");
        }
        return dto;
    }

    @GetMapping("/by-application/{appId}")
    public AuctionCaseDTO findByAppId(@PathVariable String appId) {
        AuctionCaseDTO dto = service.findByAppId(appId);
        if (dto == null) {
            throw new ResourceNotFoundException("No auction case found for application " + appId + ".");
        }
        return dto;
    }

    @GetMapping
    public List<AuctionCaseDTO> findAll() {
        return service.findAll();
    }

    // --- notes, nested under the application id (matches auction_note.app_id) ---

    @PostMapping("/{appId}/notes")
    public ResponseEntity<AuctionNoteDTO> addNote(@PathVariable String appId, @RequestBody AuctionNoteDTO dto) {
        dto.setAppId(appId);
        return ResponseEntity.status(HttpStatus.CREATED).body(noteService.create(dto));
    }

    @GetMapping("/{appId}/notes")
    public List<AuctionNoteDTO> getNotes(@PathVariable String appId) {
        return noteService.getAuctionRecord(appId);
    }

    // --- bids, nested under the application id (matches bid.app_id) ---

    @PostMapping("/{appId}/bids")
    public ResponseEntity<BidDTO> placeBid(@PathVariable String appId, @RequestBody BidDTO dto) {
        dto.setAppId(appId);
        return ResponseEntity.status(HttpStatus.CREATED).body(bidService.create(dto));
    }

    @GetMapping("/{appId}/bids")
    public List<BidDTO> getBids(@PathVariable String appId) {
        return bidService.findAll().stream().filter(b -> appId.equals(b.getAppId())).toList();
    }
}
