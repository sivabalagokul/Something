package com.hlms2.repayment.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuctionCaseDTO {
    private Long auctionId;
    private String appId;
    private String stage;
    private LocalDate noticeDate;
    private LocalDate noticeDueDate;
    private BigDecimal demandAmount;
    private LocalDate possessionDate;
    private LocalDate auctionDate;
    private BigDecimal reservePrice;
}
