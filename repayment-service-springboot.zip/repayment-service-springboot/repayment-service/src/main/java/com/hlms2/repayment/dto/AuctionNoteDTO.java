package com.hlms2.repayment.dto;

import lombok.*;

import java.time.OffsetDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuctionNoteDTO {
    private String noteId;
    private String appId;
    private OffsetDateTime noteDate;
    private String noteText;
}
