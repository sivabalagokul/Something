package com.hlms2.repayment.dto;

import lombok.*;

import java.time.OffsetDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditLogDTO {
    private Long logId;
    private String entityType;
    private String entityId;
    private String action;
    private String actorEmail;
    private String beforeData;
    private String afterData;
    private OffsetDateTime createdAt;
}
