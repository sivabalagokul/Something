package com.hlms2.repayment.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BidDTO {
    private String bidId;
    private String appId;
    private String bidderEmail;
    private BigDecimal bidAmount;
    private OffsetDateTime createdAt;
}
