package com.hlms2.repayment.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class DisbursementDTO {
    private Long disbursementId;
    private String appId;
    private OffsetDateTime disbursedDate;
    private BigDecimal amount;
    private String refNo;
    private String mode;
    private String bankDetails;
}
