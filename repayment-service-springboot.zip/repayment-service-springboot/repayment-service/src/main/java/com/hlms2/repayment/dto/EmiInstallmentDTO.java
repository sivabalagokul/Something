package com.hlms2.repayment.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class EmiInstallmentDTO {
    private String installmentId;
    private String appId;
    private Integer installmentNo;
    private LocalDate dueDate;
    private BigDecimal emiAmount;
    private BigDecimal principalComponent;
    private BigDecimal interestComponent;
    private BigDecimal closingBalance;
    private String status;
    private LocalDate paidDate;
}
