package com.hlms2.repayment.dto;

import lombok.*;

import java.time.LocalDate;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class InsurancePolicyDTO {
    private String policyId;
    private String appId;
    private String policyType;
    private String status;
    private LocalDate validTill;
}
