package com.hlms2.repayment.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'app_user'. Ported from hlms2.entity.AppUser.
 *
 * This service doesn't own app_user (that's user-service's table) - mapped
 * here read-mostly, since bid.bidder_email and audit_log.actor_email are
 * both foreign keys into it. Used to confirm those emails are real, active
 * users before a bid/log entry is recorded against them.
 */
@Entity
@Table(name = "app_user")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AppUser {

    @Id
    @Column(name = "email", length = 255)
    private String email;

    @Column(name = "name", length = 150, nullable = false)
    private String name;

    @Column(name = "mobile", length = 20, nullable = false)
    private String mobile;

    @JsonIgnore
    @Column(name = "password_hash", length = 255, nullable = false)
    private String passwordHash;

    @Column(name = "role", length = 30, nullable = false)
    private String role;

    @Column(name = "active", nullable = false)
    private Boolean active;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
