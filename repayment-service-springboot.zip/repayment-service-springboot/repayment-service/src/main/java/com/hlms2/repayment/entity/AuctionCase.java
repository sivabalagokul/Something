package com.hlms2.repayment.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * JPA entity for 'auction_case'.
 *
 * CHG(v2): switched from app_id-as-PK to a surrogate auction_id
 * (BIGSERIAL); app_id is now a unique FK column instead of the primary
 * key. Adds the deleted_at soft delete marker - and note the schema's
 * trg_cascade_soft_delete_auction_case trigger: soft-deleting a case
 * here also soft-deletes its auction_note and bid rows automatically,
 * at the DB level.
 */
@Entity
@Table(name = "auction_case")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuctionCase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "auction_id")
    private Long auctionId;

    @Column(name = "app_id", length = 50, nullable = false, unique = true)
    private String appId;

    @Column(name = "stage", length = 30)
    private String stage;

    @Column(name = "notice_date")
    private LocalDate noticeDate;

    @Column(name = "notice_due_date")
    private LocalDate noticeDueDate;

    @Column(name = "demand_amount")
    private BigDecimal demandAmount;

    @Column(name = "possession_date")
    private LocalDate possessionDate;

    @Column(name = "auction_date")
    private LocalDate auctionDate;

    @Column(name = "reserve_price")
    private BigDecimal reservePrice;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
