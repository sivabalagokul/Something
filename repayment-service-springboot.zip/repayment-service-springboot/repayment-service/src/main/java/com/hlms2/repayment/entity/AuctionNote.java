package com.hlms2.repayment.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'auction_note'. Ported from hlms2.entity.AuctionNote -
 * the FK to the auction case is via app_id (the schema's
 * auction_note.app_id references auction_case.app_id, its unique column,
 * not the surrogate auction_id), so this stays a flat appId string exactly
 * as it was pre-v2. Adds the deleted_at soft delete marker.
 */
@Entity
@Table(name = "auction_note")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuctionNote {

    @Id
    @Column(name = "note_id", length = 50)
    private String noteId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "note_date")
    private OffsetDateTime noteDate;

    @Column(name = "note_text", columnDefinition = "TEXT", nullable = false)
    private String noteText;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
