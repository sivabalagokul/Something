package com.hlms2.repayment.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'audit_log'. Ported from hlms2.entity.AuditLog.
 * No deleted_at column in the schema - this table is deliberately
 * append-only/immutable and was NOT given a soft-delete column in v2,
 * unlike every other table in this service.
 */
@Entity
@Table(name = "audit_log")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "log_id")
    private Long logId;

    @Column(name = "entity_type", length = 50, nullable = false)
    private String entityType;

    @Column(name = "entity_id", length = 50, nullable = false)
    private String entityId;

    @Column(name = "action", length = 30, nullable = false)
    private String action;

    @Column(name = "actor_email")
    private String actorEmail;

    // before_data/after_data are jsonb columns - stored/returned here as raw
    // JSON text (String), matching what hlms2's plain-JDBC version already
    // did (it just passed strings straight through too).
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "before_data", columnDefinition = "jsonb")
    private String beforeData;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "after_data", columnDefinition = "jsonb")
    private String afterData;

    @Column(name = "created_at")
    private OffsetDateTime createdAt;
}
