package com.hlms2.repayment.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * JPA entity for 'bid'. Ported from hlms2.entity.Bid - FK to the auction
 * case is via app_id (same reasoning as AuctionNote). Adds the deleted_at
 * soft delete marker.
 */
@Entity
@Table(name = "bid")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Bid {

    @Id
    @Column(name = "bid_id", length = 50)
    private String bidId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "bidder_email", nullable = false)
    private String bidderEmail;

    @Column(name = "bid_amount", nullable = false)
    private BigDecimal bidAmount;

    @Column(name = "created_at")
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
