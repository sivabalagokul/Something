package com.hlms2.repayment.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * JPA entity for 'disbursement'.
 *
 * CHG(v2): switched from app_id-as-PK to a surrogate disbursement_id
 * (BIGSERIAL); app_id is now a unique FK column. Adds the deleted_at
 * soft delete marker.
 */
@Entity
@Table(name = "disbursement")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Disbursement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "disbursement_id")
    private Long disbursementId;

    @Column(name = "app_id", length = 50, nullable = false, unique = true)
    private String appId;

    @Column(name = "disbursed_date")
    private OffsetDateTime disbursedDate;

    @Column(name = "amount")
    private BigDecimal amount;

    @Column(name = "ref_no", length = 50)
    private String refNo;

    @Column(name = "mode", length = 30)
    private String mode;

    @Column(name = "bank_details", length = 150)
    private String bankDetails;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
