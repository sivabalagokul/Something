package com.hlms2.repayment.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * JPA entity for 'emi_installment'. Ported from hlms2.entity.EmiInstallment.
 * PK (installment_id) unchanged from the plain-Java version. Adds the
 * deleted_at soft delete marker from hlms_schema_updated_v2.sql. The
 * UNIQUE (app_id, installment_no) constraint isn't checked in code -
 * a duplicate insert surfaces as a 409 via GlobalExceptionHandler.
 */
@Entity
@Table(name = "emi_installment")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class EmiInstallment {

    @Id
    @Column(name = "installment_id", length = 50)
    private String installmentId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "installment_no", nullable = false)
    private Integer installmentNo;

    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;

    @Column(name = "emi_amount", nullable = false)
    private BigDecimal emiAmount;

    @Column(name = "principal_component")
    private BigDecimal principalComponent;

    @Column(name = "interest_component")
    private BigDecimal interestComponent;

    @Column(name = "closing_balance")
    private BigDecimal closingBalance;

    @Column(name = "status", length = 30, nullable = false)
    private String status;

    @Column(name = "paid_date")
    private LocalDate paidDate;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
