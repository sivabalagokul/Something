package com.hlms2.repayment.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * JPA entity for 'insurance_policy'. Ported from hlms2.entity.InsurancePolicy.
 * PK (policy_id) unchanged. Adds the deleted_at soft delete marker.
 */
@Entity
@Table(name = "insurance_policy")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class InsurancePolicy {

    @Id
    @Column(name = "policy_id", length = 50)
    private String policyId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "policy_type", length = 50)
    private String policyType;

    @Column(name = "status", length = 30, nullable = false)
    private String status;

    @Column(name = "valid_till")
    private LocalDate validTill;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
