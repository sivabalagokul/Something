package com.hlms2.repayment.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * JPA entity for 'loan_application'. Ported from hlms2.entity.LoanApplication,
 * trimmed to the columns this service actually reads (it doesn't own this
 * table - that's loan-service's - so this is a read-mostly reference,
 * same treatment as AppUser). Every table this service does own
 * (emi_installment, auction_case, disbursement, insurance_policy) has an
 * app_id foreign key into this one.
 */
@Entity
@Table(name = "loan_application")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LoanApplication {

    @Id
    @Column(name = "app_id", length = 50)
    private String appId;

    @Column(name = "tracking_no", length = 50)
    private String trackingNo;

    @Column(name = "user_email")
    private String userEmail;

    @Column(name = "product_id")
    private String productId;

    @Column(name = "loan_amount")
    private BigDecimal loanAmount;

    @Column(name = "tenure_years")
    private Integer tenureYears;

    @Column(name = "status", length = 30)
    private String status;

    @Column(name = "stage_index")
    private Integer stageIndex;

    @Column(name = "created_at")
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
