package com.hlms2.repayment.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.OffsetDateTime;

@Getter
@AllArgsConstructor
public class ApiError {
    private final int status;
    private final String message;
    private final OffsetDateTime timestamp;

    public ApiError(int status, String message) {
        this(status, message, OffsetDateTime.now());
    }
}
