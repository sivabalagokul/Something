package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.InsurancePolicyDTO;
import com.hlms2.repayment.entity.InsurancePolicy;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.exception.Validators;
import com.hlms2.repayment.repository.InsurancePolicyRepository;
import com.hlms2.repayment.service.InsurancePolicyService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Ported from hlms2.serviceimpl.InsurancePolicyServiceImpl (plain JDBC
 * version), then updated for hlms_schema_updated_v2.sql: delete is now a
 * soft delete (sets deleted_at), with a matching restore(). PK unchanged
 * (policy_id remains the natural key).
 *
 * Business logic unchanged: validates policy type/status and keeps
 * validTill honest (a policy created as Active cannot already be
 * expired).
 */
@Service
@RequiredArgsConstructor
@Transactional
public class InsurancePolicyServiceImpl implements InsurancePolicyService {

    // Must match the policy_type CHECK constraint in the schema.
    private static final List<String> VALID_TYPES = List.of("property", "life");
    // status has no DB CHECK constraint, but the app's actual casing convention is 'Active'/'Expired'/'Cancelled'.
    private static final List<String> VALID_STATUSES = List.of("Active", "Expired", "Cancelled");

    private final InsurancePolicyRepository repository;

    @Override
    public InsurancePolicyDTO create(InsurancePolicyDTO dto) {
        validate(dto);
        InsurancePolicy entity = toEntity(dto);
        if (entity.getPolicyId() == null || entity.getPolicyId().isBlank()) {
            entity.setPolicyId("POL-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setStatus(entity.getStatus() == null ? "Active" : entity.getStatus());
        return toDto(repository.save(entity));
    }

    @Override
    public InsurancePolicyDTO update(InsurancePolicyDTO dto) {
        Validators.required(dto.getPolicyId(), "policyId");
        repository.findByPolicyIdAndDeletedAtIsNull(dto.getPolicyId())
                .orElseThrow(() -> new ResourceNotFoundException("Insurance policy " + dto.getPolicyId() + " does not exist."));
        validate(dto);
        InsurancePolicy entity = toEntity(dto);
        return toDto(repository.save(entity));
    }

    @Override
    public boolean softDelete(String policyId) {
        return repository.findByPolicyIdAndDeletedAtIsNull(policyId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(String policyId) {
        return repository.findById(policyId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public InsurancePolicyDTO findById(String policyId) {
        Validators.required(policyId, "policyId");
        return repository.findByPolicyIdAndDeletedAtIsNull(policyId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<InsurancePolicyDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    private void validate(InsurancePolicyDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        Validators.oneOf(dto.getPolicyType(), "policyType", VALID_TYPES.toArray(new String[0]));
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
        if ("ACTIVE".equalsIgnoreCase(dto.getStatus()) && dto.getValidTill() != null
                && dto.getValidTill().isBefore(LocalDate.now())) {
            throw new ValidationException("An Active policy cannot have a validTill date in the past.");
        }
    }

    private InsurancePolicy toEntity(InsurancePolicyDTO dto) {
        return InsurancePolicy.builder()
                .policyId(dto.getPolicyId())
                .appId(dto.getAppId())
                .policyType(dto.getPolicyType())
                .status(dto.getStatus())
                .validTill(dto.getValidTill())
                .build();
    }

    private InsurancePolicyDTO toDto(InsurancePolicy entity) {
        return InsurancePolicyDTO.builder()
                .policyId(entity.getPolicyId())
                .appId(entity.getAppId())
                .policyType(entity.getPolicyType())
                .status(entity.getStatus())
                .validTill(entity.getValidTill())
                .build();
    }
}
